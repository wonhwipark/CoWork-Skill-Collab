import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TOOL = ROOT / "scripts" / "msc_tool.py"

def spec():
    return {"schema":"doc-converter/msc-spec/v1","kind":"AS_IS","title":"Synthetic",
            "participants":[{"id":"L1","label":"L1"},{"id":"RF","label":"RF"}],
            "steps":[{"type":"divider","label":"INIT"},
                     {"type":"message","id":"S1","from":"L1","to":"RF",
                      "label":"INIT_REQ","evidence_status":"CODE_CONFIRMED"}]}

def run(names,mode="PROCEDURE_FEATURE"):
    with tempfile.TemporaryDirectory() as td:
        d=Path(td)
        src=d/"package.json"
        src.write_text(json.dumps({"schema":"doc-converter/msc-package/v1","issue_id":"SYNTHETIC",
                                   "view_mode":mode,"diagrams":[{"name":n,"spec":spec()} for n in names]}),encoding="utf-8")
        p=subprocess.run([sys.executable,str(TOOL),"package","--input",str(src),
                          "--output-dir",str(d/"out"),"--allow-unrendered","--json"],
                         text=True,capture_output=True)
        return p,json.loads(p.stdout),(d/"out"/"MSC_VIEW.md").read_text(encoding="utf-8")

def test_korean_names_do_not_collide():
    result,body,md=run(["초기화","종료"])
    assert result.returncode==0,(result.stdout,result.stderr)
    names=[row["name"] for row in body["diagrams"]]
    assert len(set(names))==2
    assert all(x.startswith("diagram_") for x in names)
    assert "핵심 변경" not in md
    assert "MSC_DELTA.md" not in md

def test_identical_name_blocks():
    result,body,_=run(["same","same"])
    assert result.returncode!=0
    assert any(x["code"]=="DIAGRAM_NAME_DUPLICATE" for x in body["package_errors"])

def test_issue_mode_retained():
    result,body,md=run(["01_AS_IS"],mode="ISSUE")
    assert result.returncode==0
    assert "핵심 변경" in md
