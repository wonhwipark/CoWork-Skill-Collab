# Development candidate 0.2.22 — 2026-11-16 KST

Public v0.2.21 exact ZIP baseline; deterministic Korean name hash suffix; duplicate normalized names fail closed; Procedure/Feature AS-IS view language and optional MSC_DELTA link guarded. Original ISSUE rendering unchanged. Python regression/host E2E/independent review NOT_RUN; development_not_for_deployment. B HTML viewer and published_path integration remain unimplemented and are separate next-stage work.
