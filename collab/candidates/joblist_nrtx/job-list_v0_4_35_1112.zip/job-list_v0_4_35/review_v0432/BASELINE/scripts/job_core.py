#!/usr/bin/env python3
"""job-list v0.4.28 — Skill-Updater-triggered one-shot Job runner.

Production flow:
  bundled request -> strict profile/parameter validation -> persistent local queue
  -> detached worker -> target Skill -> durable result/observer receipt.

The request document never carries commands, shell text, entrypoints, working
directories, or environment overrides.  Only a preconfigured local profile and
that profile's explicitly declared parameters are accepted.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import Any

_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))
from signal_transport import github_signal_get

VERSION = "0.4.31"
SCHEMA_VERSION = 1
ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
PROFILE_RE = ID_RE
TERMINAL_FAILURE = {"FAILED", "TIMEOUT", "REJECTED", "EXPIRED", "OUTPUT_MISSING"}
TERMINAL_NEUTRAL = {"SUPERSEDED", "CANCELLED"}
SUPERSEDE_POLICY_KEYS = {"enabled", "scope", "grace_sec"}
REQUEST_JOB_KEYS = {"job_id", "profile", "platform", "expires_at", "priority", "params"}
REQUEST_PLATFORMS = {"any", "windows", "linux"}

# v0.4.02 targeted recovery hardening.  These are historical rescue identities
# only; ordinary queued work must never be swept by this compatibility cleanup.
DISPATCHER_RECOVERY_V0409_JOB_ID = "JOB-20261004-DISPATCHER-RECOVERY-V0409"
DISPATCHER_RECOVERY_V0408_JOB_ID = "JOB-20261003-DISPATCHER-RECOVERY-V0408"  # historical compatibility alias
LEGACY_RECOVERY_PENDING_IDS = frozenset({
    "JOB-20260924-DISPATCHER-EVIDENCE-RESCUE-V0397",
    "JOB-20260925-DISPATCHER-TARGETED-RESCUE-V0399",
    "JOB-20260925-UPDATER-GATE-VERIFY-V0400",
    "JOB-20261002-DISPATCHER-RECOVERY-V0401",
    "JOB-20261002-DISPATCHER-RECOVERY-V0402",
    "JOB-20261002-DISPATCHER-RECOVERY-V0403",
    "JOB-20261002-DISPATCHER-RECOVERY-V0404",
    "JOB-20261002-DISPATCHER-RECOVERY-V0405",
    "JOB-20261002-DISPATCHER-RECOVERY-V0406",
    "JOB-20261003-DISPATCHER-RECOVERY-V0407",
    "JOB-20261003-DISPATCHER-RECOVERY-V0408",
})
SIGNAL_RELEASE_BASE = "https://github.com/wonhwipark/Fail/releases/download/signal-v1"


def _load_signal_env_file(path: Path, env: dict[str, str]) -> None:
    """Load simple KEY=VALUE task environment without prompting or scanning."""
    try:
        if not path.is_file():
            return
        for raw in path.read_text(encoding="utf-8-sig", errors="replace").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip(); value = value.strip()
            if not key or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key):
                continue
            if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
                value = value[1:-1]
            env[key] = os.path.expandvars(os.path.expanduser(value))
    except Exception:
        return


def _recovery_signal_environment() -> dict[str, str]:
    env = dict(os.environ)
    home = Path(os.environ.get("JOB_LIST_TARGET_HOME") or Path.home()).expanduser()
    # Fixed allowlist only; never recursive-scan in unattended recovery.
    for path in (
        home / "l1sw-private-skills" / "skill-updater" / "data" / "config" / "skill-updater.env",
        home / "l1sw-private-skills" / "autotask-builder" / "data" / "environment" / "skill-updater.env",
        home / "l1sw-private-skills" / "autotask-builder" / "data" / "environment" / "dispatcher.env",
    ):
        _load_signal_env_file(path, env)
    return env


def emit_dispatcher_recovery_signal(stage: str, timeout_sec: int = 12) -> dict[str, Any]:
    """Best-effort external breadcrumb for V0409. Never changes Job success/failure."""
    if os.name != "nt":
        return {"attempted": False, "stage": stage, "reason": "NON_WINDOWS"}
    asset = f"dispatcher-windows-{stage}.signal"
    url = f"{SIGNAL_RELEASE_BASE}/{asset}"
    result = github_signal_get(
        url,
        env=_recovery_signal_environment(),
        timeout=min(10.0, float(timeout_sec)),
        user_agent="job-list-v0.4.9-core-signal",
    )
    return {"attempted": True, "stage": stage, **result}

PARAM_TYPES = {"string", "enum", "integer", "relative_path"}
SEMANTIC_PRECEDENCE = ("FAILED", "BLOCKED", "REVIEW_PENDING", "ANALYSIS_PARTIAL", "LEARNING_DONE")
OBSERVER_RESULT_SCHEMA = "l1-observer-result/1"
OBSERVER_EXECUTION_STATUS = {"SUCCESS", "FAILED", "TIMEOUT", "OUTPUT_MISSING", "INTERRUPTED", "UNKNOWN"}
OBSERVER_QUALITY_STATUS = {"OK", "WARNING", "NEEDS_ATTENTION", "NEEDS_USER_INPUT", "INVALID_OUTPUT", "UNKNOWN"}
OBSERVER_QUALITY_PRECEDENCE = ("INVALID_OUTPUT", "NEEDS_USER_INPUT", "NEEDS_ATTENTION", "WARNING", "UNKNOWN", "OK")
REASON_CODE_RE = re.compile(r"^[A-Z][A-Z0-9_]{0,63}$")

# Narrow, non-destructive diagnostic profile used by the approved stabilization
# one-shot.  User-authored local profiles still remain the trust boundary for
# all target-skill execution.  A local profile with the same name overrides it.
BUILTIN_SAFE_PROFILES: dict[str, dict[str, Any]] = {
    # v0.4.31 staged-only knowledge input verification. No job is active in
    # this release; activation must pass a separate, read-only G0 check.
    "l1-knowledge-input-verify-linux": {
        "enabled": True, "skill": "job-list",
        "entrypoint": "scripts/l1_knowledge_input_verify_linux_job.py",
        "args": [], "timeout_sec": 240, "retry": 0,
        "required_outputs": ["output/l1_knowledge_input_verify/latest_result.json"],
        "semantic_result_path": "output/l1_knowledge_input_verify/latest_result.json",
        "semantic_result_required": True, "env": {}, "parameters": {},
        "supersede_policy": {"enabled": False},
    },
    'mcp-wrapper-registry-recovery-linux': {"enabled": True,"skill":"job-list","entrypoint":"scripts/mcp_wrapper_registry_recovery_linux_job.py","args":[],"timeout_sec":120,"retry":0,"required_outputs":['output/mcp_wrapper_registry_recovery/latest_result.json'],"semantic_result_path":'output/mcp_wrapper_registry_recovery/latest_result.json',"semantic_result_required":True,"env":{},"parameters":{},"supersede_policy":{"enabled":False}},
    "l1-mcp-e2e-pilot-linux": {"enabled": True,"skill":"job-list", "entrypoint":"scripts/l1_mcp_e2e_pilot_linux_job.py", "args":[],"timeout_sec":120,"retry":0,"required_outputs":["output/l1_mcp_e2e_pilot/latest_result.json"],"semantic_result_path":"output/l1_mcp_e2e_pilot/latest_result.json","semantic_result_required":True,"env":{},"parameters":{},"supersede_policy":{"enabled":False}},
    # v0.4.28: fixed one-shot, non-destructive knowledge/ LOCAL bootstrap.
    # Repo is resolved only from existing l1-github canonical work_docs host map.
    "l1-knowledge-portal-bootstrap-linux": {
        "enabled": True, "skill": "job-list",
        "entrypoint": "scripts/l1_knowledge_portal_bootstrap_linux_job.py",
        "args": [], "timeout_sec": 600, "retry": 0,
        "required_outputs": ["output/l1_knowledge_portal_bootstrap/latest_result.json"],
        "semantic_result_path": "output/l1_knowledge_portal_bootstrap/latest_result.json",
        "semantic_result_required": True, "env": {}, "parameters": {},
        "supersede_policy": {"enabled": False},
    },
    # v0.4.27: owner-gated read-only MCP status snapshot plus optional isolated proposal.
    "mcp-gateway-status-recovery-stage-linux": {
        "enabled": True, "skill": "job-list",
        "entrypoint": "scripts/mcp_gateway_status_recovery_linux_job.py",
        "args": [], "timeout_sec": 3900, "retry": 0,
        "required_outputs": ["output/mcp_gateway_status/stage/latest_result.json"],
        "semantic_result_path": "output/mcp_gateway_status/stage/latest_result.json",
        "semantic_result_required": True, "env": {}, "parameters": {},
        "supersede_policy": {"enabled": False},
    },
    # v0.4.26: SDM Parser MCP READ stage proposal; no live MCP/source writes.
    "mcp-sdm-parser-read-stage-linux": {
        "enabled": True, "skill": "job-list",
        "entrypoint": "scripts/mcp_sdm_parser_read_linux_job.py",
        "args": [], "timeout_sec": 3900, "retry": 0,
        "required_outputs": ["output/mcp_sdm_parser_read/stage/latest_result.json"],
        "semantic_result_path": "output/mcp_sdm_parser_read/stage/latest_result.json",
        "semantic_result_required": True, "env": {}, "parameters": {},
        "supersede_policy": {"enabled": False},
    },
    # v0.4.25: stage-only MCP job-catalog/queue/result READ tool proposal.
    "mcp-job-read-stage-linux": {
        "enabled": True, "skill": "job-list",
        "entrypoint": "scripts/mcp_job_read_stage_linux_job.py",
        "args": [], "timeout_sec": 3900, "retry": 0,
        "required_outputs": ["output/mcp_job_read/stage/latest_result.json"],
        "semantic_result_path": "output/mcp_job_read/stage/latest_result.json",
        "semantic_result_required": True, "env": {}, "parameters": {},
        "supersede_policy": {"enabled": False},
    },
    # v0.4.23: isolated source snapshot + proposed patch only, NEVER deploys MCP.
    "mcp-analysis-find-stage-fix-linux": {
        "enabled": True, "skill": "job-list",
        "entrypoint": "scripts/mcp_analysis_find_linux_job.py",
        "args": [], "timeout_sec": 3900, "retry": 0,
        "required_outputs": ["output/mcp_analysis_find/stage_fix/latest_result.json"],
        "semantic_result_path": "output/mcp_analysis_find/stage_fix/latest_result.json",
        "semantic_result_required": True, "env": {}, "parameters": {},
        "supersede_policy": {"enabled": False},
    },
    # v0.4.22: exact, preapproved, Linux-only migration of *published* artifacts.
    # Not an arbitrary path/shell execution. l1-github work_docs mapping is mandatory.
    "l1-workspace-artifacts-migrate-linux": {
        "enabled": True, "skill": "job-list",
        "entrypoint": "scripts/workspace_artifacts_migration_linux_job.py",
        "args": [], "timeout_sec": 900, "retry": 0,
        "required_outputs": ["output/workspace_artifacts_migration/latest_result.json"],
        "semantic_result_path": "output/workspace_artifacts_migration/latest_result.json",
        "semantic_result_required": True, "env": {}, "parameters": {},
        "supersede_policy": {"enabled": False},
    },
    # 0.4.21: one-shot scheduled Linux OpenCode real response check.
    # This tests the CLI, NOT the MCP Provider Shim or interactive TUI.
    "opencode-health-once-linux": {
        "enabled": True, "skill": "job-list",
        "entrypoint": "scripts/opencode_health_linux_job.py",
        "args": ["--timeout-sec", "150"], "timeout_sec": 300,
        "retry": 0,
        "required_outputs": ["output/opencode_health/latest_result.json"],
        "semantic_result_path": "output/opencode_health/latest_result.json",
        "semantic_result_required": True, "env": {}, "parameters": {},
        "supersede_policy": {"enabled": False},
    },
    # U3 OpenCode Job: no remote paths, commands, prompts, or environment params.
    # Both modes operate on staged source copies, never on canonical repositories.
    "u3-opencode-diagnose-linux": {
        "enabled": True, "skill": "job-list", "entrypoint": "scripts/u3_opencode_linux_job.py",
        "args": ["--mode", "diagnose"], "timeout_sec": 3900, "retry": 0,
        "required_outputs": ["output/u3_opencode/diagnose/latest_result.json"],
        "semantic_result_path": "output/u3_opencode/diagnose/latest_result.json",
        "semantic_result_required": True, "env": {}, "parameters": {},
        "supersede_policy": {"enabled": False},
    },
    "u3-opencode-stage-fix-linux": {
        "enabled": True, "skill": "job-list", "entrypoint": "scripts/u3_opencode_linux_job.py",
        "args": ["--mode", "stage-fix"], "timeout_sec": 7500, "retry": 0,
        "required_outputs": ["output/u3_opencode/stage-fix/latest_result.json"],
        "semantic_result_path": "output/u3_opencode/stage-fix/latest_result.json",
        "semantic_result_required": True, "env": {}, "parameters": {},
        "supersede_policy": {"enabled": False},
    },
    # v0.4.18: one-off, Linux-only, out-of-process Bootstrap promotion.
    # Parameters, shell, environment and target path cannot be set by a remote request.
    "skill-updater-bootstrap-apply-linux": {
        "enabled": True, "skill": "job-list",
        "entrypoint": "scripts/linux_bootstrap_apply_job.py", "args": [],
        "timeout_sec": 900, "retry": 0,
        "required_outputs": ["output/linux_bootstrap/latest_result.json"],
        "semantic_result_path": "output/linux_bootstrap/latest_result.json",
        "semantic_result_required": True, "env": {}, "parameters": {},
        "supersede_policy": {"enabled": False},
    },
    "l1-cleanup-disk-recovery-linux": {
        "enabled": True, "skill": "job-list",
        "entrypoint": "scripts/linux_disk_cleanup_job.py", "args": [],
        "timeout_sec": 3600, "retry": 0,
        "required_outputs": ["output/linux_disk_cleanup/latest_result.json"],
        "semantic_result_path": "output/linux_disk_cleanup/latest_result.json",
        "semantic_result_required": True, "env": {}, "parameters": {},
        "supersede_policy": {"enabled": False},
    },
    # Older manual preview/apply profiles require a token. For the named
    # preapproved auto Job, perform both operations in one unattended worker.
    # One registered Linux Job is authorization for the specific migration.
    # Perform preflight and apply in one unattended worker; never retry or cleanup.
    "l1-github-worktree-auto-linux": {
        "enabled": True, "skill": "job-list",
        "entrypoint": "scripts/github_worktree_recovery_linux_job.py",
        "args": ["--mode", "auto"], "timeout_sec": 420, "retry": 0,
        "required_outputs": ["output/github_worktree_recovery/latest_result.json"],
        "semantic_result_path": "output/github_worktree_recovery/latest_result.json",
        "semantic_result_required": True, "env": {},
        "parameters": {"branch": {"flag": "--branch", "type": "string", "required": True, "max_length": 101}},
        "supersede_policy": {"enabled": False}
    },
    "l1-github-worktree-preview-linux": {
        "enabled": True, "skill": "job-list",
        "entrypoint": "scripts/github_worktree_recovery_linux_job.py",
        "args": ["--mode", "preview"], "timeout_sec": 300, "retry": 0,
        "required_outputs": ["output/github_worktree_recovery/latest_result.json"],
        "semantic_result_path": "output/github_worktree_recovery/latest_result.json",
        "semantic_result_required": True, "env": {},
        "parameters": {"branch": {"flag": "--branch", "type": "string", "required": True, "max_length": 101}},
        "supersede_policy": {"enabled": False}
    },
    "l1-github-worktree-apply-linux": {
        "enabled": True, "skill": "job-list",
        "entrypoint": "scripts/github_worktree_recovery_linux_job.py",
        "args": ["--mode", "apply"], "timeout_sec": 420, "retry": 0,
        "required_outputs": ["output/github_worktree_recovery/latest_result.json"],
        "semantic_result_path": "output/github_worktree_recovery/latest_result.json",
        "semantic_result_required": True, "env": {},
        "parameters": {
            "branch": {"flag": "--branch", "type": "string", "required": True, "max_length": 101},
            "approval_token": {"flag": "--approval-token", "type": "string", "required": True, "max_length": 48}
        },
        "supersede_policy": {"enabled": False}
    },
    # v0.4.11: narrowly-scoped Linux Jira analysis entry. The remote request may
    # provide only one Jira key; command/entrypoint/environment remain package-owned.
    "l1-fla-jira-analysis-linux": {
        "enabled": True,
        "skill": "l1-fla",
        "action": "run",
        "args": ["--json", "--resume"],
        "working_dir": "~/l1sw-private-skills/l1-fla",
        "timeout_sec": 25200,
        "retry": 0,
        "required_outputs": ["data/state/observer_result.json"],
        "semantic_result_path": "data/state/observer_result.json",
        "semantic_result_required": True,
        "env": {},
        "parameters": {
            "issue": {"flag": "--issue", "type": "string", "required": True, "max_length": 64}
        },
        "min_skill_version": "0.3.41",
        "dependency_wait_sec": 300,
        "supersede_policy": {"enabled": True, "scope": "same_profile", "grace_sec": 15}
    },
    "cl-ait-lte-next-phase-windows": {
        "enabled": True,
        "skill": "job-list",
        "entrypoint": "scripts/cl_ait_lte_next_phase_windows_job.py",
        "args": [],
        "timeout_sec": 21600,
        "retry": 0,
        "required_outputs": ["output/cl_ait_lte_next_phase/latest_result.json"],
        "semantic_result_path": "output/cl_ait_lte_next_phase/latest_result.json",
        "semantic_result_required": True,
        "env": {},
        "parameters": {},
        "supersede_policy": {"enabled": True, "scope": "same_profile", "grace_sec": 20}
    },
    "cl-ait-hld-v01-windows": {
        "enabled": True,
        "skill": "job-list",
        "entrypoint": "scripts/cl_ait_hld_windows_job.py",
        "args": [],
        "timeout_sec": 14400,
        "retry": 0,
        "required_outputs": ["output/cl_ait_hld_v01/latest_result.json"],
        "semantic_result_path": "output/cl_ait_hld_v01/latest_result.json",
        "semantic_result_required": True,
        "env": {},
        "parameters": {},
        "supersede_policy": {"enabled": True, "scope": "same_profile", "grace_sec": 20}
    },
    "cl-ait-hld-quality-upgrade-windows": {
        "enabled": True,
        "skill": "job-list",
        "entrypoint": "scripts/cl_ait_hld_quality_upgrade_windows_job.py",
        "args": [],
        "timeout_sec": 28800,
        "retry": 1,
        "required_outputs": ["output/cl_ait_hld_quality_upgrade/latest_result.json"],
        "semantic_result_path": "output/cl_ait_hld_quality_upgrade/latest_result.json",
        "semantic_result_required": True,
        "env": {},
        "parameters": {
            "project_root": {"flag": "--project-root", "type": "string", "required": False, "max_length": 512},
            "hld_root": {"flag": "--hld-root", "type": "string", "required": False, "max_length": 512},
            "artifact_root": {"flag": "--artifact-root", "type": "string", "required": False, "max_length": 512},
            "common_hld": {"flag": "--common-hld", "type": "string", "required": False, "max_length": 512},
            "nr_hld": {"flag": "--nr-hld", "type": "string", "required": False, "max_length": 512},
            "lte_hld": {"flag": "--lte-hld", "type": "string", "required": False, "max_length": 512},
            "integrated_hld": {"flag": "--integrated-hld", "type": "string", "required": False, "max_length": 512}
        },
        "supersede_policy": {"enabled": True, "scope": "same_profile", "grace_sec": 20}
    },
    "dispatcher-autotask-register-windows": {
        "enabled": True,
        "skill": "job-list",
        "entrypoint": "scripts/dispatcher_autotask_register_windows_job.py",
        "args": [],
        "timeout_sec": 1500,
        "retry": 0,
        "required_outputs": ["output/dispatcher_autotask_register/latest_result.json"],
        "semantic_result_path": "output/dispatcher_autotask_register/latest_result.json",
        "semantic_result_required": True,
        "env": {},
        "parameters": {},
        "supersede_policy": {"enabled": True, "scope": "same_profile", "grace_sec": 10}
    },
    "skill-updater-gate-verify-windows": {
        "enabled": True,
        "skill": "job-list",
        "entrypoint": "scripts/updater_gate_verify_job.py",
        "args": [],
        "timeout_sec": 180,
        "retry": 0,
        "required_outputs": ["output/updater_gate_rescue_v0400/latest_result.json"],
        "semantic_result_path": "output/updater_gate_rescue_v0400/latest_result.json",
        "semantic_result_required": True,
        "env": {},
        "parameters": {},
        "supersede_policy": {"enabled": True, "scope": "same_profile", "grace_sec": 5}
    },
    "job-list-lifecycle-self-check": {
        "enabled": True,
        "skill": "job-list",
        "entrypoint": "scripts/lifecycle_self_check.py",
        "args": ["--json"],
        "timeout_sec": 120,
        "retry": 0,
        "required_outputs": ["output/core/lifecycle_self_check_latest.json"],
        "env": {},
        "parameters": {},
    }
}


def now_iso() -> str:
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def stamp() -> str:
    return dt.datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")


def atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def atomic_json(path: Path, payload: Any) -> None:
    atomic_write(path, json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n")


def append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n")
        stream.flush(); os.fsync(stream.fileno())


def fsync_stream(stream: Any) -> None:
    try:
        stream.flush()
        os.fsync(stream.fileno())
    except Exception:
        pass


def runtime_event(p: dict[str, Path], event: str, **fields: Any) -> None:
    payload = {"schema_version": 1, "version": VERSION, "event": event, "at": now_iso(), **fields}
    try:
        append_jsonl(p["runtime_events"], payload)
    except Exception:
        # Evidence logging must not become a new execution gate.
        pass


def job_receipt_path(p: dict[str, Path], run_id: str, job_id: str) -> Path:
    safe = job_id if ID_RE.fullmatch(job_id) else "invalid"
    return p["runs"] / run_id / "job_receipts" / f"{safe}.json"


def read_json(path: Path, fallback: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return fallback


def expand_path(value: str, base: Path | None = None) -> Path:
    text = os.path.expandvars(os.path.expanduser(str(value)))
    p = Path(text)
    if not p.is_absolute():
        p = (base or Path.cwd()) / p
    return p.resolve()


def canonical_root(override: str | None = None) -> Path:
    if override:
        return expand_path(override)
    env = os.environ.get("JOB_LIST_CANONICAL_ROOT", "").strip()
    if env:
        return expand_path(env)
    return (Path.home() / "l1sw-private-skills" / "job-list").resolve()


def private_skills_root(root: Path) -> Path:
    env = os.environ.get("L1SW_PRIVATE_SKILLS_ROOT", "").strip() or os.environ.get("PRIVATE_SKILLS_ROOT", "").strip()
    if env:
        return expand_path(env)
    if root.name == "job-list" and root.parent.name == "l1sw-private-skills":
        return root.parent.resolve()
    return (Path.home() / "l1sw-private-skills").resolve()


def paths(root: Path) -> dict[str, Path]:
    data = root / "data"
    state = data / "state" / "core"
    observer = data / "state" / "observer"
    output = root / "output" / "core"
    return {
        "root": root,
        "profiles": data / "config" / "overnight-profiles.json",
        "queue": state / "queue.json",
        "queue_lock": state / "queue.lock",
        "processed": state / "processed.jsonl",
        "activation_latest": data / "state" / "activation" / "latest.json",
        "activation_history": data / "state" / "activation" / "history.jsonl",
        "running": state / "running.json",
        "lock": state / "run.lock",
        "observer_current": observer / "current_run.json",
        "observer_latest": observer / "latest_result.json",
        "observer_history": observer / "history.jsonl",
        "stop_dir": state / "stop_requests",
        "runs": output / "runs",
        "logs": output / "logs",
        "last": output / "last_run.json",
        "runtime_events": output / "lifecycle_events.jsonl",
        "recovery_latest": state / "recovery-latest.json",
    }


def ensure_layout(p: dict[str, Path]) -> None:
    for key in ("runs", "logs", "stop_dir"):
        p[key].mkdir(parents=True, exist_ok=True)
    p["profiles"].parent.mkdir(parents=True, exist_ok=True)
    p["queue"].parent.mkdir(parents=True, exist_ok=True)
    p["observer_latest"].parent.mkdir(parents=True, exist_ok=True)
    p["activation_latest"].parent.mkdir(parents=True, exist_ok=True)
    if not p["profiles"].exists():
        atomic_json(p["profiles"], {"schema_version": 1, "profiles": {}})
    if not p["queue"].exists():
        atomic_json(p["queue"], {"schema_version": 1, "jobs": []})


def load_profiles(p: dict[str, Path]) -> dict[str, dict[str, Any]]:
    raw = read_json(p["profiles"], {})
    profiles = raw.get("profiles") if isinstance(raw, dict) else None
    if not isinstance(profiles, dict):
        raise RuntimeError(f"profiles must be object: {p['profiles']}")
    out: dict[str, dict[str, Any]] = {}
    for name, spec in profiles.items():
        if PROFILE_RE.fullmatch(str(name)) and isinstance(spec, dict):
            out[str(name)] = dict(spec)
    for name, spec in BUILTIN_SAFE_PROFILES.items():
        out.setdefault(name, dict(spec))
    return out


def validate_profile(name: str, spec: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if spec.get("enabled", True) not in (True, False):
        errors.append("enabled must be boolean")
    skill = str(spec.get("skill") or "")
    if not ID_RE.fullmatch(skill):
        errors.append("skill missing/invalid")
    action = str(spec.get("action") or "").strip()
    entrypoint = str(spec.get("entrypoint") or "").strip()
    if not action and not entrypoint:
        errors.append("action or entrypoint required")
    if action and not ID_RE.fullmatch(action):
        errors.append("action invalid")
    if entrypoint and Path(entrypoint).is_absolute():
        errors.append("entrypoint must be relative to target Skill root")
    args = spec.get("args", [])
    if not isinstance(args, list) or not all(isinstance(x, str) for x in args):
        errors.append("args must be string array")
    timeout = spec.get("timeout_sec", 3600)
    if not isinstance(timeout, int) or isinstance(timeout, bool) or not 60 <= timeout <= 43200:
        errors.append("timeout_sec must be integer 60..43200")
    retry = spec.get("retry", 0)
    if not isinstance(retry, int) or isinstance(retry, bool) or not 0 <= retry <= 3:
        errors.append("retry must be integer 0..3")
    outputs = spec.get("required_outputs", [])
    if not isinstance(outputs, list) or not all(isinstance(x, str) and x for x in outputs):
        errors.append("required_outputs must be string array")
    env = spec.get("env", {})
    if not isinstance(env, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in env.items()):
        errors.append("env must be string map")
    semantic = spec.get("semantic_result_path")
    if semantic is not None and (not isinstance(semantic, str) or not semantic.strip()):
        errors.append("semantic_result_path must be non-empty string")
    if spec.get("semantic_result_required", False) not in (True, False):
        errors.append("semantic_result_required must be boolean")
    min_skill_version = spec.get("min_skill_version")
    if min_skill_version is not None and not re.fullmatch(r"[0-9]+(?:\.[0-9]+){1,3}", str(min_skill_version).strip()):
        errors.append("min_skill_version must be numeric dotted version")
    dependency_wait_sec = spec.get("dependency_wait_sec", 0)
    if not isinstance(dependency_wait_sec, int) or isinstance(dependency_wait_sec, bool) or not 0 <= dependency_wait_sec <= 3600:
        errors.append("dependency_wait_sec must be integer 0..3600")
    supersede = spec.get("supersede_policy")
    if supersede is not None:
        if not isinstance(supersede, dict):
            errors.append("supersede_policy must be object")
        else:
            extra = sorted(set(supersede) - SUPERSEDE_POLICY_KEYS)
            if extra:
                errors.append("supersede_policy unknown fields: " + ", ".join(extra))
            if supersede.get("enabled", False) not in (True, False):
                errors.append("supersede_policy.enabled must be boolean")
            if str(supersede.get("scope") or "same_profile") != "same_profile":
                errors.append("supersede_policy.scope must be same_profile")
            grace = supersede.get("grace_sec", 15)
            if not isinstance(grace, int) or isinstance(grace, bool) or not 0 <= grace <= 300:
                errors.append("supersede_policy.grace_sec must be integer 0..300")
    params = spec.get("parameters", {})
    if not isinstance(params, dict):
        errors.append("parameters must be object")
    else:
        for pname, pspec in params.items():
            if not ID_RE.fullmatch(str(pname)) or not isinstance(pspec, dict):
                errors.append(f"parameter contract invalid: {pname}")
                continue
            flag = str(pspec.get("flag") or "")
            if not re.fullmatch(r"--[A-Za-z0-9][A-Za-z0-9-]{0,63}", flag):
                errors.append(f"parameter {pname} flag invalid")
            ptype = str(pspec.get("type") or "string")
            if ptype not in PARAM_TYPES:
                errors.append(f"parameter {pname} type invalid")
            if pspec.get("required", False) not in (True, False):
                errors.append(f"parameter {pname} required must be boolean")
            if ptype == "enum" and (not isinstance(pspec.get("choices"), list) or not pspec.get("choices")):
                errors.append(f"parameter {pname} enum choices required")
            if ptype == "relative_path" and not str(pspec.get("base_dir") or "").strip():
                errors.append(f"parameter {pname} relative_path base_dir required")
    return [f"{name}: {e}" for e in errors]


def parse_expiry(value: Any) -> dt.datetime | None:
    if value is None or str(value).strip() == "":
        return None
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        parsed = dt.datetime.fromisoformat(text)
    except ValueError as exc:
        raise RuntimeError("expires_at must be ISO-8601") from exc
    if parsed.tzinfo is None:
        raise RuntimeError("expires_at must include timezone")
    return parsed.astimezone()


def is_expired(value: Any) -> bool:
    parsed = parse_expiry(value)
    return parsed is not None and parsed <= dt.datetime.now().astimezone()


def current_platform() -> str:
    """Return the local runtime platform used for one-shot targeting."""
    value = sys.platform.lower()
    if value.startswith("win"):
        return "windows"
    if value.startswith("linux"):
        return "linux"
    return value or "unknown"


def normalize_request_platform(value: Any) -> str:
    """Validate a remote request platform. Missing means backward-compatible any."""
    if value is None or str(value).strip() == "":
        return "any"
    platform = str(value).strip().lower()
    if platform not in REQUEST_PLATFORMS:
        raise RuntimeError("platform must be one of: any, windows, linux")
    return platform


def platform_matches(requested: str, local: str | None = None) -> bool:
    actual = local or current_platform()
    return requested == "any" or requested == actual


def _clean_scalar(value: Any, max_len: int = 512) -> str:
    if not isinstance(value, (str, int)) or isinstance(value, bool):
        raise RuntimeError("parameter value must be string or integer")
    text = str(value)
    if not text or len(text) > max_len or "\x00" in text or "\n" in text or "\r" in text:
        raise RuntimeError("parameter value is empty/too long/contains control characters")
    return text


def render_profile_params(skill_root: Path, profile_name: str, spec: dict[str, Any], params: Any) -> list[str]:
    params = {} if params is None else params
    if not isinstance(params, dict):
        raise RuntimeError("params must be object")
    contracts = spec.get("parameters", {}) or {}
    if not isinstance(contracts, dict):
        raise RuntimeError("profile parameters contract invalid")
    unknown = sorted(set(str(k) for k in params) - set(str(k) for k in contracts))
    if unknown:
        raise RuntimeError("parameters not allowed: " + ", ".join(unknown))
    out: list[str] = []
    for pname, pspec in contracts.items():
        required = bool(pspec.get("required", False))
        if pname not in params:
            if required:
                raise RuntimeError(f"required parameter missing: {pname}")
            continue
        flag = str(pspec["flag"])
        ptype = str(pspec.get("type") or "string")
        raw = params[pname]
        if ptype == "integer":
            if not isinstance(raw, int) or isinstance(raw, bool):
                raise RuntimeError(f"parameter {pname} must be integer")
            if "min" in pspec and raw < int(pspec["min"]):
                raise RuntimeError(f"parameter {pname} below minimum")
            if "max" in pspec and raw > int(pspec["max"]):
                raise RuntimeError(f"parameter {pname} above maximum")
            value = str(raw)
        else:
            value = _clean_scalar(raw, int(pspec.get("max_length", 512)))
            if ptype == "enum":
                choices = [str(x) for x in pspec.get("choices", [])]
                if value not in choices:
                    raise RuntimeError(f"parameter {pname} not in allowed choices")
            elif ptype == "relative_path":
                rel = Path(value)
                if rel.is_absolute() or any(part in {"..", ""} for part in rel.parts):
                    raise RuntimeError(f"parameter {pname} must be safe relative path")
                base = expand_path(str(pspec.get("base_dir")), skill_root)
                resolved = (base / rel).resolve()
                try:
                    resolved.relative_to(base.resolve())
                except ValueError as exc:
                    raise RuntimeError(f"parameter {pname} escapes base_dir") from exc
                if bool(pspec.get("must_exist", True)) and not resolved.exists():
                    raise RuntimeError(f"parameter {pname} target missing: {resolved}")
                value = str(resolved)
        out.extend([flag, value])
    return out


def load_queue(p: dict[str, Path]) -> list[dict[str, Any]]:
    raw = read_json(p["queue"], {"schema_version": 1, "jobs": []})
    jobs = raw.get("jobs") if isinstance(raw, dict) else []
    return [dict(x) for x in jobs if isinstance(x, dict)]


def save_queue(p: dict[str, Path], jobs: list[dict[str, Any]]) -> None:
    jobs.sort(key=lambda x: (-int(x.get("priority", 50)), str(x.get("created_at") or ""), str(x.get("job_id") or "")))
    atomic_json(p["queue"], {"schema_version": 1, "updated_at": now_iso(), "jobs": jobs})


def processed_ids(p: dict[str, Path]) -> set[str]:
    out: set[str] = set()
    if not p["processed"].is_file():
        return out
    for line in p["processed"].read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            row = json.loads(line)
            job_id = str(row.get("job_id") or "")
            if job_id:
                out.add(job_id)
        except Exception:
            pass
    return out


def _supersede_policy(spec: dict[str, Any]) -> dict[str, Any]:
    raw = spec.get("supersede_policy")
    if not isinstance(raw, dict) or not bool(raw.get("enabled", False)):
        return {"enabled": False, "scope": "same_profile", "grace_sec": 0}
    return {
        "enabled": True,
        "scope": "same_profile",
        "grace_sec": min(300, max(0, int(raw.get("grace_sec", 15) or 0))),
    }


def _stop_request_path(p: dict[str, Path], job_id: str) -> Path:
    safe = job_id if ID_RE.fullmatch(job_id) else "invalid"
    return p["stop_dir"] / f"{safe}.json"


def _read_stop_request(p: dict[str, Path], job_id: str) -> dict[str, Any] | None:
    path = _stop_request_path(p, job_id)
    row = read_json(path, None) if path.is_file() else None
    return row if isinstance(row, dict) else None


def _write_supersede_request(p: dict[str, Path], running: dict[str, Any], new_job_id: str, grace_sec: int) -> dict[str, Any]:
    old_job_id = str(running.get("job_id") or "")
    payload = {
        "schema_version": 1,
        "status": "SUPERSEDE_REQUESTED",
        "job_id": old_job_id,
        "profile": running.get("profile"),
        "run_id": running.get("run_id"),
        "superseded_by": new_job_id,
        "requested_at": now_iso(),
        "grace_sec": grace_sec,
    }
    path = _stop_request_path(p, old_job_id)
    atomic_json(path, payload)
    return {**payload, "path": str(path)}


def _terminate_process_tree(pid: int, pgid: int | None = None, force: bool = False) -> bool:
    if pid <= 0 or not pid_alive(pid):
        return True
    try:
        if os.name == "nt":
            cmd = ["taskkill", "/PID", str(pid), "/T"]
            if force:
                cmd.append("/F")
            completed = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            return completed.returncode == 0 or not pid_alive(pid)
        import signal
        target_pgid = int(pgid or 0)
        if target_pgid > 0:
            os.killpg(target_pgid, signal.SIGKILL if force else signal.SIGTERM)
        else:
            os.kill(pid, signal.SIGKILL if force else signal.SIGTERM)
        return True
    except ProcessLookupError:
        return True
    except Exception:
        return not pid_alive(pid)


def _request_running_supersede(p: dict[str, Path], profile: str, new_job_id: str, grace_sec: int) -> dict[str, Any] | None:
    running = read_json(p["running"], {}) if p["running"].is_file() else None
    if not isinstance(running, dict) or str(running.get("profile") or "") != profile:
        return None
    old_job_id = str(running.get("job_id") or "")
    if not old_job_id or old_job_id == new_job_id:
        return None
    request = _write_supersede_request(p, running, new_job_id, grace_sec)
    child_pid = int(running.get("child_pid") or 0)
    child_pgid = int(running.get("child_pgid") or 0) or None
    deadline = time.monotonic() + grace_sec
    while child_pid > 0 and pid_alive(child_pid) and time.monotonic() < deadline:
        time.sleep(0.2)
    forced = False
    terminated = child_pid <= 0 or not pid_alive(child_pid)
    if not terminated and child_pid > 0:
        _terminate_process_tree(child_pid, child_pgid, force=False)
        term_deadline = time.monotonic() + 3.0
        while pid_alive(child_pid) and time.monotonic() < term_deadline:
            time.sleep(0.1)
        if pid_alive(child_pid):
            forced = True
            _terminate_process_tree(child_pid, child_pgid, force=True)
            kill_deadline = time.monotonic() + 2.0
            while pid_alive(child_pid) and time.monotonic() < kill_deadline:
                time.sleep(0.1)
        terminated = not pid_alive(child_pid)
    request.update({"child_pid": child_pid or None, "child_pgid": child_pgid, "terminated": terminated, "forced": forced})
    return request


def _enqueue_job_with_effects(p: dict[str, Path], profiles: dict[str, dict[str, Any]], profile: str, job_id: str | None,
                              priority: int, params: dict[str, Any] | None = None, expires_at: str | None = None,
                              platform: str = "any") -> tuple[dict[str, Any], dict[str, Any]]:
    if not PROFILE_RE.fullmatch(profile):
        raise RuntimeError("invalid profile")
    platform = normalize_request_platform(platform)
    if profile in {"l1-github-worktree-preview-linux", "l1-github-worktree-apply-linux", "l1-github-worktree-auto-linux", "l1-cleanup-disk-recovery-linux", "skill-updater-bootstrap-apply-linux"} and platform != "linux":
        raise RuntimeError("Linux-only recovery profile requires explicit platform=linux")
    if not platform_matches(platform):
        raise RuntimeError(f"platform target mismatch: requested={platform}, local={current_platform()}")
    spec = profiles.get(profile)
    if not isinstance(spec, dict) or not spec.get("enabled", True):
        raise RuntimeError(f"profile unavailable: {profile}")
    errors = validate_profile(profile, spec)
    if errors:
        raise RuntimeError("; ".join(errors))
    jid = job_id or f"job_{stamp()}_{uuid.uuid4().hex[:8]}"
    if not ID_RE.fullmatch(jid):
        raise RuntimeError("invalid job_id")
    if not 0 <= priority <= 100:
        raise RuntimeError("priority must be 0..100")
    if is_expired(expires_at):
        raise RuntimeError("job already expired")
    private_root = private_skills_root(p["root"])
    skill_root = (private_root / str(spec["skill"])).resolve()
    render_profile_params(skill_root, profile, spec, params or {})
    with FileLock(p["queue_lock"], wait_seconds=10):
        jobs = load_queue(p)
        known = processed_ids(p) | {str(x.get("job_id") or "") for x in jobs}
        if jid in known:
            raise RuntimeError(f"job_id already used: {jid}")
        job = {
            "schema_version": 1, "job_id": jid, "profile": profile, "platform": platform, "state": "PENDING",
            "execution_class": "overnight", "priority": priority, "params": params or {},
            "expires_at": expires_at, "created_at": now_iso(), "queued_at": now_iso(),
        }
        running = read_json(p["running"], {}) if p["running"].is_file() else {}
        running_job_id = str(running.get("job_id") or "") if isinstance(running, dict) else ""

        # Release-specific compatibility cleanup: a prior rescue request can be
        # left PENDING even after the updater/job-list package has moved on.
        # Supersede only the explicit historical rescue identities.  The active
        # running identity is preserved; cmd_activate already performed stale
        # runtime recovery before this function is reached.
        legacy_recovery_superseded_pending: list[dict[str, Any]] = []
        if jid in {DISPATCHER_RECOVERY_V0408_JOB_ID, DISPATCHER_RECOVERY_V0409_JOB_ID} and profile == "dispatcher-autotask-register-windows":
            kept: list[dict[str, Any]] = []
            for old in jobs:
                old_id = str(old.get("job_id") or "")
                if old_id in LEGACY_RECOVERY_PENDING_IDS and old_id != running_job_id:
                    legacy_recovery_superseded_pending.append(old)
                else:
                    kept.append(old)
            jobs = kept

        policy = _supersede_policy(spec)
        superseded_pending: list[dict[str, Any]] = []
        if policy["enabled"]:
            kept = []
            for old in jobs:
                old_id = str(old.get("job_id") or "")
                if str(old.get("profile") or "") == profile and old_id != running_job_id:
                    superseded_pending.append(old)
                else:
                    kept.append(old)
            jobs = kept
        jobs.append(job); save_queue(p, jobs)
    for old in legacy_recovery_superseded_pending:
        append_jsonl(p["processed"], {
            "schema_version": 1, "job_id": old.get("job_id"), "profile": old.get("profile"),
            "platform": old.get("platform", "any"), "state": "CONSUMED", "status": "SUPERSEDED",
            "superseded_by": jid, "completed_at": now_iso(), "source": "legacy-recovery-queue-supersede-v0409",
        })
    for old in superseded_pending:
        append_jsonl(p["processed"], {
            "schema_version": 1, "job_id": old.get("job_id"), "profile": old.get("profile"),
            "platform": old.get("platform", "any"), "state": "CONSUMED", "status": "SUPERSEDED",
            "superseded_by": jid, "completed_at": now_iso(), "source": "queue-supersede",
        })
    running_effect = _request_running_supersede(p, profile, jid, int(policy["grace_sec"])) if policy["enabled"] else None
    effects = {
        "policy": policy,
        "legacy_recovery_superseded_pending": [str(x.get("job_id") or "") for x in legacy_recovery_superseded_pending],
        "superseded_pending": [str(x.get("job_id") or "") for x in superseded_pending],
        "running_supersede": running_effect,
    }
    return job, effects


def enqueue_job(p: dict[str, Path], profiles: dict[str, dict[str, Any]], profile: str, job_id: str | None,
                priority: int, params: dict[str, Any] | None = None, expires_at: str | None = None,
                platform: str = "any") -> dict[str, Any]:
    job, _ = _enqueue_job_with_effects(p, profiles, profile, job_id, priority, params, expires_at, platform)
    return job


def _terminal_activation_record(p: dict[str, Path], job_id: str, profile: str, status: str, error: str) -> dict[str, Any]:
    rec = {"schema_version": 1, "job_id": job_id, "profile": profile, "state": "EXPIRED" if status == "EXPIRED" else "CONSUMED",
           "status": status, "error": error, "completed_at": now_iso(), "source": "bundled-request"}
    append_jsonl(p["processed"], rec)
    return rec


# v0.4.16: fixed, user-confirmed completed request; retire ONLY the old
# bundled Linux Worktree auto Job.  Preserve every other queued Job, all
# historical results and all reusable Git profiles/tools.
RETIRED_GITHUB_JOB_ID = "JOB-20261010-WT-SOC41668-AUTO-01"
RETIRED_GITHUB_PROFILE = "l1-github-worktree-auto-linux"


def retire_completed_github_request(p: dict[str, Path]) -> dict[str, Any]:
    """Idempotently remove a stale pending request before --launch.

    Does not terminate or modify a live Worker.  A prior processed receipt
    (especially SUCCESS) is authoritative and is never overwritten.
    """
    if current_platform() != "linux":
        return {"job_id": RETIRED_GITHUB_JOB_ID, "status": "NOT_LINUX"}
    with FileLock(p["queue_lock"], wait_seconds=10):
        marker = read_json(p["running"], {}) if p["running"].is_file() else {}
        if isinstance(marker, dict) and str(marker.get("job_id") or "") == RETIRED_GITHUB_JOB_ID:
            return {"job_id": RETIRED_GITHUB_JOB_ID, "status": "RUNNING_NOT_CANCELLED"}
        jobs = load_queue(p)
        removed = [j for j in jobs if str(j.get("job_id") or "") == RETIRED_GITHUB_JOB_ID
                   and str(j.get("profile") or "") == RETIRED_GITHUB_PROFILE]
        if removed:
            save_queue(p, [j for j in jobs if j not in removed])
        # Mark the retired identity as consumed so it cannot be silently
        # reintroduced by a stale request on later activation. Existing receipts
        # are retained, never replaced with a fictitious cancellation.
        had_receipt = RETIRED_GITHUB_JOB_ID in processed_ids(p)
        if not had_receipt:
            append_jsonl(p["processed"], {
                "schema_version": 1, "job_id": RETIRED_GITHUB_JOB_ID,
                "profile": RETIRED_GITHUB_PROFILE, "platform": "linux",
                "state": "CONSUMED", "status": "CANCELLED", "completed_at": now_iso(),
                "source": "user-confirmed-completed-request-retirement-v0416",
                "reason": "user reported Git worktree operation already completed",
            })
    return {"job_id": RETIRED_GITHUB_JOB_ID,
            "status": "PENDING_CANCELLED" if removed else ("ALREADY_PROCESSED" if had_receipt else "RETIREMENT_RECORDED"),
            "removed_pending": len(removed), "history_preserved": had_receipt}


BOOTSTRAP_JOB_ID_V0418 = "JOB-20261013-LINUX-BOOTSTRAP-APPLY-01"
RETIRED_LINUX_ACTIVE_JOBS_V0418 = {
    "JOB-20261005-L1FLA-SOC-415831-01": "l1-fla-jira-analysis-linux",
    "JOB-20261010-LINUX-CLEANUP-30D-01": "l1-cleanup-disk-recovery-linux",
}


def retire_old_bundled_linux_requests_v0418(p: dict[str, Path]) -> dict[str, Any]:
    """Cancel ONLY obsolete known bundled request IDs, preserving all other queue work.

    A running job is never stopped or misreported as cancelled.
    """
    if current_platform() != "linux":
        return {"status": "NOT_LINUX", "cancelled": []}
    with FileLock(p["queue_lock"], wait_seconds=10):
        running = read_json(p["running"], {}) if p["running"].is_file() else {}
        running_id = str(running.get("job_id") or "") if isinstance(running, dict) else ""
        if running_id in RETIRED_LINUX_ACTIVE_JOBS_V0418:
            return {"status": "OLD_REQUEST_RUNNING", "running_job_id": running_id, "cancelled": []}
        jobs = load_queue(p)
        removed = [j for j in jobs if str(j.get("job_id") or "") in RETIRED_LINUX_ACTIVE_JOBS_V0418
                   and str(j.get("profile") or "") == RETIRED_LINUX_ACTIVE_JOBS_V0418.get(str(j.get("job_id") or ""))]
        if removed:
            save_queue(p, [j for j in jobs if j not in removed])
    processed = processed_ids(p)
    for job in removed:
        jid = str(job["job_id"])
        if jid not in processed:
            append_jsonl(p["processed"], {"schema_version": 1, "job_id": jid,
                "profile": job.get("profile"), "platform": "linux",
                "state": "CONSUMED", "status": "CANCELLED",
                "reason": "removed from v0.4.18 Linux Bootstrap-only bundled requests",
                "completed_at": now_iso(), "source": "bootstrap-only-release-v0418"})
            processed.add(jid)
    return {"status": "PENDING_CANCELLED" if removed else "NONE_PENDING",
            "cancelled": [str(j["job_id"]) for j in removed]}


def activate_request_document(root: Path, p: dict[str, Path], source: Path) -> dict[str, Any]:
    if current_platform() != 'linux':
        return {'schema_version': 1, 'status': 'BLOCKED', 'reason': 'LINUX_ONLY_RELEASE',
                'worker_launched': False, 'source': str(source)}
    ensure_layout(p)
    started = now_iso(); outcomes: list[dict[str, Any]] = []
    retirement: dict[str, Any] = {"status": "NOT_EVALUATED"}
    try:
        raw = json.loads(source.read_text(encoding="utf-8"))
        if not isinstance(raw, dict) or set(raw) - {"schema_version", "jobs"}:
            raise RuntimeError("request root allows only schema_version/jobs")
        if raw.get("schema_version") != 1 or not isinstance(raw.get("jobs"), list):
            raise RuntimeError("request document schema_version=1 and jobs[] required")
        # v0.4.31: hard reject; never silently wait/cancel an older pending Job.
        knowledge_input_id = 'JOB-20261107-L1-KNOWLEDGE-INPUT-VERIFY-01'
        if any(isinstance(x,dict) and x.get('job_id') == knowledge_input_id for x in raw['jobs']):
            if (len(raw['jobs']) != 1 or raw['jobs'][0].get('profile') != 'l1-knowledge-input-verify-linux'
                    or raw['jobs'][0].get('platform') != 'linux'
                    or raw['jobs'][0].get('params') != {}):
                raise RuntimeError('KNOWLEDGE_INPUT_REQUEST_CONTRACT_MISMATCH')
            unrelated = [str(j.get('job_id') or '') for j in load_queue(p)
                         if str(j.get('job_id') or '') != knowledge_input_id]
            if unrelated:
                raise RuntimeError('OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_KNOWLEDGE_INPUT_RELEASE')
            running = read_json(p['running'], {})
            if isinstance(running,dict) and running.get('job_id') and running['job_id'] != knowledge_input_id:
                raise RuntimeError('OTHER_RUNNING_JOB_NOT_AUTHORIZED_IN_KNOWLEDGE_INPUT_RELEASE')
            # G0: a separate host-side owner-approved preflight is mandatory.
            # The bundled example is NOT an attestation or release permission.
            from l1_knowledge_input_verify_linux_job import preflight_check
            gate = preflight_check(root, allow_platform_only=False)
            if gate != 'PREFLIGHT_ATTESTED':
                raise RuntimeError(gate)
            # The reviewed v1.6.65 Provider invocation is not pinned on this host.
            # A format-valid local attestation alone must never consume the Job.
            raise RuntimeError('PROVIDER_ENTRYPOINT_NOT_VERIFIED')
        # v0.4.29: fixed Linux one-shot; preserve other queue/running work.
        pilot_id = 'JOB-20261107-L1-MCP-E2E-PILOT-01'
        if any(isinstance(x,dict) and x.get('job_id')==pilot_id for x in raw['jobs']):
            if (len(raw['jobs'])!=1 or raw['jobs'][0].get('profile')!='l1-mcp-e2e-pilot-linux'
                    or raw['jobs'][0].get('platform')!='linux'
                    or raw['jobs'][0].get('params') not in ({},None)):
                raise RuntimeError('MCP_E2E_PILOT_REQUEST_CONTRACT_MISMATCH')
            if any(str(j.get('job_id') or '')!=pilot_id for j in load_queue(p)):
                raise RuntimeError('OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_MCP_E2E_RELEASE')
            running=read_json(p['running'],{})
            if isinstance(running,dict) and running.get('job_id') and running['job_id']!=pilot_id:
                raise RuntimeError('OTHER_RUNNING_JOB_NOT_AUTHORIZED_IN_MCP_E2E_RELEASE')
        # v0.4.28 fixed knowledge bootstrap release: never retire/cancel or
        # dispatch an earlier queued or running one-shot request.  No remote
        # parameter path/command may be supplied to the bootstrap worker.
        knowledge_id = 'JOB-20261107-L1-KNOWLEDGE-PORTAL-BOOTSTRAP-01'
        if any(isinstance(x,dict) and x.get('job_id') == knowledge_id for x in raw['jobs']):
            if (len(raw['jobs']) != 1 or raw['jobs'][0].get('profile') != 'l1-knowledge-portal-bootstrap-linux'
                    or raw['jobs'][0].get('platform') != 'linux'
                    or raw['jobs'][0].get('params') not in ({},None)):
                raise RuntimeError('KNOWLEDGE_BOOTSTRAP_REQUEST_CONTRACT_MISMATCH')
            unrelated = [str(j.get('job_id') or '') for j in load_queue(p)
                         if str(j.get('job_id') or '') != knowledge_id]
            if unrelated:
                raise RuntimeError('OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_KNOWLEDGE_RELEASE')
            running = read_json(p['running'], {})
            if isinstance(running,dict) and running.get('job_id') and running['job_id'] != knowledge_id:
                raise RuntimeError('OTHER_RUNNING_JOB_NOT_AUTHORIZED_IN_KNOWLEDGE_RELEASE')
        # v0.4.27: one new request, no unrelated queue/running state touched.
        gateway_id = 'JOB-20261031-MCP-GATEWAY-STATUS-RECOVERY-01'
        if (len(raw['jobs']) == 1 and isinstance(raw['jobs'][0], dict)
                and raw['jobs'][0].get('job_id') == gateway_id
                and raw['jobs'][0].get('profile') == 'mcp-gateway-status-recovery-stage-linux'):
            unrelated = [str(j.get('job_id') or '') for j in load_queue(p)
                         if str(j.get('job_id') or '') != gateway_id]
            if unrelated:
                raise RuntimeError('OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_MCP_GATEWAY_RELEASE')
            running = read_json(p['running'], {})
            if isinstance(running, dict) and running.get('job_id') and running.get('job_id') != gateway_id:
                raise RuntimeError('OTHER_RUNNING_JOB_NOT_AUTHORIZED_IN_MCP_GATEWAY_RELEASE')
        # v0.4.26: one new fixed request must not start, cancel or supersede
        # any previous pending/running Job. Job history and receipts remain intact.
        sdm_id = 'JOB-20261031-MCP-SDM-PARSER-READ-STAGE-01'
        if (len(raw['jobs']) == 1 and isinstance(raw['jobs'][0], dict)
                and raw['jobs'][0].get('job_id') == sdm_id
                and raw['jobs'][0].get('profile') == 'mcp-sdm-parser-read-stage-linux'):
            unrelated = [str(j.get('job_id') or '') for j in load_queue(p)
                         if str(j.get('job_id') or '') != sdm_id]
            if unrelated:
                raise RuntimeError('OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_MCP_SDM_RELEASE')
            running = read_json(p['running'], {})
            if isinstance(running, dict) and running.get('job_id') and running.get('job_id') != sdm_id:
                raise RuntimeError('OTHER_RUNNING_JOB_NOT_AUTHORIZED_IN_MCP_SDM_RELEASE')
        # v0.4.25: forbid activation if ANY other Job is queued/running.
        # v0.4.23 and historical migration are never cancelled or replaced.
        job_read_stage_id = 'JOB-20261024-MCP-JOB-READ-STAGE-01'
        if (len(raw['jobs']) == 1 and isinstance(raw['jobs'][0], dict)
                and raw['jobs'][0].get('job_id') == job_read_stage_id
                and raw['jobs'][0].get('profile') == 'mcp-job-read-stage-linux'):
            unrelated = [str(j.get('job_id') or '') for j in load_queue(p)
                         if str(j.get('job_id') or '') != job_read_stage_id]
            if unrelated:
                raise RuntimeError('OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_MCP_JOB_READ_RELEASE')
            running = read_json(p['running'], {})
            if isinstance(running, dict) and running.get('job_id') and running.get('job_id') != job_read_stage_id:
                raise RuntimeError('OTHER_RUNNING_JOB_NOT_AUTHORIZED_IN_MCP_JOB_READ_RELEASE')
        # v0.4.23 proposal-only release: do NOT run prior migration/health/other
        # queued or running work. Never retire/replace their state or receipts.
        mcp_proposal_id = 'JOB-20261024-MCP-ANALYSIS-FIND-PROPOSAL-01'
        if (len(raw['jobs']) == 1 and isinstance(raw['jobs'][0], dict)
                and raw['jobs'][0].get('job_id') == mcp_proposal_id
                and raw['jobs'][0].get('profile') == 'mcp-analysis-find-stage-fix-linux'):
            unrelated = [str(j.get('job_id') or '') for j in load_queue(p)
                         if str(j.get('job_id') or '') != mcp_proposal_id]
            if unrelated:
                raise RuntimeError('OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_MCP_PROPOSAL_RELEASE')
            running = read_json(p['running'], {})
            if isinstance(running, dict) and running.get('job_id') and running.get('job_id') != mcp_proposal_id:
                raise RuntimeError('OTHER_RUNNING_JOB_NOT_AUTHORIZED_IN_MCP_PROPOSAL_RELEASE')
        # v0.4.22 migration release must not execute pre-existing unrelated
        # PENDING jobs. Preserve the v0.4.21 health request if not completed.
        migration_request_id = 'JOB-20261021-L1-WORKSPACE-ARTIFACTS-MIGRATE-01'
        if (len(raw['jobs']) == 1 and isinstance(raw['jobs'][0], dict)
                and raw['jobs'][0].get('job_id') == migration_request_id
                and raw['jobs'][0].get('profile') == 'l1-workspace-artifacts-migrate-linux'):
            unrelated = [str(j.get('job_id') or '') for j in load_queue(p)
                         if str(j.get('job_id') or '') != migration_request_id]
            if unrelated:
                raise RuntimeError('OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_WORKSPACE_MIGRATION_RELEASE: '
                                   + ', '.join(unrelated[:10]))
            running = read_json(p['running'], {})
            if isinstance(running, dict) and running.get('job_id') and running.get('job_id') != migration_request_id:
                raise RuntimeError('OTHER_RUNNING_JOB_NOT_AUTHORIZED_IN_WORKSPACE_MIGRATION_RELEASE')
        # v0.4.21 health-only release must never start an unrelated queued Job.
        health_request_id = 'JOB-20261017-OPENCODE-HEALTH-01'
        if (len(raw['jobs']) == 1 and isinstance(raw['jobs'][0], dict)
                and raw['jobs'][0].get('job_id') == health_request_id):
            unrelated = [str(j.get('job_id') or '') for j in load_queue(p)
                         if str(j.get('job_id') or '') != health_request_id]
            if unrelated:
                raise RuntimeError('OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_HEALTH_ONLY_RELEASE: '
                                   + ', '.join(unrelated[:10]))
        # This install-only release must not retire/cancel or launch any existing Job.
        if not raw['jobs'] and load_queue(p):
            raise RuntimeError('INSTALL_ONLY_RELEASE_PENDING_JOBS_NOT_AUTHORIZED: '
                               + ', '.join(str(j.get('job_id') or '') for j in load_queue(p)[:10]))
        if not raw['jobs']:
            retirement = {'status':'INSTALL_ONLY_NO_RETIREMENT'}
        elif (len(raw['jobs'])==1 and isinstance(raw['jobs'][0],dict)
              and raw['jobs'][0].get('job_id')==pilot_id
              and raw['jobs'][0].get('profile')=='l1-mcp-e2e-pilot-linux'):
            retirement={'status':'PRESERVED_EXISTING_HISTORY'}
        elif (len(raw['jobs']) == 1 and isinstance(raw['jobs'][0], dict)
              and raw['jobs'][0].get('job_id') == knowledge_id
              and raw['jobs'][0].get('profile') == 'l1-knowledge-portal-bootstrap-linux'):
            retirement = {'status':'PRESERVED_EXISTING_HISTORY'}
        elif (len(raw['jobs']) == 1 and isinstance(raw['jobs'][0], dict)
              and raw['jobs'][0].get('job_id') == sdm_id
              and raw['jobs'][0].get('profile') == 'mcp-sdm-parser-read-stage-linux'):
            retirement = {'status': 'PRESERVED_EXISTING_HISTORY'}
        elif (len(raw['jobs']) == 1 and isinstance(raw['jobs'][0], dict)
              and raw['jobs'][0].get('job_id') == job_read_stage_id
              and raw['jobs'][0].get('profile') == 'mcp-job-read-stage-linux'):
            # This release observes/proposes MCP READ only. Do not append an
            # unrelated historical Git cancellation receipt during activation.
            retirement = {'status': 'PRESERVED_EXISTING_HISTORY'}
        else:
            retirement = retire_completed_github_request(p)
        if retirement.get("status") == "RUNNING_NOT_CANCELLED":
            raise RuntimeError("retired Git worktree Job is already running; no new Worker will be launched")
        # Only the v0.4.18 package-owned Bootstrap request is allowed to
        # retire previous *bundled* Linux requests. Never cancel other jobs.
        if any(isinstance(item, dict) and item.get("job_id") == BOOTSTRAP_JOB_ID_V0418
               and item.get("profile") == "skill-updater-bootstrap-apply-linux" for item in raw["jobs"]):
            old_linux = retire_old_bundled_linux_requests_v0418(p)
            if old_linux.get("status") == "OLD_REQUEST_RUNNING":
                raise RuntimeError("old bundled Linux request still running; abort Bootstrap activation")
            # The release authorizes *only* the Bootstrap Job. Never launch a
            # worker which could execute some unrelated pre-existing pending Job.
            other_pending = [str(j.get("job_id") or "") for j in load_queue(p)
                             if str(j.get("job_id") or "") != BOOTSTRAP_JOB_ID_V0418]
            if other_pending:
                raise RuntimeError("OTHER_PENDING_JOBS_NOT_AUTHORIZED_IN_BOOTSTRAP_ONLY_RELEASE: "
                                   + ", ".join(other_pending[:10]))
        profiles = load_profiles(p)
        for item in raw["jobs"]:
            if not isinstance(item, dict):
                outcomes.append({"status": "REJECTED", "error": "job must be object"}); continue
            extra = sorted(set(item) - REQUEST_JOB_KEYS)
            jid = str(item.get("job_id") or "")
            profile = str(item.get("profile") or "")
            requested_platform = "any"
            if extra:
                error = "forbidden job fields: " + ", ".join(extra)
            elif not ID_RE.fullmatch(jid):
                error = "job_id missing/invalid"
            elif not PROFILE_RE.fullmatch(profile):
                error = "profile missing/invalid"
            else:
                try:
                    requested_platform = normalize_request_platform(item.get("platform"))
                    error = ""
                except Exception as exc:
                    error = str(exc)
            if error:
                rec = {"job_id": jid or None, "profile": profile or None, "platform": item.get("platform", "any"), "status": "REJECTED", "error": error}
                outcomes.append(rec)
                if ID_RE.fullmatch(jid):
                    known = processed_ids(p) | {str(x.get("job_id") or "") for x in load_queue(p)}
                    if jid not in known:
                        _terminal_activation_record(p, jid, profile, "REJECTED", error)
                continue
            known = processed_ids(p) | {str(x.get("job_id") or "") for x in load_queue(p)}
            if jid in known:
                outcomes.append({"job_id": jid, "profile": profile, "platform": requested_platform, "status": "DUPLICATE_SKIPPED"}); continue
            local_platform = current_platform()
            if not platform_matches(requested_platform, local_platform):
                outcomes.append({"job_id": jid, "profile": profile, "platform": requested_platform,
                                 "local_platform": local_platform, "status": "TARGET_MISMATCH"})
                continue
            try:
                if is_expired(item.get("expires_at")):
                    rec = _terminal_activation_record(p, jid, profile, "EXPIRED", "expires_at is in the past")
                    outcomes.append(rec); continue
                priority = item.get("priority", 50)
                if not isinstance(priority, int) or isinstance(priority, bool):
                    raise RuntimeError("priority must be integer 0..100")
                job, effects = _enqueue_job_with_effects(p, profiles, profile, jid, priority,
                                                       item.get("params") or {}, item.get("expires_at"), requested_platform)
                outcomes.append({"job_id": jid, "profile": profile, "platform": requested_platform, "state": "PENDING", "status": "QUEUED", "job": job, "supersede": effects})
            except Exception as exc:
                error = f"{type(exc).__name__}: {exc}"
                _terminal_activation_record(p, jid, profile, "REJECTED", error)
                outcomes.append({"job_id": jid, "profile": profile, "platform": requested_platform, "status": "REJECTED", "error": error})
        status = "PASS"
        error = None
    except Exception as exc:
        status = "FAIL"; error = f"{type(exc).__name__}: {exc}"
    summary = {"schema_version": 1, "producer": "job-list-activation", "version": VERSION, "status": status,
               "source": str(source), "local_platform": current_platform(), "started_at": started, "completed_at": now_iso(), "outcomes": outcomes,
               "retired_git_job": retirement,
               "queued": sum(1 for x in outcomes if x.get("status") == "QUEUED"),
               "rejected": sum(1 for x in outcomes if x.get("status") == "REJECTED"),
               "expired": sum(1 for x in outcomes if x.get("status") == "EXPIRED"),
               "duplicates": sum(1 for x in outcomes if x.get("status") == "DUPLICATE_SKIPPED"),
               "target_mismatch": sum(1 for x in outcomes if x.get("status") == "TARGET_MISMATCH"),
               "legacy_recovery_superseded_pending": sum(len((x.get("supersede") or {}).get("legacy_recovery_superseded_pending") or []) for x in outcomes),
               "superseded_pending": sum(len((x.get("supersede") or {}).get("superseded_pending") or []) for x in outcomes),
               "supersede_requested": sum(1 for x in outcomes if isinstance((x.get("supersede") or {}).get("running_supersede"), dict)),
               "supersede_forced": sum(1 for x in outcomes if bool(((x.get("supersede") or {}).get("running_supersede") or {}).get("forced"))),
               "pending_after": len(load_queue(p)), "error": error}
    atomic_json(p["activation_latest"], summary); append_jsonl(p["activation_history"], summary)
    return summary


def _systemd_user_main_pid(unit: str) -> int | None:
    systemctl = shutil.which("systemctl")
    if not systemctl:
        return None
    for _ in range(10):
        try:
            cp = subprocess.run(
                [systemctl, "--user", "show", unit, "--property=MainPID", "--value"],
                stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, timeout=2, check=False,
            )
            raw = (cp.stdout or "").strip()
            if cp.returncode == 0 and raw.isdigit() and int(raw) > 0:
                return int(raw)
        except Exception:
            return None
        time.sleep(0.05)
    return None


def _launch_worker_via_systemd_user(root: Path, p: dict[str, Path], command: list[str], log_path: Path, stream: Any) -> dict[str, Any] | None:
    """Prefer a sibling user-systemd service so updater service teardown cannot kill the worker cgroup.

    This is resilience, not a new gate: any unavailable/unsupported user-systemd path
    falls back to the existing detached Popen launch.  No persistent unit is installed.
    """
    if os.name == "nt":
        return None
    systemd_run = shutil.which("systemd-run")
    if not systemd_run:
        return None
    unit_base = f"l1sw-job-list-worker-{stamp()}-{uuid.uuid4().hex[:6]}"
    unit = unit_base + ".service"
    systemd_cmd = [
        systemd_run, "--user", "--quiet", "--collect", "--no-block",
        f"--unit={unit_base}",
        "--property=Type=exec",
        f"--property=StandardOutput=append:{log_path}",
        f"--property=StandardError=append:{log_path}",
        "--", *command,
    ]
    try:
        cp = subprocess.run(
            systemd_cmd, cwd=str(root), stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, timeout=8, check=False,
        )
    except Exception as exc:
        stream.write((f"JOB_LIST_ACTIVATION_WORKER_SYSTEMD_FALLBACK reason={type(exc).__name__}:{exc} at={now_iso()}\n").encode("utf-8", errors="replace"))
        fsync_stream(stream)
        runtime_event(p, "ACTIVATION_WORKER_SYSTEMD_FALLBACK", reason=f"{type(exc).__name__}: {exc}", log=str(log_path))
        return None
    if cp.returncode != 0:
        reason = ((cp.stderr or cp.stdout or "systemd-run failed").strip().replace("\n", " "))[:500]
        stream.write((f"JOB_LIST_ACTIVATION_WORKER_SYSTEMD_FALLBACK rc={cp.returncode} reason={reason} at={now_iso()}\n").encode("utf-8", errors="replace"))
        fsync_stream(stream)
        runtime_event(p, "ACTIVATION_WORKER_SYSTEMD_FALLBACK", returncode=cp.returncode, reason=reason, log=str(log_path))
        return None
    worker_pid = _systemd_user_main_pid(unit)
    stream.write((f"JOB_LIST_ACTIVATION_WORKER_SYSTEMD_STARTED unit={unit} pid={worker_pid or 0} at={now_iso()}\n").encode("utf-8"))
    fsync_stream(stream)
    runtime_event(p, "ACTIVATION_WORKER_SYSTEMD_STARTED", worker_pid=worker_pid, unit=unit, log=str(log_path))
    return {
        "status": "STARTED", "pid": worker_pid, "log": str(log_path),
        "command": ["python", "job_core.py", "run"],
        "supervisor": "systemd-user", "unit": unit,
    }


def launch_detached_worker(root: Path, p: dict[str, Path]) -> dict[str, Any]:
    script = root / "scripts" / "job_core.py"
    log_path = p["logs"] / f"activation_worker_{stamp()}_{uuid.uuid4().hex[:6]}.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    command = [sys.executable, "-u", str(script), "run", "--root", str(root), "--execution-class", "overnight",
               "--wait-lock-sec", "43200", "--yes"]
    stream = log_path.open("ab", buffering=0)
    stream.write((f"JOB_LIST_ACTIVATION_WORKER_SPAWN_REQUEST version={VERSION} at={now_iso()}\n").encode("utf-8"))
    fsync_stream(stream)
    try:
        systemd_result = _launch_worker_via_systemd_user(root, p, command, log_path, stream)
        if systemd_result is not None:
            return systemd_result

        kwargs: dict[str, Any] = {"cwd": str(root), "stdin": subprocess.DEVNULL, "stdout": stream, "stderr": subprocess.STDOUT, "close_fds": True}
        if os.name == "nt":
            kwargs["creationflags"] = (getattr(subprocess, "DETACHED_PROCESS", 0x00000008) |
                                       getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200) |
                                       getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000))
        else:
            # Fallback for Linux environments without a usable user-systemd bus.
            # This preserves prior behavior and intentionally does not block activation.
            kwargs["start_new_session"] = True
        proc = subprocess.Popen(command, **kwargs)
        stream.write((f"JOB_LIST_ACTIVATION_WORKER_SPAWNED pid={proc.pid} supervisor=detached-popen at={now_iso()}\n").encode("utf-8"))
        fsync_stream(stream)
        runtime_event(p, "ACTIVATION_WORKER_SPAWNED", worker_pid=int(proc.pid), supervisor="detached-popen", log=str(log_path))
        return {"status": "STARTED", "pid": proc.pid, "log": str(log_path), "command": ["python", "job_core.py", "run"],
                "supervisor": "detached-popen"}
    finally:
        stream.close()



def launch_deferred_worker_after_runtime(root: Path, p: dict[str, Path], max_wait_sec: int = 14400) -> dict[str, Any]:
    """Spawn a detached watcher that waits for the existing Job-list runtime.

    This prevents a version-change activation from being lost when the previous
    one-shot is still running.  The watcher never kills or supersedes the live
    worker; after it exits, the watcher launches the pending queue through the
    normal `run` path.
    """
    script = root / "scripts" / "job_core.py"
    log_path = p["logs"] / f"deferred_activation_{stamp()}_{uuid.uuid4().hex[:6]}.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    command = [sys.executable, "-u", str(script), "wait-launch", "--root", str(root),
               "--max-wait-sec", str(int(max_wait_sec)), "--poll-sec", "15"]
    stream = log_path.open("ab", buffering=0)
    stream.write((f"JOB_LIST_DEFERRED_LAUNCH_SPAWN_REQUEST version={VERSION} at={now_iso()}\n").encode("utf-8"))
    fsync_stream(stream)
    try:
        kwargs: dict[str, Any] = {"cwd": str(root), "stdin": subprocess.DEVNULL,
                                  "stdout": stream, "stderr": subprocess.STDOUT, "close_fds": True}
        if os.name == "nt":
            kwargs["creationflags"] = (getattr(subprocess, "DETACHED_PROCESS", 0x00000008) |
                                       getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200) |
                                       getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000))
        else:
            kwargs["start_new_session"] = True
        proc = subprocess.Popen(command, **kwargs)
        stream.write((f"JOB_LIST_DEFERRED_LAUNCH_SPAWNED pid={proc.pid} at={now_iso()}\n").encode("utf-8"))
        fsync_stream(stream)
        runtime_event(p, "DEFERRED_ACTIVATION_WATCHER_SPAWNED", watcher_pid=int(proc.pid), log=str(log_path))
        return {"status": "WAITING_FOR_LIVE_RUNTIME", "pid": proc.pid, "log": str(log_path),
                "supervisor": "detached-popen", "max_wait_sec": int(max_wait_sec)}
    finally:
        stream.close()


def cmd_wait_launch(args: argparse.Namespace) -> int:
    root = canonical_root(args.root); p = paths(root); ensure_layout(p)
    deadline = time.monotonic() + max(60, int(args.max_wait_sec or 14400))
    poll = max(2, int(args.poll_sec or 15))
    runtime_event(p, "DEFERRED_ACTIVATION_WATCHER_START", watcher_pid=os.getpid(), max_wait_sec=int(args.max_wait_sec or 14400))
    while time.monotonic() < deadline:
        recovery = recover_stale_runtime(p)
        if not recovery.get("blocking_live_process"):
            queued = len(load_queue(p))
            if queued <= 0:
                runtime_event(p, "DEFERRED_ACTIVATION_WATCHER_NO_PENDING", watcher_pid=os.getpid())
                return 0
            runtime_event(p, "DEFERRED_ACTIVATION_WATCHER_HANDOFF", watcher_pid=os.getpid(), queued=queued)
            ns = argparse.Namespace(root=str(root), execution_class="overnight", window_end=None,
                                    wait_lock_sec=30.0, max_jobs=None, yes=True)
            return cmd_run(ns)
        time.sleep(poll)
    runtime_event(p, "DEFERRED_ACTIVATION_WATCHER_TIMEOUT", watcher_pid=os.getpid(), queued=len(load_queue(p)))
    return 3


def action_command(skill_root: Path, action: str, args: list[str]) -> list[str]:
    # Prefer lifecycle/actions.json when a target Skill exposes it.
    path = skill_root / "lifecycle" / "actions.json"
    raw = read_json(path, {})
    actions = raw.get("actions") if isinstance(raw, dict) else None
    spec = actions.get(action) if isinstance(actions, dict) else None
    if not isinstance(spec, dict):
        # Private Skills commonly use skillsilent/policy.json as their deterministic action contract.
        path = skill_root / "skillsilent" / "policy.json"
        raw = read_json(path, {})
        actions = raw.get("actions") if isinstance(raw, dict) else None
        spec = actions.get(action) if isinstance(actions, dict) else None
    if not isinstance(spec, dict):
        raise RuntimeError(f"action contract missing: {skill_root.name}/{action}")
    entry = str(spec.get("entrypoint") or "").strip()
    if not entry:
        raise RuntimeError("action entrypoint missing")
    prefix = spec.get("prefix_args", [])
    if not isinstance(prefix, list) or not all(isinstance(x, str) for x in prefix):
        raise RuntimeError("action prefix_args invalid")
    return entrypoint_command(skill_root, entry, [*prefix, *args])


def entrypoint_command(skill_root: Path, entrypoint: str, args: list[str]) -> list[str]:
    candidate = (skill_root / entrypoint).resolve()
    try:
        candidate.relative_to(skill_root.resolve())
    except ValueError:
        raise RuntimeError("entrypoint escapes target Skill root")
    if not candidate.is_file():
        raise RuntimeError(f"entrypoint missing: {candidate}")
    suffix = candidate.suffix.lower()
    if suffix == ".py":
        return [sys.executable, "-u", str(candidate), *args]
    if os.name == "nt" and suffix in {".cmd", ".bat"}:
        return [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", str(candidate), *args]
    return [str(candidate), *args]


class DependencyNotReady(RuntimeError):
    pass


def _version_tuple(value: str) -> tuple[int, ...]:
    parts = [int(x) for x in str(value).strip().lstrip("vV").split(".")]
    return tuple(parts + [0] * (4 - len(parts)))


def ensure_min_skill_version(skill_root: Path, required: str | None, wait_sec: int = 0) -> str | None:
    if not required:
        return None
    deadline = time.monotonic() + max(0, int(wait_sec or 0))
    version_file = skill_root / "VERSION"
    observed = None
    while True:
        if version_file.is_file():
            try:
                observed = version_file.read_text(encoding="utf-8").strip().lstrip("vV")
                if _version_tuple(observed) >= _version_tuple(required):
                    return observed
            except Exception:
                observed = None
        if time.monotonic() >= deadline:
            raise DependencyNotReady(f"target Skill version not ready: {skill_root.name} observed={observed or 'missing'} required>={required}")
        time.sleep(2.0)


def resolve_profile_command(root: Path, profile_name: str, spec: dict[str, Any], job: dict[str, Any] | None = None) -> tuple[list[str], Path, int, int, list[str], dict[str, str], Path | None, bool]:
    private_root = private_skills_root(root)
    skill = str(spec["skill"])
    skill_root = (private_root / skill).resolve()
    if not skill_root.is_dir():
        raise RuntimeError(f"target Skill root missing: {skill_root}")
    ensure_min_skill_version(skill_root, str(spec.get("min_skill_version") or "") or None, int(spec.get("dependency_wait_sec", 0) or 0))
    args = [str(x) for x in spec.get("args", [])]
    args.extend(render_profile_params(skill_root, profile_name, spec, (job or {}).get("params") or {}))
    action = str(spec.get("action") or "").strip()
    command = action_command(skill_root, action, args) if action else entrypoint_command(skill_root, str(spec.get("entrypoint") or ""), args)
    working = expand_path(str(spec.get("working_dir") or skill_root), skill_root)
    if not working.is_dir():
        raise RuntimeError(f"working_dir missing: {working}")
    timeout = int(spec.get("timeout_sec", 3600)); retry = int(spec.get("retry", 0))
    required_outputs = [str(x) for x in spec.get("required_outputs", [])]
    env_extra = {str(k): str(v) for k, v in (spec.get("env") or {}).items()}
    semantic_raw = spec.get("semantic_result_path")
    semantic_path = expand_path(str(semantic_raw), skill_root) if semantic_raw else None
    semantic_required = bool(spec.get("semantic_result_required", False))
    return command, working, timeout, retry, required_outputs, env_extra, semantic_path, semantic_required


def output_exists(value: str, working: Path) -> bool:
    p = expand_path(value, working)
    return p.exists()


def seconds_until_window_end(value: str | None) -> float | None:
    if not value:
        return None
    try:
        hh, mm = [int(x) for x in value.split(":", 1)]
        current = dt.datetime.now().astimezone()
        end = current.replace(hour=hh, minute=mm, second=0, microsecond=0)
        if end <= current:
            end += dt.timedelta(days=1)
        return (end - current).total_seconds()
    except Exception:
        return None


def read_semantic_result(path: Path | None) -> dict[str, Any] | None:
    if path is None or not path.is_file():
        return None
    raw = read_json(path, None)
    return raw if isinstance(raw, dict) else None


def _clean_short_text(value: Any, limit: int = 240) -> str | None:
    if value is None:
        return None
    text = " ".join(str(value).replace("\r", " ").replace("\n", " ").split()).strip()
    return text[:limit] if text else None


def normalize_observer_result(semantic: dict[str, Any] | None, execution_status: str) -> dict[str, Any] | None:
    """Return a fail-closed, path-free observer-result/v1 payload.

    Producers may expose the contract as the semantic result itself or under
    ``observer_result``. Unknown fields are intentionally discarded so Job-list
    receipts remain stable and safe for generic local observers.
    """
    if not isinstance(semantic, dict):
        return None
    candidate = semantic.get("observer_result") if isinstance(semantic.get("observer_result"), dict) else semantic
    if str(candidate.get("schema") or "") != OBSERVER_RESULT_SCHEMA:
        return None
    quality = str(candidate.get("quality_status") or "UNKNOWN").upper()
    if quality not in OBSERVER_QUALITY_STATUS:
        quality = "UNKNOWN"
    reasons: list[str] = []
    for value in candidate.get("reason_codes") or []:
        code = str(value or "").strip().upper()
        if REASON_CODE_RE.fullmatch(code) and code not in reasons:
            reasons.append(code)
        if len(reasons) >= 20:
            break
    artifact_count = candidate.get("artifact_count", 0)
    if not isinstance(artifact_count, int) or isinstance(artifact_count, bool) or artifact_count < 0:
        artifact_count = 0
    out: dict[str, Any] = {
        "schema": OBSERVER_RESULT_SCHEMA,
        "execution_status": execution_status if execution_status in OBSERVER_EXECUTION_STATUS else "UNKNOWN",
        "quality_status": quality,
        "reason_codes": reasons,
        "artifact_count": min(artifact_count, 1000000),
        "user_action_required": bool(candidate.get("user_action_required", False)),
    }
    for key in ("producer", "subject", "summary", "external_summary"):
        text = _clean_short_text(candidate.get(key))
        if text is not None:
            out[key] = text
    return out


def aggregate_observer_result(outcomes: list[dict[str, Any]], job_status: str) -> dict[str, Any] | None:
    rows = [x.get("observer_result") for x in outcomes if isinstance(x.get("observer_result"), dict)]
    if not rows:
        return None
    qualities = {str(x.get("quality_status") or "UNKNOWN").upper() for x in rows}
    quality = next((q for q in OBSERVER_QUALITY_PRECEDENCE if q in qualities), "UNKNOWN")
    reasons: list[str] = []
    subjects: list[str] = []
    artifact_count = 0
    action = False
    for row in rows:
        artifact_count += int(row.get("artifact_count") or 0)
        action = action or bool(row.get("user_action_required"))
        subject = _clean_short_text(row.get("subject"), 80)
        if subject and subject not in subjects:
            subjects.append(subject)
        for code in row.get("reason_codes") or []:
            if code not in reasons:
                reasons.append(code)
    if job_status == "SUCCESS":
        execution = "SUCCESS"
    elif job_status == "FAILED":
        execution = "FAILED"
    else:
        execution = "UNKNOWN"
    out: dict[str, Any] = {
        "schema": OBSERVER_RESULT_SCHEMA,
        "producer": "job-list-core",
        "execution_status": execution,
        "quality_status": quality,
        "reason_codes": reasons[:20],
        "artifact_count": min(artifact_count, 1000000),
        "user_action_required": action,
    }
    if len(subjects) == 1:
        out["subject"] = subjects[0]
    elif subjects:
        out["subject"] = "multiple"
    return out


def aggregate_semantic_status(outcomes: list[dict[str, Any]]) -> str | None:
    statuses = {str(x.get("semantic_status") or "").upper() for x in outcomes if x.get("semantic_status")}
    for status in SEMANTIC_PRECEDENCE:
        if status in statuses:
            return status
    return sorted(statuses)[0] if statuses else None


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if pid == os.getpid():
        return True
    try:
        if os.name == "nt":
            completed = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/NH"], capture_output=True, text=True, timeout=5)
            return completed.returncode == 0 and str(pid) in (completed.stdout or "")
        os.kill(pid, 0)
        return True
    except PermissionError:
        return True
    except Exception:
        return False


def lock_owner(path: Path) -> tuple[int | None, str | None]:
    try:
        text = path.read_text(encoding="utf-8", errors="replace").strip()
        if not text:
            return None, None
        parts = text.split(maxsplit=1)
        return int(parts[0]), parts[1] if len(parts) > 1 else None
    except Exception:
        return None, None


def recover_dead_lock(path: Path, stale_seconds: int = 86400) -> dict[str, Any] | None:
    if not path.is_file():
        return None
    pid, started_at = lock_owner(path)
    try:
        age_sec = max(0.0, time.time() - path.stat().st_mtime)
    except Exception:
        age_sec = 0.0
    dead = pid is not None and not pid_alive(pid)
    malformed_stale = pid is None and age_sec >= stale_seconds
    if dead or malformed_stale:
        path.unlink(missing_ok=True)
        return {"path": str(path), "pid": pid, "started_at": started_at, "age_sec": int(age_sec),
                "reason": "DEAD_PID" if dead else "MALFORMED_STALE_LOCK"}
    return None


def recover_stale_runtime(p: dict[str, Path]) -> dict[str, Any]:
    """Recover interrupted runtime without inventing new hard gates.

    Key invariant: a dead worker + dead/missing child + no terminal receipt is an
    interrupted *attempt*, not proof that the one-shot Job itself was consumed.
    The Job is left queued (or restored from the running snapshot) so a later
    activation can retry it.  If an orphan child is still alive, recovery blocks
    a duplicate launch until that real process exits.
    """
    recovered: list[dict[str, Any]] = []
    blocking_live_process = False
    running = read_json(p["running"], {}) if p["running"].is_file() else None

    if isinstance(running, dict) and running:
        try:
            worker_pid = int(running.get("worker_pid") or running.get("pid") or 0)
        except Exception:
            worker_pid = 0
        try:
            child_pid = int(running.get("child_pid") or 0)
        except Exception:
            child_pid = 0
        worker_live = worker_pid > 0 and pid_alive(worker_pid)
        child_live = child_pid > 0 and pid_alive(child_pid)
        job_id = str(running.get("job_id") or "")
        run_id = str(running.get("run_id") or "")
        receipt = None
        receipt_path = None
        raw_receipt = str(running.get("completion_receipt") or "").strip()
        if raw_receipt:
            receipt_path = expand_path(raw_receipt, p["root"])
        elif run_id and job_id:
            receipt_path = job_receipt_path(p, run_id, job_id)
        if receipt_path is not None and receipt_path.is_file():
            candidate = read_json(receipt_path, None)
            if isinstance(candidate, dict):
                receipt = candidate

        if not worker_live and child_live:
            blocking_live_process = True
            reason = "ORPHAN_CHILD_ALIVE"
            if running.get("recovery_state") != reason:
                running = {**running, "recovery_state": reason, "recovery_observed_at": now_iso()}
                atomic_json(p["running"], running)
                runtime_event(p, "ORPHAN_CHILD_ALIVE", job_id=job_id or None, run_id=run_id or None,
                              worker_pid=worker_pid or None, child_pid=child_pid)
            recovered.append({"type": "RUNNING_MARKER", "job_id": job_id or None, "run_id": run_id or None,
                              "worker_pid": worker_pid or None, "child_pid": child_pid,
                              "reason": reason, "blocking": True})
        elif not worker_live:
            # The real process is gone.  Prefer an already-written terminal
            # receipt; otherwise terminalize only the interrupted attempt and
            # preserve/restore the one-shot Job for a later activation.
            if isinstance(receipt, dict):
                with FileLock(p["queue_lock"], wait_seconds=10):
                    jobs = load_queue(p)
                    if job_id:
                        jobs = [x for x in jobs if str(x.get("job_id") or "") != job_id]
                        save_queue(p, jobs)
                if job_id and job_id not in processed_ids(p):
                    append_jsonl(p["processed"], {**receipt, "recovered_from_receipt": True,
                                                  "recovered_at": now_iso()})
                reason = "TERMINAL_RECEIPT_RECOVERED"
                recovered.append({"type": "RUNNING_MARKER", "job_id": job_id or None, "run_id": run_id or None,
                                  "worker_pid": worker_pid or None, "child_pid": child_pid or None,
                                  "reason": reason, "receipt": str(receipt_path) if receipt_path else None})
                runtime_event(p, reason, job_id=job_id or None, run_id=run_id or None,
                              receipt=str(receipt_path) if receipt_path else None)
            else:
                stop = _read_stop_request(p, job_id) if job_id else None
                requeued = False
                if isinstance(stop, dict) and job_id:
                    if job_id not in processed_ids(p):
                        append_jsonl(p["processed"], {
                            "schema_version": 1, "job_id": job_id, "profile": running.get("profile"),
                            "platform": running.get("platform", "any"), "state": "CONSUMED", "status": "SUPERSEDED",
                            "superseded_by": stop.get("superseded_by"), "completed_at": now_iso(),
                            "source": "runtime-recovery", "recovery_reason": "INTERRUPTED_WITH_SUPERSEDE_REQUEST",
                        })
                    reason = "INTERRUPTED_WITH_SUPERSEDE_REQUEST"
                else:
                    snapshot = running.get("job_snapshot")
                    if isinstance(snapshot, dict) and job_id and job_id not in processed_ids(p):
                        with FileLock(p["queue_lock"], wait_seconds=10):
                            jobs = load_queue(p)
                            if not any(str(x.get("job_id") or "") == job_id for x in jobs):
                                jobs.append(dict(snapshot))
                                save_queue(p, jobs)
                                requeued = True
                    reason = "INTERRUPTED_NO_RECEIPT"
                attempt_receipt = {
                    "schema_version": 1, "producer": "job-list-core", "version": VERSION,
                    "job_id": job_id or None, "profile": running.get("profile"), "platform": running.get("platform", "any"),
                    "run_id": run_id or None, "attempt": running.get("attempt"), "status": "INTERRUPTED",
                    "state": "RECOVERABLE" if reason == "INTERRUPTED_NO_RECEIPT" else "CONSUMED",
                    "recoverable": reason == "INTERRUPTED_NO_RECEIPT", "requeued": requeued,
                    "worker_pid": worker_pid or None, "child_pid": child_pid or None,
                    "recovery_reason": reason, "recovered_at": now_iso(),
                }
                recovery_receipt = p["runs"] / (run_id or "unknown") / "recovery_receipt.json"
                atomic_json(recovery_receipt, attempt_receipt)
                atomic_json(p["recovery_latest"], attempt_receipt)
                runtime_event(p, reason, job_id=job_id or None, run_id=run_id or None,
                              worker_pid=worker_pid or None, child_pid=child_pid or None,
                              requeued=requeued, recovery_receipt=str(recovery_receipt))
                recovered.append({"type": "RUNNING_MARKER", "job_id": job_id or None, "run_id": run_id or None,
                                  "worker_pid": worker_pid or None, "child_pid": child_pid or None,
                                  "reason": reason, "requeued": requeued, "recovery_receipt": str(recovery_receipt)})
            p["running"].unlink(missing_ok=True)

    # Recover dead locks after inspecting child liveness.  A live orphan child
    # must keep the run lane closed even though its worker process is gone.
    for key in ("lock", "queue_lock"):
        if key == "lock" and blocking_live_process:
            continue
        item = recover_dead_lock(p[key])
        if item:
            recovered.append({"type": "LOCK", **item})
            runtime_event(p, "DEAD_LOCK_RECOVERED", lock=key, **item)

    current = read_json(p["observer_current"], {}) if p["observer_current"].is_file() else None
    if isinstance(current, dict) and current and not blocking_live_process:
        live_running = False
        if p["running"].is_file():
            row = read_json(p["running"], {})
            try:
                live_running = pid_alive(int(row.get("worker_pid") or row.get("pid") or 0)) or pid_alive(int(row.get("child_pid") or 0))
            except Exception:
                live_running = False
        live_lock = False
        if p["lock"].is_file():
            owner, _ = lock_owner(p["lock"])
            live_lock = bool(owner and pid_alive(owner))
        if not live_running and not live_lock:
            interrupted = {**current, "status": "FAIL", "job_status": "INTERRUPTED", "completed_at": now_iso(),
                           "recovery_reason": "STALE_CURRENT_RUN"}
            atomic_json(p["observer_latest"], interrupted)
            append_jsonl(p["observer_history"], interrupted)
            recovered.append({"type": "OBSERVER_CURRENT", "run_id": current.get("run_id"), "started_at": current.get("started_at"),
                              "reason": "NO_LIVE_OWNER"})
            runtime_event(p, "STALE_OBSERVER_RECOVERED", run_id=current.get("run_id"))
            p["observer_current"].unlink(missing_ok=True)

    payload = {"recovered": recovered, "count": len(recovered), "blocking_live_process": blocking_live_process}
    if recovered:
        atomic_json(p["recovery_latest"], {"schema_version": 1, "version": VERSION, "at": now_iso(), **payload})
    return payload


class FileLock:
    def __init__(self, path: Path, wait_seconds: float = 0):
        self.path = path; self.acquired = False; self.wait_seconds = max(0.0, float(wait_seconds))
    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        deadline = time.monotonic() + self.wait_seconds
        while True:
            recover_dead_lock(self.path)
            try:
                fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.write(fd, f"{os.getpid()} {now_iso()}\n".encode()); os.close(fd); self.acquired = True
                return self
            except FileExistsError:
                if time.monotonic() >= deadline:
                    owner, started_at = lock_owner(self.path)
                    raise RuntimeError(f"lock busy: {self.path} owner_pid={owner} started_at={started_at}")
                time.sleep(0.25)
    def __exit__(self, *_):
        if self.acquired:
            self.path.unlink(missing_ok=True)


def execute_job(root: Path, p: dict[str, Path], job: dict[str, Any], profile: dict[str, Any], run_id: str, window_end: str | None) -> dict[str, Any]:
    job_id = str(job["job_id"]); started = now_iso()
    base = {"job_id": job_id, "profile": job["profile"], "platform": job.get("platform", "any"), "state": "RUNNING", "execution_class": "overnight", "started_at": started, "run_id": run_id}
    profile_errors = validate_profile(str(job["profile"]), profile)
    if profile_errors:
        return {**base, "state": "CONSUMED", "status": "REJECTED", "attempts": 0, "returncode": 2,
                "error": "invalid profile at execution: " + " | ".join(profile_errors), "completed_at": now_iso()}
    try:
        command, working, timeout, retry, required_outputs, env_extra, semantic_path, semantic_required = resolve_profile_command(root, str(job["profile"]), profile, job)
    except DependencyNotReady as exc:
        return {**base, "state": "PENDING", "status": "DEFERRED_DEPENDENCY", "attempts": 0, "returncode": None, "error": str(exc), "completed_at": now_iso()}
    except Exception as exc:
        return {**base, "state": "CONSUMED", "status": "FAILED", "attempts": 0, "returncode": 2, "error": str(exc), "completed_at": now_iso()}

    max_attempts = 1 + retry; attempts = 0; last_rc = None; last_status = "FAILED"; last_error = None
    semantic_before = semantic_path.read_bytes() if semantic_path is not None and semantic_path.is_file() else None
    log_path = p["logs"] / f"{run_id}_{job_id}.log"; log_path.parent.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ); env.update(env_extra)
    env.update({
        "JOB_LIST_JOB_ID": job_id, "JOB_LIST_PROFILE": str(job["profile"]), "JOB_LIST_PLATFORM": str(job.get("platform", "any")), "JOB_LIST_RUN_ID": run_id,
        "JOB_LIST_OUTPUT_ROOT": str(p["root"] / "output"), "PYTHONIOENCODING": "utf-8", "PYTHONUNBUFFERED": "1",
    })
    while attempts < max_attempts:
        remaining = seconds_until_window_end(window_end)
        if remaining is not None and remaining < timeout:
            if attempts == 0:
                return {**base, "state": "PENDING", "status": "DEFERRED_WINDOW", "attempts": 0, "returncode": None,
                        "error": f"remaining_window_sec={int(remaining)} < timeout_sec={timeout}", "completed_at": now_iso()}
            break
        attempts += 1
        stop_path = _stop_request_path(p, job_id)
        env["JOB_LIST_STOP_REQUEST"] = str(stop_path)
        pre_stop = _read_stop_request(p, job_id)
        if isinstance(pre_stop, dict):
            last_status = "SUPERSEDED"; last_error = f"superseded_by={pre_stop.get('superseded_by')}"; last_rc = None
            break
        receipt_path = job_receipt_path(p, run_id, job_id)
        running_base = {**base, "attempt": attempts, "pid": os.getpid(), "worker_pid": os.getpid(),
                        "working_dir": str(working), "log": str(log_path), "stop_request": str(stop_path),
                        "completion_receipt": str(receipt_path), "job_snapshot": dict(job)}
        atomic_json(p["running"], {**running_base, "status": "STARTING"})
        runtime_event(p, "JOB_STARTING", job_id=job_id, profile=job.get("profile"), run_id=run_id, attempt=attempts,
                      worker_pid=os.getpid(), completion_receipt=str(receipt_path))
        with log_path.open("a", encoding="utf-8", buffering=1) as log:
            log.write(f"=== job={job_id} profile={job['profile']} attempt={attempts}/{max_attempts} at {now_iso()} ===\n")
            log.write("command=" + subprocess.list2cmdline(command) + "\n")
            fsync_stream(log)
            proc = None
            try:
                popen_kwargs: dict[str, Any] = {
                    "cwd": str(working), "env": env, "stdin": subprocess.DEVNULL,
                    "stdout": log, "stderr": subprocess.STDOUT,
                }
                if os.name == "nt":
                    popen_kwargs["creationflags"] = (getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200))
                else:
                    popen_kwargs["start_new_session"] = True
                proc = subprocess.Popen(command, **popen_kwargs)
                child_pid = int(proc.pid)
                child_pgid = child_pid if os.name != "nt" else 0
                atomic_json(p["running"], {**running_base, "status": "RUNNING", "child_pid": child_pid, "child_pgid": child_pgid or None, "spawned_at": now_iso()})
                runtime_event(p, "CHILD_SPAWNED", job_id=job_id, run_id=run_id, attempt=attempts, worker_pid=os.getpid(),
                              child_pid=child_pid, child_pgid=child_pgid or None)
                log.write(f"child_spawned pid={child_pid} pgid={child_pgid or ''} at={now_iso()}\n")
                fsync_stream(log)
                try:
                    last_rc = int(proc.wait(timeout=timeout))
                    runtime_event(p, "CHILD_EXIT", job_id=job_id, run_id=run_id, attempt=attempts, child_pid=child_pid, returncode=last_rc)
                    log.write(f"child_exit pid={child_pid} returncode={last_rc} at={now_iso()}\n")
                    fsync_stream(log)
                except subprocess.TimeoutExpired:
                    _terminate_process_tree(child_pid, child_pgid or None, force=False)
                    try:
                        proc.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        _terminate_process_tree(child_pid, child_pgid or None, force=True)
                        try: proc.wait(timeout=2)
                        except subprocess.TimeoutExpired: pass
                    last_rc = 124; last_status = "TIMEOUT"; last_error = f"timeout_sec={timeout}"
                    break
                stop = _read_stop_request(p, job_id)
                if isinstance(stop, dict):
                    last_status = "SUPERSEDED"
                    last_error = f"superseded_by={stop.get('superseded_by')}"
                    break
                if last_rc == 0:
                    missing = [x for x in required_outputs if not output_exists(x, working)]
                    if missing:
                        last_status = "OUTPUT_MISSING"; last_error = "missing outputs: " + ", ".join(missing)
                    else:
                        semantic_bytes = semantic_path.read_bytes() if semantic_path is not None and semantic_path.is_file() else None
                        semantic_fresh = semantic_bytes is not None and semantic_bytes != semantic_before
                        if semantic_required and not semantic_fresh:
                            last_status = "OUTPUT_MISSING"; last_error = f"fresh semantic result missing: {semantic_path}"
                        else:
                            last_status = "SUCCESS"; last_error = None
                            break
                else:
                    last_status = "FAILED"; last_error = f"returncode={last_rc}"
            except Exception as exc:
                if proc is not None and proc.poll() is None:
                    _terminate_process_tree(int(proc.pid), int(proc.pid) if os.name != "nt" else None, force=True)
                last_rc = 127; last_status = "FAILED"; last_error = f"{type(exc).__name__}: {exc}"
                runtime_event(p, "JOB_EXCEPTION", job_id=job_id, run_id=run_id, attempt=attempts, error=last_error)
                log.write(f"job_exception error={last_error} at={now_iso()}\n")
                fsync_stream(log)
    stop = _read_stop_request(p, job_id)
    semantic_bytes = semantic_path.read_bytes() if semantic_path is not None and semantic_path.is_file() else None
    semantic_fresh = semantic_bytes is not None and semantic_bytes != semantic_before
    semantic = read_semantic_result(semantic_path) if last_status == "SUCCESS" and semantic_fresh else None
    result = {**base, "state": "CONSUMED", "status": last_status, "attempts": attempts, "returncode": last_rc,
              "error": last_error, "completed_at": now_iso(), "log": str(log_path)}
    if last_status == "SUPERSEDED" and isinstance(stop, dict):
        result["superseded_by"] = stop.get("superseded_by")
        result["supersede_requested_at"] = stop.get("requested_at")
    _stop_request_path(p, job_id).unlink(missing_ok=True)
    if semantic is not None:
        if (job.get("profile") == "l1-github-worktree-preview-linux"
                and semantic.get("status") == "PREVIEW_READY"
                and isinstance(semantic.get("approval_token"), str)):
            result["approval_token"] = semantic["approval_token"]
            result["approval_expires_at"] = semantic.get("approval_expires_at")
            result["linked_head"] = semantic.get("linked_head")
        result.update({
            "semantic_status": str(semantic.get("status") or "").upper() or None,
            "semantic_run_id": semantic.get("run_id"),
            "semantic_completed_at": semantic.get("completed_at"),
            "semantic_result": str(semantic_path),
            "terminal_signal_sent": bool(semantic.get("terminal_signal_sent")),
        })
        observer_result = normalize_observer_result(semantic, last_status)
        if observer_result is not None:
            result["observer_result"] = observer_result
    receipt_path = job_receipt_path(p, run_id, job_id)
    atomic_json(receipt_path, result)
    runtime_event(p, "JOB_RECEIPT_WRITTEN", job_id=job_id, run_id=run_id, status=last_status,
                  returncode=last_rc, receipt=str(receipt_path))
    if p["running"].is_file():
        marker = read_json(p["running"], {})
        if isinstance(marker, dict) and str(marker.get("job_id") or "") == job_id:
            atomic_json(p["running"], {**marker, "status": "RECEIPT_WRITTEN", "receipt_written_at": now_iso(),
                                       "completion_receipt": str(receipt_path)})
    p["running"].unlink(missing_ok=True)
    return result


def cmd_validate(args: argparse.Namespace) -> int:
    root = canonical_root(args.root); p = paths(root); ensure_layout(p); profiles = load_profiles(p)
    errors: list[str] = []
    for name, spec in sorted(profiles.items()):
        errors.extend(validate_profile(name, spec))
    payload = {"schema_version": 1, "version": VERSION, "profiles": len(profiles), "errors": errors, "status": "PASS" if not errors else "FAIL"}
    print(json.dumps(payload, ensure_ascii=False, indent=2)); return 0 if not errors else 1


def cmd_enqueue(args: argparse.Namespace) -> int:
    root = canonical_root(args.root); p = paths(root); ensure_layout(p); profiles = load_profiles(p)
    try:
        raw_params = json.loads(args.params_json) if args.params_json else {}
        job = enqueue_job(p, profiles, args.profile, args.job_id, args.priority, raw_params, args.expires_at, args.platform)
    except Exception as exc:
        print(json.dumps({"status": "REJECTED", "error": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr); return 2
    print(json.dumps({"status": "QUEUED", "job": job}, ensure_ascii=False, indent=2)); return 0


def cmd_activate(args: argparse.Namespace) -> int:
    if current_platform() != 'linux':
        print(json.dumps({'status':'BLOCKED','reason':'LINUX_ONLY_RELEASE','worker_launched':False}))
        return 2
    root = canonical_root(args.root); p = paths(root); ensure_layout(p)
    recovery = recover_stale_runtime(p)
    source = expand_path(args.source, root)
    summary = activate_request_document(root, p, source)
    summary["runtime_recovery"] = recovery
    if args.launch and summary.get("pending_after", 0) > 0 and summary.get("status") == "PASS":
        if recovery.get("blocking_live_process"):
            # v0.3.75: do not kill/supersede the previous CL-AIT run and do not
            # lose this version-change activation. A detached watcher waits for
            # the live runtime to end, then starts the pending queue normally.
            try:
                summary["worker"] = launch_deferred_worker_after_runtime(root, p)
            except Exception as exc:
                summary["worker"] = {"status": "FAILED", "error": f"{type(exc).__name__}: {exc}"}
                summary["status"] = "FAIL"
                summary["error"] = "deferred worker launch failed"
        else:
            try:
                summary["worker"] = launch_detached_worker(root, p)
            except Exception as exc:
                summary["worker"] = {"status": "FAILED", "error": f"{type(exc).__name__}: {exc}"}
                summary["status"] = "FAIL"
                summary["error"] = "detached worker launch failed"
        atomic_json(p["activation_latest"], summary); append_jsonl(p["activation_history"], {**summary, "event": "worker-launch"})
    # V0409 external observability: a queued/accepted Windows recovery emits a
    # non-terminal breadcrumb before the detached worker is relied upon.  This
    # makes "no signal at all" evidence of an earlier updater/activation fault.
    target = next((x for x in summary.get("outcomes", []) if x.get("job_id") == DISPATCHER_RECOVERY_V0409_JOB_ID), None)
    if isinstance(target, dict) and target.get("status") != "TARGET_MISMATCH":
        worker = summary.get("worker") if isinstance(summary.get("worker"), dict) else {}
        if summary.get("status") != "PASS" or target.get("status") in {"REJECTED", "EXPIRED"} or worker.get("status") == "FAILED":
            summary["external_signal_v0409_activation"] = emit_dispatcher_recovery_signal("job-list-fail")
        elif target.get("status") in {"QUEUED", "DUPLICATE_SKIPPED"}:
            summary["external_signal_v0409_activation"] = emit_dispatcher_recovery_signal("job-list-deferred")
        atomic_json(p["activation_latest"], summary)
        append_jsonl(p["activation_history"], {**summary, "event": "external-signal"})
    from job_bootstrap_status import activation_output
    print(activation_output(summary, root))
    return 0 if summary.get("status") == "PASS" else 2


# v0.4.15 fixed-target, read-only Linux Cleanup result bridge.
# This function MUST NOT call ensure_layout/recovery/activate/run, nor create files.
LINUX_CLEANUP_JOB_ID = "JOB-20261010-LINUX-CLEANUP-30D-01"
LINUX_CLEANUP_PROFILE = "l1-cleanup-disk-recovery-linux"
LINUX_CLEANUP_MIN_FREE_BYTES = 20 * 1024**3


def read_linux_cleanup_result(root: Path) -> dict[str, Any]:
    """Read only the fixed cleanup Job's existing evidence, never trigger work."""
    p = paths(root)
    jid = LINUX_CLEANUP_JOB_ID
    activation = read_json(p["activation_latest"], {})
    if not isinstance(activation, dict):
        activation = {}
    matching = [x for x in activation.get("outcomes", []) if isinstance(x, dict) and x.get("job_id") == jid]
    last_activation = matching[-1] if matching else {}
    running = read_json(p["running"], {})
    active = isinstance(running, dict) and running.get("job_id") == jid and running.get("status") in {"RUNNING", "STARTING", "RECEIPT_WRITTEN"}
    queue = read_json(p["queue"], {})
    waiting = isinstance(queue, dict) and any(x.get("job_id") == jid for x in queue.get("jobs", []) if isinstance(x, dict))
    processed = None
    if p["processed"].is_file():
        with p["processed"].open(encoding="utf-8", errors="replace") as stream:
            for line in stream:
                if jid not in line:
                    continue
                try:
                    row = json.loads(line)
                except ValueError:
                    continue
                if isinstance(row, dict) and row.get("job_id") == jid:
                    processed = row
    semantic_path = root / "output" / "linux_disk_cleanup" / "latest_result.json"
    semantic = read_json(semantic_path, {})
    if not isinstance(semantic, dict) or semantic.get("job_id") != jid or semantic.get("profile") != LINUX_CLEANUP_PROFILE:
        semantic = {}
    # No result can prove execution unless the Job runner also has terminal evidence.
    job_status = str((processed or {}).get("status") or "")
    cleanup_status = str(semantic.get("status") or "")
    if active:
        status = "RUNNING"
    elif processed is not None:
        if job_status in {"SUCCESS", "FAILED", "TIMEOUT", "OUTPUT_MISSING", "REJECTED", "EXPIRED", "SUPERSEDED"}:
            status = job_status
        else:
            status = "UNKNOWN"
    elif waiting:
        status = "PENDING"
    elif last_activation.get("status") in {"REJECTED", "EXPIRED", "TARGET_MISMATCH"}:
        status = str(last_activation["status"])
    else:
        status = "UNKNOWN"
    confirmed = status == "SUCCESS" and cleanup_status == "SUCCESS" and bool(semantic)
    free_after = semantic.get("free_bytes_after") if semantic else None
    historical_free_known = type(free_after) is int and free_after >= 0
    # Read-only current statvfs of the same HOME measured by the Cleanup job.
    live_free = None
    if root.is_dir() and sys.platform.startswith("linux") and root.parent.is_dir():
        try:
            live_free = shutil.disk_usage(Path.home()).free
        except OSError:
            pass
    live_free_known = type(live_free) is int and live_free >= 0
    sufficient_now = bool(confirmed and historical_free_known and live_free_known
                          and live_free >= LINUX_CLEANUP_MIN_FREE_BYTES)
    if status == "SUCCESS" and cleanup_status == "INSUFFICIENT_SPACE":
        status = "INSUFFICIENT_SPACE"
    elif status == "SUCCESS" and not confirmed:
        status = "UNVERIFIED_SEMANTIC_RESULT"
    elif status == "SUCCESS" and not historical_free_known:
        status = "UNVERIFIED_FREE_SPACE"
    out: dict[str, Any] = {
        "schema": "job-list-cleanup-result-bridge/1", "bridge_version": VERSION,
        "read_only": True, "job_id": jid, "profile": LINUX_CLEANUP_PROFILE,
        "status": status, "worker_status": job_status or "UNKNOWN", "cleanup_status": cleanup_status or "UNKNOWN",
        "activation_status": last_activation.get("status") or "UNKNOWN",
        "worker_active": bool(active), "pending": bool(waiting),
        "run_id": (processed or {}).get("run_id") or semantic.get("run_id"),
        "started_at": (processed or {}).get("started_at") or semantic.get("started_at"),
        "completed_at": (processed or {}).get("completed_at") or semantic.get("completed_at"),
        "free_bytes_before": semantic.get("free_bytes_before"),
        "free_bytes_after": free_after,
        "live_free_bytes": live_free,
        "live_free_checked_at": now_iso() if live_free_known else None,
        "observed_reclaimed_bytes": semantic.get("observed_reclaimed_bytes"),
        "permanent_deleted_bytes": semantic.get("permanent_deleted_bytes"),
        "permanent_deleted_count": semantic.get("permanent_deleted_count"),
        "min_required_free_bytes": LINUX_CLEANUP_MIN_FREE_BYTES,
        "analysis_disk_ready": sufficient_now,
        "result_path": str(semantic_path) if semantic else None,
        "cleanup_report_json": semantic.get("cleanup_report_json"),
        "error": (processed or {}).get("error") or semantic.get("error") or last_activation.get("error"),
        "first_failed_stage": None,
    }
    if status in {"FAILED", "TIMEOUT", "OUTPUT_MISSING", "REJECTED", "EXPIRED"}:
        out["first_failed_stage"] = "JOB_EXECUTION" if processed else "ACTIVATION"
    elif status in {"INSUFFICIENT_SPACE", "UNVERIFIED_SEMANTIC_RESULT", "UNVERIFIED_FREE_SPACE"}:
        out["first_failed_stage"] = "RESULT_VERIFICATION"
    # Saved free_bytes_after remains a historical report; live_free_bytes
    # is collected separately by statvfs at query time.
    out["disk_reading_is_current"] = live_free_known
    return out


def cmd_cleanup_result(args: argparse.Namespace) -> int:
    root = canonical_root(args.root)
    print(json.dumps(read_linux_cleanup_result(root), ensure_ascii=False, indent=2))
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    root = canonical_root(args.root); p = paths(root); ensure_layout(p)
    recovery = recover_stale_runtime(p); jobs = load_queue(p)
    latest = read_json(p["observer_latest"], {})
    payload = {"schema_version": 1, "version": VERSION, "root": str(root), "queued": len(jobs),
               "jobs": jobs, "running": read_json(p["running"], {}) if p["running"].is_file() else None,
               "runtime_recovery": recovery, "last_result": latest}
    print(json.dumps(payload, ensure_ascii=False, indent=2)); return 0


def cmd_run(args: argparse.Namespace) -> int:
    if not args.yes:
        print("--yes required", file=sys.stderr); return 2
    root = canonical_root(args.root); p = paths(root); ensure_layout(p)
    print(f"JOB_LIST_WORKER_START version={VERSION} pid={os.getpid()} at={now_iso()}", flush=True)
    recovery = recover_stale_runtime(p)
    print("JOB_LIST_RUNTIME_RECOVERY " + json.dumps(recovery, ensure_ascii=False, sort_keys=True), flush=True)
    if recovery.get("blocking_live_process"):
        summary = {"schema_version": 1, "version": VERSION, "status": "PASS", "job_status": "DEFERRED_LIVE_RUNTIME",
                   "runtime_recovery": recovery, "queued_remaining": len(load_queue(p)), "completed_at": now_iso()}
        atomic_json(p["last"], summary)
        print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
        return 0
    started = now_iso(); run_id = f"core_{stamp()}_{uuid.uuid4().hex[:8]}"; run_dir = p["runs"] / run_id; run_dir.mkdir(parents=True, exist_ok=True)
    runtime_event(p, "WORKER_RUN_START", run_id=run_id, worker_pid=os.getpid())
    atomic_json(p["observer_current"], {"schema_version": 1, "producer": "job-list-core", "version": VERSION, "run_id": run_id, "status": "RUNNING", "started_at": started})
    outcomes: list[dict[str, Any]] = []; error = None; deferred = 0
    try:
        with FileLock(p["lock"], wait_seconds=float(getattr(args, "wait_lock_sec", 0) or 0)):
            profiles = load_profiles(p)
            with FileLock(p["queue_lock"], wait_seconds=10):
                jobs = load_queue(p)
            original_ids = {str(x.get("job_id") or "") for x in jobs}
            remaining_jobs: list[dict[str, Any]] = []; executed = 0
            for job in jobs:
                # Defense in depth: an already-started worker may have loaded an
                # older pending queue before activate retired this Job. The new
                # runner must never call the completed Worktree migration again.
                if (str(job.get("job_id") or "") == RETIRED_GITHUB_JOB_ID
                        and str(job.get("profile") or "") == RETIRED_GITHUB_PROFILE):
                    rec = {"schema_version": 1, "job_id": RETIRED_GITHUB_JOB_ID,
                           "profile": RETIRED_GITHUB_PROFILE, "platform": "linux",
                           "state": "CONSUMED", "status": "CANCELLED", "run_id": run_id,
                           "completed_at": now_iso(), "source": "worker-retired-job-guard-v0416"}
                    outcomes.append(rec)
                    if RETIRED_GITHUB_JOB_ID not in processed_ids(p):
                        append_jsonl(p["processed"], rec)
                    continue
                if str(job.get("execution_class") or "overnight") != args.execution_class:
                    remaining_jobs.append(job); continue
                if args.max_jobs is not None and executed >= max(0, args.max_jobs):
                    remaining_jobs.append(job); continue
                if is_expired(job.get("expires_at")):
                    rec = {"job_id": job.get("job_id"), "profile": job.get("profile"), "platform": job.get("platform", "any"), "state": "EXPIRED", "status": "EXPIRED", "error": "expires_at is in the past", "completed_at": now_iso(), "run_id": run_id}
                    outcomes.append(rec); append_jsonl(p["processed"], rec); continue
                profile = profiles.get(str(job.get("profile") or ""))
                if not isinstance(profile, dict) or not profile.get("enabled", True):
                    rec = {"job_id": job.get("job_id"), "profile": job.get("profile"), "platform": job.get("platform", "any"), "state": "CONSUMED", "status": "REJECTED", "error": "profile unavailable", "completed_at": now_iso(), "run_id": run_id}
                    outcomes.append(rec); append_jsonl(p["processed"], rec); continue
                executed += 1
                print(f"JOB_LIST_JOB_START job_id={job.get('job_id')} profile={job.get('profile')} run_id={run_id}", flush=True)
                rec = execute_job(root, p, job, profile, run_id, args.window_end); outcomes.append(rec)
                print(f"JOB_LIST_JOB_END job_id={job.get('job_id')} status={rec.get('status')} returncode={rec.get('returncode')}", flush=True)
                if rec["status"] in {"DEFERRED_WINDOW", "DEFERRED_DEPENDENCY"}:
                    deferred += 1; remaining_jobs.append(job)
                else:
                    # One-shot invariant: once execution starts, the Job is consumed even
                    # when Study Runner reports ANALYSIS_PARTIAL/REVIEW/BLOCKED.
                    append_jsonl(p["processed"], rec)
            with FileLock(p["queue_lock"], wait_seconds=10):
                current_jobs = load_queue(p)
                newly_queued = [x for x in current_jobs if str(x.get("job_id") or "") not in original_ids]
                save_queue(p, [*newly_queued, *remaining_jobs])
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
    finally:
        p["running"].unlink(missing_ok=True)

    failures = sum(1 for x in outcomes if x.get("status") in TERMINAL_FAILURE)
    superseded = sum(1 for x in outcomes if x.get("status") == "SUPERSEDED")
    status = "FAIL" if error or failures else "PASS"
    if status == "FAIL":
        job_status = "FAILED"
    elif deferred:
        job_status = "DEFERRED"
    elif outcomes and all(x.get("status") in TERMINAL_NEUTRAL for x in outcomes):
        job_status = "SUPERSEDED" if superseded == len(outcomes) else "CANCELLED"
    elif outcomes:
        job_status = "SUCCESS"
    else:
        job_status = "IDLE"
    semantic_status = aggregate_semantic_status(outcomes)
    observer_result = aggregate_observer_result(outcomes, job_status)
    completed = now_iso()
    observer = {
        "schema_version": 1, "producer": "job-list-core", "version": VERSION, "run_id": run_id,
        "status": status, "job_status": job_status, "semantic_status": semantic_status,
        "started_at": started, "completed_at": completed, "received": len(outcomes),
        "success_count": sum(1 for x in outcomes if x.get("status") == "SUCCESS"),
        "failure_count": failures, "deferred_count": deferred, "superseded_count": superseded, "queued_remaining": len(load_queue(p)),
    }
    if observer_result is not None:
        observer["observer_result"] = observer_result
    # If V0409 never produced a semantic result (for example profile resolve/spawn
    # failure), core itself emits the terminal breadcrumb.  Normal profile exits
    # carry terminal_signal_sent=true in their semantic result and are not doubled.
    v0409 = next((x for x in outcomes if x.get("job_id") == DISPATCHER_RECOVERY_V0409_JOB_ID), None)
    if isinstance(v0409, dict) and not v0409.get("terminal_signal_sent"):
        vstatus = str(v0409.get("status") or "")
        if vstatus in {"DEFERRED_WINDOW", "DEFERRED_DEPENDENCY", "SUPERSEDED"}:
            observer["external_signal_v0409_core"] = emit_dispatcher_recovery_signal("job-list-deferred")
        elif vstatus != "SUCCESS":
            observer["external_signal_v0409_core"] = emit_dispatcher_recovery_signal("job-list-fail")
    atomic_json(p["observer_latest"], observer); append_jsonl(p["observer_history"], observer); p["observer_current"].unlink(missing_ok=True)
    summary = {"schema_version": 1, "version": VERSION, "run_id": run_id, "status": status, "job_status": job_status,
               "semantic_status": semantic_status, "observer_result": observer_result, "runtime_recovery": recovery,
               "started_at": started, "completed_at": completed,
               "results": outcomes, "error": error, "queued_remaining": observer["queued_remaining"], "observer_receipt": str(p["observer_latest"])}
    atomic_json(run_dir / "summary.json", summary); atomic_json(p["last"], summary)
    runtime_event(p, "WORKER_RUN_END", run_id=run_id, status=status, job_status=job_status, queued_remaining=observer["queued_remaining"])
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True); return 0 if status == "PASS" else 1


def cmd_u3_result(args: argparse.Namespace) -> int:
    """Minimal read-only U3 status bridge; no OpenCode invocation or Work writes."""
    root = canonical_root(args.root)
    mode = str(args.mode)
    path = root / 'output' / 'u3_opencode' / mode / 'latest_result.json'
    raw = read_json(path, {})
    if not isinstance(raw, dict) or raw.get('producer') != 'job-list/u3-opencode-linux' or raw.get('mode') != mode:
        raw = {}
    payload = {
        'schema': 'job-list-u3-result-bridge/1', 'read_only': True, 'job_list_version': VERSION,
        'mode': mode, 'status': raw.get('status') or 'NOT_RUN',
        'run_id': raw.get('run_id'), 'reason_codes': raw.get('reason_codes') or [],
        'summary': raw.get('summary'), 'error_code': raw.get('error_code'),
        'staged_changed_files': raw.get('staged_changed_files') or [],
        'production_modified': raw.get('production_modified'),
        'review_required': True, 'completed_at': raw.get('completed_at'),
        'result_path': str(path) if raw else None,
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


def cmd_mcp_analysis_find_result(args: argparse.Namespace) -> int:
    """Read-only bridge for the fixed stage-fix Job; no activation or MCP writes."""
    root = canonical_root(args.root)
    path = root / 'output/mcp_analysis_find/stage_fix/latest_result.json'
    raw = read_json(path, {}) if path.is_file() else {}
    ok = (isinstance(raw, dict) and raw.get('producer') == 'job-list/mcp-analysis-find-linux'
          and raw.get('job_id') == 'JOB-20261024-MCP-ANALYSIS-FIND-PROPOSAL-01'
          and raw.get('profile') == 'mcp-analysis-find-stage-fix-linux')
    if not ok:
        raw = {}
    payload = {'schema': 'job-list-mcp-analysis-find-result/1', 'read_only': True,
               'job_list_version': VERSION, 'status': raw.get('status', 'NOT_RUN'),
               'run_id': raw.get('run_id'), 'error_code': raw.get('error_code'),
               'reason_codes': raw.get('reason_codes', []),
               'staged_changed_files': raw.get('staged_changed_files', []),
               'production_modified': raw.get('production_modified', False),
               'mcp_e2e': 'NOT_TESTED', 'review_required': True,
               'completed_at': raw.get('completed_at')}
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0



def cmd_job_catalog_read(args: argparse.Namespace) -> int:
    """Read-only local catalogue for a future allowlisted whpark-mcp handler."""
    from mcp_job_read_bridge import catalog
    root = canonical_root(args.root)
    print(json.dumps(catalog(root, args.job_id, args.limit), ensure_ascii=False))
    return 0


def cmd_job_queue_read(args: argparse.Namespace) -> int:
    """Read-only local queue, running, and receipt state. Never ensure_layout."""
    from mcp_job_read_bridge import queue
    root = canonical_root(args.root)
    print(json.dumps(queue(root, args.job_id), ensure_ascii=False))
    return 0


def cmd_job_result_read(args: argparse.Namespace) -> int:
    """Allowlisted sanitized semantic output only, no transcript or raw patch."""
    from mcp_job_read_bridge import result
    root = canonical_root(args.root)
    print(json.dumps(result(root, args.job_id, args.cursor, args.max_bytes), ensure_ascii=False))
    return 0

def cmd_opencode_health_result(args: argparse.Namespace) -> int:
    """Read latest persisted health evidence only; never launch OpenCode."""
    root = canonical_root(args.root)
    path = root / 'output/opencode_health/latest_result.json'
    raw = read_json(path, {})
    if not isinstance(raw, dict) or raw.get('producer') != 'job-list/opencode-health-linux':
        raw = {}
    payload = {
        'schema': 'job-list-opencode-health-bridge/1',
        'read_only': True, 'job_list_version': VERSION,
        'status': raw.get('status', 'NOT_RUN'),
        'binary_status': raw.get('binary_status', 'NOT_TESTED'),
        'model_response': raw.get('model_response', 'NOT_TESTED'),
        'opencode_version': raw.get('opencode_version'),
        'error_code': raw.get('error_code'),
        'reason_codes': raw.get('reason_codes', []),
        'recent_opencode_log_signals': raw.get('recent_opencode_log_signals', []),
        'summary': raw.get('summary'),
        'mcp_verified': False, 'mcp_status': 'NOT_TESTED',
        'tui_status': 'NOT_TESTED', 'web_status': 'NOT_TESTED',
        'completed_at': raw.get('completed_at'),
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


def cmd_workspace_migration_result(args: argparse.Namespace) -> int:
    """Read local result only; never queue, run or mutate a workspace."""
    root = canonical_root(args.root)
    path = root / 'output' / 'workspace_artifacts_migration' / 'latest_result.json'
    raw = read_json(path, {}) if path.is_file() else {}
    allowed = ('SUCCESS','BLOCKED','FAILED')
    ok_identity = (isinstance(raw,dict)
                   and raw.get('job_id')=='JOB-20261021-L1-WORKSPACE-ARTIFACTS-MIGRATE-01'
                   and raw.get('profile')=='l1-workspace-artifacts-migrate-linux')
    status = str(raw.get('status') or 'NOT_RUN') if ok_identity else 'NOT_RUN'
    result = {'schema':'job-list-workspace-migration-result/1', 'read_only':True,
              'job_id':'JOB-20261021-L1-WORKSPACE-ARTIFACTS-MIGRATE-01',
              'status':status if status in (*allowed, 'NOT_RUN') else 'UNVERIFIED',
              'result_code':raw.get('result_code') if ok_identity else None,
              'renamed':raw.get('renamed',0) if ok_identity else 0,
              'indexed':raw.get('indexed',0) if ok_identity else 0,
              'commit_performed':False,'push_performed':False,
              'requires_separate_commit_and_push_approval':bool(raw.get('requires_separate_commit_and_push_approval')) if ok_identity else False}
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0


def cmd_knowledge_bootstrap_result(args: argparse.Namespace) -> int:
    """Read-only bounded output; no job re-execution, no repository disclosure."""
    from mcp_job_read_bridge import result
    root = canonical_root(args.root)
    obj=result(root, 'JOB-20261107-L1-KNOWLEDGE-PORTAL-BOOTSTRAP-01')
    print(json.dumps(obj,ensure_ascii=False,indent=2))
    return 0 if obj.get('query_status')=='OK' else 2


def cmd_job_bootstrap_status(args: argparse.Namespace) -> int:
    """Observe existing evidence without layout creation, recovery, or activation."""
    from job_bootstrap_status import snapshot, wire, failure
    try:
        result = snapshot(canonical_root(args.root), job_id=args.job_id)
    except Exception:
        result = failure('SNAPSHOT_UNREADABLE')
    print(wire(result) if args.compact else json.dumps(result, ensure_ascii=False, indent=2))
    return 2 if result.get('blocker') in ('INVALID_INPUT', 'SNAPSHOT_UNREADABLE') else 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="job-list-core", description="Lifecycle v2 isolated local one-shot Job runner")
    parser.add_argument("--version", action="version", version=VERSION); sub = parser.add_subparsers(dest="command", required=True)
    for name, func in (("validate", cmd_validate), ("status", cmd_status)):
        p = sub.add_parser(name); p.add_argument("--root"); p.set_defaults(func=func)
    p = sub.add_parser("mcp-analysis-find-result", help="read fixed MCP proposal status without running anything")
    p.add_argument("--root"); p.set_defaults(func=cmd_mcp_analysis_find_result)
    p = sub.add_parser("job-bootstrap-status", help="READ ONLY: compact bootstrap Job evidence; no activation")
    p.add_argument("--root"); p.add_argument("--job-id"); p.add_argument("--compact", action="store_true")
    p.set_defaults(func=cmd_job_bootstrap_status)
    p = sub.add_parser("job-catalog-read", help="READ ONLY: fixed Job registration metadata")
    p.add_argument("--root"); p.add_argument("--job-id"); p.add_argument("--limit", type=int, default=20)
    p.set_defaults(func=cmd_job_catalog_read)
    p = sub.add_parser("job-queue-read", help="READ ONLY: fixed Job queue and terminal receipt")
    p.add_argument("--root"); p.add_argument("--job-id", required=True)
    p.set_defaults(func=cmd_job_queue_read)
    p = sub.add_parser("job-result-read", help="READ ONLY: sanitized Job result")
    p.add_argument("--root"); p.add_argument("--job-id", required=True)
    p.add_argument("--cursor"); p.add_argument("--max-bytes", type=int, default=4096)
    p.set_defaults(func=cmd_job_result_read)
    p = sub.add_parser("knowledge-bootstrap-result", help="READ ONLY: knowledge portal bootstrap result; no execution")
    p.add_argument("--root"); p.set_defaults(func=cmd_knowledge_bootstrap_result)
    p = sub.add_parser("workspace-migration-result", help="read workspace artifact migration result without executing it")
    p.add_argument("--root"); p.set_defaults(func=cmd_workspace_migration_result)
    p = sub.add_parser("opencode-health-result", help="read one-shot Linux OpenCode health evidence, never run")
    p.add_argument("--root"); p.set_defaults(func=cmd_opencode_health_result)
    p = sub.add_parser("u3-result", help="read U3 latest semantic result, never run U3")
    p.add_argument("--root"); p.add_argument("--mode", choices=["diagnose", "stage-fix"], default="diagnose")
    p.set_defaults(func=cmd_u3_result)
    p = sub.add_parser("cleanup-result", help="read fixed Linux cleanup Job evidence only (no side effects)")
    p.add_argument("--root"); p.set_defaults(func=cmd_cleanup_result)
    p = sub.add_parser("enqueue", help="create one local one-shot Job")
    p.add_argument("--root"); p.add_argument("--profile", required=True); p.add_argument("--job-id"); p.add_argument("--priority", type=int, default=50)
    p.add_argument("--expires-at"); p.add_argument("--platform", choices=sorted(REQUEST_PLATFORMS), default="any")
    p.add_argument("--params-json", default="{}"); p.set_defaults(func=cmd_enqueue)
    p = sub.add_parser("activate", help="import strict bundled one-shot requests")
    p.add_argument("--root"); p.add_argument("--source", required=True); p.add_argument("--launch", action="store_true"); p.set_defaults(func=cmd_activate)
    p = sub.add_parser("wait-launch", help="wait for an existing runtime then launch the pending queue")
    p.add_argument("--root"); p.add_argument("--max-wait-sec", type=int, default=14400); p.add_argument("--poll-sec", type=int, default=15); p.set_defaults(func=cmd_wait_launch)
    p = sub.add_parser("run")
    p.add_argument("--root"); p.add_argument("--execution-class", default="overnight", choices=["overnight"])
    p.add_argument("--window-end", default=None, help="optional local HH:MM; a not-yet-started job may be deferred")
    p.add_argument("--wait-lock-sec", type=float, default=0)
    p.add_argument("--max-jobs", type=int); p.add_argument("--yes", action="store_true"); p.set_defaults(func=cmd_run)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if current_platform() != 'linux':
        print(json.dumps({'status':'BLOCKED','reason':'LINUX_ONLY_RELEASE'}))
        return 2
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
