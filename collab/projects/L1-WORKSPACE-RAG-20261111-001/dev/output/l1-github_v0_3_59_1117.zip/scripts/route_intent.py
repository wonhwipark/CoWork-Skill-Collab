"""Small, conservative pre-parser: requested operations are distinct from constraints."""
import re

LABEL = r"([A-Za-z0-9][A-Za-z0-9._/-]*)"


def clean_request(text):
    constraints = {}
    names = {"push": r"push|푸시", "commit": r"commit|커밋", "worktree": r"worktree|워크트리"}
    for key, words in names.items():
        neg = rf"(?:{words})(?:는|은|를|을)?\s*(?:(?:만들|생성)\s*)?(?:하지\s*마(?:세요)?|하지\s*않\S*|금지|없이|말고|나중에|만들지\s*마)"
        text, n = re.subn(neg, " ", text, flags=re.I)
        # Coordinated 'Worktree와 Push는 하지 마' applies to both verbs.
        if n:
            constraints['no_' + key] = True
        english = rf"(?:do\s+not|don't|no|without)\s+(?:{words})\b"
        text, n = re.subn(english, " ", text, flags=re.I)
        if n:
            constraints['no_' + key] = True
    if constraints.get('no_push') and re.search(r'(?:worktree|워크트리)와\s*', text, re.I):
        text = re.sub(r'(?:worktree|워크트리)와\s*', ' ', text, flags=re.I)
        constraints['no_worktree'] = True
    conditional = r"(?:conflict|충돌)(?:가|이)?\s*(?:발생하면|발생\s*시|시|나면)[^.!?]*(?:멈\S*|알려\S*|중단\S*)"
    text, n = re.subn(conditional, " ", text, flags=re.I)
    text, n2 = re.subn(r"if\s+(?:a\s+)?conflict\b[^.!?]*", " ", text, flags=re.I)
    if n or n2:
        constraints['stop_on_conflict'] = True
    return text, constraints


def cmd_request(text):
    return bool(re.search(
        r"cmd[- ]set|command\s+set|명령(?:어)?\s*(?:세트|순서)|"
        r"(?:git\s*)?(?:cmd|commands?|명령어?)\s*(?:만|를|을)?\s*(?:먼저\s*)?(?:제공|보여|출력|정리|알려)",
        text, re.I))


def values(text):
    result = {}
    for key, label in (("target", r"타겟|타깃|target"), ("local", r"로컬|local")):
        m = re.search(rf"(?:{label})\s*(?:브랜치|branch)?\s*[:=]?\s*[`\"']?{LABEL}", text, re.I)
        if m:
            result[key] = m.group(1)
    if 'target' not in result:
        # Korean speech recognition often inserts a space: "업스트림 Dev".
        # Never infer a base from just "upstream PR".
        m_dev = re.search(r"(?:upstream|업스트림)(?:의|/)?\s*(?:dev|데브)(?:에|에서|를|의|는)?(?=$|[\s,;.!?])", text, re.I)
        if m_dev:
            result['target'] = 'dev'
    if 'target' not in result:
        m = re.search(r"(?:upstream|업스트림)(?:의|/)\s*([A-Za-z0-9][A-Za-z0-9._/-]*)", text, re.I)
        if m and m.group(1).lower() not in {'pr', 'base', '브랜치'}:
            result['target'] = m.group(1)
    return result


def branch_name(text):
    patterns = [rf"[`\"']?{LABEL}[`\"']?\s*(?:브랜치|branch)(?:로|으로)?\s*(?:전환|이동|변경|생성|만들)",
                rf"(?:로컬|local)\s*(?:브랜치|branch)?\s+{LABEL}",
                rf"(?:create|switch\s+to)\s+(?:branch\s+)?{LABEL}"]
    for pattern in patterns:
        m = re.search(pattern, text, re.I)
        if m:
            return m.group(1)
    return ""


def is_create(text):
    return bool(re.search(r"생성|만들어|\bcreate\b", text, re.I))


def pr_merge_request(text):
    return bool(re.search(r"merge\s*해|머지\s*해|병합\s*해|\bmerge\b.*\bpr\b|\bpr\b.*\bmerge\b", text, re.I))
