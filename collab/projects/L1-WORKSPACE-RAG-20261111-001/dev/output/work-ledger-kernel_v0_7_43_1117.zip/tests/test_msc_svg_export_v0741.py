from pathlib import Path
import pytest
from work_ledger_kernel.artifact_names import name_for
from work_ledger_kernel.work_ux import _validate_safe_msc_svg
from work_ledger_kernel.errors import KernelError


def test_msc_svg_name_is_supported():
    value=name_for("analysis","MSC_INIT.svg","E-1234567890ab")
    assert value.endswith(".svg") and "1234567890ab" in value


def test_safe_svg_blocks_script(tmp_path):
    path=tmp_path/"MSC.svg"
    path.write_text('<svg xmlns="http://www.w3.org/2000/svg"><script>bad()</script></svg>',encoding="utf-8")
    with pytest.raises(KernelError):
        _validate_safe_msc_svg(path)


def test_safe_svg_accepts_simple_svg(tmp_path):
    path=tmp_path/"MSC.svg"
    path.write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">'
                    '<text y="20">INIT</text></svg>',encoding="utf-8")
    _validate_safe_msc_svg(path)
