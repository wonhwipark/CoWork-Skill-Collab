---
name: l1-github
description: >
  Git/GitHub contributor workflow Skill. 단순 read-only Git은 thin native path로 위임하고,
  회사 policy/고위험 workflow(PC간 resume, base merge/conflict, merged-PR rebase, PR↔base 검증)를 안전하게 소유한다.
  계획/실행 Git CMD 설명과 local command journal을 제공한다.
metadata:
  compatibility: "Claude Code + OpenCode; Python 3; git; skillsilent NOT required; optional gh; company remote access via Shared Environment SSOT"
  version: "0.3.58"
  audience: "single-contributor"
  workflow: "github-contributor"
  low_llm: "dispatcher-first"
---

# l1-github v0.3.58 — Fork Worktree Incident Recovery


## v0.3.56 — Fork 전용 문제별 자동 진단 및 안전 조치

- `fork-worktree-doctor --json`: canonical `workflow_mode=fork`, upstream/origin URL 검증 후 B 상태를 읽기 전용 진단하고 사고 유형별 next action 제시. `work_docs`/`l1-workspace` 및 direct repository 제외.
- PR 기준 생성·Worktree 생성/이전·브랜치 전환 차단 시에도 Fork에서만 진단 자동 출력. 무단 clean/reset/stash/전환/삭제 금지, 승인 후 기존 preview→apply 계약. `references/fork_worktree_recovery.md` 참조.

과거 이력은 `CHANGELOG.md`, `RELEASE_NOTES.md`와 각 reference에 보존. v0.3.55의 A/B 고정 경로, 기본 primary-only 및 총 2개 제한 유지.

## 1. 사용자 표면

```text
status          회사 policy 포함 상태/다음 단계
workspace-state local Git 상태 JSON snapshot(read-only, orchestration용)
fork-worktree-doctor Fork 전용 차단 유형 및 안전 조치(read-only)
untracked-audit  local untracked 원인 추정·집계(read-only, 파일 삭제 없음)
branch-list     local branch 목록(read-only)
switch-branch   기본 저장소에서 기존 local branch 전환/직전 branch 복귀
worktree-mode   opt-in, 전체 2개(primary 포함) Worktree 운용 및 원복
worktree-create primary에서 두 번째 linked Worktree를 고정 B 폴더에 생성(preview/apply)
worktree-relocate 기존 linked Worktree 경로를 고정 B 폴더로 안전 이전(preview/apply)
worktree-list/status Worktree 목록·dirty/untracked 상태 확인
worktree-to-primary 기존 linked Worktree의 branch/변경사항을 기본 저장소로 복구
user-merged-prs GitHub login 기준 merge 수행자별 PR 목록(read-only)
auto            자연어 → 안전 action
native-git      단순 read-only Git fast path
guide           Git CMD 인터뷰 안내
cmd-set         target·merged PR·local → 상황별 명령 세트 생성(실행 안 함)
cmd-set --quick-new 신규 PR 기준 브랜치 생성 Git 명령만 즉시 출력(Git/MCP/API 호출 0회)
explain-*       예정/실행/워크플로 Git CMD 설명
```

예: `fix-SOC-41668 브랜치로 전환해줘`, `사용자 ID alice가 merge한 PR 목록 조회해줘`, `feature/A 브랜치로 전환해줘`, `이전 작업 브랜치로 돌아가줘`, `PR 123 코드 분석해줘`, `push 해줘`.

P4→Git 실행은 범위 밖이다.

## 2. Fast path + Dispatcher — MUST

명시적인 단순 read-only 요청(`git status`, `git diff`, `git log`)은 dispatcher 없이 바로 `native-git`을 호출한다. 그 외 요청만 아래 dispatcher를 1회 사용한다.

```powershell
py "$HOME/l1sw-private-skills/l1-github/scripts/low_llm_dispatcher.py" route --request "<사용자 원문>" --json
```

`route`에 필요한 state가 이미 포함된다. **같은 요청에서 별도 `state --json`을 반복 호출하지 않는다.**

1. HELP/GUIDE는 Git write 금지.
2. explicit primitive read는 direct `native-git`; dispatcher가 `NATIVE_READ`을 반환해도 reference load 생략.
3. `reference_load=SKIP`이면 문서 로드를 생략하고 그 외에는 `reference` 1개만 lazy-load.
4. write는 preview → 명확한 사용자 의도 → `--apply`. route의 `preview.ok=true`이면 별도 preview 호출 없이 `helper_apply` 사용. apply 시 상태는 다시 검증한다.
5. `confidence=LOW`는 write 승격 금지. MEDIUM write는 preview source/target이 요청과 같은지 확인한다. `constraints`의 금지/충돌 중단 조건을 유지한다.
6. 사용자 요청 1회당 write action 최대 1개. `cmd-set`은 명령 생성만 하고 실행하지 않는다. 안내 요청을 write로 승격하지 않는다.

Canonical: `~/l1sw-private-skills/l1-github/`

**`skillsilent`는 필수 런타임 의존성이 아니다.** `doctor`와 일반 GitHub workflow, standalone PR 분석은 skillsilent 없이 동작해야 한다.

### First-run GitHub access bootstrap — MUST

원격 GitHub 인증 정보가 없으면 `access-bootstrap --json` 사용. Mango MCP 먼저 1회 시도하고 실패할 때만 외부 토큰 설정 절차로 진행. Token/PAT 값 요청·저장 금지. `references/shared_environment_ssot.md`에 전체 절차를 보존한다.

**Stacked PR cleanup:** 부모 Squash-Merged PR + 자식 Open PR 번호/URL 요청은 `stacked-pr-cleanup`(준비, 원본 불변) → `stacked-pr-cleanup-verify`(자식 변경 파일만 Diff 확인) → 별도 명시 승인 `stacked-pr-cleanup-publish`(exact `--force-with-lease`) 3단계. 단일 primary checkout만, 기존 Worktree 생성 금지. 기본 Push 보호/신규 Repo 등록 정책 유지. 세부: `references/stacked_pr_cleanup.md`.

## 3. Single-write safety — MUST

```text
commit 요청          → commit → STOP
push 요청            → push → STOP
merge-complete 요청  → merge commit → STOP
rebase-pr 요청        → rebase/첫 conflict → STOP
rebase-continue 요청  → 한 단계 continue → STOP
```

raw `git commit/push/merge` 또는 `gh pr create`로 guarded workflow를 우회하지 않는다.

## 4. Core safety

- `.l1git/policy.json` 우선, protected branch 직접 push 금지.
- dirty push 기본 BLOCK.
- 기본 동작은 primary-only. 사용자가 `worktree-mode --enable --apply`로 opt-in 한 저장소에서만 서로 다른 브랜치의 primary + linked 1개에서 개발 가능. 최대 2개 제한 초과/unknown/detached면 guarded 작업 BLOCK. 새 작업 시작/전환은 해당 worktree clean 필수. 각 LLM 창은 작업 경로를 고정하고 global worktree-select로 전환하지 않는다. 작업물/worktree 자동 삭제 금지.
- 자동 force push/hard reset 금지. rebase는 guarded `rebase-pr` 또는 `rebase-open-pr`만 허용. 원본 OPEN PR rewrite는 별도 explicit action의 exact `--force-with-lease`만 허용.
- conflict ours/theirs 임의 선택 금지.
- Token/password/private key/session 저장 금지.
- `mango_mcp` 선택 시 direct remote Git 우회 금지.
- Windows/Linux Git subprocess는 non-interactive + watchdog timeout; hook/signing은 자동 우회하지 않음.
- build/UT `UNKNOWN`을 `PASS`로 취급 금지.

## 5. Thin native Git fast path

명시적인 단순 `git status / git diff / git log`는 full policy/state scan 없이 `native-git`으로 실행한다. write verb는 거부하며 실제 명령은 command journal에 기록한다. 고급 `file-history/blame/file-at/code-owner`은 호환 fallback으로 유지한다. 상세: `references/native_git.md`.

## 6. Git command explainability

```text
explain-plan                 최신 preview의 예정 Git CMD
explain-last                 최신 session의 실제 실행 Git CMD
explain-workflow <workflow>  표준 Git command contract
```

`planned`와 `executed`를 섞지 않는다. journal은 local-only이고 credential을 masking한다. 기존 action 단위 설명은 `help history/history-help`로 유지한다. 상세: `references/git_command_explain.md`.

## 7. Workflow references (lazy-load exactly one)

For base merge, lazy-load `references/merge_mode.md`. See `references/reference_index.md` for full routing and choose one topic-specific reference. PR history: `references/pr_history.md`; Worktree recovery: `references/worktree_to_primary.md`. `smp1900` defaults to primary checkout; optional bounded dual mode requires explicit opt-in. See `references/dual_workspace.md`.

명령 세트: `references/cmd_set.md`. merged PR 기준 생성/Open PR merge: `references/fast_pr_actions.md`.

## 8. Reference map

기능별 세부 계약/실행 명령은 `references/reference_index.md`에서 선택한 문서 하나만 로드한다.

## Repository role / Push safety

- Canonical repo roles, new repo confirmation and Push verification: `references/repo_role_and_push_guard.md` (lazy-load when configuring or pushing).
- Repositories with unregistered/mismatched role, multiple push URLs or unconfirmed host path are **BLOCKED**; user explicitly confirms role, URL and Push target before registration, and Push requires separate approval.
- `work_docs` is separate from `source_code` and `group_skills`; company Fork and external skill-updater repos never share automatic Push authority.
- Legacy worktree recovery remains explicitly opt-in; normal development is primary-only unless dual mode is explicitly enabled.

## v0.3.58 — PR 병합 메타데이터와 실제 적용 상태 분리

- `pr-code-analysis`는 GitHub PR REST의 `merged`, `merged_at`, `merge_commit_sha`와 source base/head를 별도 저장한다. CLOSED는 MERGED가 아니다.
- `merge_landing`의 로컬 target ref 관측은 실시간 원격 확인이나 적용/시험 PASS가 아니다. Squash/rebase/backport는 동일 head SHA라고 단정하지 않는다.
- 동일 저장소 여러 PR 분석은 prepare → code-analyzer → Work/Evidence 정착 → 다음 PR 순서로 직렬 수행하고 분석 snapshot을 재확인한다.


### Workflow 개인 Knowledge 경로 보호 (개발 후보 v0.3.58)
- Work-docs commit/push entrypoint의 status-staged/unstaged/untracked 경로에 `knowledge/` 변경이 있으면 fail-closed.
- raw Git/동일 자격증명 우회 가능성은 별도 호스트 권한 경계의 G0 검증 조건이며 본 guard만으로 완전 차단 주장 금지.
