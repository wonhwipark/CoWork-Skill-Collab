# Development candidate v0.7.40-dev.1 / 2026-11-16 KST

Base PRIVATE v0.7.39-dev.1, preserving its CL/PR WorkReference changes. Allow small SVG Evidence through existing export docs path, retain published_path and digest conflict checks. Oversize SVG emits MSC_SVG_TOO_LARGE instead of silent skip. No relative-link rewrites or group-writer changes. Python regression, actual E3, independent code review NOT_RUN. development_not_for_deployment.
