# Kernel one-cycle MSC SVG export fix (2026-11-16)
- Extend artifact publication naming to .svg for verified, explicitly MSC-identified Evidence.
- Preserve old behavior for unrelated SVG and oversize MD/HTML. Active/direct-open SVG content blocks.
- Continue using existing published_path digest and collision checks. G0 writer/host not validated.
- One reviewer cycle; no subsequent review requested. development_not_for_deployment.
