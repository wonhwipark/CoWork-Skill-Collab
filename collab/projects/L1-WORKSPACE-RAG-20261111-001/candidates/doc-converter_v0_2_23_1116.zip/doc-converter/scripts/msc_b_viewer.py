"""Safe standalone B HTML viewer for existing rendered SVG."""
import base64
import hashlib
from html import escape
from pathlib import Path
import re
import xml.etree.ElementTree as ET

def build_html(svg_path: Path, title: str, phases: list[str]) -> str:
    data=Path(svg_path).read_bytes()
    if len(data)>2*1024*1024:
        raise ValueError("B_VIEW_SVG_TOO_LARGE")
    root=ET.fromstring(data)
    if root.tag.rsplit("}",1)[-1].lower()!="svg":
        raise ValueError("B_VIEW_NOT_SVG")
    try:
        box=[float(x) for x in re.split(r"[ ,]+",root.attrib["viewBox"].strip()) if x]
    except (KeyError,ValueError) as exc:
        raise ValueError("B_VIEW_VIEWBOX_MISSING") from exc
    if len(box)!=4 or box[2]<=0 or box[3]<=0:
        raise ValueError("B_VIEW_VIEWBOX_INVALID")
    controls=[]
    for phase in dict.fromkeys(phases):
        ys=[]
        for element in root.iter():
            if element.tag.rsplit("}",1)[-1].lower()!="text":
                continue
            label="".join(element.itertext()).strip()
            if label==phase or label.strip("= ").strip()==phase:
                try:
                    ys.append(float(element.attrib["y"]))
                except (KeyError,ValueError):
                    pass
        if len(ys)==1:
            controls.append('<button class="phase" data-y="'+str(ys[0]-box[1])+'">'+escape(phase)+'</button>')
    encoded=base64.b64encode(data).decode("ascii")
    js="""const pane=document.getElementById('pane'),img=document.getElementById('msc');let zoom=1;
document.querySelectorAll('button.phase').forEach(b=>b.onclick=()=>{
const ratio=img.getBoundingClientRect().width/Number(img.dataset.vbw);
pane.scrollTo({top:Math.max(0,Number(b.dataset.y)*ratio-24),behavior:'smooth'});});
document.getElementById('plus').onclick=()=>{zoom=Math.min(3,zoom+.25);img.style.width=(zoom*100)+'%';};
document.getElementById('minus').onclick=()=>{zoom=Math.max(.5,zoom-.25);img.style.width=(zoom*100)+'%';};"""
    digest=base64.b64encode(hashlib.sha256(js.encode("utf-8")).digest()).decode("ascii")
    return ('<!doctype html><html lang="ko"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; img-src data:; style-src \'unsafe-inline\'; script-src \'sha256-'+digest+'\'">'
            '<title>'+escape(title)+'</title>'
            '<style>body{margin:0;font-family:system-ui,sans-serif;background:#f8fafc;color:#1c2d46}'
            'header{padding:16px;background:white;border-bottom:1px solid #d5dfeb}'
            'h1{font-size:19px;margin:0 0 10px}.controls{display:flex;gap:8px;flex-wrap:wrap}'
            'button{border:1px solid #c8d5e5;border-radius:7px;background:white;padding:8px 12px;cursor:pointer}'
            '.viewport{height:78vh;overflow:auto;margin:16px;background:white;border:1px solid #d5dfeb}'
            'img{display:block;width:100%;min-width:320px;height:auto}</style></head><body>'
            '<header><h1>'+escape(title)+'</h1><div class="controls">'
            '<button id="minus" aria-label="축소">−</button><button id="plus" aria-label="확대">+</button>'
            +"".join(controls)+'</div></header>'
            '<main class="viewport" id="pane"><img id="msc" alt="'+escape(title,quote=True)+
            '" data-vbw="'+str(box[2])+'" src="data:image/svg+xml;base64,'+encoded+
            '"></main><script>'+js+'</script></body></html>')
