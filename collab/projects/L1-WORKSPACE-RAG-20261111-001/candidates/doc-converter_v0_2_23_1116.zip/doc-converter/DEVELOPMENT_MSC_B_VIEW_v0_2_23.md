# doc-converter v0.2.23 candidate / 2026-11-16 KST

Based on v0.2.22, preserving Unicode name collision prevention and Procedure/Feature AS-IS view. New opt-in PROCEDURE_FEATURE mode generates standalone SVG-in-HTML B viewer; phase jump buttons only for unique labels in actual SVG. Local MSC_VIEW and public manifest now reference HTML. Remote published_path and group/Workspace writer linking require G0/readback. Python regression, browser/CSP E2E and independent review NOT_RUN. development_not_for_deployment.
