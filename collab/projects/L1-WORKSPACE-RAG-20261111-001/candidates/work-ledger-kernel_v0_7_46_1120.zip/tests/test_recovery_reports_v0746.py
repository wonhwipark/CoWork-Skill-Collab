from __future__ import annotations
import hashlib
import json
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.errors import KernelError
from work_ledger_kernel.cli import main
from contextlib import redirect_stdout
from io import StringIO

CONTRACTS = Path(__file__).resolve().parents[1] / 'contracts'


class RecoveryReportsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.root = Path(self.temp.name)
        self.k = WorkLedgerKernel(self.root/'ledger', CONTRACTS)
        self.wid = 'SYNTHETIC-RECOVERY'; self.k.new(self.wid, 'BUG', 'Synthetic report')
        self.source = self.root/'report.md'; self.source.write_text('# Recovery\nCovered: 1\nHOLD: 1\nRuntime: NOT_RUN\n')

    def tearDown(self): self.temp.cleanup()

    def preview(self, **kw):
        return self.k.recovery_report_preview(self.wid, kw.get('source',self.source), 'unverified', kw.get('rev','git:synthetic:one'), kw.get('summary','Synthetic candidates'))

    def save(self, preview=None, **kw):
        p=preview or self.preview(**kw)
        return self.k.record_recovery_report(self.wid, kw.get('source',self.source),'unverified',kw.get('rev','git:synthetic:one'),kw.get('summary','Synthetic candidates'),p['source_sha256'],p['evidence_revision'])

    def assert_code(self, code, fn):
        with self.assertRaises(KernelError) as e: fn()
        self.assertEqual(code,e.exception.code)

    def test_preview_and_read_leave_record_and_journal_unchanged(self):
        before={p:p.read_bytes() for p in (self.root/'ledger').rglob('*') if p.is_file()}
        self.assertFalse(self.preview()['saved']);self.assertEqual(0,self.k.work_recovery_reports(self.wid)['count'])
        self.assertEqual(before,{p:p.read_bytes() for p in (self.root/'ledger').rglob('*') if p.is_file()})

    def test_saved_copy_survives_run_cleanup_without_lifecycle_promotion(self):
        saved=self.save(); self.source.unlink(); r=self.k.work_recovery_reports(self.wid)
        self.assertEqual(1,r['count']);self.assertEqual('MATCH',r['items'][0]['integrity'])
        self.assertEqual(saved['source_sha256'],r['items'][0]['sha256'])
        self.assertEqual('OPEN',r['lifecycle_state']);self.assertFalse(saved['provider_executed'])
        self.assertEqual('AUTO_CANDIDATE',r['items'][0]['confidence_state'])

    def test_retry_reuses_exact_evidence_without_second_write(self):
        p=self.preview();a=self.save(p);before=self.k.storage.record_path(self.wid).read_bytes()
        b=self.save(p);self.assertEqual(a['evidence_id'],b['evidence_id']);self.assertEqual(0,b['created'])
        self.assertEqual(before,self.k.storage.record_path(self.wid).read_bytes())
        self.assertEqual(1,len(self.k.load_record(self.wid)['evidence_index']))

    def test_new_revision_preserves_previous_report(self):
        a=self.save();b=self.save(rev='git:synthetic:two')
        self.assertNotEqual(a['evidence_id'],b['evidence_id']);self.assertEqual(2,self.k.work_recovery_reports(self.wid)['count'])

    def test_changed_summary_cannot_reuse_existing_identity(self):
        self.save();self.assert_code('EVIDENCE_ID_CONFLICT',lambda:self.save(summary='Different assertion'))

    def test_changed_bytes_reject_stale_preview_without_record(self):
        p=self.preview();self.source.write_text('changed')
        self.assert_code('RECOVERY_PREVIEW_STALE',lambda:self.save(p));self.assertEqual(0,self.k.work_recovery_reports(self.wid)['count'])

    def test_competing_evidence_requires_fresh_preview(self):
        p=self.preview();self.save();self.source.write_text('another run')
        p2=self.preview();p2['evidence_revision']=p['evidence_revision']
        self.assert_code('EVIDENCE_REVISION_CONFLICT',lambda:self.save(p2))
        self.assertEqual(1,self.k.work_recovery_reports(self.wid)['count'])

    def test_tampered_original_is_visible_and_cannot_be_reused(self):
        p=self.preview();saved=self.save(p);e=saved['evidence'];(self.k.storage.work_dir(self.wid)/e['path']).write_text('tamper')
        self.assertEqual('SHA_MISMATCH',self.k.work_recovery_reports(self.wid)['items'][0]['integrity'])
        self.assert_code('EVIDENCE_ID_CONFLICT',lambda:self.save(p))

    def test_same_report_concurrent_retry_is_one_evidence(self):
        p=self.preview()
        with ThreadPoolExecutor(max_workers=2) as pool: results=list(pool.map(lambda _:self.save(p),range(2)))
        self.assertEqual([0,1],sorted(r['created'] for r in results))
        self.assertEqual(1,self.k.work_recovery_reports(self.wid)['count'])

    def test_supplementary_report_does_not_satisfy_any_profile_analysis_gate(self):
        for profile in ['BUG','BUG-NR','FEATURE','REFACTOR','PERF','MAINT','TOOLING']:
            wid='SYNTHETIC-'+profile;self.k.new(wid,profile,'Synthetic')
            p=self.k.recovery_report_preview(wid,self.source,'unverified','synthetic','summary')
            self.k.record_recovery_report(wid,self.source,'unverified','synthetic','summary',p['source_sha256'],0)
            record=self.k.load_record(wid);self.assertEqual('OPEN',record['state']);self.assertFalse(self.k._analysis_valid(wid,record))

    def test_existing_registry_still_rejects_wrong_kind_or_source_provider(self):
        self.assert_code('REGISTRY_MISMATCH',lambda:self.k.record_evidence(self.wid,self.source,'impact','analyze','l1-channel-recovery','1','synthetic','s'))
        self.assert_code('REGISTRY_MISMATCH',lambda:self.k.record_evidence(self.wid,self.source,'recovery_analysis','utility','code-analyzer','1','synthetic','s'))

    def test_embedded_json_provenance_cannot_disagree(self):
        source=self.root/'report.json';source.write_text(json.dumps({'provider':'code-analyzer'}))
        self.assert_code('RECOVERY_PROVENANCE_MISMATCH',lambda:self.preview(source=source))
        source.write_text('{invalid');self.assert_code('RECOVERY_REPORT_INVALID',lambda:self.preview(source=source))

    def test_invalid_formats_sizes_and_work_ids_are_rejected(self):
        self.source.write_bytes(b'\xff');self.assert_code('RECOVERY_REPORT_INVALID',self.preview)
        self.source.write_bytes(b'x'*(5*1024*1024+1));self.assert_code('RECOVERY_SIZE_INVALID',self.preview)
        self.source.write_text('valid');link=self.root/'link.md';link.symlink_to(self.source)
        self.assert_code('RECOVERY_SOURCE_INVALID',lambda:self.preview(source=link))
        self.assert_code('RECOVERY_WORK_INVALID',lambda:self.k.work_recovery_reports('../outside'))

    def test_export_links_digests_repeat_and_manual_document_preservation(self):
        saved=self.save();docs=self.root/'docs';out=self.k.work_docs_export(str(docs),self.wid)
        self.assertTrue(out['generation_complete']);work=docs/'works'/self.wid
        projection=json.loads((work/'state/recovery_reports.json').read_text());item=projection['items'][0]
        artifact=work/item['published_path'];self.assertEqual(saved['source_sha256'],hashlib.sha256(artifact.read_bytes()).hexdigest())
        self.assertIn('RECOVERY.md',(docs/'README.md').read_text());self.assertIn('RECOVERY.md',(work/'README.md').read_text())
        self.assertEqual(self.wid,json.loads((docs/'index/recovery.json').read_text())['items'][0]['work_id'])
        self.assertNotIn('work_category',json.loads((work/'state/work_snapshot.json').read_text()))
        before={str(p.relative_to(docs)):p.read_bytes() for p in docs.rglob('*') if p.is_file()}
        self.k.work_docs_export(str(docs),self.wid)
        self.assertEqual(before,{str(p.relative_to(docs)):p.read_bytes() for p in docs.rglob('*') if p.is_file()})
        (work/'RECOVERY.md').write_text('manual note')
        changed=self.k.work_docs_export(str(docs),self.wid)
        self.assertEqual('manual note',(work/'RECOVERY.md').read_text());self.assertFalse(changed['generation_complete'])

    def test_cross_host_export_preserves_existing_recovery_projection(self):
        self.save();docs=self.root/'docs';self.k.work_docs_export(str(docs),self.wid)
        k2=WorkLedgerKernel(self.root/'other-ledger',CONTRACTS);k2.new('SYNTHETIC-OTHER','BUG','Other')
        k2.work_docs_export(str(docs),'SYNTHETIC-OTHER')
        self.assertEqual(self.wid,json.loads((docs/'index/recovery.json').read_text())['items'][0]['work_id'])

    def test_cross_host_projection_cannot_override_work_identity_or_escape_link(self):
        self.save();docs=self.root/'docs';self.k.work_docs_export(str(docs),self.wid)
        path=docs/'works'/self.wid/'state/recovery_reports.json';data=json.loads(path.read_text())
        data['items'][0].update(work_id='../outside',work_path='../outside',published_path='../../outside.md')
        path.write_text(json.dumps(data))
        k2=WorkLedgerKernel(self.root/'other-ledger',CONTRACTS);k2.new('SYNTHETIC-OTHER','BUG','Other')
        k2.work_docs_export(str(docs),'SYNTHETIC-OTHER')
        entry=json.loads((docs/'index/recovery.json').read_text())['items'][0]
        self.assertEqual(self.wid,entry['work_id']);self.assertEqual('works/'+self.wid,entry['work_path'])
        self.assertIsNone(entry['published_path']);self.assertEqual('PUBLISHED_UNVERIFIED',entry['integrity'])

    def test_no_recovery_does_not_create_new_views(self):
        docs=self.root/'docs';self.k.work_docs_export(str(docs),self.wid)
        self.assertFalse((docs/'RECOVERY.md').exists());self.assertFalse((docs/'index/recovery.json').exists())

    def test_read_cli_returns_existing_metadata_without_body_or_write(self):
        self.save();before=self.k.storage.record_path(self.wid).read_bytes();out=StringIO()
        with redirect_stdout(out):rc=main(['--root',str(self.root/'ledger'),'recovery-list','--work-id',self.wid])
        self.assertEqual(0,rc);result=json.loads(out.getvalue());self.assertTrue(result['read_only'])
        self.assertEqual(1,result['count']);self.assertNotIn('Covered: 1',out.getvalue())
        self.assertEqual(before,self.k.storage.record_path(self.wid).read_bytes())

if __name__=='__main__':unittest.main()
