# Recovery 보고서 저장·조회 계약 — 개발 후보 0.7.46

이 계약은 기존 Work의 부가 보고서를 보존하는 기능이에요. 분석기 실행, source 수정, lifecycle 전이, Knowledge 게시와 운영 설치는 포함하지 않아요.

- 생산자: `l1-channel-recovery` / Evidence kind: `recovery_analysis`.
- 기존 `utility` stage에 보고서 첨부용 `attach-recovery-report` 슬롯을 추가해요. 기존 profile·record schema·FSM은 그대로예요.
- 보고서 형식은 UTF-8 Markdown 또는 JSON object, 최대 5 MiB예요. JSON에 provider/provider_version/code_rev가 있으면 선언과 일치해야 해요.
- 버전·code_rev는 호출자가 제공하는 출처 선언이에요. 이 저장 API가 분석 실행·설치 버전·source revision의 실제 의미를 독립 검증했다고 해석하지 않아요.
- 기존 코드 사실과 Recovery 판단은 각각 실제 생성한 provider로 등록해요. 제공자 이름을 바꿔 기존 슬롯을 우회하지 않아요.

## 생산자→허용된 writer

`kernel.recovery_report_preview(work_id, source_path, provider_version, code_rev, summary)`로 기존 Work와 파일을 대조해요. 반환의 `source_sha256`·`evidence_revision`을 고정한 뒤 허용된 writer가 `record_recovery_report(..., expected_sha256, expected_revision)`를 호출해요.

Work ID는 명시한 기존 ID예요. 이 API는 Work를 만들거나 focus를 바꾸지 않아요. 같은 Work/본문 hash/생산자 버전/code_rev는 기존 `E-<12hex>` Evidence ID로 연결해요. 동일 재시도는 원본 byte hash와 선언을 대조하고 기존 Evidence를 반환해요. 파일명만 바뀌어도 같은 내용/출처는 중복 등록하지 않아요. summary가 다른 동일 ID, 원본 변조, 다른 보고서의 stale preview는 충돌로 거부해요. 다른 source revision·내용은 별도 Evidence로 보존해요.

기존 record_evidence의 Work lock 안에서 등록·중복/수량 충돌을 검사해요. 읽은 보고서는 임시 고정 byte 복사본을 통해 기존 writer에 넘겨요. `AUTO_CANDIDATE`로 저장하며 저장 성공이 분석·수정·시험 성공이 되지 않아요. 거부/수정된 기존 confidence도 재시도에서 올리지 않아요.

## 읽기와 파생 문서

`work_recovery_reports(work_id)`와 아래 CLI는 본문을 실행하거나 분석을 재호출하지 않아요.

```text
<기존 Kernel launcher> recovery-list --work-id <기존 Work ID>
```

현재 등록 파일의 SHA/경로를 검사한 메타정보를 반환해요. 제품 효과나 적용성을 자동 판정하지 않아요. 기존 docs export는 해당 report의 실제 게시 매핑을 사용해 다음 파생 문서를 만들어요.

- `works/<work_id>/RECOVERY.md`: 원본 보고서 링크·출처·후보 상태.
- `works/<work_id>/state/recovery_reports.json`: 기존 Evidence 메타정보의 읽기 projection.
- `RECOVERY.md`, `index/recovery.json`: 게시된 Work의 Recovery 탐색 모음.

위 JSON은 재생성 가능한 조회 정보이며 새 Work 원장이나 기술 정본이 아니에요. 기존 Module→Feature→Scenario 분류를 대체하지 않아요. Viewer/Updater의 실제 mapping은 업무 GPT가 업무 환경에서 이 계약과 대조해요. 개인 `knowledge/`의 writer는 Updater로 유지해요.

기존 수동 편집 보존·export hash·Git 게시 guard를 유지해요. 파생 문서 충돌은 기존 export 결과의 manual_conflicts로 표시해요. 보고서 등록, export, Git 게시, Viewer 열람은 별도 성공 단계예요. 게시 실패 때문에 분석이나 등록을 다시 시작하지 않아요.

## 현재 적용 경계

이 패키지는 PRIVATE 개발 후보예요. 업무 스킬의 실제 출력 매핑·독립 코드 리뷰·호스트 통합 시험은 별도예요. MCP 자료 제공 기능을 먼저 구현하거나 사용자에게 설치본 자료를 요구하는 흐름은 필요하지 않아요. 업무 GPT는 실제 생산자 결과 형식과 이 계약을 연결하는 설계를 진행해요.
