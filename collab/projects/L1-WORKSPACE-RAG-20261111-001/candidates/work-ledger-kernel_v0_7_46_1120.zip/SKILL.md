---
name: work-ledger-kernel
version: "0.7.46"
description: Provides deterministic Work Ledger state, evidence, approval, safety, staleness, resume, and transfer guards for l1-fix-workflow.
---

## Recovery 보고서 보존 — 개발 후보 0.7.46

- 기존 Work에 l1-channel-recovery의 후보 보고서를 부가 Evidence로 보존. 저장만으로 분석·검증 완료 전이 없음.
- Work/루트 Recovery 보기와 recovery-list는 기존 원본·게시 hash를 참조. 개인 Knowledge/그룹 게시와 분리.
- 실제 생산자와 연결할 때 [저장·조회 계약](docs/RECOVERY_REPORT_INTAKE.md)을 확인. 개발 후보이며 설치·업무 통합 성공을 주장하지 않음.


## 개발 검증 후보 0.7.31-dev.1 (정식 배포 금지)

- 신규 `analyze-issue` Provider Registry에서 폐기 `l1-log-analysis` 제거. 과거 Evidence는 삭제하지 않음.
- Windows/Linux 및 MCP E2E 통합 검증 전 파트 배포 금지.

## MCP RESPONSE STANDARD 0.7.30 — 우선 적용

1. MCP 읽기 전용 `plan --read-only`는 `user_summary`의 결론/상태/다음 3행을 **가공 없이** 그대로 표시한다. 기본 600자·10행, 모바일 텍스트 표시. `display`는 사용자 명시 상세 요청에서만 표시한다. JSON 전체를 사용자에게 전송하지 않는다.
2. 내부 `action`, `saved`, `read_only`, `blocker`, Work ID/Evidence는 **기계 필드**로 그대로 유지한다. `presentation_version`, `response_view`, `truncated`는 표시 메타데이터다. 기존 `view` 필드 의미 변경 금지.
3. 읽기: 진행 상태, 논의 정리, 결정 후보(원장 승인 아님), 목록/오늘 할 일, 주간보고 200자 한 줄, 기존 MSC, 가이드. 쓰기/Provider/Git/Jira는 MCP에서 실행하지 않는다.
4. PC·MCP는 동일 Ledger 사실을 표현하지만 다음 행동/권한은 환경별로 다르다. 승인된 결정 ≠ 코드 검증. 모든 실행 성공/실패를 원장 근거 없이 추정하지 않는다.
5. 번호 선택 단독 자동처리 미지원(안전한 선택 세션 바인딩 별도 구현 필요). Topic+Option을 명시한다. 사내 Agent/MCP wrapper 연결·권한·길이는 F5 미검증.




## v0.7.29 논의 저장 / 권한

- 원장 `DECISION` 이벤트는 기존 타입 유지; `metadata.discussion_turn`으로 Topic/Option revision 식별.
- `discussion_draft.py`: same-PC Work-scoped 스냅샷, 승인 원장과 별도. PC CLI writer env로만 저장.
- 승인 후 원장 기록은 Linux writer + actor/session + pending ID + `--approve-record` 필요. PC 사용자 확인은 실제 사내에서 E2E 별도 점검.
- 원본 Legacy 이벤트/문서는 삭제하지 않음. `수정논의.md`, `수정설계.md`는 신규 Topic 기록이 있을 때만 생성.
- HARD Hook raw `git push` 차단. SOFT 런타임의 보호를 대체하지 않음.



## REVIEW PATCH 0.7.29 — top-level deterministic operation

1. `plan`/MCP = read-only: classify once; return `user_summary`, `summary_markdown`, `slot_request.submit_command`; never claim Draft or Ledger saved.
2. Existing code inspection / analysis report-based HLD → code-fact provider. Modified Diff code review → capability gate only. Do not fabricate provider success.
3. Authenticated local PC only: `discussion-draft upsert --turn-json -` retains all omitted options, bumps changed option revision, rejects stale selection.
4. `discussion-capture --operation preview --from-draft T1 --draft-revision N [--decide O2] [--prepare-pending]` generates normalized preview; apply requires identified PC actor/session + explicit approval.
5. Public `수정논의.md` is Ledger-derived, not local Draft; code facts require separate evidence; Git push raw shell prohibited.
6. State: REVIEW_CANDIDATE; real in-house Loader/Agent/MCP Git/Provider E2E NOT VERIFIED.


# work-ledger-kernel v0.7.29

## 관리 전용 Work 및 대화 이력 (검증 후보)

- 기술 분석이나 코드 수정 없이 이슈를 기록하려면 `l1-fix-workflow issue-track create/preview/apply/read`를 사용합니다. Kernel 자체는 `work_create(..., purpose="TRACKING_ONLY")`를 지원합니다.
- 사내 Linux PC Agent는 실제 사용자 제공 정보만 요약한 뒤 먼저 미리보기하고, 명시 승인·`L1_PC_LEDGER_WRITER=1`·actor/session 확인 후 기록합니다. 이 환경변수는 인증 수단이 아니므로 MCP Wrapper에 넘기지 않습니다.
- MCP는 `plan --read-only` 또는 `L1_WORKFLOW_MCP_READ_ONLY=1`로 강제 조회/미리보기로 운용합니다. 일반 PC `plan`은 과거 호환성 때문에 쓰기 경로가 남으므로 읽기 전용이라고 가정하지 않습니다.
- 생성된 `ISSUE_OVERVIEW.md`, `FOLLOW_UP.md`, `WORK_DISCUSSION.md`는 Ledger 파생 문서일 뿐, GitHub 원격 게시나 Jira 확인을 의미하지 않습니다.
- 사용 상세는 Workflow 패키지의 `docs/ISSUE_TRACKING_USER_GUIDE.md` 참조. 사내 E2E 미검증.

## v0.7.25 — GitHub artifacts 이름 자동 검사 및 일회성 마이그레이션 (REVIEW CANDIDATE)

- 신규 Work artifacts는 게시용 한글 유형 접두어 + 원본 기반 설명 + 안정적 Evidence ID 파일명을 사용합니다.
- 기존 Work는 GitHub 게시 전 미정리 이름과 매핑 누락을 자동 감지합니다.
- 안전한 경우에만 별도 `l1-workspace-migrate`를 1회 호출합니다. 도구가 없거나 Dirty/Diverged/충돌이면 fail-closed.
- 원본 Evidence·ID·SHA-256은 그대로 유지하며 GitHub Push 정책도 불변입니다.


# work-ledger-kernel


## v0.7.24 — GitHub Work 문서 찾기 개선 (REVIEW CANDIDATE, 2026-10-21)

- 기존 `works/<Work ID>/` 경로와 모든 영문 문서 파일명을 유지하고, 각 유효한 Work Snapshot별 `문서안내.md`를 생성하여 한글 용도별 링크를 제공합니다.
- 루트 README의 기존 이슈 테이블과 이슈 README 링크는 유지하면서 `문서 보기` 열을 추가했습니다.
- 다른 PC에서 생성된 기존 Work Snapshot도 안내 문서를 **추가**하지만, 과거 README/원문·Ledger 이벤트는 수정하지 않습니다.
- 수동 `문서안내.md` 충돌 시 보존하고 기존 README로 안내합니다. 반복 실행 멱등, Git/Jira 쓰기 없음.
- 신규 기능 테스트 및 선택적 회귀 통과. 기존 TL_REVIEW 레거시 테스트 1건은 이전 배포와 동일하게 차단 기대값 불일치. 사내 GitHub E2E 미검증.

## v0.7.23 — 결정적 Work Docs Dashboard 출력

- `work_docs_export`의 루트 README 생성시각을 실행 현재시각 대신 원본 Work 기록의 최신 갱신시각 기준으로 출력해 동일 입력 격리 preview/digest가 안정적으로 재현되게 개선했습니다.
- Work 이벤트, schema, Work ID, 이전 discussion/change-note exporter 동작, 승인정책은 변경하지 않습니다. Workflow >=1.6.35와 합성 검증 후보입니다.

## v0.7.21 — Work 논의 기록·문서 View (2026-10-20)

- 신규 `discussion_capture().preview/apply`로 과거 대화 요약의 출처/확정 상태를 검증하고 인증된 Linux PC에서만 append-only 기록.
- `work_docs_export()`에서 기존 Work context 기반 `WORK_DISCUSSION.md` 생성/갱신, 현 결정과 변경 이력/정정 이력 분리. 동시 활성 결정 충돌 표시. TL-private/자동 생성 안내 제외.
- 기존 Work/ID/record schema/evidence/approval/Repo Guard 불변, Windows/MCP 기본 조회. ChatGPT 계정 과거 대화 자동 복원/추론 없음.
- Workflow 1.6.33와 함께 REVIEW CANDIDATE / 사내 E2E 미검증.

## v0.7.20 — S0–S5 합성 검증 후보 (2026-10-20)

- **REVIEW CANDIDATE / NOT PRODUCTION VERIFIED.** 기존 Ledger를 마이그레이션하지 않습니다.
- MCP `plan` 및 Windows 기본 read-only: 조회·UNKNOWN에서 기록/INTENT/Focus 변경 금지. TL 전용 Review 본문은 Agent 출력·shared export에서 제외.
- PC Feature 저장은 신뢰된 Linux writer 환경에서만, `feature-capture preview/apply`로 session/actor/host/opaque pending+digest 확인 후 append. `L1_PC_LEDGER_WRITER=1`은 인증 토큰이 **아니므로** MCP Wrapper에 설정 금지.
- REQ/DEC 집계·30분 Pending·10분 경량 취소, 6건 batch 멱등, evidence SHA/registry `AUTO_CANDIDATE`; 기존 record/journal/approval/GitHub ref 보존.
- Design 공유본 `REQUIREMENTS.md`, `decisions.md`, `CODE_FACTS.md`, `DESIGN_CURRENT.md`, `CHANGE_HISTORY.md`; 레거시 TL_REVIEW portable 문서화는 안전 검증 전 BLOCKED.
- Jira 생성·댓글, P4 CL, Push, Source write, 일반 빌드·UT, worktree는 기본 비활성. 사내 live E2E 필요. `VALIDATION.md`, `KNOWN_FAILURES.json`, `RELEASE_COMPATIBILITY_MATRIX.md` 확인.

## v0.7.19 — 사람 중심 표시 개선 (REVIEW CANDIDATE)

- `<`·`>` 수치 비교 원문 의미 보존 (Markdown은 안전하게 escape). Daily·Weekly에서 실제 항목과 다음 할 일 표시.
- Work README/대시보드에는 한글 상태·KST·중복 없는 Jira 제목을 우선, 내부 Work ID/코드는 상세/JSON에 보관.
- HANDOFF README 준비 완료 사전 주장 금지, GitHub 원격 SHA/readback 없으면 동기화 완료 주장 금지.
- `plan`의 기록/전환 요청은 읽기 전용 미리보기이며 실제 기록이 아님. TL Review는 외부 게시 금지.
- 사내 GitHub push/MCP Runner/E2E는 미검증. 배포 보류.

## v0.7.19 — CrossHost human-first Work view (2026-10-19)

- GitHub dashboard and per-Work latest checkpoint facts, hypotheses, questions, multiple next actions and source time.
- Local docs are never remote-sync proofs. Escaped Markdown prevents table/HTML injection.
- Preserves Work Ledger original records, approvals, history, source references and private TL review separation.

## v0.7.17 — TL Work Continuity hardening (2026-10-19)

- Work Checkpoint / TL Review event-based continuity and KST Daily/Weekly views.
- Explicit natural/CLI adapter; no autonomous Provider execution, Jira write, product build/UT or Git Push.
- Work-linked context is append-only portable WorkUX context; Work-less Jira TL reviews are TL_PRIVATE_LOCAL_ONLY, including Work-linked reviews.
- Deployment status is REVIEW CANDIDATE. In-house MCP/Jira E2E not yet verified.



## Version lookup (authoritative)

- YAML `version` and top-level `VERSION` must match; `pyproject.toml`, package `__version__`, and `.skill-release.json` follow the same value.
- Read version through the installed skill's `SKILL.md` metadata or `VERSION`, not an MCP tool's advertised version alone.
- Version is a package identifier, **not** proof that the active MCP process reloaded the package.

Version: **0.7.23**  
Stage: **REVIEW CANDIDATE**

## 0.7.15 — Analysis Scope Seal / Explicit External Write Gate (2026-10-13)

- Scope Sealing confirms read-only analysis inputs (Jira IDs, log paths, code patterns) and records SHA256+revision in portable Work Ledger journal. It **never** approves Perforce or Jira writes.
- Scope revision changes invalidate outstanding external approval tokens; repeated return to earlier scope does not revive consent. Changed sealed scope invalidates previous source-write approval and rolls an existing spec lifecycle back to `SPECIFIED`.
- One-shot, exact payload SHA256-bound external mutation approvals: `p4_cl_create`, `jira_comment_create`, `jira_issue_create`. Every operation requires an authenticated **USER** confirmation. Gate `consume=True` atomically claims once; if external execution fails, obtain fresh consent.
- The source implementation spec is separate from `analysis_scope`. A `SPECIFIED` state is NOT equivalent to sealed analysis input scope.
- HARD Hook denies raw `p4 change -i` even if a separate approval exists: trusted Perforce/Jira Provider or MCP Wrapper must use `external-gate --consume` immediately before invoking an external API and enforce the same target/payload. Jira MCP tools do not pass through shell hooks.
- `--actor USER` text is **not proof of user identity**. Only an authenticated MCP/user-interaction layer can supply approval; agent/model must never invoke grant commands. Direct source approval FSM stays unchanged.

## 0.7.15 — Analysis Scope Seal / Explicit External Write Gate (2026-10-13)

- Scope Sealing confirms read-only analysis inputs (Jira IDs, log paths, code patterns) and records SHA256+revision in portable Work Ledger journal. It **never** approves Perforce or Jira writes.
- Scope revision changes invalidate outstanding external approval tokens; repeated return to earlier scope does not revive consent. Changed sealed scope invalidates previous source-write approval and rolls an existing spec lifecycle back to `SPECIFIED`.
- One-shot, exact payload SHA256-bound external mutation approvals: `p4_cl_create`, `jira_comment_create`, `jira_issue_create`. Every operation requires an authenticated **USER** confirmation. Gate `consume=True` atomically claims once; if external execution fails, obtain fresh consent.
- The source implementation spec is separate from `analysis_scope`. A `SPECIFIED` state is NOT equivalent to sealed analysis input scope.
- HARD Hook denies raw `p4 change -i` even if a separate approval exists: trusted Perforce/Jira Provider or MCP Wrapper must use `external-gate --consume` immediately before invoking an external API and enforce the same target/payload. Jira MCP tools do not pass through shell hooks.
- `--actor USER` text is **not proof of user identity**. Only an authenticated MCP/user-interaction layer can supply approval; agent/model must never invoke grant commands. Direct source approval FSM stays unchanged.

## 0.7.15 — Analysis Scope Seal / Explicit External Write Gate (2026-10-13)

- Scope Sealing confirms read-only analysis inputs (Jira IDs, log paths, code patterns) and records SHA256+revision in portable Work Ledger journal. It **never** approves Perforce or Jira writes.
- Scope revision changes invalidate outstanding external approval tokens; repeated return to earlier scope does not revive consent. Changed sealed scope invalidates previous source-write approval and rolls an existing spec lifecycle back to `SPECIFIED`.
- One-shot, exact payload SHA256-bound external mutation approvals: `p4_cl_create`, `jira_comment_create`, `jira_issue_create`. Every operation requires an authenticated **USER** confirmation. Gate `consume=True` atomically claims once; if external execution fails, obtain fresh consent.
- The source implementation spec is separate from `analysis_scope`. A `SPECIFIED` state is NOT equivalent to sealed analysis input scope.
- HARD Hook denies raw `p4 change -i` even if a separate approval exists: trusted Perforce/Jira Provider or MCP Wrapper must use `external-gate --consume` immediately before invoking an external API and enforce the same target/payload. Jira MCP tools do not pass through shell hooks.
- `--actor USER` text is **not proof of user identity**. Only an authenticated MCP/user-interaction layer can supply approval; agent/model must never invoke grant commands. Direct source approval FSM stays unchanged.

## 0.7.15 — Analysis Scope Seal / Explicit External Write Gate (2026-10-13)

- Scope Sealing confirms read-only analysis inputs (Jira IDs, log paths, code patterns) and records SHA256+revision in portable Work Ledger journal. It **never** approves Perforce or Jira writes.
- Scope revision changes invalidate outstanding external approval tokens; repeated return to earlier scope does not revive consent. Changed sealed scope invalidates previous source-write approval and rolls an existing spec lifecycle back to `SPECIFIED`.
- One-shot, exact payload SHA256-bound external mutation approvals: `p4_cl_create`, `jira_comment_create`, `jira_issue_create`. Every operation requires an authenticated **USER** confirmation. Gate `consume=True` atomically claims once; if external execution fails, obtain fresh consent.
- The source implementation spec is separate from `analysis_scope`. A `SPECIFIED` state is NOT equivalent to sealed analysis input scope.
- HARD Hook denies raw `p4 change -i` even if a separate approval exists: trusted Perforce/Jira Provider or MCP Wrapper must use `external-gate --consume` immediately before invoking an external API and enforce the same target/payload. Jira MCP tools do not pass through shell hooks.
- `--actor USER` text is **not proof of user identity**. Only an authenticated MCP/user-interaction layer can supply approval; agent/model must never invoke grant commands. Direct source approval FSM stays unchanged.

## GitHub Work human layout v2 — v0.7.8

`docs-export` now writes `works/<work_id>/` using immutable Work IDs, with human-readable `README.md` / `decisions.md`, `artifacts/` for outputs, and `state/` for machine resume files. Recognized legacy `active/` / `archive/` exports are migrated without deleting unrecognized folders.

## Cross-host portable context — v0.7.6

Sealed `export_work_item` / `import_work_item` transfers preserve Work name, decisions, current state, and next action through portable context files. Host-local paths, workspace bindings, leases, and credentials remain local-only.

## Purpose

Deterministic SSOT/state/evidence/safety kernel for `l1-fix-workflow`.

## Authority

Kernel alone may mutate the Work Ledger and decide lifecycle transitions/guards. It must not perform technical root-cause analysis, select a technical fix, author HLD, or fabricate provider evidence.

## CLI discovery contract

Do **not** treat a missing PATH entry (`work-ledger-kernel: command not found`) as a missing CLI. The ZIP ships package-local launchers. For every CLI action, including the first Work creation, resolve the launcher in this order:

```text
1. directory containing this SKILL.md
   Linux  : <skill_root>/work-ledger-kernel
   Windows: <skill_root>\work-ledger-kernel.cmd
2. canonical private skill directory
   Linux  : ~/l1sw-private-skills/work-ledger-kernel/work-ledger-kernel
   Windows: %USERPROFILE%\l1sw-private-skills\work-ledger-kernel\work-ledger-kernel.cmd
3. only if package import is already available: python -m work_ledger_kernel
```

Never stop after only `which/where work-ledger-kernel` fails. Check the package-local launcher first. If the launcher exists, continue with it.

### Claude Code: registration-only permission (optional, POSIX Bash)

Local `work-create` / `work-adopt` from the **absolute package launcher** can be
pre-approved without pre-approving the rest of Bash. Install the project-local
Hook with `python scripts/install_claude_hooks.py --project <project>
--auto-allow-registration`. The installer preserves existing `permissions`,
`hooks`, and `env`. It sets `WORK_LEDGER_AUTO_ALLOW_REGISTRATION=1` for that
project only. This is OFF without the flag and does not bypass explicit
Claude Code `ask`/`deny` rules, managed policies, or a Kernel HARD denial.

**For registration-only user requests**, invoke the resolved Kernel launcher
with `work-create` or `work-adopt` directly, in a single Bash command.
Do **not** use the general Workflow `plan` command for this path: `plan` may
execute additional work actions and is not in the narrow permission grant.
This opt-in supports POSIX `Bash` with the canonical `work-ledger-kernel`
launcher, not Windows `PowerShell` or `.cmd` (separate verification required).
It never automatically approves tests, source edits, provider calls, Git or
external writes. Unrecognized commands continue through normal permissions.

### First Work creation

For natural-language requests such as `새 작업 만들어줘`, `TxSwitch 작업 생성해줘`, or when a new Work is required before further orchestration, use one atomic UX command:

```text
<resolved_launcher> work-create --title "<title>" --goal "<goal>" [--host-id <host>] [--session-id <session>]
```

`work-create` creates a `YYYYMMDD-<id>` Work and focuses it. Do **not** require a prior `new`, profile selection, workspace binding, or PATH installation. `--profile` is optional and may be deferred until the first technical provider route.

### Adopt an already-running session

When the user asks to register the work already being discussed/debugged, use `work-adopt` instead of creating an empty Work. Summarize the current session into title/goal plus decisions, attempts, failures, current state, and next actions; do not ask the user to repeat information already visible in the current session.

```text
<resolved_launcher> work-adopt --title "<title>" --goal "<goal>" \
  [--decision "<decision>"] [--attempt "<attempt>"] [--failure "<failure>"] \
  --current-state "<current state>" [--next-action "<next>"] \
  [--workspace <path> --scm <scm> --repo-id <repo>] [--host-id <host>] [--session-id <session>]
```

Imported history is context only. Never convert it into retroactive lifecycle evidence or approval.

## Commands

```text
new
work-create
work-adopt
work-list
work-select
work-focus
work-state
work-name
context
docs-export
use
status
resume --view brief|diagnostic
note
spec set
approve
approve-delivery
record
gate
advance
export
import
```

`approve` and `approve-delivery` are explicit USER actions. Claude HARD mode blocks model-initiated approval commands while leaving direct user terminal execution available.

## Lifecycle

```text
OPEN → ANALYZED → SPECIFIED → APPROVED → IMPLEMENTED → VERIFIED → DELIVERED
```

Baseline/measurement is evidence, not an FSM state. Failed AFTER verification stays `IMPLEMENTED`.

## Profile guards

- BUG/BUG-NR: `issue_analysis + repro_attempt`
- FEATURE: `asis_callflow + impact`
- REFACTOR: `structure_metric + impact`, plus approved structure-oriented anchor
- MAINT: `impact`
- TOOLING: `impact`; typed `tooling_baseline/tooling_after`
- PERF: `impact`; typed `baseline_measure/after_measure`

All source-changing profiles retain spec → USER approval → valid baseline → scoped implementation provenance → AFTER verification → USER delivery approval.

## TOOLING

TOOLING typed checks are `UT`, `COMMAND_SMOKE`, or `STATIC_VALIDATION`. BASELINE must cover approved anchors and protect oracles. AFTER must observe approved expected-after values and pass protect oracles. Config files to be modified are source scope and use the same source-write gate.

## PERF

The Kernel deterministically validates:
- metric id/unit/direction/aggregation;
- threshold semantics;
- raw samples and exact sample count;
- warmup and outlier policy;
- minimum effective sample count;
- device/hardware/OS/config/tool/build identity;
- baseline/AFTER sampling-policy compatibility;
- functional protect oracles;
- baseline reference and implementation `code_rev`.

Environment, metric, or sampling incompatibility is `INCONCLUSIVE`; numerical PASS alone is insufficient.

## Explicit multi-host transfer

`export` creates a sealed archive containing record, sealed evidence, normalized semantic journal, and manifest. It excludes bindings, write leases, source-host binding events, and transfer audit events.

`import` verifies repository identity, paths, duplicate entries, file hashes/sizes, evidence metadata hashes, content fingerprint, and same-work-id divergence. Automatic merge is forbidden. After a successful import, only the destination workspace is locally bound.

## Enforcement

Claude Code: HARD hooks.  
Roo/OpenCode: SOFT mode (`status/resume`, then `gate` before writes); do not claim hard bypass prevention.

## Final contract references

- `contracts/profile_policies_v1.json`
- `contracts/registry_v1.json`
- `contracts/transfer_manifest_v1.schema.json`
- `docs/MULTI_HOST_TRANSFER_v1.md`
- `docs/WORK_LEDGER_CONTRACT_v1.md`

## v0.6.2 user-facing commands

```text
work-ledger-kernel code-rev --work-id <ID> --workspace <PATH>
work-ledger-kernel set-profile --work-id <ID> --profile <PROFILE>
work-ledger-kernel authorize-resume-write --work-id <ID> --workspace <PATH> [--changed-path <PATH> ...]
```

Root precedence: explicit `--root` → `WORK_LEDGER_ROOT` → `L1_LEDGER_ROOT` → platform default. `--root` is accepted before or after the subcommand. Same-path `use` rebinding replaces the old binding.

## Mutable Work name

The generated Work ID is immutable. If the user says `이 작업 이름을 SOC-1234-RECOVERY로 변경해줘`, resolve the current Work and call:

```text
<resolved_launcher> work-name --work-id <immutable-id> --name "SOC-1234-RECOVERY"
```

Display `YYYYMMDD-SOC-1234-RECOVERY` when the internal ID is a prefixless generated ID. Never rename the ledger directory, `record.json` identity, focus binding, or evidence references. The mutable name is searchable and must be unique case-insensitively across the ledger.

## v0.7.9 — Work context revision

`context-revision --work-id ID` reads current event count; `context --work-id ID --type DECISION --text "..." --expected-revision N` atomically rejects stale updates. Legacy callers may omit `--expected-revision`. This controls context journal only, not all Work lifecycle revisions; MCP wrapper must not present it as a global revision.


Latest: `continuity` now handles TORN_TAIL/PARTIAL, deterministic retry, latest event Board, cited Weekly and TL-private review history. Existing record/Evidence/Approval remain unchanged. See `references/legacy_skill_guide_v0_7_16.md`.


## Code change note (review candidate 0.7.22)
- Public `WorkLedgerKernel.change_note().read(work_id)` and `.render(view, mobile=True|False)` read stored change provenance, revision-matched verification and approved discussion events only; never infer missing conversation or code behavior.
- `CODE_CHANGE_NOTE.md` is generated via explicit docs-sync; it is not an authoritative new Work.
- `.preview()` / `.apply()` are authenticated Linux-PC-only, same host/session/actor/digest, 30-minute, append-only *presentation context* operations. The accepted explanation does not become verification Evidence and cannot override any existing safety gate.
- No source code snippets or diff are published by default. Registry mock contract is not proof of company `l1-fla` compatibility.

## 2026-10-22 생성 문서 전달력 규칙 (0.7.26)
모든 새 View는 Ledger/canonical 근거에서 결정론적으로 생성합니다. 문서 생성은 source_write 승인이나 GitHub Push가 아닙니다.
상세 계약: references/generated_docs_communication.md


## Claude Code 자동 승인 정책 (0.7.34-dev.1 개발 검증)
- 설치기 `--auto-allow-workflow --workflow-root <trusted skill path>`는 사용자 명시 opt-in이다.
- Python `-m l1_fix_workflow ... plan`, Work 바인딩된 표준 pytest/unittest만 안전한 CLI 형태에서 Hook allow; 임의 Python/scripts는 제외한다.
- 사용자 명시적 분석 요청 이외 Provider 실행, Source/SCM/외부 변경 승인, HARD gate, 기존 Ask/Deny 규칙은 이 기능으로 대체하지 않는다.
- Windows PowerShell 및 실제 CLI 설치 통합은 미검증.

## Work 목록 사용자 요약 (0.7.36-dev.1 개발 후보)
- `work_list` API에서 기존 machine `items`는 그대로 제공하며 `user_summary`에 `번호 / 이슈 번호 / 작업 내용` 표를 추가한다.
- 내부 Work ID와 이력, 포커스, 선택 스냅샷은 변경하지 않는다. 대화형 에이전트는 `user_summary`를 우선 표시한다.
- Jira 연결은 저장된 참조 및 유효한 원천 제목/목표의 Jira 키만 활용한다. Jira 네트워크 실시간 조회·원천 자동수정 없음.
- v0.7.34의 명시적 opt-in Workflow Hook 최소 권한 설정은 그대로 유지한다. Hook 허용이 Claude settings ask/deny 정책보다 우선한다고 주장하지 않는다.

## v0.7.38-dev.1 — Python 3.10/3.11 f-string 구문 후보

- Work 요구사항 문서와 Dashboard 출력에서 f-string 표현식 내부 따옴표를 사전에 계산하여 Python 3.10/3.11에서도 파싱 가능하도록 보완. Work/Evidence registry/schema, 운영 DB 및 exporter의 출력 계약 변경 없음.


### 개인 Knowledge와 exporter 공존 (개발 후보 v0.7.43)
- `work_ux.export_docs`는 Updater 전용 `knowledge/`를 읽기 전용으로 유지하며 실제 `knowledge/README.md`가 있을 때 루트 탐색 링크만 생성.
- Kernel 신규 Knowledge Profile/ref_type/원장은 선제 도입하지 않음. Work-side backlink 실제 계약은 G0 이후 확정.


### MSC Work-root 안내 링크 정합성 (개발 후보 0.7.45)
- 기존 Work-root MSC_VIEW.md는 Kernel writer만 관리. Converter 상세 MSC_VIEW.md Evidence bytes 불변.
- 실제 게시된 doc-converter HTML Evidence의 published_path를 같은 Work 안내에 MSC HTML 다운로드 링크로 표시.
- 수동 편집/기존 생성 해시 불일치 시 기존 write_communication 정책대로 보류. 개인 knowledge/ 쓰기 없음.
- 브라우저 렌더·업무 호스트 설치·Updater/group writer 검증을 주장하지 않음.
