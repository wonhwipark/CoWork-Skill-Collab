"""Supplementary Recovery reports: existing Evidence writer, derived read views.

This module neither runs a provider nor advances the engineering lifecycle.
"""
from __future__ import annotations

import hashlib
import json
import re
import tempfile
from pathlib import Path
from urllib.parse import quote

from .errors import KernelError

PROVIDER = "l1-channel-recovery"
KIND = "recovery_analysis"
STAGE = "utility"
MAX_BYTES = 5 * 1024 * 1024


def _require(ok, code, message):
    if not ok:
        raise KernelError(code, message)


def _work(kernel, work_id):
    _require(isinstance(work_id, str) and re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", work_id)
             and work_id not in {".", ".."}, "RECOVERY_WORK_INVALID", "Exact Work ID required")
    directory = kernel.storage.work_dir(work_id)
    _require(not directory.is_symlink() and directory.resolve().is_relative_to(kernel.storage.root),
             "RECOVERY_WORK_INVALID", "Work directory must remain inside this Ledger")
    record = kernel.load_record(work_id)
    _require(record["work_id"] == work_id, "RECOVERY_WORK_INVALID", "Work identity mismatch")
    return record


def _input(work_id, path, provider_version, code_rev, summary):
    for value in (provider_version, code_rev, summary):
        _require(isinstance(value, str) and value.strip() and len(value) <= 4096,
                 "RECOVERY_PROVENANCE_REQUIRED", "Declared producer version, source revision and summary required")
    source = Path(path).expanduser()
    _require(not source.is_symlink(), "RECOVERY_SOURCE_INVALID", "Report symlink is not supported")
    source = source.resolve(strict=True)
    _require(source.is_file() and source.suffix.lower() in {".md", ".json"},
             "RECOVERY_SOURCE_INVALID", "A local Markdown or JSON report is required")
    with source.open("rb") as stream:
        data = stream.read(MAX_BYTES + 1)
    _require(0 < len(data) <= MAX_BYTES, "RECOVERY_SIZE_INVALID", "Report must be nonempty and at most 5 MiB")
    try:
        text = data.decode("utf-8")
        if source.suffix.lower() == ".json":
            payload = json.loads(text)
            _require(isinstance(payload, dict), "RECOVERY_JSON_INVALID", "JSON report must be an object")
            for key, expected in (("provider", PROVIDER), ("provider_version", provider_version), ("code_rev", code_rev)):
                _require(key not in payload or payload[key] == expected,
                         "RECOVERY_PROVENANCE_MISMATCH", "Embedded provenance differs from declaration")
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise KernelError("RECOVERY_REPORT_INVALID", "Report must contain valid UTF-8/JSON") from exc
    digest = hashlib.sha256(data).hexdigest()
    identity = json.dumps([work_id, PROVIDER, KIND, provider_version, code_rev, digest], separators=(",", ":"))
    # Preserve the existing immutable Evidence/publication naming contract.
    eid = "E-" + hashlib.sha256(identity.encode()).hexdigest()[:12]
    return source.name, data, digest, eid


def preview(kernel, work_id, source_path, provider_version, code_rev, summary):
    record = _work(kernel, work_id)
    _, data, digest, eid = _input(work_id, source_path, provider_version, code_rev, summary)
    return {"ok": True, "action": "RECOVERY_REPORT_PREVIEW", "saved": False,
            "work_id": work_id, "provider": PROVIDER, "provider_version": provider_version,
            "kind": KIND, "stage": STAGE, "code_rev": code_rev, "summary": summary,
            "source_sha256": digest, "source_bytes": len(data), "evidence_id": eid,
            "evidence_revision": len(record.get("evidence_index") or []),
            "already_recorded": any(e.get("id") == eid for e in record.get("evidence_index") or []),
            "confidence_state": "AUTO_CANDIDATE", "provider_executed": False, "git_push": False}


def record(kernel, work_id, source_path, provider_version, code_rev, summary,
           expected_sha256, expected_revision):
    _work(kernel, work_id)
    name, data, digest, eid = _input(work_id, source_path, provider_version, code_rev, summary)
    _require(expected_sha256 == digest and isinstance(expected_revision, int) and not isinstance(expected_revision, bool),
             "RECOVERY_PREVIEW_STALE", "Preview digest and Evidence revision are required")
    # Freeze the bytes once: a producer editing its output must not change an
    # artifact between preview validation and the existing Kernel copy operation.
    with tempfile.TemporaryDirectory(prefix="recovery-report-") as td:
        frozen = Path(td) / name
        frozen.write_bytes(data)
        result = kernel.record_evidence(work_id, frozen, KIND, STAGE, PROVIDER,
                    provider_version, code_rev, summary, evidence_id=eid,
                    expected_evidence_count=expected_revision, reuse_if_identical=True)
    evidence = result["evidence"]
    _require(evidence["sha256"] == digest, "RECOVERY_READBACK_FAILED", "Registered report digest differs")
    return {"ok": True, "action": "RECOVERY_REPORT_RECORDED" if result["created"] else "RECOVERY_REPORT_ALREADY_RECORDED",
            "saved": True, "created": int(result["created"]), "work_id": work_id,
            "evidence_id": evidence["id"], "source_sha256": evidence["sha256"],
            "evidence": evidence, "provider_executed": False, "git_push": False,
            "lifecycle_advanced": False, "technical_verification": "NOT_ASSERTED"}


def read(kernel, work_id):
    record = _work(kernel, work_id)
    base = kernel.storage.work_dir(work_id).resolve()
    items = []
    for evidence in record.get("evidence_index") or []:
        if (evidence.get("provider"), evidence.get("kind"), evidence.get("stage")) != (PROVIDER, KIND, STAGE):
            continue
        item = dict(evidence)
        relative = Path(str(item.get("path") or ""))
        source = base / relative
        if (relative.is_absolute() or ".." in relative.parts or source.is_symlink()
                or not source.resolve().is_relative_to(base)):
            integrity = "UNSAFE_PATH"
        elif not source.is_file():
            integrity = "MISSING"
        elif source.stat().st_size > MAX_BYTES:
            integrity = "TOO_LARGE"
        else:
            integrity = "MATCH" if hashlib.sha256(source.read_bytes()).hexdigest() == item.get("sha256") else "SHA_MISMATCH"
        item["integrity"] = integrity
        items.append(item)
    return {"ok": True, "work_id": work_id, "category": "Recovery", "read_only": True,
            "items": items, "count": len(items), "provider_executed": False,
            "lifecycle_state": record["state"], "technical_verification": "NOT_ASSERTED"}


def _cell(value):
    return str(value or "-").replace("\n", " ").replace("\r", " ").replace("|", "\\|").replace("[", "\\[").replace("]", "\\]")[:220]


def project_work(kernel, work_id, out_dir, artifact_entries, write_communication, write_if_changed):
    result = read(kernel, work_id)
    state_file = out_dir / "state" / "recovery_reports.json"
    if not result["items"] and not state_file.exists():
        return False
    rows = []
    lines = ["# Recovery 분석", "", "> 저장된 후보 보고서 모음. 코드 수정·제품 시험·안전 복귀의 검증 상태는 각 원본에서 확인하세요.", "",
             "| Evidence | 요약 | 선언된 source revision | 근거 상태 | 원본 |", "|---|---|---|---|---|"]
    for item in result["items"]:
        mapping = artifact_entries.get(item["id"], {})
        published = mapping.get("published_path")
        valid = False
        if isinstance(published, str):
            rel = Path(published)
            target = out_dir / rel
            valid = (not rel.is_absolute() and ".." not in rel.parts and not target.is_symlink()
                     and target.resolve().is_relative_to(out_dir.resolve()) and target.is_file()
                     and mapping.get("sha256") == item["sha256"] and item["integrity"] == "MATCH"
                     and hashlib.sha256(target.read_bytes()).hexdigest() == item["sha256"])
        entry = {key: item.get(key) for key in ("id", "provider", "provider_version", "code_rev", "sha256", "summary", "confidence_state", "integrity")}
        entry["published_path"] = published if valid else None
        rows.append(entry)
        link = "[보고서](" + quote(published, safe="/") + ")" if valid else "미게시/무결성 미확인"
        lines.append("| " + " | ".join((_cell(item["id"]), _cell(item["summary"]), _cell(item["code_rev"]),
                     _cell(item["confidence_state"] + " / " + item["integrity"]), link)) + " |")
    payload = {"schema_version": 1, "derived": True, "work_id": work_id, "items": rows}
    write_if_changed(state_file, json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    write_communication(out_dir, "RECOVERY.md", "\n".join(lines) + "\n")
    return bool(rows)


def project_index(root, dashboard_rows, write_communication, write_if_changed):
    items = []
    found_projection = False
    for work in dashboard_rows:
        wid = work["work_id"]
        if not re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", wid) or wid in {".", ".."}:
            continue
        directory = root / "works" / wid
        path = directory / "state" / "recovery_reports.json"
        if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()) or not path.is_file():
            continue
        if path.stat().st_size > MAX_BYTES:
            raise KernelError("RECOVERY_PROJECTION_INVALID", "Recovery projection exceeds size limit")
        data = json.loads(path.read_text(encoding="utf-8"))
        if data.get("schema_version") != 1 or data.get("work_id") != wid or data.get("derived") is not True:
            raise KernelError("RECOVERY_PROJECTION_INVALID", "Recovery projection identity differs")
        entries = data.get("items")
        _require(isinstance(entries, list) and len(entries) <= 10000,
                 "RECOVERY_PROJECTION_INVALID", "Invalid Recovery projection entries")
        found_projection = True
        for entry in entries:
            _require(isinstance(entry, dict) and entry.get('provider') == PROVIDER
                     and isinstance(entry.get('id'), str),
                     "RECOVERY_PROJECTION_INVALID", "Invalid Recovery projection provenance")
            selected = {key: entry.get(key) for key in ("id", "provider", "provider_version", "code_rev", "sha256", "summary", "confidence_state", "integrity", "published_path")}
            published = selected.get('published_path')
            if isinstance(published, str):
                rel = Path(published)
                target = directory / rel
                safe = (not rel.is_absolute() and '..' not in rel.parts and not target.is_symlink()
                        and target.resolve().is_relative_to(directory.resolve()) and target.is_file())
                if not safe or hashlib.sha256(target.read_bytes()).hexdigest() != selected.get('sha256'):
                    selected['published_path'] = None
                    selected['integrity'] = 'PUBLISHED_UNVERIFIED'
            items.append({**selected, "work_id": wid, "work_path": "works/" + wid})
    if not found_projection:
        return 0
    items.sort(key=lambda x: (x["work_id"], x["id"]))
    lines = ["# Recovery 분석 모음", "", "> 기존 Work/Evidence에서 파생한 탐색 목록. 분석·구현·시험 성공 판정은 원본과 구분하세요.", "",
             "| Work | Evidence | 요약 | 원본 위치 |", "|---|---|---|---|"]
    for item in items:
        work_path = item["work_path"]
        lines.append("| " + " | ".join((_cell(item["work_id"]), _cell(item["id"]), _cell(item["summary"]),
                     "[Recovery 보기](" + work_path + "/RECOVERY.md)")) + " |")
    write_communication(root, "RECOVERY.md", "\n".join(lines) + "\n")
    write_if_changed(root / "index" / "recovery.json", json.dumps(
        {"schema_version": 1, "derived": True, "category": "Recovery", "items": items},
        ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    return len(items)
