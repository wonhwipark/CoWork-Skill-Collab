#!/usr/bin/env python3
"""Deterministic, MCP-evidence-driven Jira -> P4 L1 postmortem screening.

This module NEVER contacts Jira or P4. The hosting agent must collect Jira
read-only evidence using its Jira MCP and P4 evidence using Mango MCP only.
"""
from __future__ import annotations

import argparse
import fnmatch
import json
import re
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any

VERSION = "0.6.8"
SCHEMA = "p4-code-owner.jira-fix-cl-scan.v1"
ISSUE_RE = re.compile(r"(?<![A-Za-z0-9])([A-Z][A-Z0-9]{1,14}-\d{1,12})(?![A-Za-z0-9])")
CL_PATTERNS = (
    re.compile(r"(?<![A-Za-z0-9])(?:p4\s*[-#:]?\s*)?(?:changelist|change\s*list|change|CL|체인지리스트)\s*(?:no\.?\s*)?[:=#-]?\s*(\d{5,11})(?!\d)", re.I),
    re.compile(r"(?<!\d)(\d{5,11})\s*(?:번\s*)?(?:CL|changelist)(?![A-Za-z0-9])", re.I),
)
FIX_RE = re.compile(r"수정|고침|수정본|패치|결함\s*해결|fix(?:ed|es|ing)?|patch|resolve(?:d)?|solution|버그\s*수정", re.I)
INTEGRATION_RE = re.compile(r"반영|이관|통합|merge(?:d)?|integrat(?:e|ed|ion)|cherry[- ]?pick|sync|포팅|backport", re.I)
REVERT_RE = re.compile(r"revert(?:ed)?|rollback|roll[- ]?back|원복|되돌림|복구", re.I)
NON_FIX_RE = re.compile(r"참고|참조|이전|관련|비교|원인\s*CL|문제\s*유발|reference|related|caused|introduced|not\s*fix|non[- ]fix", re.I)
SOURCE_EXTENSIONS = (".c", ".cc", ".cpp", ".cxx", ".h", ".hpp", ".hxx")
KST = timezone(timedelta(hours=9))


def save_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def issue_keys(markdown: str) -> list[str]:
    return list(dict.fromkeys(m.group(1) for m in ISSUE_RE.finditer(markdown)))


def canonical_output(run_id: str) -> Path:
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,90}", run_id) or run_id in (".", ".."):
        raise ValueError("Invalid run-id (must be simple filename, no traversal)")
    return (Path.home() / "l1sw-private-skills" / "p4-code-owner" / "output" / run_id).resolve()


def markdown_escape(value: Any) -> str:
    return str(value if value is not None else "-").replace("|", "\\|").replace("\r", " ").replace("\n", " ").strip() or "-"


def text_body(body: Any) -> str:
    """Extract textual content from plain Jira body or ADF tree without HTML."""
    if isinstance(body, str):
        return body
    if isinstance(body, list):
        return "\n".join(filter(None, (text_body(p) for p in body)))
    if isinstance(body, dict):
        if body.get("type") == "text":
            return str(body.get("text", ""))
        return text_body(body.get("content", []))
    return ""


def local_clause(value: str, start: int, end: int) -> tuple[str, str]:
    """Use bounded clause context: do not borrow 'fix' from another CL."""
    left = value[max(0, start - 100):start]
    right = value[end:end + 100]
    left = re.split(r"[\n\r;,，；]|\s{3,}", left)[-1][-38:]
    right = re.split(r"[\n\r;,，；]|\s{3,}", right)[0][:38]
    # A preceding CL token is a boundary too.
    left = re.split(r"(?:\bCL\s*[:=#-]?\s*\d{5,11}\b|\b\d{5,11}\s*CL\b)", left, flags=re.I)[-1]
    right = re.split(r"(?:\bCL\s*[:=#-]?\s*\d{5,11}\b|\b\d{5,11}\s*CL\b)", right, flags=re.I)[0]
    return left, right


def candidate_role(body: str, start: int, end: int) -> tuple[str, str]:
    left, right = local_clause(body, start, end)
    context = (left + " " + right).strip()
    # Prior modifiers take precedence: 'fix CL 123, merge CL 456'.
    focus = left[-23:]
    if REVERT_RE.search(focus) or REVERT_RE.search(right[:15]):
        return "REVERT_CANDIDATE", context
    if INTEGRATION_RE.search(focus) or INTEGRATION_RE.search(right[:18]):
        return "INTEGRATION_CANDIDATE", context
    if NON_FIX_RE.search(focus) or NON_FIX_RE.search(right[:18]):
        return "REFERENCE_ONLY", context
    if FIX_RE.search(focus) or FIX_RE.search(right[:24]):
        return "FIX_CANDIDATE", context
    return "UNKNOWN_ROLE", context


def cl_candidates(issues: list[dict[str, Any]]) -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    for issue in issues:
        key = issue["issue_key"]
        segments: list[tuple[str, str, Any]] = [("description", "-", issue.get("description", ""))]
        for index, comment in enumerate(issue.get("comments", [])):
            segments.append(("comment", str(comment.get("id", index)), comment.get("body", "")))
        for location, comment_id, raw_body in segments:
            body = text_body(raw_body)
            seen: set[tuple[int, int, str]] = set()
            for pattern in CL_PATTERNS:
                for match in pattern.finditer(body):
                    cl = match.group(1)
                    point = (match.start(), match.end(), cl)
                    if point in seen:
                        continue
                    seen.add(point)
                    role, context = candidate_role(body, match.start(), match.end())
                    found.append({"issue_key": key, "cl": cl, "role": role,
                                  "location": location, "comment_id": comment_id,
                                  "excerpt": context[:180]})
    return found


def validate_jira_evidence(data: Any, keys: list[str]) -> list[dict[str, Any]]:
    if not isinstance(data, dict) or not isinstance(data.get("issues"), list):
        raise ValueError("jira_evidence.json must contain an issues list")
    by_key: dict[str, dict[str, Any]] = {}
    for item in data["issues"]:
        if not isinstance(item, dict) or not isinstance(item.get("issue_key"), str):
            raise ValueError("Each Jira issue needs issue_key")
        key = item["issue_key"].upper()
        if key in by_key:
            raise ValueError("Duplicate jira evidence issue_key: " + key)
        if not isinstance(item.get("comments", []), list):
            raise ValueError("comments must be an array: " + key)
        by_key[key] = {**item, "issue_key": key}
    return [by_key.get(k, {"issue_key": k, "retrieval_status": "MISSING", "comments_complete": False,
                                  "description": "", "comments": []}) for k in keys]


def load_scope(path: Path) -> dict[str, Any] | None:
    if not path.is_file():
        return None
    obj = read_json(path)
    if not isinstance(obj, dict):
        raise ValueError("L1 scope config must be a JSON object")
    includes = obj.get("l1_include_paths")
    excludes = obj.get("l1_exclude_paths", [])
    extensions = obj.get("source_extensions", list(SOURCE_EXTENSIONS))
    if (not isinstance(includes, list) or not all(isinstance(p, str) for p in includes)
            or not isinstance(excludes, list) or not all(isinstance(p, str) for p in excludes)
            or not isinstance(extensions, list) or not all(isinstance(p, str) for p in extensions)):
        raise ValueError("Scope config requires string lists for include/exclude/extensions")
    return {"l1_include_paths": includes, "l1_exclude_paths": excludes,
            "source_extensions": extensions, "case_sensitive": bool(obj.get("case_sensitive", False))}


def classify_file(file: dict[str, Any], scope: dict[str, Any] | None) -> str:
    if scope is None or not scope["l1_include_paths"]:
        return "UNKNOWN_SCOPE"
    path = file.get("path")
    if not isinstance(path, str) or not path.startswith("//"):
        return "UNKNOWN_PATH"
    action = str(file.get("action", "")).casefold()
    if action not in ("add", "edit", "delete", "move/add", "move/delete", "branch", "integrate"):
        return "UNKNOWN_ACTION"  # No assumption about custom P4 actions.
    testpath = path if scope["case_sensitive"] else path.casefold()
    includes = scope["l1_include_paths"]
    excludes = scope["l1_exclude_paths"]
    if not scope["case_sensitive"]:
        includes = [p.casefold() for p in includes]
        excludes = [p.casefold() for p in excludes]
    if not any(fnmatch.fnmatchcase(testpath, pat) for pat in includes):
        return "NOT_L1_PATH"
    if any(fnmatch.fnmatchcase(testpath, pat) for pat in excludes):
        return "EXCLUDED_PATH"
    if not path.casefold().endswith(tuple(str(ext).casefold() for ext in scope["source_extensions"])):
        return "NON_SOURCE_FILE"
    return "L1_SOURCE"


def validated_change(record: dict[str, Any] | None, scope: dict[str, Any] | None) -> dict[str, Any]:
    if record is None:
        return {"state": "MISSING_P4", "files": [], "l1_files": []}
    if (record.get("status") != "OK" or record.get("submitted") is not True
            or not isinstance(record.get("files"), list)):
        return {"state": "P4_UNVERIFIED", "files": [], "l1_files": []}
    files = record["files"]
    classified = [(f, classify_file(f, scope)) for f in files if isinstance(f, dict)]
    l1_files = [f["path"] for f, kind in classified if kind == "L1_SOURCE"]
    if scope is None or not scope["l1_include_paths"]:
        state = "SCOPE_NOT_CONFIGURED"
    elif l1_files:
        state = "L1_VERIFIED"
    elif (files and record.get("files_complete") is True and len(classified) == len(files)
          and all(c not in ("UNKNOWN_ACTION", "UNKNOWN_PATH") for _, c in classified)):
        state = "NON_L1_VERIFIED"
    else:
        state = "P4_INCOMPLETE"
    # Integration-only CL does not prove the original fix without source-trace evidence.
    if record.get("change_kind") == "INTEGRATION" and record.get("origin_confirmed") is not True:
        state = "INTEGRATION_ORIGIN_UNRESOLVED"
    return {"state": state, "files": files, "l1_files": l1_files,
            "source_cls": record.get("source_cls", []), "user": record.get("user")}


def score_issues(keys: list[str], jira: list[dict[str, Any]], candidates: list[dict[str, Any]],
                 p4: dict[str, Any], scope: dict[str, Any] | None) -> list[dict[str, Any]]:
    by_key = {i["issue_key"]: i for i in jira}
    by_cl: dict[str, dict[str, Any]] = {}
    for row in p4.get("changes", []):
        if not isinstance(row, dict) or "cl" not in row:
            continue
        cl = str(row["cl"])
        if cl in by_cl:
            raise ValueError("Duplicate P4 change evidence: " + cl)
        by_cl[cl] = row
    output = []
    for key in keys:
        issue = by_key[key]
        records = [c for c in candidates if c["issue_key"] == key]
        qualifying = [c for c in records if c["role"] in ("FIX_CANDIDATE", "REVERT_CANDIDATE", "INTEGRATION_CANDIDATE")]
        unknown = any(c["role"] == "UNKNOWN_ROLE" for c in records)
        checked: list[dict[str, Any]] = []
        for c in qualifying:
            status = validated_change(by_cl.get(c["cl"]), scope)
            checked.append({**c, **status})
        positive = [r for r in checked if r["state"] == "L1_VERIFIED"]
        nonl1 = [r for r in checked if r["state"] == "NON_L1_VERIFIED"]
        if positive:
            outcome = "INCLUDED_L1"
            reason = "VERIFIED_L1_SOURCE_FIX_CL"
        elif (qualifying and len(nonl1) == len(checked) and not unknown
              and issue.get("retrieval_status") == "OK" and issue.get("comments_complete") is True):
            outcome = "EXCLUDED_NON_L1"
            reason = "ALL_FIX_CLS_VERIFIED_NON_L1"
        else:
            outcome = "PENDING"
            if scope is None or not scope["l1_include_paths"]:
                reason = "L1_SCOPE_NOT_CONFIGURED"
            elif issue.get("retrieval_status") != "OK":
                reason = "JIRA_NOT_RETRIEVED"
            elif not issue.get("comments_complete"):
                reason = "JIRA_COMMENTS_INCOMPLETE"
            elif not qualifying:
                reason = "NO_VERIFIED_FIX_CL_CANDIDATE" if records else "NO_CL_FOUND"
            elif unknown:
                reason = "AMBIGUOUS_CL_ROLE"
            else:
                reason = next((r["state"] for r in checked if r["state"] != "NON_L1_VERIFIED"), "UNRESOLVED")
        l1files = list(dict.fromkeys(f for r in positive for f in r["l1_files"]))
        cls = list(dict.fromkeys(r["cl"] for r in positive))
        warnings = []
        if issue.get("retrieval_status") != "OK" or issue.get("comments_complete") is not True:
            warnings.append("JIRA_EVIDENCE_INCOMPLETE")
        if any(r["state"] != "L1_VERIFIED" for r in checked):
            warnings.append("SOME_FIX_CLS_UNVERIFIED")
        output.append({"issue_key": key, "summary": issue.get("summary", ""),
                       "feature": issue.get("feature", "UNCLASSIFIED"), "outcome": outcome,
                       "reason": reason, "verified_fix_cls": cls, "l1_files": l1files,
                       "candidates": records, "checked": checked, "warnings": warnings})
    return output


def render_md(rows: list[dict[str, Any]], *, included: bool) -> str:
    header = "# L1 Postmortem Target List" if included else "# L1 Postmortem Excluded / Pending List"
    picked = [r for r in rows if (r["outcome"] == "INCLUDED_L1") == included]
    lines = [header, "", "> Evidence-based screening only. Not a Root Cause assessment.", "",
             "| Jira Key | Feature | Summary | Fix CL (verified L1) | L1 File(s) | Result / Reason |",
             "|---|---|---|---|---|---|"]
    for r in picked:
        cols = (r["issue_key"], r["feature"], r["summary"],
                ", ".join(r["verified_fix_cls"]) or "-", ", ".join(r["l1_files"]) or "-",
                r["outcome"] + " / " + r["reason"])
        lines.append("| " + " | ".join(map(markdown_escape, cols)) + " |")
    if not picked:
        lines.append("| - | - | - | - | - | No matching issues |")
    lines.extend(["", "## Evidence details", ""])
    for r in picked:
        lines.append(f"### {r['issue_key']} — {r['outcome']}")
        lines.append(f"- Reason: `{r['reason']}`; Warning: {', '.join(r['warnings']) or 'none'}")
        if r["checked"]:
            for item in r["checked"]:
                lines.append(f"- CL `{item['cl']}` / `{item['role']}` / `{item['state']}`; Jira {item['location']} `{item['comment_id']}`; P4 evidence {item['cl']}")
        else:
            lines.append("- No confirmed Fix CL; keep unresolved for manual review.")
        lines.append("")
    return "\n".join(lines) + "\n"


# CL-only extension, inserted before execute() in jira_fix_cl_scan.py.
CL_ONLY_SCHEMA = "p4-code-owner.cl-only.v1"
_CL_NUMBER = re.compile(r"(?:CL[:#]?|P4-CL[:#]?)?([1-9][0-9]{0,10})\Z", re.I)


def parse_cl_only_input(text: str) -> list[str]:
    """Accept explicit CL numbers only. Never infer Jira IDs from free text."""
    result: list[str] = []
    for line in text.splitlines():
        content = line.split("# ", 1)[0].strip()
        if not content:
            continue
        for field in content.split(","):
            item = field.strip()
            if not item:
                raise ValueError("Empty CL token")
            match = _CL_NUMBER.fullmatch(item)
            if not match:
                raise ValueError("Expected explicit CL number or CL:<number>, not prose/Jira")
            if match.group(1) not in result:
                result.append(match.group(1))
            if len(result) > 100:
                raise ValueError("CL list capped at 100")
    if not result:
        raise ValueError("No CL numbers")
    return result


def execute_cl_only(args: argparse.Namespace) -> dict[str, Any]:
    """Read-only, two-stage Mango MCP evidence consumer; no Jira/P4 CLI calls."""
    if args.stage == "cl-prepare":
        if not args.input:
            raise ValueError("--input is required for cl-prepare")
        input_path = Path(args.input).expanduser().resolve()
        if not input_path.is_file() or input_path.is_symlink() or input_path.stat().st_size > 65536:
            raise ValueError("CL input must be a small regular file")
        cls = parse_cl_only_input(input_path.read_text(encoding="utf-8-sig"))
        run_id = args.run_id or ("cl_only_" + datetime.now(KST).strftime("%Y%m%d_%H%M%S"))
        folder = canonical_output(run_id)
        if folder.exists():
            raise FileExistsError("CL run already exists")
        folder.mkdir(parents=True)
        save_json(folder / "run_manifest.json", {
            "schema": CL_ONLY_SCHEMA, "version": VERSION, "run_id": run_id,
            "stage": "PREPARED", "cl_list": cls, "input_file": str(input_path),
            "provider": "mango_mcp_only", "jira_required": False})
        save_json(folder / "p4_requests.json", {
            "schema": CL_ONLY_SCHEMA, "provider": "mango_mcp_only",
            "requests": [{"cl": cl, "operations": ["describe -s", "integration provenance if applicable"]}
                         for cl in cls],
            "p4_evidence_requirements": ["cl", "status", "submitted", "files",
                                         "files_complete", "change_kind", "origin_confirmed"]})
        return {"stage": "CL_PREPARED", "run_id": run_id,
                "unique_cls": len(cls), "output_dir": str(folder),
                "next_action": "Approved agent: obtain read-only CL evidence with Mango MCP, then cl-finalize."}

    if not args.run_id:
        raise ValueError("--run-id required for cl-finalize")
    folder = canonical_output(args.run_id)
    manifest = read_json(folder / "run_manifest.json")
    if manifest.get("schema") != CL_ONLY_SCHEMA or manifest.get("stage") not in ("PREPARED", "FINALIZED"):
        raise ValueError("CL run manifest absent/invalid")
    cls = manifest["cl_list"]
    p4_path = Path(args.p4_evidence).expanduser() if args.p4_evidence else folder / "p4_evidence.json"
    if p4_path.is_symlink() or not p4_path.is_file() or p4_path.stat().st_size > 1048576:
        raise ValueError("Unsafe or missing Mango MCP evidence file")
    p4 = read_json(p4_path)
    if not isinstance(p4, dict) or not isinstance(p4.get("changes"), list):
        raise ValueError("Expected Mango MCP evidence changes array")
    by_cl: dict[str, dict[str, Any]] = {}
    for record in p4["changes"]:
        if not isinstance(record, dict) or not isinstance(record.get("cl"), (int, str)):
            raise ValueError("Malformed P4 evidence")
        cl = str(record["cl"]).strip()
        if cl not in cls or cl in by_cl:
            raise ValueError("Duplicate or unrequested CL evidence: " + cl)
        by_cl[cl] = record
    scope_path = (Path(args.scope_config).expanduser() if args.scope_config else
                  Path.home() / "l1sw-private-skills" / "p4-code-owner" / "data" / "config" / "jira_l1_scope.json")
    scope = load_scope(scope_path)
    rows = []
    for cl in cls:
        record = by_cl.get(cl)
        checked = validated_change(record, scope)
        state = checked["state"]
        complete = bool(record and record.get("files_complete") is True)
        outcome = ("INCLUDED_L1" if state == "L1_VERIFIED" and complete else
                   "EXCLUDED_NON_L1" if state == "NON_L1_VERIFIED" and complete else "PENDING")
        file_refs = []
        for item in (record.get("files", []) if isinstance(record, dict) else []):
            if not isinstance(item, dict):
                continue
            file_refs.append({"path": item.get("path"), "action": item.get("action"),
                              "rev": item.get("rev"), "from_rev": item.get("from_rev")})
        rows.append({"cl": cl, "outcome": outcome, "p4_state": state,
                     "origin_confirmed": bool(record and record.get("origin_confirmed") is True),
                     "source_cls": checked.get("source_cls", []),
                     "l1_files": checked.get("l1_files", []), "file_revisions": file_refs,
                     "claim_state": "INFERENCE" if outcome == "INCLUDED_L1" else "UNKNOWN",
                     "root_cause": "NOT_ESTABLISHED", "test_status": "NOT_RUN",
                     "work_write": False})
    counts = {k: sum(x["outcome"] == k for x in rows)
              for k in ("INCLUDED_L1", "EXCLUDED_NON_L1", "PENDING")}
    save_json(folder / "cl_screening.json", {"schema": CL_ONLY_SCHEMA, "results": rows,
                                            "scope_configured": bool(scope and scope["l1_include_paths"]),
                                            "counts": counts})
    lines = ["# P4 CL-only screening (Mango MCP evidence)", "",
             "CL metadata and L1 scope are not root-cause/test verification.", "",
             "| CL | Outcome | P4 state | Claim |", "|---|---|---|---|"]
    lines.extend(f"| {r['cl']} | {r['outcome']} | {r['p4_state']} | {r['claim_state']} |" for r in rows)
    (folder / "CL_Screening.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    manifest["stage"] = "FINALIZED"
    save_json(folder / "run_manifest.json", manifest)
    return {"stage": "CL_FINALIZED", "run_id": args.run_id, "output_dir": str(folder),
            "counts": counts, "report_path": str(folder / "CL_Screening.md"),
            "next_action": "Use source revision evidence for code analysis; never mark a fix/test PASS from CL submission."}


def execute(args: argparse.Namespace) -> dict[str, Any]:
    if args.stage in ('cl-prepare', 'cl-finalize'):
        return execute_cl_only(args)
    if args.stage == "prepare":
        if not args.input:
            raise ValueError("--input MD file is required for prepare")
        input_path = Path(args.input).expanduser().resolve()
        keys = issue_keys(input_path.read_text(encoding="utf-8-sig"))
        if not keys:
            raise ValueError("No Jira Issue Keys in MD input")
        run_id = args.run_id or ("jira_fix_cl_" + datetime.now(KST).strftime("%Y%m%d_%H%M%S"))
        folder = canonical_output(run_id)
        if folder.exists():
            raise FileExistsError("Run already exists; use --run-id with scan/finalize, or new run-id")
        folder.mkdir(parents=True, exist_ok=True)
        manifest = {"schema": SCHEMA, "version": VERSION, "run_id": run_id, "stage": "PREPARED",
                    "input_file": str(input_path), "issue_keys": keys,
                    "jira_provider": "jira_mcp_agent", "p4_provider": "mango_mcp_agent",
                    "jira_evidence": str(folder / "jira_evidence.json"),
                    "p4_evidence": str(folder / "p4_evidence.json")}
        save_json(folder / "run_manifest.json", manifest)
        save_json(folder / "jira_requests.json", {
            "schema": SCHEMA, "requests": [{"issue_key": k, "operations": ["get_issue", "get_all_comments_paginated"]} for k in keys],
            "jira_evidence_requirements": ["issue_key", "retrieval_status", "summary", "description", "comments", "comments_complete"]})
        return {"stage": "PREPARED", "run_id": run_id, "issues": len(keys), "output_dir": str(folder),
                "next_action": "Agent: Jira MCP로 전 이슈 Description/전체 Comment 조회 후 jira_evidence.json 기록; scan 실행"}
    if not args.run_id:
        raise ValueError("--run-id required for scan/finalize")
    folder = canonical_output(args.run_id)
    manifest_path = folder / "run_manifest.json"
    manifest = read_json(manifest_path)
    if manifest.get("schema") != SCHEMA:
        raise ValueError("Invalid run manifest schema")
    keys = manifest["issue_keys"]
    jira_path = Path(args.jira_evidence).expanduser() if args.jira_evidence else folder / "jira_evidence.json"
    jira = validate_jira_evidence(read_json(jira_path), keys)
    candidates = cl_candidates(jira)
    save_json(folder / "cl_candidates.json", {"schema": SCHEMA, "candidates": candidates})
    if args.stage == "scan":
        cls = list(dict.fromkeys(c["cl"] for c in candidates if c["role"] != "REFERENCE_ONLY"))
        save_json(folder / "p4_requests.json", {
            "schema": SCHEMA,
            "p4_provider": "mango_mcp_only",
            "requests": [{"cl": cl, "operations": ["describe -s", "integration provenance if required"]} for cl in cls],
            "p4_evidence_requirements": ["cl", "status", "submitted", "files", "files_complete", "change_kind", "origin_confirmed"]})
        manifest["stage"] = "JIRA_SCANNED"
        save_json(manifest_path, manifest)
        return {"stage": "JIRA_SCANNED", "run_id": args.run_id, "issues": len(keys),
                "cl_mentions": len(candidates), "unique_cls": len(cls), "output_dir": str(folder),
                "next_action": "Agent: Mango MCP로 CL describe 및 필요 시 integration 계보 확인, p4_evidence.json 기록; finalize 실행"}
    if manifest.get("stage") not in ("JIRA_SCANNED", "FINALIZED"):
        raise ValueError("Run scan before finalize")
    p4_path = Path(args.p4_evidence).expanduser() if args.p4_evidence else folder / "p4_evidence.json"
    p4 = read_json(p4_path)
    if not isinstance(p4, dict) or not isinstance(p4.get("changes"), list):
        raise ValueError("p4_evidence.json must contain changes array")
    scope_path = (Path(args.scope_config).expanduser() if args.scope_config else
                  Path.home() / "l1sw-private-skills" / "p4-code-owner" / "data" / "config" / "jira_l1_scope.json")
    scope = load_scope(scope_path)
    rows = score_issues(keys, jira, candidates, p4, scope)
    save_json(folder / "issue_screening.json", {"schema": SCHEMA, "results": rows})
    (folder / "L1_Postmortem_Target_List.md").write_text(render_md(rows, included=True), encoding="utf-8")
    (folder / "L1_Postmortem_Excluded_List.md").write_text(render_md(rows, included=False), encoding="utf-8")
    counts = {status: sum(r["outcome"] == status for r in rows)
              for status in ("INCLUDED_L1", "EXCLUDED_NON_L1", "PENDING")}
    save_json(folder / "summary.json", {"schema": SCHEMA, "counts": counts,
                                       "scope_config": str(scope_path), "scope_configured": bool(scope and scope["l1_include_paths"]),
                                       "jira_issues": len(keys), "cl_mentions": len(candidates)})
    manifest["stage"] = "FINALIZED"
    save_json(manifest_path, manifest)
    return {"stage": "FINALIZED", "run_id": args.run_id, "counts": counts,
            "output_dir": str(folder), "scope_configured": bool(scope and scope["l1_include_paths"]),
            "target_file": str(folder / "L1_Postmortem_Target_List.md"),
            "excluded_file": str(folder / "L1_Postmortem_Excluded_List.md")}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Jira Issue List -> P4 L1 Fix CL postmortem screening (agent MCP evidence required)")
    ap.add_argument("--stage", choices=("prepare", "scan", "finalize", "cl-prepare", "cl-finalize"), required=True)
    ap.add_argument("--input", help="Jira issue list MD (prepare only)")
    ap.add_argument("--run-id", help="Existing run id for scan/finalize")
    ap.add_argument("--jira-evidence", help="Jira MCP normalized evidence JSON")
    ap.add_argument("--p4-evidence", help="Mango MCP normalized P4 evidence JSON")
    ap.add_argument("--scope-config", help="L1 path allowlist JSON")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    try:
        result = execute(args)
    except (ValueError, FileNotFoundError, KeyError, json.JSONDecodeError, FileExistsError) as exc:
        result = {"stage": "ERROR", "reason": str(exc)}
        print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else f"ERROR: {exc}")
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else
          f"{result['stage']} | run={result['run_id']} | {result['output_dir']} | {result.get('counts', result.get('unique_cls', result.get('issues')))}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
