# Recovery 보고서를 기존 Work에 연결 — 개발 후보 1.6.75

새 분석·Git 게시 경로를 만들지 않고 기존 `attach-evidence`의 preview/apply를 재사용해요. 지원 Kernel은 `recovery_report_preview`와 `record_recovery_report`를 제공하는 개발 후보 0.7.46 계약이에요. 미지원 Kernel은 `RECOVERY_KERNEL_UNSUPPORTED`로 답해요.

```text
<기존 Workflow launcher> attach-evidence --work-id <기존 ID> --file <결과 MD/JSON> --kind recovery_analysis --provider l1-channel-recovery --provider-version <실제 선언 버전> --code-rev <고정 대상 revision> --summary <보고서 요약>
```

preview는 저장하지 않아요. 로컬에서 이미 허용된 Linux PC writer가 preview의 `source_sha256`·`evidence_revision`을 사용해 같은 명령에 `--apply --expected-sha256 <hash> --expected-revision <revision> --actor <기존 identity> --session-id <기존 session>`을 붙여 저장해요.

- 기존 인증된 로컬 writer 경계를 그대로 사용해요. writer 환경 플래그를 새로 활성화하는 설치 지시가 아니에요.
- MCP read-only 모드에서는 파일 읽기 전에 이 로컬 첨부 경로를 거부해요. MCP 도구 등록/권한을 추가하지 않아요.
- 실제 l1-channel-recovery가 생성한 보고서에만 해당 provider를 사용해요. source revision/생산자 선언의 실제 확인 근거는 업무 Work에 보존해요.
- 후보/보호됨/기각/보류·미분석과 REQ→CNF timeout 제외를 원본 보고서에 유지해요. 보고서 본문을 자동 재작성하지 않아요.
- 같은 내용/출처의 재시도는 기존 Evidence를 반환해요. 다른 내용·revision은 기존 원본을 덮어쓰지 않아요. 저장만으로 lifecycle을 전이하지 않아요.
- 저장 후 기존 Kernel `recovery-list --work-id <ID>`와 docs export에서 원본·Recovery 파생 목록을 확인할 수 있어요. Git 게시와 Viewer 연결은 기존 허용 경로에서 별도로 확인해요.
- 기존 code-analyzer/hld-composer 첨부는 기존 동작을 유지해요. 개인 Knowledge 분류는 Updater 책임이에요.

개발·합성 확인과 실제 업무 호스트 설치·생산자 연결 완료는 구분해요. 업무 GPT가 이 구현 계약을 참고해 접근 가능한 설치본과 최소 연결 설계를 진행하며, 사용자에게 MCP 자료를 먼저 제공하라는 요청을 반복하지 않아요.
