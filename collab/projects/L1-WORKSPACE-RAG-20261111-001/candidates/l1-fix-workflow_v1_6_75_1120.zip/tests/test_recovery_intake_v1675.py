from __future__ import annotations
import json,os,tempfile,unittest
from pathlib import Path
from contextlib import redirect_stdout
from io import StringIO
from unittest.mock import patch
from work_ledger_kernel.kernel import WorkLedgerKernel
from work_ledger_kernel.errors import KernelError
from l1_fix_workflow.feature_evidence import attach_evidence
from l1_fix_workflow.cli import main


class RecoveryIntakeTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory();self.root=Path(self.t.name)
        self.k=WorkLedgerKernel(self.root/'ledger');self.k.new('SYNTHETIC-RECOVERY','BUG','Synthetic')
        self.source=self.root/'report.md';self.source.write_text('# Recovery\nNOT_RUN\n')
        self.args=dict(work_id='SYNTHETIC-RECOVERY',source_path=self.source,provider='l1-channel-recovery',provider_version='unverified',code_rev='synthetic',evidence_kind='recovery_analysis',summary='Synthetic report')

    def tearDown(self):self.t.cleanup()

    def test_existing_preview_apply_path_records_only_supplementary_report(self):
        p=attach_evidence(self.k,**self.args);self.assertFalse(p['saved'])
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1','L1_WORKFLOW_MCP_READ_ONLY':'0'}):
            result=attach_evidence(self.k,**self.args,apply=True,expected_sha256=p['source_sha256'],expected_revision=p['evidence_revision'],actor='local-agent',session_id='synthetic-session')
        self.assertEqual(1,result['created']);self.assertEqual('l1-channel-recovery',result['evidence']['provider'])
        self.assertEqual('OPEN',self.k.load_record('SYNTHETIC-RECOVERY')['state'])

    def test_write_without_existing_pc_authority_is_denied(self):
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'0'}):
            with self.assertRaises(KernelError):attach_evidence(self.k,**self.args,apply=True)
        self.assertEqual(0,len(self.k.load_record('SYNTHETIC-RECOVERY')['evidence_index']))

    def test_mcp_mode_rejected_before_report_access_even_with_local_writer_flag(self):
        args={**self.args,'source_path':self.root/'does-not-exist.md'}
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1','L1_WORKFLOW_MCP_READ_ONLY':'1'}):
            with self.assertRaises(KernelError) as caught:attach_evidence(self.k,**args)
        self.assertEqual('RECOVERY_LOCAL_ONLY',caught.exception.code)

    def test_unsupported_kernel_and_kind_are_explicit(self):
        with self.assertRaises(KernelError) as caught:attach_evidence(object(),**self.args)
        self.assertEqual('RECOVERY_KERNEL_UNSUPPORTED',caught.exception.code)
        with self.assertRaises(KernelError) as caught:attach_evidence(self.k,**{**self.args,'evidence_kind':'impact'})
        self.assertEqual('RECOVERY_KIND_INVALID',caught.exception.code)

    def test_cli_preview_and_apply_reuse_existing_command(self):
        args=['--ledger-root',str(self.root/'ledger'),'attach-evidence','--work-id','SYNTHETIC-RECOVERY','--file',str(self.source),'--kind','recovery_analysis','--provider','l1-channel-recovery','--provider-version','unverified','--code-rev','synthetic','--summary','Synthetic report']
        out=StringIO()
        with redirect_stdout(out):rc=main(args)
        self.assertEqual(0,rc);p=json.loads(out.getvalue())
        with patch.dict(os.environ,{'L1_PC_LEDGER_WRITER':'1','L1_WORKFLOW_MCP_READ_ONLY':'0'}):
            with redirect_stdout(StringIO()):rc=main(args+['--apply','--expected-sha256',p['source_sha256'],'--expected-revision',str(p['evidence_revision']),'--actor','local-agent','--session-id','synthetic-session'])
        self.assertEqual(0,rc);self.assertEqual(1,self.k.work_recovery_reports('SYNTHETIC-RECOVERY')['count'])

if __name__=='__main__':unittest.main()
