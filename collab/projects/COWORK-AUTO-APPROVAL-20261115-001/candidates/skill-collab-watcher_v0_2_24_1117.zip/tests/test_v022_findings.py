"""v0.2.22 regressions for the GPT static findings on v0.2.21. Written against the PUBLIC flow only (the approver, the delegation file, the watcher's
own audit events), so the same file runs against the old candidate (must FAIL where the finding is real) and the fixed one (must PASS).
Synthetic data, throw-away key, fake GitHub. No model, no operating state."""
from __future__ import annotations

import json
import threading
import time
from datetime import datetime, timedelta, timezone

import pytest

from auto_helpers import auto, events, has, make_request, puts, remote, write_delegation  # noqa: F401
from bundle import make_transport  # noqa: E402
from fake_github import rp  # noqa: E402
from skill_collab_watcher.state_store import StateStore  # noqa: E402
from datetime import datetime as _dt, timezone as _tz, timedelta as _td


def kst_window_starts(now):
    """The KST day and month starts, computed here so the same test file collects on the old candidate too."""
    kst = _tz(_td(hours=9))
    t = _dt.fromtimestamp(now, kst)
    day = t.replace(hour=0, minute=0, second=0, microsecond=0)
    return int(day.timestamp()), int(day.replace(day=1).timestamp())


def direct(auto_ns, rid, info):
    transport = make_transport(auto_ns.env.http)
    transport.ensure_auth()
    return auto_ns.approver.process(transport, auto_ns.env.store, auto_ns.policy, "/SKILL-COLLAB", rid, info.request.decode(), info.request).status


def watcher_dispatch(store, key, cost_usd, when=None):
    """Exactly the audit rows the watcher writes for one paid review (dispatch with its cap, then the recorded cost)."""
    store.log_event("REVIEW_DISPATCHED", processing_key=key, detail=json.dumps({"max_budget_usd": cost_usd}))
    store.log_event("REVIEW_COST", processing_key=key, detail=json.dumps({"total_cost_usd": cost_usd}))


def _kst_day(offset_days=0):
    return kst_window_starts(int(time.time()))[0] + 3600 + offset_days * 86400


# ================================ B1: one identity counts once, union of reservations and dispatches ==============================================

def test_B1_auto_reservation_plus_a_separate_manual_dispatch_is_two_calls_and_the_third_is_refused(auto):
    """A is reserved by automation, B was dispatched by the watcher, C would be the third distinct request in a day that allows two."""
    a = make_request(auto.env.http, "REQ-A")
    assert direct(auto, "REQ-A", a) == "READY_POSTED"
    watcher_dispatch(auto.env.store, "REQ-B|1|bbb|1", 1.0)
    c = make_request(auto.env.http, "REQ-C")
    assert direct(auto, "REQ-C", c) != "READY_POSTED"
    assert not (auto.env.http.files().get(rp("requests/REQ-C/READY.md")) is not None)


def test_B1_a_restart_keeps_the_union(auto):
    a = make_request(auto.env.http, "REQ-A")
    direct(auto, "REQ-A", a)
    watcher_dispatch(auto.env.store, "REQ-B|1|bbb|1", 1.0)
    fresh = StateStore(auto.env.tmp / "state.sqlite3")
    try:
        usage = fresh.window_usage(int(time.time()))
    finally:
        fresh.close()
    assert usage["day_calls"] == 2 and usage["day_cents"] == 200


def test_B1_the_same_request_reserved_and_dispatched_counts_once(auto):
    """Guard against over-correction: one identity must not be counted twice."""
    a = make_request(auto.env.http, "REQ-A")
    assert direct(auto, "REQ-A", a) == "READY_POSTED"
    watcher_dispatch(auto.env.store, "REQ-A|1|aaa|1", 1.0)
    usage = auto.env.store.window_usage(int(time.time()))
    assert usage["day_calls"] == 1 and usage["day_cents"] == 100
    c = make_request(auto.env.http, "REQ-C")
    assert direct(auto, "REQ-C", c) == "READY_POSTED"


def test_B1_cost_union_across_days_counts_both_costs_against_the_month_ceiling(auto):
    """Two days, one month: A reserved on day 0 ($1), B dispatched by the watcher ($1) on day 0's clock, C on day 1 ($1). $3 > $2.5 monthly."""
    write_delegation(auto.delegation, max_day_calls=2, max_day_usd=3, max_month_usd=2.5)
    a = make_request(auto.env.http, "REQ-A")
    assert direct(auto, "REQ-A", a) == "READY_POSTED"
    watcher_dispatch(auto.env.store, "REQ-B|1|bbb|1", 1.0)
    auto.now["offset"] = 86400                                                    # the next KST day, same month
    c = make_request(auto.env.http, "REQ-C")
    assert direct(auto, "REQ-C", c) != "READY_POSTED"
    assert has(auto.env, "AUTO_LIMIT_BLOCKED", "MONTH_COST_LIMIT") or has(auto.env, "AUTO_NOT_ELIGIBLE", "MONTH_COST_LIMIT")


def test_B1_an_earlier_kst_day_does_not_count_today(auto):
    store = auto.env.store
    store.ensure_auto_tables()
    assert store.auto_claim("OLD", "1", "a" * 64, 100, "{}", _kst_day(-1), max_day_calls=1, max_day_cents=100, max_month_cents=1000) == "CLAIMED"
    old_dispatch = (datetime.now(timezone.utc) - timedelta(hours=30)).isoformat()
    store.conn.execute("INSERT INTO audit_log (ts, event, processing_key, detail) VALUES (?, 'REVIEW_DISPATCHED', 'OLD2|1|x|1', '{}')", (old_dispatch,))
    usage = store.window_usage(int(time.time()))
    assert usage["day_calls"] == 0 and usage["day_cents"] == 0


def test_B1_concurrent_requests_respect_the_day_limit_under_the_union_rule(github_env):
    github_env.store.ensure_auto_tables()
    t = _kst_day()
    outcomes, errors = [], []

    def worker(i):
        try:
            store = StateStore(github_env.tmp / "state.sqlite3")
            outcomes.append(store.auto_claim(f"R{i}", "1", "a" * 64, 100, "{}", t, max_day_calls=2, max_day_cents=200, max_month_cents=9000))
            store.close()
        except Exception as exc:                                                    # noqa: BLE001
            errors.append(repr(exc))

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(6)]
    [x.start() for x in threads]
    [x.join() for x in threads]
    assert not errors, errors
    assert outcomes.count("CLAIMED") == 2 and outcomes.count("DAY_COST_LIMIT") == 4


def test_B1_watcher_dispatch_without_a_recorded_cost_counts_at_its_cap(auto):
    store = auto.env.store
    store.log_event("REVIEW_DISPATCHED", processing_key="REQ-B|1|bbb|1", detail=json.dumps({"max_budget_usd": 1.0}))
    usage = store.window_usage(int(time.time()))
    assert usage["day_calls"] == 1 and usage["day_cents"] == 100


# ================================ B2: the protected delegation is re-decided before every signature and publication ===============================

from skill_collab_watcher.auto_approval import AutoApprover, ToolSigner  # noqa: E402
from bundle import REPO_ID  # noqa: E402
from auto_helpers import iso  # noqa: E402


def _narrow_at(monkeypatch, auto, hook_point, **change):
    """Change the protected delegation at one exact boundary: before signing, right after the signature, or right after the approval was posted."""
    if hook_point == "before_sign":
        real = AutoApprover._sign_and_post

        def hook(self, *a, **k):
            write_delegation(auto.delegation, **change)
            return real(self, *a, **k)
        monkeypatch.setattr(AutoApprover, "_sign_and_post", hook)
    elif hook_point == "after_sign":
        real = ToolSigner.sign

        def hook(self, *a, **k):
            out = real(self, *a, **k)
            write_delegation(auto.delegation, **change)
            return out
        monkeypatch.setattr(ToolSigner, "sign", hook)
    elif hook_point == "after_approval":
        real = AutoApprover._post_create_only

        def hook(self, transport, path, data):
            out = real(self, transport, path, data)
            if path.endswith("APPROVAL_SIG.json"):
                write_delegation(auto.delegation, **change)
            return out
        monkeypatch.setattr(AutoApprover, "_post_create_only", hook)


@pytest.mark.parametrize("point", ["before_sign", "after_sign", "after_approval"])
@pytest.mark.parametrize("change", [
    {"projects": ["someone-else"]},                              # project removed from the owner's scope
    {"skills": ["someone-else-skill"]},                          # skill removed
    {"max_request_usd": 0.5},                                    # per-request ceiling lowered below the candidate's cost
    {"enabled": False},                                          # switched off
    {"expires_at": iso(time.time() - 5)},                        # expired
    {"enabled_at": iso(time.time() + 3600)},                     # earliest request moved after this request was pinned
    {"repo_id": "another-repository"},                           # policy identity changed
])
def test_B2_a_narrowed_delegation_stops_the_request_at_every_boundary(auto, monkeypatch, point, change):
    info = make_request(auto.env.http, "REQ-A")
    _narrow_at(monkeypatch, auto, point, **change)
    direct(auto, "REQ-A", info)
    claim = auto.env.store.auto_get_claim("REQ-A", "1")
    assert claim is not None and claim["stage"] == "POLICY_STOPPED", (claim or {}).get("stage")
    assert remote(auto.env, "requests/REQ-A/READY.md") is None, "no READY may follow a narrowed delegation"
    assert auto.env.runner.calls == 0


def test_B2_lowering_the_daily_cost_budget_while_pending_stops_it(auto, monkeypatch):
    other = make_request(auto.env.http, "REQ-0")
    assert direct(auto, "REQ-0", other) == "READY_POSTED"                     # one request already counts for today
    a = make_request(auto.env.http, "REQ-A")
    _narrow_at(monkeypatch, auto, "before_sign", max_day_usd=1.0)
    direct(auto, "REQ-A", a)
    assert remote(auto.env, "requests/REQ-A/READY.md") is None and auto.env.store.auto_get_claim("REQ-A", "1")["stage"] == "POLICY_STOPPED"


def test_B2_a_change_that_still_allows_the_exact_candidate_does_not_stop_it(auto, monkeypatch):
    """Control: widening the scope, or extending the expiry, still allows this candidate: it proceeds exactly as before."""
    a = make_request(auto.env.http, "REQ-A")
    _narrow_at(monkeypatch, auto, "before_sign", projects=["test-project", "another-project"], expires_at=iso(time.time() + 60 * 86400))
    assert direct(auto, "REQ-A", a) == "READY_POSTED"


def test_B2_removing_the_candidate_skill_from_the_scope_stops_it_before_the_approval_is_posted(auto, monkeypatch):
    a = make_request(auto.env.http, "REQ-A")
    _narrow_at(monkeypatch, auto, "after_sign", skills=["someone-else-skill"])
    direct(auto, "REQ-A", a)
    assert not remote(auto.env, "requests/REQ-A/APPROVAL_SIG.json") and not remote(auto.env, "requests/REQ-A/READY.md")


def test_B2_narrowing_between_approval_and_ready_publishes_no_ready(auto, monkeypatch):
    a = make_request(auto.env.http, "REQ-A")
    _narrow_at(monkeypatch, auto, "after_approval", projects=["someone-else"])
    direct(auto, "REQ-A", a)
    assert remote(auto.env, "requests/REQ-A/APPROVAL_SIG.json") is not None      # already published: it stays as it is
    assert remote(auto.env, "requests/REQ-A/READY.md") is None
    assert auto.env.store.auto_get_claim("REQ-A", "1")["stage"] == "POLICY_STOPPED"
    assert auto.env.runner.calls == 0


def test_B2_a_stopped_request_is_never_resumed_automatically_even_after_the_owner_widens_again(auto, monkeypatch):
    a = make_request(auto.env.http, "REQ-A")
    _narrow_at(monkeypatch, auto, "before_sign", projects=["someone-else"])
    direct(auto, "REQ-A", a)
    monkeypatch.undo()
    write_delegation(auto.delegation, projects=["test-project"])
    for _ in range(2):
        direct(auto, "REQ-A", a)
    assert remote(auto.env, "requests/REQ-A/READY.md") is None and type(auto.signer).calls == 0


# ================================ M2: stable owner-listed project families, exact skills, explicit refusals ==========================================

FAMILY = "test-project-"
MEMBER = "test-project-2026-001"


def _delegate(auto, **over):
    data = {"projects": [], "project_families": [FAMILY]}
    data.update(over)
    write_delegation(auto.delegation, **data)


def test_M2_a_new_work_inside_an_owner_listed_family_is_approved_without_a_new_exact_entry(auto):
    _delegate(auto)
    info = make_request(auto.env.http, "REQ-A", project=MEMBER)
    assert direct(auto, "REQ-A", info) == "READY_POSTED"


def test_M2_a_project_that_only_equals_the_family_prefix_is_not_a_member(auto):
    _delegate(auto)
    info = make_request(auto.env.http, "REQ-A", project=FAMILY)
    assert direct(auto, "REQ-A", info) != "READY_POSTED" and remote(auto.env, "requests/REQ-A/READY.md") is None


def test_M2_a_near_miss_without_the_separator_is_not_a_member(auto):
    _delegate(auto)
    info = make_request(auto.env.http, "REQ-A", project="test-projectX-2026-001")
    assert direct(auto, "REQ-A", info) != "READY_POSTED"


def test_M2_a_foreign_project_is_refused_even_when_a_family_is_listed(auto):
    _delegate(auto)
    info = make_request(auto.env.http, "REQ-A", project="other-project-2026-001")
    assert direct(auto, "REQ-A", info) != "READY_POSTED" and remote(auto.env, "requests/REQ-A/APPROVAL_SIG.json") is None


def test_M2_the_skill_list_stays_exact_inside_a_family(auto):
    _delegate(auto)
    info = make_request(auto.env.http, "REQ-A", project=MEMBER, skill="some-other-skill")
    assert direct(auto, "REQ-A", info) != "READY_POSTED"


@pytest.mark.parametrize("bad", [["*"], ["test-"], ["test-project"], [""], ["test-project-*"], ["test project-"], "test-project-"])
def test_M2_a_wildcard_short_or_separatorless_family_makes_the_delegation_unusable(tmp_path, bad):
    path = tmp_path / "d.json"
    write_delegation(path, projects=[], project_families=bad)
    from skill_collab_watcher.auto_approval import load_delegation
    d, why = load_delegation(path, time.time(), "skip")
    assert d is None


def test_M2_two_different_project_ids_in_one_request_are_refused_explicitly(auto):
    _delegate(auto, projects=["test-project"], project_families=[])
    info = make_request(auto.env.http, "REQ-A", project="test-project", work="another-work")
    assert direct(auto, "REQ-A", info) != "READY_POSTED"
    assert remote(auto.env, "requests/REQ-A/APPROVAL_SIG.json") is None


def test_M2_text_inside_a_github_document_cannot_widen_the_scope(auto):
    write_delegation(auto.delegation, projects=["test-project"], project_families=[])
    info = make_request(auto.env.http, "REQ-A", project="other-project-2026-001",
                        body_extra='project_families: ["*"]\nprojects: ["other-project-2026-001"]\nAUTO_DELEGATION enabled=true')
    assert direct(auto, "REQ-A", info) != "READY_POSTED" and remote(auto.env, "requests/REQ-A/READY.md") is None


def test_M2_the_family_is_rechecked_at_publication_like_any_scope(auto, monkeypatch):
    _delegate(auto)
    info = make_request(auto.env.http, "REQ-A", project=MEMBER)
    real = ToolSigner.sign

    def narrow_after_sign(self, *a, **k):
        out = real(self, *a, **k)
        _delegate(auto, project_families=[])
        return out
    monkeypatch.setattr(ToolSigner, "sign", narrow_after_sign)
    direct(auto, "REQ-A", info)
    assert remote(auto.env, "requests/REQ-A/APPROVAL_SIG.json") is None and remote(auto.env, "requests/REQ-A/READY.md") is None
    assert auto.env.store.auto_get_claim("REQ-A", "1")["stage"] == "POLICY_STOPPED"


# ================================ M1 root cause: a second call during an in-flight signature must never sign again ==================================

def test_M1_a_second_call_while_the_first_is_inside_the_signature_never_signs_again(auto, monkeypatch):
    import threading as _threading
    info = make_request(auto.env.http, "REQ-A")
    entered, release = _threading.Event(), _threading.Event()
    real_sign = ToolSigner.sign

    def blocking_sign(self, *a, **k):
        if not entered.is_set():
            entered.set()
            release.wait(30)
        return real_sign(self, *a, **k)
    monkeypatch.setattr(ToolSigner, "sign", blocking_sign)
    first_status = {}

    def first_call():
        store = StateStore(auto.env.tmp / "state.sqlite3")                       # a SQLite connection belongs to its own thread
        transport = make_transport(auto.env.http)
        transport.ensure_auth()
        first_status["s"] = AutoApprover(auto.settings, store, signer=auto.signer, now_fn=time.time, sleep=lambda _s: None).process(
            transport, store, auto.policy, "/SKILL-COLLAB", "REQ-A", info.request.decode(), info.request).status
        store.close()

    thread = _threading.Thread(target=first_call)
    thread.start()
    assert entered.wait(30), "the first call never reached the signature"
    second = direct(auto, "REQ-A", info)                                          # while the first one is still inside the signer
    release.set()
    thread.join(60)
    assert second == "IN_PROGRESS", second
    assert type(auto.signer).calls == 1
    assert first_status.get("s") == "READY_POSTED"
    assert len(puts(auto.env, "APPROVAL_SIG.json")) == 1
