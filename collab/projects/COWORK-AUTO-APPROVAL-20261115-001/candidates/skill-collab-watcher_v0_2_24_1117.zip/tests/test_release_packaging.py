"""The release ZIP: deterministic, allow-listed, free of credentials."""
from __future__ import annotations

import zipfile
from pathlib import Path

import pytest

from tools import build_release as br

REPO_ROOT = Path(__file__).resolve().parents[1]


def _plant(root: Path, rel: str, text: str | bytes = "x") -> None:
    path = root / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text if isinstance(text, bytes) else text.encode("utf-8"))


@pytest.fixture
def tree(tmp_path):
    root = tmp_path / "proj"
    _plant(root, "README.md", "# r")
    _plant(root, "requirements.txt", "dropbox")
    _plant(root, "skill_collab_watcher/__init__.py", "")
    _plant(root, "skill_collab_watcher/a.py", "print(1)")
    _plant(root, "tests/test_a.py", "def test(): pass")
    _plant(root, "windows/run.cmd", "@echo off")
    _plant(root, "config/reviewer.config.example.json", "{}")
    # things that must never be packaged
    _plant(root, ".venv/Lib/x.py", "venv")
    _plant(root, "skill_collab_watcher/__pycache__/a.cpython-311.pyc", b"\0")
    _plant(root, ".pytest_cache/v/cache", "c")
    _plant(root, "config/reviewer.config.json", '{"machine": "specific"}')
    _plant(root, "secrets.json", '{"refresh_' + 'token": "abcdefghijklmnopqrstuvwxyz"}')
    _plant(root, "tests/state.sqlite3", b"db")
    _plant(root, "runs/out.json", "{}")
    return root


def test_only_allow_listed_files_are_collected(tree):
    names = [p.as_posix() for p in br.collect_files(tree)]
    assert names == sorted(names)
    assert "skill_collab_watcher/a.py" in names and "config/reviewer.config.example.json" in names
    for forbidden in (".venv", "__pycache__", ".pytest_cache", "secrets.json", "reviewer.config.json",
                      "state.sqlite3", "runs/"):
        assert not any(forbidden in n for n in names), forbidden
    assert "secrets.json" not in names  # also not at the top level, which is not an allow-listed location


def test_build_is_byte_for_byte_reproducible(tree, tmp_path):
    a = br.build_zip(tree, tmp_path / "a.zip")
    b = br.build_zip(tree, tmp_path / "b.zip")
    assert a == b
    assert (tmp_path / "a.zip").read_bytes() == (tmp_path / "b.zip").read_bytes()


def test_existing_output_with_different_bytes_is_never_replaced(tree, tmp_path):
    out = tmp_path / "pkg.zip"
    br.build_zip(tree, out)
    before = out.read_bytes()
    br.build_zip(tree, out)  # identical bytes: fine
    _plant(tree, "skill_collab_watcher/a.py", "print(2)")
    with pytest.raises(FileExistsError):
        br.build_zip(tree, out)
    assert out.read_bytes() == before


def test_scan_passes_on_a_clean_zip(tree, tmp_path):
    out = tmp_path / "clean.zip"
    br.build_zip(tree, out)
    report = br.scan_zip(out)
    assert report.clean and report.files_scanned == len(br.collect_files(tree))


# Each payload is assembled from two literals so that THIS file does not
# itself contain a credential-shaped string (the self-package test below
# scans it).
@pytest.mark.parametrize("payload", [
    b'{"refresh_' + b'token": "AbCdEfGhIjKlMnOpQrStUv"}',
    b'x = "s' + b'l.ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcd"',
    b"Authorization" + b": Bearer abcdefghijklmnop1234",
    b"-----BEGIN RSA PRIVATE" + b" KEY-----",
])
def test_scan_detects_credential_shapes(tree, tmp_path, payload):
    _plant(tree, "skill_collab_watcher/leak.py", payload)
    out = tmp_path / "leaky.zip"
    br.build_zip(tree, out)
    assert not br.scan_zip(out).clean


def test_scan_detects_a_credential_value_known_from_this_machine(tree, tmp_path):
    _plant(tree, "README.md", "the token is MY-LOCAL-REFRESH-VALUE-123")
    out = tmp_path / "known.zip"
    br.build_zip(tree, out)
    report = br.scan_zip(out, known_secrets=["MY-LOCAL-REFRESH-VALUE-123"])
    assert not report.clean and report.known_secret_values_checked == 1


def test_scan_flags_forbidden_file_names_even_if_one_slips_in(tmp_path):
    out = tmp_path / "bad.zip"
    with zipfile.ZipFile(out, "w") as zf:
        zf.writestr("config/secrets.json", "{}")
    assert not br.scan_zip(out).clean


def test_this_project_itself_packages_cleanly(tmp_path):
    out = tmp_path / "self.zip"
    br.build_zip(REPO_ROOT, out)
    report = br.scan_zip(out)
    assert report.clean, report.findings
    with zipfile.ZipFile(out) as zf:
        names = zf.namelist()
    assert "skill_collab_watcher/cli.py" in names
    basenames = {n.rsplit("/", 1)[-1] for n in names}
    assert not basenames & {"reviewer.config.json", "secrets.json", "state.sqlite3", ".env"}
    assert "secrets_store.py" in basenames  # the source module is packaged; only credential FILES are not
