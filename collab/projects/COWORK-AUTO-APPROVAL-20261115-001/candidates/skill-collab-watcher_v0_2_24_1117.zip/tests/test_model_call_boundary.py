"""Static evidence that review_runner.py is the only place a `claude`
process can be started. If a future change adds a second subprocess/Popen
call anywhere else in the package, this test fails."""
from __future__ import annotations

import ast
from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parents[1] / "skill_collab_watcher"
ALLOWED_FILE = "review_runner.py"


_DANGEROUS_ATTRS = {"run", "Popen", "call", "check_call", "check_output"}


def _uses_subprocess_or_popen(tree: ast.AST) -> bool:
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        if (
            isinstance(func, ast.Attribute)
            and isinstance(func.value, ast.Name)
            and func.value.id == "subprocess"
            and func.attr in _DANGEROUS_ATTRS
        ):
            return True
        if isinstance(func, ast.Name) and func.id == "Popen":
            return True
    return False


def test_only_review_runner_imports_subprocess():
    offenders = []
    for path in PACKAGE_DIR.glob("*.py"):
        if path.name == ALLOWED_FILE:
            continue
        tree = ast.parse(path.read_text(encoding="utf-8"))
        imports_subprocess = any(
            (isinstance(n, ast.Import) and any(a.name == "subprocess" for a in n.names))
            or (isinstance(n, ast.ImportFrom) and n.module == "subprocess")
            for n in ast.walk(tree)
        )
        if imports_subprocess:
            offenders.append(path.name)
    assert offenders == [], f"subprocess imported outside {ALLOWED_FILE}: {offenders}"


def test_review_runner_is_the_only_file_calling_subprocess_run():
    for path in PACKAGE_DIR.glob("*.py"):
        if path.name == ALLOWED_FILE:
            continue
        tree = ast.parse(path.read_text(encoding="utf-8"))
        assert not _uses_subprocess_or_popen(tree), f"possible process-start call in {path.name}"
