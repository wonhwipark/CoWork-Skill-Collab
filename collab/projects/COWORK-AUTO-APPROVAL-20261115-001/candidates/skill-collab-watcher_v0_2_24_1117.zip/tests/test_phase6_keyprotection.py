"""B: the approver's private key at rest. Real Ed25519 and throw-away keys; skipped (NOT_RUN) without `cryptography`."""
from __future__ import annotations

import base64
import subprocess
import sys

import pytest

pytest.importorskip("cryptography")

from test_phase5_signer import KEY, REPO, Kit  # noqa: E402
from tools import approval_signer, trust_root_tool  # noqa: E402

GOOD = "correct horse battery staple"


def answers(monkeypatch, *values):
    queue = list(values)
    monkeypatch.setattr(approval_signer, "_ask", lambda _prompt: queue.pop(0))


def keygen(tmp_path, *flags):
    private, public = tmp_path / "enc.key", tmp_path / "enc.pub"
    rc = approval_signer.main(["keygen", "--out-private", str(private), "--out-public", str(public), *flags])
    return rc, private, public


def test_a_key_must_be_created_with_an_explicit_choice_of_protection(tmp_path):
    with pytest.raises(SystemExit):
        approval_signer.main(["keygen", "--out-private", str(tmp_path / "k"), "--out-public", str(tmp_path / "p")])
    assert not (tmp_path / "k").exists()


def test_the_two_choices_cannot_be_combined(tmp_path):
    with pytest.raises(SystemExit):
        keygen(tmp_path, "--passphrase", "--allow-plaintext-key")


def test_an_encrypted_key_file_does_not_contain_the_raw_key_or_its_base64(tmp_path, monkeypatch):
    answers(monkeypatch, GOOD, GOOD)
    rc, private, _ = keygen(tmp_path, "--passphrase")
    assert rc == 0
    text = private.read_text(encoding="ascii")
    assert text.startswith(approval_signer.ENC_HEADER)
    raw = approval_signer.load_private_bytes(text, ask=lambda _p: GOOD)
    assert len(raw) == 32 and base64.b64encode(raw).decode() not in text and GOOD not in text


def test_a_wrong_passphrase_is_refused(tmp_path, monkeypatch):
    answers(monkeypatch, GOOD, GOOD)
    _, private, _ = keygen(tmp_path, "--passphrase")
    with pytest.raises(ValueError, match="WRONG_PASSPHRASE_OR_CORRUPT"):
        approval_signer.load_private_bytes(private.read_text(encoding="ascii"), ask=lambda _p: "not the passphrase")


def test_a_changed_key_file_is_refused(tmp_path, monkeypatch):
    answers(monkeypatch, GOOD, GOOD)
    _, private, _ = keygen(tmp_path, "--passphrase")
    text = private.read_text(encoding="ascii")
    head, body = text.split("\n", 1)
    blob = bytearray(base64.b64decode(body.strip()))
    blob[-1] ^= 1
    broken = head + "\n" + base64.b64encode(bytes(blob)).decode() + "\n"
    with pytest.raises(ValueError, match="WRONG_PASSPHRASE_OR_CORRUPT"):
        approval_signer.load_private_bytes(broken, ask=lambda _p: GOOD)


@pytest.mark.parametrize("first, second", [("short", "short"), (GOOD, GOOD + "x")])
def test_a_short_or_mismatched_passphrase_writes_no_key(tmp_path, monkeypatch, first, second):
    answers(monkeypatch, first, second)
    rc, private, public = keygen(tmp_path, "--passphrase")
    assert rc == 2 and not private.exists() and not public.exists()


def test_two_keys_with_the_same_passphrase_have_different_ciphertext(tmp_path, monkeypatch):
    answers(monkeypatch, GOOD, GOOD)
    _, first, _ = keygen(tmp_path, "--passphrase")
    other = tmp_path / "other"
    other.mkdir()
    answers(monkeypatch, GOOD, GOOD)
    _, second, _ = keygen(other, "--passphrase")
    assert first.read_text() != second.read_text()


def test_signing_with_an_encrypted_key_is_accepted_by_the_watcher_side_check(tmp_path, monkeypatch):
    kit = Kit(tmp_path)
    answers(monkeypatch, GOOD, GOOD)
    rc, private, public = keygen(tmp_path, "--passphrase")
    assert rc == 0
    assert trust_root_tool.main(["build", "--repo-id", REPO, "--out", str(tmp_path / "enc_root.json"), "--version", "1",
                                 "--key", f"{KEY}:{public.read_text().strip()}"]) == 0
    answers(monkeypatch, GOOD)
    assert kit.sign(**{"private-key": str(private)}) == 0
    assert kit.check(**{"trust-root": str(tmp_path / "enc_root.json")}) == 0


def test_signing_with_the_wrong_passphrase_makes_no_approval(tmp_path, monkeypatch):
    kit = Kit(tmp_path)
    answers(monkeypatch, GOOD, GOOD)
    _, private, _ = keygen(tmp_path, "--passphrase")
    answers(monkeypatch, "wrong passphrase!!")
    assert kit.sign(**{"private-key": str(private)}) == 2
    assert not (kit.out / "APPROVAL_SIG.json").exists()


def test_a_legacy_plain_key_still_signs(tmp_path):
    kit = Kit(tmp_path)
    assert kit.sign() == 0


def test_the_plain_choice_says_so_in_its_output(tmp_path, capsys):
    rc, _, _ = keygen(tmp_path, "--allow-plaintext-key")
    assert rc == 0 and "PLAIN base64" in capsys.readouterr().out


@pytest.mark.skipif(sys.platform != "win32", reason="Windows access control")
def test_the_key_file_is_restricted_to_the_owner_on_windows(tmp_path, monkeypatch):
    answers(monkeypatch, GOOD, GOOD)
    _, private, _ = keygen(tmp_path, "--passphrase")
    listing = subprocess.run(["icacls", str(private)], capture_output=True, text=True).stdout
    assert "BUILTIN\\Users" not in listing and "Everyone" not in listing and "Authenticated Users" not in listing
    assert "(I)" not in listing   # nothing inherited from the folder
