from __future__ import annotations

from skill_collab_watcher.models import JobState


def test_create_and_get_job_roundtrip(store):
    store.create_job("key-1", "REQ-1", "1", "a" * 64, JobState.VALIDATED)
    job = store.get_job("key-1")
    assert job is not None
    assert job.state == JobState.VALIDATED
    assert job.attempt_count == 0


def test_update_job_state_bumps_attempt(store):
    store.create_job("key-1", "REQ-1", "1", "a" * 64, JobState.VALIDATED)
    store.update_job_state("key-1", JobState.CLAIMED, bump_attempt=True)
    job = store.get_job("key-1")
    assert job.state == JobState.CLAIMED
    assert job.attempt_count == 1


def test_counters_increment_independently(store):
    assert store.get_counter("model_calls") == 0
    store.increment_counter("model_calls", 1)
    store.increment_counter("review_dispatch_count", 1)
    assert store.get_counter("model_calls") == 1
    assert store.get_counter("review_dispatch_count") == 1
    assert store.get_counter("claude_process_start_count") == 0


def test_cursor_persistence(store):
    assert store.get_cursor("skill_collab_root") is None
    store.set_cursor("skill_collab_root", "cursor-abc")
    assert store.get_cursor("skill_collab_root") == "cursor-abc"
    store.set_cursor("skill_collab_root", "cursor-def")
    assert store.get_cursor("skill_collab_root") == "cursor-def"


def test_single_instance_lock_blocks_second_holder(tmp_path):
    from skill_collab_watcher.lock import SingleInstanceLock

    lock_path = tmp_path / "watch.lock"
    first = SingleInstanceLock(lock_path)
    assert first.acquire() is True

    second = SingleInstanceLock(lock_path)
    assert second.acquire() is False  # two watcher instances must not both run

    first.release()
    assert second.acquire() is True
    second.release()
