"""Authorization-code prompt.

Part 1 (always runs): behaviour with the dialog replaced.
Part 2 (opt-in, SKILL_COLLAB_GUI_TESTS=1): the REAL Tk dialog is opened and
driven by injected events. Each scenario runs in its own fresh Python
process, exactly like production (one Tk() per process). Creating and
destroying several Tk interpreters inside one long-lived pytest process makes
Tcl's library lookup fail intermittently, which says nothing about the
product.

The user's clipboard is never read or written: the paste binding is checked
by inspecting Tk's event table, not by pasting. The scenarios print only
whether the returned text matched, never the text.
The windows are topmost and take keyboard focus: do not type while they run.
"""
from __future__ import annotations

import ast
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from skill_collab_watcher import secret_prompt as sp

MODULE_PATH = Path(sp.__file__)
ROOT = MODULE_PATH.parents[1]


# --- part 1: logic ---------------------------------------------------------------


def test_returns_the_stripped_code():
    assert sp.ask_authorization_code(ask=lambda t, p: "  abc-123  \n") == "abc-123"


def test_cancel_empty_and_unavailable_are_three_different_outcomes():
    with pytest.raises(sp.PromptCancelled):
        sp.ask_authorization_code(ask=lambda t, p: None)
    for blank in ("", "   ", "\t\n"):
        with pytest.raises(sp.PromptEmpty):
            sp.ask_authorization_code(ask=lambda t, p, b=blank: b)
    assert not issubclass(sp.PromptCancelled, sp.PromptEmpty)
    assert not issubclass(sp.PromptEmpty, sp.PromptCancelled)
    assert issubclass(sp.PromptUnavailable, sp.PromptError)


def test_exception_messages_never_contain_the_entered_value():
    secret = "TOP-SECRET-CODE-xyz"
    for entered, exc in ((None, sp.PromptCancelled), (" ", sp.PromptEmpty)):
        with pytest.raises(exc) as info:
            sp.ask_authorization_code(ask=lambda t, p, e=entered: e)
        assert secret not in str(info.value)


def _explode(*args, **kwargs):
    raise AssertionError("must not fall back to a console prompt")


def test_missing_tkinter_is_prompt_unavailable_without_console_fallback(monkeypatch):
    monkeypatch.setitem(sys.modules, "tkinter", None)  # makes `import tkinter` raise ImportError
    monkeypatch.setattr("builtins.input", _explode)
    import getpass
    monkeypatch.setattr(getpass, "getpass", _explode)
    with pytest.raises(sp.PromptUnavailable, match="tkinter is not available"):
        sp.ask_authorization_code()


def test_no_display_is_prompt_unavailable_without_console_fallback(monkeypatch):
    import tkinter

    def no_display(*a, **k):
        raise tkinter.TclError("no display name and no $DISPLAY environment variable")

    monkeypatch.setattr(tkinter, "Tk", no_display)
    monkeypatch.setattr("builtins.input", _explode)
    import getpass
    monkeypatch.setattr(getpass, "getpass", _explode)
    with pytest.raises(sp.PromptUnavailable, match="no usable display"):
        sp.ask_authorization_code()


def test_module_has_no_console_clipboard_or_logging_access():
    """Static guard: this module may not print, log, read the console, or
    touch the clipboard - the only way text enters is the user's paste inside
    the dialog."""
    tree = ast.parse(MODULE_PATH.read_text(encoding="utf-8"))
    forbidden_calls = {"print", "input", "getpass", "open"}
    forbidden_attrs = {"clipboard_get", "clipboard_append", "clipboard_clear", "selection_get", "paste"}
    forbidden_imports = {"getpass", "logging", "pyperclip", "subprocess", "os", "sys"}
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            func = node.func
            name = func.id if isinstance(func, ast.Name) else getattr(func, "attr", "")
            assert name not in forbidden_calls, f"forbidden call {name}()"
        if isinstance(node, ast.Attribute):
            assert node.attr not in forbidden_attrs, f"forbidden attribute {node.attr}"
        if isinstance(node, ast.Import):
            assert not {a.name.split(".")[0] for a in node.names} & forbidden_imports
        if isinstance(node, ast.ImportFrom):
            assert (node.module or "").split(".")[0] not in forbidden_imports


# --- part 2: the real Tk dialog, one fresh process per scenario ------------------------

# Runs inside the child process. Prints one JSON line: which outcome the
# public API produced, whether a returned value equalled the expected dummy,
# and what the open dialog looked like. The value itself is never printed.
_CHILD = r"""
import json, sys
sys.path.insert(0, {root!r})
from tkinter import simpledialog
from skill_collab_watcher import secret_prompt as sp

SCENARIO = {scenario!r}
DUMMY = "dummy-value-123"
seen = {{}}

def find(root):
    for w in root.winfo_children():
        if isinstance(w, simpledialog.Dialog):
            return w

def drive(root):
    root.after(15000, root.destroy)              # watchdog: never hang
    def attempt():
        d = find(root)
        if d is None:
            root.after(100, attempt)
            return
        seen["show"] = d.entry.cget("show")
        seen["paste_keys"] = list(root.event_info("<<Paste>>"))
        seen["class_has_paste"] = bool(root.bind_class("Entry", "<<Paste>>"))
        seen["topmost_parent"] = bool(root.attributes("-topmost"))
        if SCENARIO == "type_ok":
            d.entry.insert(0, DUMMY); d.ok()
        elif SCENARIO == "cancel_button":
            d.cancel()
        elif SCENARIO == "empty_ok":
            d.ok()
        elif SCENARIO == "whitespace_ok":
            d.entry.insert(0, "   "); d.ok()
        elif SCENARIO == "window_close":
            d.tk.call(d.protocol("WM_DELETE_WINDOW"))
    attempt()

out = {{}}
try:
    value = sp.ask_authorization_code(ask=lambda t, p: sp._tk_ask(t, p, _driver=drive))
    out["outcome"] = "OK"
    out["matches_expected"] = (value == DUMMY)
except sp.PromptError as exc:
    out["outcome"] = type(exc).__name__
out["seen"] = seen
print(json.dumps(out))
"""


def _gui_tests_enabled() -> bool:
    """Opt-in. These tests open real topmost windows that take keyboard focus,
    so anything typed while they run lands in the test dialog (and makes the
    run fail). Enable deliberately, and keep your hands off the keyboard."""
    if os.environ.get("SKILL_COLLAB_GUI_TESTS") != "1":
        return False
    probe = subprocess.run(
        [sys.executable, "-I", "-c", "import tkinter as tk; tk.Tk().destroy()"],
        capture_output=True, timeout=60,
    )
    return probe.returncode == 0


needs_gui = pytest.mark.skipif(
    not _gui_tests_enabled(), reason="real-window tests are opt-in: set SKILL_COLLAB_GUI_TESTS=1"
)


def _scenario(name: str) -> dict:
    code = _CHILD.format(root=str(ROOT), scenario=name)
    result = subprocess.run([sys.executable, "-I", "-c", code], capture_output=True, text=True, timeout=90)
    assert result.returncode == 0, result.stderr[-2000:]
    return json.loads(result.stdout.strip().splitlines()[-1])


@needs_gui
def test_real_dialog_ok_returns_the_typed_text():
    out = _scenario("type_ok")
    assert out["outcome"] == "OK" and out["matches_expected"] is True


@needs_gui
def test_real_dialog_masks_the_entry():
    assert _scenario("type_ok")["seen"]["show"] == "*"


@needs_gui
def test_real_dialog_has_ctrl_v_and_shift_insert_paste_bindings():
    seen = _scenario("cancel_button")["seen"]
    assert seen["class_has_paste"]
    keys = seen["paste_keys"]
    assert any("Control" in k and k.lower().endswith("v>") for k in keys), keys
    assert any("Insert" in k for k in keys), keys


@needs_gui
def test_real_dialog_opens_in_front_via_a_topmost_parent():
    assert _scenario("cancel_button")["seen"]["topmost_parent"] is True


@needs_gui
@pytest.mark.parametrize("scenario,expected", [
    ("cancel_button", "PromptCancelled"),
    ("window_close", "PromptCancelled"),
    ("empty_ok", "PromptEmpty"),
    ("whitespace_ok", "PromptEmpty"),
])
def test_real_dialog_cancel_close_and_empty_are_told_apart(scenario, expected):
    assert _scenario(scenario)["outcome"] == expected
