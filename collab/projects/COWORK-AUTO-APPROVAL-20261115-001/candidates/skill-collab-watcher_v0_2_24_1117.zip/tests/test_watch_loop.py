"""Watch loop behaviour with a simulated clock: no real sleeping, no network."""
from __future__ import annotations

import threading
from dataclasses import dataclass

from skill_collab_watcher.transport_base import TransientTransportError
from skill_collab_watcher.watch_loop import compute_backoff, run_watch


class SimStop(threading.Event):
    """An Event whose wait() advances a fake clock instead of sleeping."""

    def __init__(self, clock):
        super().__init__()
        self.clock = clock
        self.waits: list[float] = []

    def wait(self, timeout=None):
        self.waits.append(timeout)
        self.clock.now += timeout or 0
        return self.is_set()


class Clock:
    def __init__(self):
        self.now = 0.0

    def __call__(self):
        return self.now


@dataclass
class Summary:
    note: str


def drive(notes, **kwargs):
    clock = Clock()
    stop = SimStop(clock)
    events: list[tuple[str, str]] = []
    queue = list(notes)
    cycle_times: list[float] = []

    def run_cycle():
        cycle_times.append(clock.now)
        note = queue.pop(0) if queue else "OK"
        if note == "STOP":
            stop.set()
            return Summary("STOPPING")
        return Summary(note)

    result = run_watch(run_cycle=run_cycle, stop=stop, clock=clock,
                       on_event=lambda e, d: events.append((e, d)), **kwargs)
    return result, stop, events, cycle_times


def test_compute_backoff_doubles_and_caps():
    assert [compute_backoff(n, 30, 300) for n in range(0, 8)] == [0, 30, 60, 120, 240, 300, 300, 300]
    assert compute_backoff(10_000, 30, 300) == 300  # no overflow


def test_persistent_failure_backs_off_exponentially_up_to_the_cap():
    result, stop, events, _ = drive(["TRANSPORT_ERROR"] * 7, poll_interval=30, max_backoff=300, max_cycles=7)
    assert stop.waits == [30, 60, 120, 240, 300, 300]
    assert result.reason == "MAX_CYCLES"
    assert result.transport_error_cycles == 7 and result.max_consecutive_failures == 7
    assert result.recoveries == 0 and result.backoff_waits == 6


def test_recovery_resets_backoff_and_is_counted_once():
    result, stop, events, _ = drive(
        ["TRANSPORT_ERROR", "TRANSPORT_ERROR", "OK", "OK"], poll_interval=30, max_cycles=4)
    assert stop.waits == [30, 60, 30]  # back to the normal interval after the clean cycle
    assert result.recoveries == 1 and result.ok_cycles == 2
    assert [e for e, _ in events if e == "WATCH_RECOVERED"] == ["WATCH_RECOVERED"]


def test_auth_required_ends_the_loop_without_waiting():
    result, stop, _, _ = drive(["OK", "AUTH_REQUIRED", "OK"], poll_interval=30)
    assert result.reason == "AUTH_REQUIRED" and result.auth_required is True
    assert result.cycles == 2
    assert stop.waits == [30]  # only the wait after the first clean cycle


def test_stop_request_ends_the_run_immediately():
    result, stop, _, _ = drive(["OK", "STOP", "OK"], poll_interval=30)
    assert result.reason == "STOP_REQUESTED"
    assert result.cycles == 2
    assert stop.waits == [30]  # no wait after the cycle that was interrupted


def test_max_runtime_bounds_the_run_and_trims_the_last_wait():
    result, stop, _, times = drive([], poll_interval=30, max_runtime_sec=100)
    assert result.reason == "MAX_RUNTIME"
    assert times == [0, 30, 60, 90]
    assert stop.waits == [30, 30, 30, 10]  # last wait trimmed to the remaining 10s
    assert result.elapsed_sec == 100


def test_failure_backoff_never_overruns_max_runtime():
    result, stop, _, _ = drive(["TRANSPORT_ERROR"] * 20, poll_interval=30, max_backoff=300, max_runtime_sec=100)
    assert result.reason == "MAX_RUNTIME"
    assert result.elapsed_sec <= 100


def test_longpoll_replaces_the_interval_wait_but_keeps_a_minimum_gap():
    calls = []

    def longpoll(timeout):
        calls.append(timeout)
        return len(calls) % 2 == 1

    result, stop, _, _ = drive([], poll_interval=30, max_cycles=4, longpoll=longpoll, longpoll_timeout=60,
                               min_cycle_gap=5)
    assert calls == [60, 60, 60]
    assert result.longpoll_calls == 3 and result.longpoll_changes == 2
    assert stop.waits == [5, 5, 5]  # longpoll returned instantly in the simulation -> min gap only


def test_longpoll_error_falls_back_to_plain_polling_and_is_counted():
    def longpoll(timeout):
        raise TransientTransportError("ReadTimeout")

    result, stop, events, _ = drive([], poll_interval=30, max_cycles=3, longpoll=longpoll)
    assert result.longpoll_errors == 2
    assert stop.waits == [30, 30]
    assert [e for e, _ in events] == ["LONGPOLL_ERROR", "LONGPOLL_ERROR"]


def test_longpoll_is_skipped_when_it_could_overrun_the_run_budget():
    calls = []
    result, stop, _, _ = drive([], poll_interval=30, max_cycles=2, max_runtime_sec=100,
                               longpoll=lambda t: calls.append(t) or True, longpoll_timeout=60)
    assert calls == []  # 100s left < 60 + 120
    assert stop.waits == [30]
