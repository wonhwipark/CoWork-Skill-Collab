"""Stand-in for `claude` that leaves a GRANDCHILD behind: used to check what happens to the process tree on a timeout.
Never contacts a model. The grandchild writes a marker file after a delay if (and only if) it is still alive then."""
import os
import subprocess
import sys
import time

if sys.argv[1:3] == ["auth", "status"]:
    print('{"loggedIn": true}')
    sys.exit(0)
sys.stdin.read()
code = ("import os, pathlib, time\n"
        "time.sleep(float(os.environ['TREE_DELAY']))\n"
        "pathlib.Path(os.environ['TREE_MARKER']).write_text('grandchild survived')\n")
subprocess.Popen([sys.executable, "-c", code])
time.sleep(60)
