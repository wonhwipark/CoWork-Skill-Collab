"""Regression tests for the five findings of the independent R1 review of v0.2.14 (REQ-COWORK-V0214-R1-20261114).
Each test FAILED on v0.2.16 and passes with the fix. Synthetic data only; no model, no real GitHub."""
from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path

import pytest

pytest.importorskip("cryptography", reason="the entry-point tests need real Ed25519 approvals")

from bundle import github_policy, publish_bundle  # noqa: E402
from conftest import make_package_zip  # noqa: E402
from skill_collab_watcher import orchestrator  # noqa: E402
from skill_collab_watcher.review_runner import RealReviewRunner  # noqa: E402
from skill_collab_watcher.state_store import StateStore  # noqa: E402
from test_cli_entrypoint_e2e import e2e  # noqa: E402,F401  (re-exported fixture)
from test_phase1_github import run  # noqa: E402

HERE = Path(__file__).resolve().parent


def events_named(store, name):
    return [d for _t, e, _k, d in store.recent_events(500) if e == name]


# --- finding 1: a never-dispatched job under another policy revision must not allow a second review ------------------

def test_f1_a_pending_job_under_an_old_policy_revision_cannot_dispatch_after_the_logical_request_was_reviewed(github_env):
    publish_bundle(github_env.http)                                                     # approval bound to revision 1
    run(github_env, policy=github_policy(local_policy_revision="1"), allowed=False)    # VALIDATED, never dispatched
    publish_bundle(github_env.http, payload_changes={"local_policy_revision": "2"})    # operator re-signs for revision 2
    run(github_env, policy=github_policy(local_policy_revision="2"))                    # reviewed once under revision 2
    assert github_env.runner.calls == 1
    # Rollback to the old policy revision with a lost cursor: the whole folder is listed again, the approval is valid again.
    publish_bundle(github_env.http, payload_changes={"nonce": "synthetic-nonce-fresh-0003"})  # re-signed for revision 1: new nonce
    github_env.store.conn.execute("DELETE FROM cursors")
    run(github_env, policy=github_policy(local_policy_revision="1"))                    # the old pending row must stay unused
    assert github_env.runner.calls == 1


# --- finding 3: the daily ceiling must be reserved atomically -------------------------------------------------------

def test_f3_two_requests_cannot_both_pass_a_one_per_day_ceiling(github_env, monkeypatch):
    shared = make_package_zip("shared")                       # both requests point at the same package path
    publish_bundle(github_env.http, request_id="REQ-1", package=shared)
    publish_bundle(github_env.http, request_id="REQ-2", package=shared)
    policy = github_policy(max_dispatches_per_day=1)
    other = StateStore(github_env.tmp / "state.sqlite3")      # a second process: its own connection and owner
    real_materialize, nested = orchestrator._materialize_snapshot, {"done": False}

    def interleaved(*args, **kwargs):
        if not nested["done"]:
            nested["done"] = True                              # the other process runs between our claim and our dispatch
            orchestrator.run_scan_cycle(
                __import__("bundle").make_transport(github_env.http), other, policy, github_env.runner, allowed=True,
                snapshot_root=github_env.snapshot_root, review_run_dir=github_env.review_run_dir,
                remote_root=__import__("bundle").ROOT, exclusive=False)
        return real_materialize(*args, **kwargs)

    monkeypatch.setattr(orchestrator, "_materialize_snapshot", interleaved)
    try:
        run(github_env, policy=policy)
    finally:
        other.close()
    assert github_env.runner.calls == 1


# --- findings 2 and 4: scan and watch must not share a database without sharing the lock ----------------------------

def _wait_for(e2e, name, seconds=40):
    end = time.time() + seconds
    while time.time() < end:
        try:
            if any(e == name for e, _ in e2e.events()):
                return
        except Exception:
            pass
        time.sleep(0.4)
    raise AssertionError(f"event {name} never appeared")


def test_f2_a_watch_starting_during_a_scans_model_call_does_not_seal_the_scans_job(e2e):
    e2e.publish()
    scan = e2e.popen("scan", sleep="7")
    _wait_for(e2e, "CLAIMED")
    watch = e2e.popen("watch", "--max-cycles", "1", "--poll-interval", "1")
    watch.communicate(timeout=120)
    scan.communicate(timeout=180)
    names = [e for e, _ in e2e.events()]
    assert "REVIEW_UNCERTAIN" not in names, "the live scan's job was reported as an interrupted model call"
    assert e2e.model_calls == 1


def test_f4_a_scan_killed_during_the_model_call_is_sealed_by_the_next_scan_and_never_re_run(e2e):
    e2e.publish()
    scan = e2e.popen("scan", sleep="40")
    _wait_for(e2e, "CLAIMED")
    subprocess.run(["taskkill", "/F", "/T", "/PID", str(scan.pid)], capture_output=True)
    scan.communicate(timeout=60)
    code, out, err = e2e.scan()
    names = [e for e, _ in e2e.events()]
    assert "REVIEW_UNCERTAIN" in names, "a crashed scan left the job CLAIMED silently"
    assert e2e.model_calls == 1


def test_a_second_scan_is_refused_while_another_scan_or_watch_holds_the_lock(e2e):
    e2e.publish()
    first = e2e.popen("scan", sleep="6")
    _wait_for(e2e, "CLAIMED")
    code, out, err = e2e.scan()
    first.communicate(timeout=180)
    assert code == 3 and "already holds" in (out + err).lower()
    assert e2e.model_calls == 1


# --- finding 5: a timeout must end the whole process tree -----------------------------------------------------------

def test_f5_a_timeout_ends_the_reviewer_process_tree_not_only_its_first_process(tmp_path, monkeypatch):
    marker = tmp_path / "marker.txt"
    monkeypatch.setenv("TREE_MARKER", str(marker))
    monkeypatch.setenv("TREE_DELAY", "4")
    claude = tmp_path / "claude.cmd"
    claude.write_text(f'@"{sys.executable}" "{HERE / "e2e_tree_stub.py"}" %*\r\n', encoding="utf-8")
    runner = RealReviewRunner(str(claude), None, ["Read"], 1.0, 1)
    snap, rundir = tmp_path / "snap", tmp_path / "run"
    snap.mkdir()
    rundir.mkdir()
    result = runner.run(snap, "prompt", rundir)
    assert result.ok is False and "timeout" in (result.error or "")
    time.sleep(6)                                           # long enough for a surviving grandchild to write its marker
    assert not marker.exists(), "a process of the reviewer's tree survived the timeout"


# --- a SHADOW isolation refusal keeps its own exit code in scan and in watch (lock handlers must not swallow it) --------

@pytest.mark.parametrize("command", [["scan"], ["watch", "--max-cycles", "1"]])
def test_a_shadow_isolation_refusal_is_not_reported_as_a_lock_failure(tmp_path, command, capsys):
    from skill_collab_watcher import cli
    from test_phase5_shadow import write_config

    (tmp_path / "live").mkdir()                                    # this account created it, so it can reach it
    path = write_config(tmp_path, shadow={"state_dir": str(tmp_path / "shadow"), "account_isolation": "enforce"})
    assert cli.main(["--config", str(path), *command]) == cli.EXIT_REFUSED
    assert "SHADOW REFUSED" in capsys.readouterr().err
