"""windows\\*.cmd must find the project whatever the caller's working
directory is. Runs the real script with --help (no network, no prompt)."""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "windows" / "auth_init.cmd"

pytestmark = pytest.mark.skipif(
    sys.platform != "win32" or not (ROOT / ".venv" / "Scripts" / "python.exe").is_file(),
    reason="needs Windows and the project's .venv",
)


def _run(cwd: Path, script: str):
    return subprocess.run(
        ["cmd", "/c", script, "--help"], cwd=str(cwd), stdin=subprocess.DEVNULL,
        capture_output=True, text=True, timeout=90,
    )


@pytest.mark.parametrize("where", ["tmp", "drive_root", "inside_tests", "sibling_relative"])
def test_auth_init_cmd_works_from_any_working_directory(where, tmp_path):
    if where == "tmp":
        cwd, script = tmp_path, str(SCRIPT)
    elif where == "drive_root":
        cwd, script = Path(SCRIPT.anchor), str(SCRIPT)
    elif where == "inside_tests":
        cwd, script = ROOT / "tests", str(SCRIPT)
    else:  # started from the parent folder through a relative path
        cwd, script = ROOT.parent, f"{ROOT.name}\\windows\\auth_init.cmd"
    result = _run(cwd, script)
    assert result.returncode == 0, result.stdout + result.stderr
    assert "usage: skill-collab-watcher auth-init" in result.stdout
    assert "--force" in result.stdout
