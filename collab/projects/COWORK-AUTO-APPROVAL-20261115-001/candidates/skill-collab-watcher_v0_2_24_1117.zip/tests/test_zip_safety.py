from __future__ import annotations

import io
import zipfile

import pytest

from skill_collab_watcher.zip_safety import UnsafeZip, safe_extract


def _zip_with(name: str, content: bytes = b"x") -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr(name, content)
    return buf.getvalue()


def test_rejects_path_traversal(tmp_path):
    data = _zip_with("../../evil.txt")
    with pytest.raises(UnsafeZip):
        safe_extract(data, tmp_path / "dest")


def test_rejects_absolute_path(tmp_path):
    data = _zip_with("/etc/passwd")
    with pytest.raises(UnsafeZip):
        safe_extract(data, tmp_path / "dest")


def test_accepts_normal_zip(tmp_path):
    data = _zip_with("SKILL-COLLAB/CLAUDE.md", b"hello")
    dest = tmp_path / "dest"
    safe_extract(data, dest)
    assert (dest / "SKILL-COLLAB" / "CLAUDE.md").read_bytes() == b"hello"
