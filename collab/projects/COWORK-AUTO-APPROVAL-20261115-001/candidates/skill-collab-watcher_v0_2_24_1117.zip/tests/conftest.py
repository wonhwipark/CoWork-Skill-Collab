from __future__ import annotations

import hashlib
import io
import sys
import zipfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from skill_collab_watcher.fake_runner import FakeReviewRunner  # noqa: E402
from skill_collab_watcher.mock_transport import MockTransport  # noqa: E402
from skill_collab_watcher.state_store import StateStore  # noqa: E402
from skill_collab_watcher.validator import LocalPolicy  # noqa: E402

BASELINE = "TEST-BASELINE-0001"
REMOTE_ROOT = "/SKILL-COLLAB"
RUN_POLICY_REF = "POLICY-STATIC-V1"


@pytest.fixture
def policy() -> LocalPolicy:
    return LocalPolicy(
        active_baseline_id=BASELINE,
        local_policy_revision="1",
        known_run_policy_refs=[RUN_POLICY_REF],
    )


@pytest.fixture
def store(tmp_path):
    s = StateStore(tmp_path / "state.sqlite3")
    yield s
    s.close()


@pytest.fixture
def transport() -> MockTransport:
    return MockTransport()


@pytest.fixture
def runner() -> FakeReviewRunner:
    return FakeReviewRunner()


@pytest.fixture
def snapshot_root(tmp_path) -> Path:
    d = tmp_path / "snapshots"
    d.mkdir()
    return d


@pytest.fixture
def review_run_dir(tmp_path) -> Path:
    d = tmp_path / "runs"
    d.mkdir()
    return d


@pytest.fixture
def github_env(tmp_path, snapshot_root, review_run_dir):
    from types import SimpleNamespace

    from fake_github import FakeGitHub

    e = SimpleNamespace(http=FakeGitHub(), store=StateStore(tmp_path / "state.sqlite3"),
                        runner=FakeReviewRunner(), snapshot_root=snapshot_root,
                        review_run_dir=review_run_dir, tmp=tmp_path)
    yield e
    e.store.close()


def make_package_zip(marker: str = "ok") -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        # A fixed timestamp: zipfile stamps the current time (2 s resolution), so the same content built across
        # a 2-second boundary used to give different bytes and made a few tests fail at random.
        info = zipfile.ZipInfo("SKILL-COLLAB/CLAUDE.md", date_time=(2026, 11, 1, 0, 0, 0))
        zf.writestr(info, f"# test package {marker}\n")
    return buf.getvalue()


def request_md(
    request_id="REQ-1", request_revision=1, package_sha256="", package_size=0,
    run_policy_ref=RUN_POLICY_REF, state="SUBMITTED", knowledge_refs_yaml="[]",
) -> str:
    return f"""---
schema: SKILL_COLLAB_REVIEW_REQUEST_V1
state: {state}
request_id: {request_id}
request_revision: {request_revision}
project_id: test-project
work_id: test-work
skill_id: test-skill
package_path: /SKILL-COLLAB/packages/test.zip
package_file_id: id:TEST
package_rev: rev1
package_sha256: {package_sha256}
package_size_bytes: {package_size}
baseline_package_ref: null
knowledge_refs: {knowledge_refs_yaml}
consumer_profiles: []
reviewer_os: WINDOWS
test_policy: STATIC_ONLY
run_policy_ref: {run_policy_ref}
output_contract: SKILL_COLLAB_REVIEW_RESULT_V1
---

# body
"""


def ready_md(
    request_sha256, package_sha256, request_id="REQ-1", request_revision=1,
    baseline_id=BASELINE, state="READY",
) -> str:
    return f"""---
schema: SKILL_COLLAB_READY_V1
state: {state}
request_id: {request_id}
request_revision: {request_revision}
request_path: /SKILL-COLLAB/requests/{request_id}/REQUEST.md
request_sha256: {request_sha256}
package_sha256: {package_sha256}
baseline_id: {baseline_id}
---

# ready
"""


def push_valid_request(mock: MockTransport, request_id: str = "REQ-1", revision: int = 1):
    package = make_package_zip(request_id)
    package_sha = hashlib.sha256(package).hexdigest()
    req_text = request_md(
        request_id=request_id, request_revision=revision,
        package_sha256=package_sha, package_size=len(package),
    )
    req_sha = hashlib.sha256(req_text.encode("utf-8")).hexdigest()
    ready_text = ready_md(req_sha, package_sha, request_id=request_id, request_revision=revision)
    mock.push_file(f"{REMOTE_ROOT}/requests/{request_id}/REQUEST.md", req_text.encode("utf-8"))
    mock.push_file(f"{REMOTE_ROOT}/requests/{request_id}/READY.md", ready_text.encode("utf-8"))
    mock.push_file("/SKILL-COLLAB/packages/test.zip", package)
    return package_sha
