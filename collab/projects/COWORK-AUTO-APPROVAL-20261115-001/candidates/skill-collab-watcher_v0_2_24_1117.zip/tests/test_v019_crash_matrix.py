"""v0.2.19: a durable REMOTE dispatch reservation is written before the model starts. Crash injection at every step of a dispatch,
combined with what happens to the local state afterwards (kept, lost completely, or an OLD backup restored). The invariant:
the model is never started a second time for one request id and revision, and no job disappears. Synthetic only: no model, no GitHub."""
from __future__ import annotations

import shutil
import sqlite3

import pytest

from bundle import github_policy, publish_bundle
from skill_collab_watcher import orchestrator
from skill_collab_watcher.fake_runner import FakeReviewRunner
from skill_collab_watcher.models import JobState
from skill_collab_watcher.state_store import StateStore
from skill_collab_watcher.transport_base import TransportError
from test_phase1_github import has_event, run


class Crash(BaseException):
    """The process dies here (BaseException: no `except Exception` in the watcher may absorb it)."""


class CrashingRunner(FakeReviewRunner):
    def __init__(self):
        super().__init__()
        self.crash_in_run = False

    def run(self, *a, **k):
        self.calls += 1
        if self.crash_in_run:
            raise Crash("died during the model call")
        return self.canned_result


def lose_state(env):
    env.store.close()
    for suffix in ("", "-wal", "-shm"):
        p = env.tmp / f"state.sqlite3{suffix}"
        if p.exists():
            p.unlink()
    env.store = StateStore(env.tmp / "state.sqlite3")


def restart(env):
    env.store.close()
    env.store = StateStore(env.tmp / "state.sqlite3")


def remote_files(env):
    return [p for p in env.http.files() if "REQ-1" in p]


# (name, how the crash is injected, model starts at the moment of the crash)
POINTS = ["before_reservation", "after_reservation", "during_model", "before_result_saved", "before_publish", "publish_fails", "completed"]
EXPECTED_STARTS = {  # total model starts after the crash and the recovery scans: (state kept, state lost)
    "before_reservation": (0, 1),   # nothing was recorded anywhere and no model ran: a fresh dispatch is correct after state loss
    "after_reservation": (0, 0),
    "during_model": (1, 1),
    "before_result_saved": (1, 1),
    "before_publish": (1, 1),
    "publish_fails": (1, 1),
    "completed": (1, 1),
}


def inject(point, env, monkeypatch):
    if point == "before_reservation":
        def boom(*a, **k):
            raise Crash
        monkeypatch.setattr(orchestrator, "_reserve_dispatch", boom)
    elif point == "after_reservation":
        real = orchestrator._reserve_dispatch

        def after(*a, **k):
            real(*a, **k)
            raise Crash
        monkeypatch.setattr(orchestrator, "_reserve_dispatch", after)
    elif point == "during_model":
        env.runner.crash_in_run = True
    elif point == "before_result_saved":
        def boom(*a, **k):
            raise Crash
        monkeypatch.setattr(orchestrator, "_save_result_locally", boom)
    elif point == "before_publish":
        def boom(*a, **k):
            raise Crash
        monkeypatch.setattr(orchestrator, "_publish_result", boom)
    elif point == "publish_fails":
        def fail(*a, **k):
            raise TransportError("synthetic outage while publishing")
        monkeypatch.setattr(orchestrator, "_publish_result", fail)


@pytest.mark.parametrize("state_after", ["kept", "lost"])
@pytest.mark.parametrize("point", POINTS)
def test_a_crash_at_any_step_never_starts_the_model_twice(github_env, monkeypatch, point, state_after):
    github_env.runner = CrashingRunner()
    publish_bundle(github_env.http)
    inject(point, github_env, monkeypatch)
    if point in ("publish_fails", "completed"):
        run(github_env, policy=github_policy())                       # no crash: the cycle ends normally
    else:
        with pytest.raises(Crash):
            run(github_env, policy=github_policy())
    monkeypatch.undo()
    github_env.runner.crash_in_run = False

    if state_after == "lost":
        lose_state(github_env)
    else:
        restart(github_env)
    for _ in range(3):                                                # recovery: several scans, as a restarted watcher would do
        run(github_env, policy=github_policy(), exclusive=True)
        restart(github_env) if state_after == "kept" else None

    assert github_env.runner.calls == EXPECTED_STARTS[point][0 if state_after == "kept" else 1]
    jobs = github_env.store.conn.execute("select state from jobs").fetchall()
    if state_after == "kept" and point in ("during_model", "before_result_saved", "after_reservation", "before_reservation"):
        assert [j[0] for j in jobs] == [JobState.REVIEW_UNCERTAIN.value], "an interrupted job is sealed, never lost and never repeated"
    if state_after == "kept" and point in ("before_publish", "publish_fails"):
        # the result is published or stays publishable; either way no second model start (asserted above)
        assert [j[0] for j in jobs] in ([JobState.UPLOAD_PENDING.value], [JobState.COMPLETED.value], [JobState.RESULT_SAVED.value])
    if state_after == "lost" and point in ("after_reservation", "during_model", "before_result_saved", "before_publish", "publish_fails"):
        assert has_event(github_env.store, "REVIEW_UNCERTAIN") or has_event(github_env.store, "REMOTE_RESULT_EXISTS"), "the doubt is recorded"


def test_restoring_an_old_backup_after_the_review_does_not_repeat_it(github_env):
    publish_bundle(github_env.http)
    github_env.store.conn.commit()
    backup = github_env.tmp / "old_backup.sqlite3"
    src, dst = sqlite3.connect(github_env.tmp / "state.sqlite3"), sqlite3.connect(backup)
    src.backup(dst)                                                   # a backup taken BEFORE the review
    src.close(), dst.close()
    run(github_env, policy=github_policy())
    assert github_env.runner.calls == 1
    github_env.store.close()
    for suffix in ("-wal", "-shm"):
        p = github_env.tmp / f"state.sqlite3{suffix}"
        if p.exists():
            p.unlink()
    shutil.copyfile(backup, github_env.tmp / "state.sqlite3")         # the isolated restore of the old backup
    github_env.store = StateStore(github_env.tmp / "state.sqlite3")
    run(github_env, policy=github_policy(), exclusive=True)
    run(github_env, policy=github_policy(), exclusive=True)
    assert github_env.runner.calls == 1


def test_a_reservation_that_cannot_be_written_starts_no_model_and_the_request_waits(github_env, monkeypatch):
    publish_bundle(github_env.http)
    github_env.http.inject("PUT", "/contents/collab/dispatch/", status=403, times=100)
    run(github_env, policy=github_policy())
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "DISPATCH_RESERVATION_FAILED")
    assert [j[0] for j in github_env.store.conn.execute("select state from jobs").fetchall()] == [JobState.VALIDATED.value]
    github_env.http._inject.clear()
    run(github_env, policy=github_policy())
    assert github_env.runner.calls == 1                               # once writing works, the one review runs


def test_a_reservation_that_cannot_be_read_back_starts_no_model(github_env, monkeypatch):
    publish_bundle(github_env.http)
    github_env.http.inject("PUT", "/contents/collab/dispatch/", status=422, times=100)   # "already exists" but unreadable by this watcher
    github_env.http.inject("GET", "/contents/collab/dispatch/", status=500, times=100)
    run(github_env, policy=github_policy())
    assert github_env.runner.calls == 0


def test_a_foreign_reservation_seals_the_request_as_uncertain_without_a_model_call(github_env):
    publish_bundle(github_env.http)
    from fake_github import rp
    github_env.http.commit({rp("dispatch/REQ-1/DISPATCH_1.md"): b'{"processing_key": "someone-else", "package_sha256": "x"}'})
    run(github_env, policy=github_policy())
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "REVIEW_UNCERTAIN")
    assert [j[0] for j in github_env.store.conn.execute("select state from jobs").fetchall()] == [JobState.REVIEW_UNCERTAIN.value]


def test_the_reservation_is_written_exactly_once_per_review(github_env):
    publish_bundle(github_env.http)
    run(github_env, policy=github_policy())
    run(github_env, policy=github_policy())
    puts = [u for m, u in github_env.http.calls if m == "PUT" and "/dispatch/" in u]
    assert len(puts) == 1 and any(p.endswith("DISPATCH_1.md") for p in remote_files(github_env))
