from __future__ import annotations

import hashlib

from skill_collab_watcher.models import ValidationOutcome
from skill_collab_watcher.validator import FrontMatterError, parse_front_matter, validate

from conftest import request_md, ready_md


def test_parse_front_matter_rejects_non_mapping():
    try:
        parse_front_matter("---\n- a\n- b\n---\nbody")
    except FrontMatterError:
        pass
    else:
        raise AssertionError("expected FrontMatterError")


def test_parse_front_matter_uses_safe_load_not_arbitrary_python(monkeypatch):
    # yaml.safe_load must never construct arbitrary Python objects from a
    # remote REQUEST/READY file.
    malicious = "---\nx: !!python/object/apply:os.system ['echo pwned']\n---\nbody"
    try:
        parse_front_matter(malicious)
    except FrontMatterError:
        pass  # rejected by safe_load - this is the required behaviour
    else:
        raise AssertionError("yaml.safe_load unexpectedly accepted a python/object tag")


def test_validate_missing_request_is_wait_input(policy):
    result = validate(None, None, None, policy)
    assert result.outcome == ValidationOutcome.WAIT_INPUT


def test_validate_full_happy_path(policy):
    package_sha = "a" * 64
    req_text = request_md(package_sha256=package_sha, package_size=123)
    req_sha = hashlib.sha256(req_text.encode("utf-8")).hexdigest()
    ready_text = ready_md(req_sha, package_sha)
    result = validate(req_text, ready_text, (123, package_sha), policy)
    assert result.outcome == ValidationOutcome.VALIDATED
    assert result.processing_key == f"REQ-1|1|{package_sha}|{policy.local_policy_revision}"


def test_validate_needs_package_download_before_package_known(policy):
    package_sha = "a" * 64
    req_text = request_md(package_sha256=package_sha, package_size=123)
    req_sha = hashlib.sha256(req_text.encode("utf-8")).hexdigest()
    ready_text = ready_md(req_sha, package_sha)
    result = validate(req_text, ready_text, None, policy)
    assert result.outcome == ValidationOutcome.WAIT_INPUT
    assert result.needs_package_download is True
