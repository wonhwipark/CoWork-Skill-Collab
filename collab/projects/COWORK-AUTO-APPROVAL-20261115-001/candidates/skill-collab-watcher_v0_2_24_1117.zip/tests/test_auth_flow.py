"""OAuth parameters and the auth-init / auth-check commands, with the
network and the interactive prompt replaced. No real credentials."""
from __future__ import annotations

import json
from types import SimpleNamespace

import pytest

from skill_collab_watcher import cli
from skill_collab_watcher.auth_flow import REQUIRED_SCOPES, build_flow, validate_grant
from skill_collab_watcher.secrets_store import APP_KEY_ENV, REFRESH_TOKEN_ENV, load_secrets, save_secrets

TOKEN = "REFRESH-TOKEN-SHOULD-NEVER-BE-PRINTED"
APP_KEY = "APPKEY-SHOULD-NOT-BE-PRINTED"


def test_exactly_the_four_documented_scopes_and_none_of_team_level():
    assert set(REQUIRED_SCOPES) == {
        "account_info.read", "files.metadata.read", "files.content.read", "files.content.write",
    }
    assert validate_grant(" ".join(REQUIRED_SCOPES), TOKEN) == []


def test_flow_requests_pkce_offline_and_explicit_scopes():
    captured = {}

    class FakeFlow:
        def __init__(self, app_key, **kwargs):
            captured["app_key"] = app_key
            captured.update(kwargs)

    build_flow("the-key", FakeFlow)
    assert captured["use_pkce"] is True
    assert captured["token_access_type"] == "offline"
    assert captured["scope"] == list(REQUIRED_SCOPES)


@pytest.mark.parametrize("granted,token,needle", [
    ("account_info.read files.metadata.read files.content.read", TOKEN, "files.content.write"),
    (" ".join(REQUIRED_SCOPES), None, "no refresh token"),
    (" ".join(REQUIRED_SCOPES) + " team_info.read", TOKEN, "team-level"),
    (" ".join(REQUIRED_SCOPES) + " members.read", TOKEN, "team-level"),
    ("", TOKEN, "missing required"),
])
def test_validate_grant_reports_problems(granted, token, needle):
    problems = validate_grant(granted, token)
    assert any(needle in p for p in problems)
    assert all(TOKEN not in p for p in problems)


def test_validate_grant_accepts_list_form():
    assert validate_grant(list(REQUIRED_SCOPES), TOKEN) == []


# --- commands -----------------------------------------------------------------------


@pytest.fixture
def cfg_path(tmp_path, monkeypatch):
    monkeypatch.delenv(APP_KEY_ENV, raising=False)
    monkeypatch.delenv(REFRESH_TOKEN_ENV, raising=False)
    state = tmp_path / "state"
    path = tmp_path / "cfg.json"
    path.write_text(json.dumps({
        "schema_version": 1, "baseline_id": "B", "remote_root": "/SKILL-COLLAB",
        "local_state_dir": str(state), "review_policy": {"enabled": False, "dry_run": True},
    }), encoding="utf-8")
    return path, state


class ExplodingFlow:
    def __init__(self, *a, **k):
        raise AssertionError("a new authorization must not start while valid credentials exist")


def _patch_flow(monkeypatch, flow_cls):
    import dropbox.oauth
    monkeypatch.setattr(dropbox.oauth, "DropboxOAuth2FlowNoRedirect", flow_cls)


def test_auth_init_keeps_valid_credentials_and_starts_no_flow(cfg_path, monkeypatch, capsys):
    path, state = cfg_path
    save_secrets(state, APP_KEY, TOKEN, scope=" ".join(REQUIRED_SCOPES))
    monkeypatch.setattr(cli, "_verify_stored_credentials", lambda cfg: cli.EXIT_OK)
    _patch_flow(monkeypatch, ExplodingFlow)
    assert cli.main(["--config", str(path), "auth-init"]) == cli.EXIT_OK
    out = capsys.readouterr().out
    assert "Nothing to do" in out and TOKEN not in out and APP_KEY not in out


def test_auth_init_does_not_overwrite_on_network_trouble(cfg_path, monkeypatch):
    path, state = cfg_path
    save_secrets(state, APP_KEY, TOKEN)
    monkeypatch.setattr(cli, "_verify_stored_credentials", lambda cfg: cli.EXIT_TRANSPORT)
    _patch_flow(monkeypatch, ExplodingFlow)
    assert cli.main(["--config", str(path), "auth-init"]) == cli.EXIT_TRANSPORT
    assert load_secrets(state)["refresh_token"] == TOKEN


class GoodFlow:
    def __init__(self, app_key, **kwargs):
        self.kwargs = kwargs

    def start(self):
        return "https://example.invalid/authorize"

    def finish(self, code):
        return SimpleNamespace(refresh_token="NEW-" + TOKEN, scope=" ".join(REQUIRED_SCOPES))


def test_auth_init_saves_new_credentials_without_printing_them(cfg_path, monkeypatch, capsys):
    path, state = cfg_path
    _patch_flow(monkeypatch, GoodFlow)
    monkeypatch.setattr(cli, "ask_authorization_code", lambda *a, **k: "auth-code-123")
    assert cli.main(["--config", str(path), "auth-init", "--app-key", APP_KEY]) == cli.EXIT_OK
    captured = capsys.readouterr()
    for stream in (captured.out, captured.err):
        assert "NEW-" + TOKEN not in stream and APP_KEY not in stream and "auth-code-123" not in stream
    secrets = load_secrets(state)
    assert secrets["refresh_token"] == "NEW-" + TOKEN and secrets["app_key"] == APP_KEY
    saved = json.loads((state / "secrets.json").read_text(encoding="utf-8"))
    assert saved["scope"].split() == list(REQUIRED_SCOPES)


def test_auth_init_reauthorizes_only_when_dropbox_rejects_stored_credentials(cfg_path, monkeypatch, capsys):
    path, state = cfg_path
    save_secrets(state, APP_KEY, "OLD-" + TOKEN)
    monkeypatch.setattr(cli, "_verify_stored_credentials", lambda cfg: cli.EXIT_AUTH_REQUIRED)
    _patch_flow(monkeypatch, GoodFlow)
    monkeypatch.setattr(cli, "ask_authorization_code", lambda *a, **k: "code")
    assert cli.main(["--config", str(path), "auth-init", "--app-key", APP_KEY]) == cli.EXIT_OK
    assert load_secrets(state)["refresh_token"] == "NEW-" + TOKEN


class WrongScopeFlow(GoodFlow):
    def finish(self, code):
        return SimpleNamespace(refresh_token=TOKEN, scope="account_info.read files.metadata.read")


def test_auth_init_refuses_to_save_an_insufficient_grant(cfg_path, monkeypatch, capsys):
    path, state = cfg_path
    _patch_flow(monkeypatch, WrongScopeFlow)
    monkeypatch.setattr(cli, "ask_authorization_code", lambda *a, **k: "code")
    assert cli.main(["--config", str(path), "auth-init", "--app-key", APP_KEY]) == cli.EXIT_REFUSED
    assert not (state / "secrets.json").exists()
    assert TOKEN not in capsys.readouterr().out


# --- the code prompt: cancel / empty / no GUI / rejected code -------------------------


def _no_console_input(monkeypatch):
    """Any attempt to read the code from the console fails the test."""
    def boom(*a, **k):
        raise AssertionError("the authorization code must never be requested on the console")
    monkeypatch.setattr("builtins.input", boom)
    import getpass
    monkeypatch.setattr(getpass, "getpass", boom)


def _raiser(exc):
    def f(*a, **k):
        raise exc
    return f


def test_cancelled_dialog_saves_nothing_and_has_its_own_exit_code(cfg_path, monkeypatch, capsys):
    path, state = cfg_path
    _patch_flow(monkeypatch, GoodFlow)
    _no_console_input(monkeypatch)
    monkeypatch.setattr(cli, "ask_authorization_code", _raiser(cli.PromptCancelled("x")))
    assert cli.main(["--config", str(path), "auth-init", "--app-key", APP_KEY]) == cli.EXIT_CANCELLED
    assert not (state / "secrets.json").exists()
    assert "Cancelled" in capsys.readouterr().out


def test_empty_entry_saves_nothing_and_has_its_own_exit_code(cfg_path, monkeypatch, capsys):
    path, state = cfg_path
    _patch_flow(monkeypatch, GoodFlow)
    _no_console_input(monkeypatch)
    monkeypatch.setattr(cli, "ask_authorization_code", _raiser(cli.PromptEmpty("x")))
    assert cli.main(["--config", str(path), "auth-init", "--app-key", APP_KEY]) == cli.EXIT_EMPTY_INPUT
    assert not (state / "secrets.json").exists()
    assert "No code was entered" in capsys.readouterr().out


def test_no_gui_is_a_clear_error_and_never_falls_back_to_the_console(cfg_path, monkeypatch, capsys):
    path, state = cfg_path
    _patch_flow(monkeypatch, GoodFlow)
    _no_console_input(monkeypatch)
    monkeypatch.setattr(cli, "ask_authorization_code",
                        _raiser(cli.PromptUnavailable("Could not open a window (no usable display).")))
    assert cli.main(["--config", str(path), "auth-init", "--app-key", APP_KEY]) == cli.EXIT_NO_GUI
    captured = capsys.readouterr()
    assert "no usable display" in captured.err and "never requested on the console" in captured.err
    assert not (state / "secrets.json").exists()


def _http_error(status: int, body: bytes):
    import requests

    resp = requests.Response()
    resp.status_code = status
    resp._content = body
    resp.headers["content-type"] = "application/json"
    return requests.HTTPError(f"{status} Client Error for url: https://api.dropboxapi.com/oauth2/token", response=resp)


def test_token_failure_shows_status_and_the_oauth_error_word_only():
    from skill_collab_watcher.auth_flow import describe_token_failure

    exc = _http_error(400, b'{"error": "invalid_grant", "error_description": "code CODE-ECHO-123 is bad"}')
    summary, hint = describe_token_failure(exc)
    assert summary == "HTTPError HTTP 400 invalid_grant"
    assert "NEW URL" in hint
    assert "CODE-ECHO-123" not in summary + hint


@pytest.mark.parametrize("body", [
    b'{"error": "Not A Plain Word CODE-ECHO-123"}',   # not the OAuth vocabulary -> dropped
    b"<html>gateway error CODE-ECHO-123</html>",       # not JSON
    b'{"error": 400}',                                 # wrong type
    b'["invalid_grant"]',                              # wrong shape
])
def test_token_failure_drops_anything_that_is_not_a_plain_oauth_error_word(body):
    from skill_collab_watcher.auth_flow import describe_token_failure

    summary, hint = describe_token_failure(_http_error(400, body))
    assert summary == "HTTPError HTTP 400"
    assert "CODE-ECHO-123" not in summary + hint


def test_token_failure_hint_for_public_client_setting():
    from skill_collab_watcher.auth_flow import describe_token_failure

    _, hint = describe_token_failure(_http_error(401, b'{"error": "invalid_client"}'))
    assert "Allow public clients" in hint


def _flaky_flow(failures: int):
    state = {"calls": 0}

    class Flaky(GoodFlow):
        def finish(self, code):
            state["calls"] += 1
            if state["calls"] <= failures:
                raise _http_error(400, b'{"error": "invalid_grant", "error_description": "code CODE-ECHO-123"}')
            return super().finish(code)

    return Flaky, state


def test_rejected_code_can_be_pasted_again_without_restarting(cfg_path, monkeypatch, capsys):
    path, state = cfg_path
    flow, calls = _flaky_flow(failures=1)
    _patch_flow(monkeypatch, flow)
    asked = []
    monkeypatch.setattr(cli, "ask_authorization_code", lambda *a, **k: asked.append(1) or "auth-code-123")
    assert cli.main(["--config", str(path), "auth-init", "--app-key", APP_KEY]) == cli.EXIT_OK
    assert len(asked) == 2 and calls["calls"] == 2
    captured = capsys.readouterr()
    assert "HTTPError HTTP 400 invalid_grant" in captured.out
    for stream in (captured.out, captured.err):
        assert "CODE-ECHO-123" not in stream and "auth-code-123" not in stream
    assert load_secrets(state)["refresh_token"] == "NEW-" + TOKEN


def test_repeated_rejection_stops_after_the_attempt_limit_and_saves_nothing(cfg_path, monkeypatch, capsys):
    from skill_collab_watcher.auth_flow import MAX_CODE_ATTEMPTS

    path, state = cfg_path
    flow, calls = _flaky_flow(failures=99)
    _patch_flow(monkeypatch, flow)
    asked = []
    monkeypatch.setattr(cli, "ask_authorization_code", lambda *a, **k: asked.append(1) or "auth-code-123")
    assert cli.main(["--config", str(path), "auth-init", "--app-key", APP_KEY]) == cli.EXIT_REFUSED
    assert len(asked) == MAX_CODE_ATTEMPTS == calls["calls"]
    assert not (state / "secrets.json").exists()
    assert "Giving up" in capsys.readouterr().out


def test_cancelling_on_the_second_attempt_stops_cleanly(cfg_path, monkeypatch, capsys):
    path, state = cfg_path
    flow, _ = _flaky_flow(failures=99)
    _patch_flow(monkeypatch, flow)
    answers = iter(["auth-code-123", None])

    def ask(*a, **k):
        value = next(answers)
        if value is None:
            raise cli.PromptCancelled("x")
        return value

    monkeypatch.setattr(cli, "ask_authorization_code", ask)
    assert cli.main(["--config", str(path), "auth-init", "--app-key", APP_KEY]) == cli.EXIT_CANCELLED
    assert not (state / "secrets.json").exists()


class RejectingFlow(GoodFlow):
    def finish(self, code):
        raise RuntimeError(f"server said bad code {code}")  # a message that echoes the code


def test_rejected_code_reports_only_the_exception_type(cfg_path, monkeypatch, capsys):
    path, state = cfg_path
    _patch_flow(monkeypatch, RejectingFlow)
    monkeypatch.setattr(cli, "ask_authorization_code", lambda *a, **k: "auth-code-SECRET-9")
    assert cli.main(["--config", str(path), "auth-init", "--app-key", APP_KEY]) == cli.EXIT_REFUSED
    captured = capsys.readouterr()
    for stream in (captured.out, captured.err):
        assert "auth-code-SECRET-9" not in stream
    assert "RuntimeError" in captured.out
    assert not (state / "secrets.json").exists()


def test_auth_check_without_credentials_is_auth_required(cfg_path, capsys):
    path, _ = cfg_path
    assert cli.main(["--config", str(path), "auth-check"]) == cli.EXIT_AUTH_REQUIRED


def test_config_check_prints_presence_only_never_values(cfg_path, capsys):
    path, state = cfg_path
    save_secrets(state, APP_KEY, TOKEN, scope=" ".join(REQUIRED_SCOPES))
    assert cli.main(["--config", str(path), "config-check"]) == cli.EXIT_OK
    out = capsys.readouterr().out
    assert TOKEN not in out and APP_KEY not in out
    assert "app_key=yes refresh_token=yes" in out
    assert "dispatch_allowed: False" in out
    assert "enabled_source: review_policy.enabled" in out


def test_bad_config_value_exits_with_config_error_not_a_traceback(tmp_path, capsys):
    path = tmp_path / "cfg.json"
    path.write_text(json.dumps({"review_policy": {"enabled": "false"}, "local_state_dir": str(tmp_path / "s")}),
                    encoding="utf-8")
    assert cli.main(["--config", str(path), "config-check"]) == cli.EXIT_CONFIG
    assert "CONFIG ERROR" in capsys.readouterr().err
