"""B-2 .. B-6 regression checks plus T08, T21 and T29. Dropbox-style cases use the
mock transport; provider cutover cases reuse the GitHub fake."""
from __future__ import annotations

import hashlib
import sqlite3

import pytest

from bundle import ROOT, github_policy, key_for, publish_bundle, make_transport, sha256
from conftest import BASELINE, REMOTE_ROOT, RUN_POLICY_REF, make_package_zip, push_valid_request, ready_md, request_md
from skill_collab_watcher.models import JobState
from skill_collab_watcher.orchestrator import group_request_entries, run_scan_cycle
from skill_collab_watcher.state_store import ProviderConflict, StateStore
from skill_collab_watcher.transport_base import EntryMeta
from skill_collab_watcher.validator import LocalPolicy, validate

PKG = "ab" * 32


def _meta(path: str) -> EntryMeta:
    return EntryMeta(path=path, rev="r", size=1, content_hash="h")


def _scan(transport, store, policy, runner, snapshot_root, review_run_dir, exclusive=False):
    return run_scan_cycle(transport, store, policy, runner, allowed=True, snapshot_root=snapshot_root,
                          review_run_dir=review_run_dir, remote_root=REMOTE_ROOT, exclusive=exclusive)


def _events(store):
    return [(e, d or "") for _ts, e, _k, d in store.recent_events(500)]


# --- B-2: sidecar names are never REQUEST/READY, and old folders stay blocked ----

def test_B2_sidecars_do_not_compete_with_request_or_ready():
    names = ["REQUEST.md", "READY.md", "APPROVAL_SIG.json", "SOURCE_PIN.json"]
    group = group_request_entries([_meta(f"{ROOT}/requests/REQ-1/{n}") for n in names], ROOT)["REQ-1"]
    assert group["request"].path.endswith("/REQUEST.md")
    assert group["ready"].path.endswith("/READY.md")


def test_B2_legacy_ready_sidecar_folder_is_blocked_with_zero_model_calls(
        transport, store, runner, snapshot_root, review_run_dir):
    push_valid_request(transport)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/READY_APPROVAL.json", b"{}")
    _scan(transport, store, _policy(), runner, snapshot_root, review_run_dir)
    assert runner.calls == 0
    assert any(e == "LEGACY_SIDECAR_BLOCKED" and "READY_APPROVAL.json" in d for e, d in _events(store))
    assert store.list_pending() == []


def test_B2_new_sidecar_names_do_not_block_a_valid_request(transport, store, runner, snapshot_root, review_run_dir):
    push_valid_request(transport)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/APPROVAL_SIG.json", b"{}")
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/SOURCE_PIN.json", b"{}")
    _scan(transport, store, _policy(), runner, snapshot_root, review_run_dir)
    assert runner.calls == 1


def _policy():
    return LocalPolicy(active_baseline_id=BASELINE, local_policy_revision="1",
                       known_run_policy_refs=[RUN_POLICY_REF])


# --- B-3: sealing needs the watcher lock and spares this process's own jobs -----

def _in_flight(store, key, state=JobState.REVIEW_RUNNING, claim=True):
    store.create_job(key, "REQ-1", "1", PKG, JobState.VALIDATED)
    store.update_job_state(key, state)
    if claim:
        store.record_claim(key)


def test_B3_without_the_watcher_lock_nothing_is_sealed(tmp_path):
    dead = StateStore(tmp_path / "s.sqlite3")
    _in_flight(dead, "K1")
    dead.close()
    live = StateStore(tmp_path / "s.sqlite3")
    assert live.seal_interrupted(exclusive=False) == 0
    assert live.get_job("K1").state == JobState.REVIEW_RUNNING
    live.close()


def test_B3_with_the_lock_orphans_are_sealed_and_recorded_once(tmp_path):
    dead = StateStore(tmp_path / "s.sqlite3")
    _in_flight(dead, "K1", JobState.CLAIMED)
    _in_flight(dead, "K2", JobState.REVIEW_RUNNING, claim=False)
    dead.create_job("K3", "REQ-3", "1", PKG, JobState.COMPLETED)
    dead.close()
    live = StateStore(tmp_path / "s.sqlite3")
    assert live.seal_interrupted(exclusive=True) == 2
    assert live.get_job("K1").state == JobState.REVIEW_UNCERTAIN
    assert live.get_job("K2").state == JobState.REVIEW_UNCERTAIN
    assert live.get_job("K3").state == JobState.COMPLETED
    assert live.seal_interrupted(exclusive=True) == 0
    sealed = [r for r in live.conn.execute("SELECT processing_key FROM audit_log WHERE event='REVIEW_UNCERTAIN'")]
    assert len(sealed) == 2
    live.close()


def test_B3_jobs_claimed_by_this_process_are_never_sealed(tmp_path):
    store = StateStore(tmp_path / "s.sqlite3")
    _in_flight(store, "MINE", JobState.REVIEW_RUNNING)
    assert store.seal_interrupted(exclusive=True) == 0
    assert store.get_job("MINE").state == JobState.REVIEW_RUNNING
    store.close()


def test_B3_read_only_store_never_seals(tmp_path):
    rw = StateStore(tmp_path / "s.sqlite3")
    _in_flight(rw, "K1", JobState.CLAIMED, claim=False)
    rw.close()
    ro = StateStore(tmp_path / "s.sqlite3", read_only=True)
    assert ro.seal_interrupted(exclusive=True) == 0
    assert ro.get_job("K1").state == JobState.CLAIMED
    ro.close()


def test_B3_operator_requeue_of_uncertain_jobs_is_refused(tmp_path, capsys, monkeypatch):
    from skill_collab_watcher import cli
    cfg_dir = tmp_path / "state"
    store = StateStore(cfg_dir / "state.sqlite3")
    store.create_job("K1", "REQ-1", "1", PKG, JobState.REVIEW_UNCERTAIN)
    store.close()

    class Cfg:
        state_dir = cfg_dir
        provider_mode = "LIVE"

    monkeypatch.setattr(cli, "_load", lambda _path: Cfg())
    rc = cli.cmd_recover(type("A", (), {"config": None, "requeue": True})())
    assert rc == cli.EXIT_REFUSED
    check = StateStore(cfg_dir / "state.sqlite3")
    assert check.get_job("K1").state == JobState.REVIEW_UNCERTAIN
    check.close()


# --- B-4: one LIVE provider; SHADOW is read-only; switches are logged ------------

def test_B4_second_live_provider_is_refused(tmp_path):
    store = StateStore(tmp_path / "s.sqlite3")
    store.check_provider("github", "LIVE")
    store.check_provider("github", "LIVE")
    with pytest.raises(ProviderConflict):
        store.check_provider("dropbox", "LIVE")
    store.close()


def test_B4_shadow_cannot_write_and_leaves_the_lease_alone(tmp_path):
    path = tmp_path / "s.sqlite3"
    store = StateStore(path)
    store.check_provider("github", "LIVE")
    store.close()
    ro = StateStore(path, read_only=True)
    ro.check_provider("dropbox", "SHADOW")
    with pytest.raises(sqlite3.OperationalError):
        ro.conn.execute("DELETE FROM counters")
    ro.close()
    again = StateStore(path)
    assert again.conn.execute("SELECT provider FROM provider_lease WHERE id=1").fetchone()[0] == "github"
    again.close()


def test_B4_switch_is_refused_while_a_job_is_in_flight(tmp_path):
    store = StateStore(tmp_path / "s.sqlite3")
    store.check_provider("dropbox", "LIVE")
    _in_flight(store, "K1", JobState.REVIEW_RUNNING)
    with pytest.raises(ProviderConflict, match="in flight"):
        store.switch_provider("dropbox", "github")
    assert store.conn.execute("SELECT provider FROM provider_lease WHERE id=1").fetchone()[0] == "dropbox"
    store.close()


def test_B4_switch_must_start_from_the_active_provider(tmp_path):
    store = StateStore(tmp_path / "s.sqlite3")
    store.check_provider("dropbox", "LIVE")
    with pytest.raises(ProviderConflict):
        store.switch_provider("github", "dropbox")
    store.close()


# --- T21 / T29: cutover reuses completed history; rollback keeps one ACTIVE lease

def test_T21_completed_job_under_the_previous_provider_is_not_repeated(github_env):
    github_env.store.check_provider("dropbox", "LIVE")
    pkg = publish_bundle(github_env.http)
    _scan_github(github_env)
    assert github_env.runner.calls == 1
    epoch = github_env.store.switch_provider("dropbox", "github")
    assert epoch == 2
    _scan_github(github_env)
    assert github_env.runner.calls == 1
    assert github_env.store.get_job(key_for(pkg)).state == JobState.COMPLETED


def test_T29_rollback_keeps_one_active_provider_and_history(github_env):
    store = github_env.store
    store.check_provider("dropbox", "LIVE")
    store.switch_provider("dropbox", "github")
    store.switch_provider("github", "dropbox")
    rows = store.conn.execute("SELECT provider, epoch FROM provider_lease").fetchall()
    assert rows == [("dropbox", 3)]
    history = store.conn.execute("SELECT from_provider, to_provider FROM provider_history ORDER BY id").fetchall()
    assert history == [(None, "dropbox"), ("dropbox", "github"), ("github", "dropbox")]


def _scan_github(env):
    run_scan_cycle(make_transport(env.http), env.store, github_policy(), env.runner, allowed=True,
                   snapshot_root=env.snapshot_root, review_run_dir=env.review_run_dir, remote_root=ROOT)


# --- B-5: a policy revision change does not repeat a completed review -------------

def test_B5_policy_revision_change_does_not_redispatch_completed_request(
        transport, runner, snapshot_root, review_run_dir, store):
    push_valid_request(transport)
    _scan(transport, store, _policy(), runner, snapshot_root, review_run_dir)
    assert runner.calls == 1
    push_valid_request(transport)
    changed = LocalPolicy(active_baseline_id=BASELINE, local_policy_revision="2",
                          known_run_policy_refs=[RUN_POLICY_REF])
    _scan(transport, store, changed, runner, snapshot_root, review_run_dir)
    assert runner.calls == 1
    details = [d for e, d in _events(store) if e == "DUPLICATE_SKIPPED"]
    assert any("another policy revision" in d for d in details)


# --- T08: same request_id and revision with another ZIP is a conflict -------------

def test_T08_same_revision_with_another_package_is_conflict_and_original_kept(
        transport, store, runner, snapshot_root, review_run_dir):
    pkg_a = push_valid_request(transport)
    _scan(transport, store, _policy(), runner, snapshot_root, review_run_dir)
    package_b = make_package_zip("B-different")
    pkg_b = hashlib.sha256(package_b).hexdigest()
    req_b = request_md(package_sha256=pkg_b, package_size=len(package_b)).encode("utf-8")
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/REQUEST.md", req_b)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/READY.md",
                        ready_md(hashlib.sha256(req_b).hexdigest(), pkg_b).encode("utf-8"))
    transport.push_file("/SKILL-COLLAB/packages/test.zip", package_b)
    _scan(transport, store, _policy(), runner, snapshot_root, review_run_dir)
    assert runner.calls == 1
    assert store.get_job(key_for(pkg_a)).state == JobState.COMPLETED
    assert any(e == "CONFLICT" and "original kept" in d for e, d in _events(store))


# --- B-6: hashes cover the stored bytes; CRLF is hashed as-is; BOM is refused -----

def test_B6_crlf_request_is_hashed_over_its_stored_bytes(policy):
    text = request_md(package_sha256=PKG, package_size=10)
    crlf = text.replace("\n", "\r\n").encode("utf-8")
    ready = ready_md(hashlib.sha256(crlf).hexdigest(), PKG)
    assert validate(crlf.decode("utf-8"), ready, None, policy,
                    expected_request_id="REQ-1", request_bytes=crlf).needs_package_download
    lf = text.encode("utf-8")
    assert not validate(lf.decode("utf-8"), ready, None, policy,
                        expected_request_id="REQ-1", request_bytes=lf).needs_package_download


def test_B6_stored_bytes_hash_equals_the_legacy_text_hash_for_valid_utf8():
    raw = request_md(package_sha256=PKG, package_size=10).replace("\n", "\r\n").encode("utf-8")
    legacy_text_hash = hashlib.sha256(raw.decode("utf-8").encode("utf-8")).hexdigest()
    assert legacy_text_hash == sha256(raw)


def test_B6_legacy_text_hash_equals_stored_byte_hash_for_any_valid_utf8_document():
    import random

    rng = random.Random(20261110)
    pieces = ["\r\n", "\n", "\r", "\t", "\x00", "﻿", "한글", "é", "😀", "---", ": ", "'", '"', " " * 5]
    for _ in range(2000):
        text = "".join(rng.choice(pieces) for _ in range(rng.randint(0, 40)))
        raw = text.encode("utf-8")
        assert hashlib.sha256(raw.decode("utf-8").encode("utf-8")).hexdigest() == hashlib.sha256(raw).hexdigest()


def test_B6_only_invalid_utf8_can_make_the_two_hashes_differ_and_that_is_rejected_first(
        transport, store, runner, snapshot_root, review_run_dir):
    push_valid_request(transport)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/REQUEST.md", b"---\n\xff\xfe\n---\n")
    _scan(transport, store, _policy(), runner, snapshot_root, review_run_dir)
    assert runner.calls == 0
    assert any(e == "REJECTED" and "UTF-8" in d for e, d in _events(store))


def test_B6_bom_request_is_refused_before_any_model_call(transport, store, runner, snapshot_root, review_run_dir):
    push_valid_request(transport)
    text = transport.files[f"{REMOTE_ROOT}/requests/REQ-1/REQUEST.md"].data
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/REQUEST.md", b"\xef\xbb\xbf" + text)
    _scan(transport, store, _policy(), runner, snapshot_root, review_run_dir)
    assert runner.calls == 0
    assert any(e == "REJECTED" and "BOM" in d for e, d in _events(store))
