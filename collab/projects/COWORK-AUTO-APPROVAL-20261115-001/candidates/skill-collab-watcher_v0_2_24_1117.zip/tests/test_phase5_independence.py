"""S-2: the account the watcher runs as must not be able to change what it trusts; and a clock that
runs backwards must not bring an expired approval back to life. Synthetic data, test-double signatures."""
from __future__ import annotations

import hashlib
import json
import sys
from datetime import datetime, timedelta, timezone

import pytest

from bundle import KEY_ID, REPO_ID, github_policy, publish_bundle
from skill_collab_watcher import cli, orchestrator
from skill_collab_watcher.approval import ClockUntrusted, watcher_write_findings
from skill_collab_watcher.state_store import StateStore
from test_phase1_github import has_event, run
from test_phase3_gates import events_of, make_config, open_rt, trust_file

READ_ONLY = 0x120089      # FILE_GENERIC_READ
FULL = 0x1F01FF           # FILE_ALL_ACCESS
MODIFY = 0x1301BF


# --- the effective-rights check ---------------------------------------------------------------

def make_files(tmp_path):
    root = tmp_path / "trust.json"
    root.write_text("{}", encoding="utf-8")
    return [("trust root file", str(root)), ("trust root folder", str(tmp_path))]


def test_read_only_access_for_the_watcher_account_is_independent(tmp_path):
    assert watcher_write_findings(make_files(tmp_path), effective_mask=lambda _p: READ_ONLY) == []


@pytest.mark.parametrize("mask", [FULL, MODIFY, 0x2, 0x4, 0x40, 0x10000, 0x40000, 0x80000, 0x40000000])
def test_any_write_like_right_for_the_watcher_account_is_a_finding(tmp_path, mask):
    findings = watcher_write_findings(make_files(tmp_path), effective_mask=lambda _p: READ_ONLY | mask)
    assert len(findings) == 2 and all("watcher's own account" in f for f in findings)


def test_findings_name_the_role_never_the_path(tmp_path):
    findings = watcher_write_findings(make_files(tmp_path), effective_mask=lambda _p: FULL)
    assert all(str(tmp_path) not in f for f in findings)


def test_a_missing_item_and_an_unreadable_permission_are_findings_not_passes(tmp_path):
    assert watcher_write_findings([("pin file", str(tmp_path / "absent"))], effective_mask=lambda _p: 0) == [
        "pin file does not exist"]

    def boom(_p):
        raise OSError("denied")

    out = watcher_write_findings(make_files(tmp_path), effective_mask=boom)
    assert out and all("could not be read" in f for f in out)


def test_an_item_the_account_may_not_even_look_at_is_a_finding_not_a_crash(tmp_path, monkeypatch):
    """Found on a real host: for a folder the account has no access to, Path.exists() raises
    PermissionError, which used to abort the check instead of reporting it."""
    from pathlib import Path

    def deny(self):
        raise PermissionError(13, "Access is denied")

    monkeypatch.setattr(Path, "exists", deny)
    out = watcher_write_findings([("trust root file", str(tmp_path / "x"))], effective_mask=lambda _p: 0)
    assert out == ["trust root file: permissions could not be read"]


@pytest.mark.skipif(sys.platform != "win32", reason="Windows access control")
def test_the_real_windows_api_says_the_current_user_can_change_its_own_files(tmp_path):
    """On this kind of host the interactive user owns its files: the answer must be 'yes, it can write'.
    That is exactly why a trust root kept in the user's own profile is NOT independent."""
    findings = watcher_write_findings(make_files(tmp_path))
    assert len(findings) == 2


@pytest.mark.skipif(sys.platform != "win32", reason="Windows access control")
def test_the_real_windows_api_reads_a_system_file_without_error():
    import os

    path = os.path.join(os.environ["SystemRoot"], "System32", "drivers", "etc", "hosts")
    if not os.path.exists(path):
        pytest.skip("no hosts file")
    from skill_collab_watcher.approval import _effective_mask

    assert isinstance(_effective_mask(path), int)


# --- wiring in the runtime ---------------------------------------------------------------------

def pinned(tmp_path, **kw):
    path = trust_file(tmp_path, **kw)
    return path, hashlib.sha256(path.read_bytes()).hexdigest()


def test_enforce_refuses_a_root_the_watcher_account_can_change(tmp_path, monkeypatch):
    monkeypatch.setattr(cli, "check_trust_root_acl", lambda _p: [])
    monkeypatch.setattr(cli, "watcher_write_findings", lambda items: [f"{role} can be modified by the watcher's own account" for role, _ in items])
    path, pin = pinned(tmp_path)
    rt = open_rt(make_config(tmp_path, trust_root_file=str(path), trust_root_sha256=pin))
    assert rt.policy.trust_root is None
    assert any(e == "TRUST_ROOT_REFUSED" and "NOT_INDEPENDENT" in d for e, d in events_of(rt))
    rt.close()


def test_the_checked_items_are_the_root_its_folder_the_pin_holder_and_its_folder(tmp_path, monkeypatch):
    monkeypatch.setattr(cli, "check_trust_root_acl", lambda _p: [])
    seen = []
    monkeypatch.setattr(cli, "watcher_write_findings", lambda items: seen.append([r for r, _ in items]) or [])
    path, pin = pinned(tmp_path)
    open_rt(make_config(tmp_path, trust_root_file=str(path), trust_root_sha256=pin)).close()
    assert seen == [["trust root file", "trust root folder", "config file that holds the pin", "config folder"]]


def test_warn_mode_loads_the_root_but_records_the_weakness(tmp_path, monkeypatch):
    monkeypatch.setattr(cli, "check_trust_root_acl", lambda _p: [])
    monkeypatch.setattr(cli, "watcher_write_findings", lambda items: ["trust root file can be modified by the watcher's own account"])
    path, pin = pinned(tmp_path)
    rt = open_rt(make_config(tmp_path, trust_root_file=str(path), trust_root_sha256=pin, trust_root_independence="warn"))
    assert rt.policy.trust_root is not None
    assert any(e == "TRUST_ROOT_INDEPENDENCE_WARNING" for e, _d in events_of(rt))
    rt.close()


def test_enforce_is_the_default(tmp_path):
    assert make_config(tmp_path).trust_root_independence == "enforce"


def test_an_independent_root_loads_in_enforce_mode(tmp_path, monkeypatch):
    monkeypatch.setattr(cli, "check_trust_root_acl", lambda _p: [])
    monkeypatch.setattr(cli, "watcher_write_findings", lambda _items: [])  # the account cannot change the files
    path, pin = pinned(tmp_path, version=4)
    rt = open_rt(make_config(tmp_path, trust_root_file=str(path), trust_root_sha256=pin))
    assert rt.policy.trust_root.version == 4
    rt.close()


@pytest.mark.skipif(sys.platform != "win32", reason="Windows access control")
def test_on_a_real_user_profile_enforce_mode_refuses_the_root_end_to_end(tmp_path, monkeypatch):
    """No stubs for the independence check: files made by the current user are changeable by it,
    so enforce mode must refuse - this is the honest result for the current host layout."""
    monkeypatch.setattr(cli, "check_trust_root_acl", lambda _p: [])
    monkeypatch.undo()
    monkeypatch.setattr(cli, "check_trust_root_acl", lambda _p: [])
    monkeypatch.setattr(cli, "watcher_write_findings", watcher_write_findings)
    path, pin = pinned(tmp_path)
    rt = open_rt(make_config(tmp_path, trust_root_file=str(path), trust_root_sha256=pin))
    assert rt.policy.trust_root is None
    assert any(e == "TRUST_ROOT_REFUSED" and "NOT_INDEPENDENT" in d for e, d in events_of(rt))
    rt.close()


# --- clock rollback ----------------------------------------------------------------------------

def test_the_provider_time_high_water_mark_only_moves_forward(tmp_path):
    store = StateStore(tmp_path / "s.sqlite3")
    store.check_time_ratchet(1_000_000)
    store.check_time_ratchet(1_000_100)
    store.check_time_ratchet(1_000_000 + 100 - 200)   # a little jitter below the mark is tolerated
    with pytest.raises(ClockUntrusted, match="backwards"):
        store.check_time_ratchet(1_000_100 - 301)
    assert store.get_counter("provider_time_epoch") == 1_000_100
    store.close()


def test_a_read_only_store_compares_but_never_records_the_time(tmp_path):
    rw = StateStore(tmp_path / "s.sqlite3")
    rw.check_time_ratchet(2_000_000)
    rw.close()
    ro = StateStore(tmp_path / "s.sqlite3", read_only=True)
    ro.check_time_ratchet(2_000_500)
    with pytest.raises(ClockUntrusted):
        ro.check_time_ratchet(1_999_000)
    assert ro.get_counter("provider_time_epoch") == 2_000_000
    ro.close()


def test_a_provider_whose_clock_went_backwards_blocks_dispatch(github_env):
    github_env.store.increment_counter("provider_time_epoch", int(datetime.now(timezone.utc).timestamp()) + 3600)
    publish_bundle(github_env.http)
    run(github_env)
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_CLOCK_UNTRUSTED", "backwards")


def test_rolling_the_local_clock_back_cannot_revive_an_expired_approval(github_env, monkeypatch):
    expired = (datetime.now(timezone.utc) - timedelta(minutes=10)).isoformat()
    publish_bundle(github_env.http, payload_changes={"expires_at": expired})

    class RolledBack(datetime):
        @classmethod
        def now(cls, tz=None):
            return datetime.now(tz) - timedelta(minutes=30)

    monkeypatch.setattr(orchestrator, "datetime", RolledBack)
    run(github_env)
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_CLOCK_UNTRUSTED", "differs")


def test_a_normal_clock_still_dispatches_and_advances_the_mark(github_env):
    publish_bundle(github_env.http)
    run(github_env)
    assert github_env.runner.calls == 1
    assert github_env.store.get_counter("provider_time_epoch") > 0
