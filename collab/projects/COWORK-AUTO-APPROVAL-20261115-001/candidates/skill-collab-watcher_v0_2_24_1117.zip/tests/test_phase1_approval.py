"""Approval gate S01-S10 through the GitHub pipeline, with a test-double signature
backend, plus direct checks of verify_approval. Real Ed25519 is in
test_phase2_ed25519.py."""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

import pytest

from bundle import (
    DoubleBackend, KEY_ID, PUBLIC, REPO_ID, TRUST, github_policy, publish_bundle, sig_for,
)
from skill_collab_watcher.approval import (
    PAYLOAD_SCHEMA, PIN_SCHEMA, APPROVAL_SCHEMA, ApprovalRejected, NotConfigured, TrustedKey, TrustRoot,
    canonical, load_trust_root, verify_approval,
)
from fake_github import j
from test_phase1_github import has_event, run


def _reject(github_env, name: str, detail: str, **bundle_kwargs) -> None:
    publish_bundle(github_env.http, **bundle_kwargs)
    run(github_env)
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, name, detail)


def test_S01_unsigned_bundle_without_approval_costs_no_model_call(github_env):
    _reject(github_env, "APPROVAL_MISSING", "approval bundle incomplete", omit=("approval",))


def test_S02_forged_signature_is_rejected(github_env):
    _reject(github_env, "APPROVAL_REJECTED", "BAD_SIGNATURE", signature="TESTSIG:forged")


def test_S03_approval_for_another_repository_is_rejected(github_env):
    _reject(github_env, "APPROVAL_REJECTED", "REPO_ID_MISMATCH", payload_changes={"repo_id": "other-repo"})


def test_S04_expired_approval_is_rejected(github_env):
    past = (datetime.now(timezone.utc) - timedelta(minutes=10)).isoformat()
    _reject(github_env, "APPROVAL_REJECTED", "APPROVAL_EXPIRED", payload_changes={"expires_at": past})


def test_S05_tampered_source_commit_is_rejected(github_env):
    _reject(github_env, "APPROVAL_REJECTED", "SOURCE_COMMIT_MISMATCH", pin_commit="f" * 40)


def test_S06_request_bytes_not_matching_the_approval_are_rejected(github_env):
    _reject(github_env, "APPROVAL_REJECTED", "BINDING_MISMATCH:request_sha256",
            payload_changes={"request_sha256": "0" * 64})


def test_S07_package_bytes_not_matching_the_approval_are_rejected(github_env):
    _reject(github_env, "APPROVAL_REJECTED", "BINDING_MISMATCH:package_sha256",
            payload_changes={"package_sha256": "1" * 64})


def test_S08_retired_key_is_rejected(github_env):
    retired = TrustRoot(repo_id=REPO_ID, keys={KEY_ID: TrustedKey(
        key_id=KEY_ID, public_key=PUBLIC, fingerprint="0" * 64, status="RETIRED")})
    publish_bundle(github_env.http)
    run(github_env, policy=github_policy(trust_root=retired))
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_REJECTED", "KEY_RETIRED")


def test_S08_unknown_key_id_is_rejected(github_env):
    _reject(github_env, "APPROVAL_REJECTED", "UNKNOWN_KEY_ID", key_id="key-never-issued")


def test_S09_approval_replayed_under_a_new_policy_revision_is_rejected(github_env):
    publish_bundle(github_env.http)
    run(github_env, policy=github_policy(local_policy_revision="2"))
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_REJECTED", "BINDING_MISMATCH:local_policy_revision")


def test_S09_approval_replayed_for_another_request_is_rejected(github_env):
    from conftest import make_package_zip
    package = make_package_zip("REQ-1")
    publish_bundle(github_env.http, "REQ-1", package=package)
    approval = github_env.http.files()["collab/requests/REQ-1/APPROVAL_SIG.json"]
    pin = github_env.http.files()["collab/requests/REQ-1/SOURCE_PIN.json"]
    publish_bundle(github_env.http, "REQ-2", package=package)
    github_env.http.commit({
        "collab/requests/REQ-2/APPROVAL_SIG.json": approval,
        "collab/requests/REQ-2/SOURCE_PIN.json": pin,
    })
    run(github_env)
    assert has_event(github_env.store, "APPROVAL_REJECTED", "BINDING_MISMATCH:request_id")
    assert github_env.runner.calls == 1


def test_S10_partial_sidecar_pair_waits_without_model_call(github_env):
    _reject(github_env, "APPROVAL_MISSING", "approval bundle incomplete", omit=("pin",))


def test_S_unconfigured_signature_backend_fails_closed(github_env):
    publish_bundle(github_env.http)
    run(github_env, policy=github_policy(trust_root=None, signature_backend=None))
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_UNVERIFIABLE")


def test_S_nonce_missing_is_rejected(github_env):
    _reject(github_env, "APPROVAL_REJECTED", "NONCE_MISSING", payload_changes={"nonce": "short"})


# --- verify_approval direct checks (explicit clock) ------------------------------

def _pair(now: datetime, *, issued=timedelta(hours=-1), expires=timedelta(hours=1), commit="c" * 40):
    payload = {"schema": PAYLOAD_SCHEMA, "repo_id": REPO_ID, "source_commit": commit,
               "nonce": "n" * 24, "issued_at": (now + issued).isoformat(),
               "expires_at": (now + expires).isoformat()}
    approval = j({"schema": APPROVAL_SCHEMA, "key_id": KEY_ID, "payload": payload,
                  "signature": sig_for(canonical(payload))})
    pin = j({"schema": PIN_SCHEMA, "repo_id": REPO_ID, "commit": commit})
    return approval, pin


def _verify(approval, pin, now, trust=TRUST, backend=None):
    return verify_approval(approval, pin, trust=trust, backend=backend or DoubleBackend(),
                           expected={}, now=now)


def test_verify_is_fail_closed_without_trust_root_or_backend():
    now = datetime.now(timezone.utc)
    approval, pin = _pair(now)
    with pytest.raises(NotConfigured):
        _verify(approval, pin, now, trust=None)
    with pytest.raises(NotConfigured):
        verify_approval(approval, pin, trust=TRUST, backend=None, expected={}, now=now)


def test_verify_accepts_a_correctly_signed_pair():
    now = datetime.now(timezone.utc)
    approval, pin = _pair(now)
    assert _verify(approval, pin, now)["repo_id"] == REPO_ID


def test_S02_payload_altered_after_signing_is_rejected():
    now = datetime.now(timezone.utc)
    approval, pin = _pair(now)
    obj = json.loads(approval)
    obj["payload"]["nonce"] = "m" * 24
    with pytest.raises(ApprovalRejected, match="BAD_SIGNATURE"):
        _verify(j(obj), pin, now)


def test_S04_expiry_boundary_is_exclusive():
    now = datetime.now(timezone.utc)
    approval, pin = _pair(now, expires=timedelta(seconds=0))
    with pytest.raises(ApprovalRejected, match="APPROVAL_EXPIRED"):
        _verify(approval, pin, now)
    approval, pin = _pair(now, expires=timedelta(seconds=1))
    _verify(approval, pin, now)


def test_S04_clock_skew_is_limited_to_five_minutes():
    now = datetime.now(timezone.utc)
    approval, pin = _pair(now, issued=timedelta(minutes=4))
    _verify(approval, pin, now)
    approval, pin = _pair(now, issued=timedelta(minutes=6))
    with pytest.raises(ApprovalRejected, match="APPROVAL_NOT_YET_VALID"):
        _verify(approval, pin, now)


def test_trust_root_fingerprint_must_match_its_key(tmp_path):
    from skill_collab_watcher.approval import TRUST_ROOT_SCHEMA
    path = tmp_path / "trust.json"
    path.write_text(json.dumps({"schema": TRUST_ROOT_SCHEMA, "repo_id": REPO_ID, "keys": [
        {"key_id": "k1", "public_key": "AAAA", "fingerprint": "0" * 64, "status": "ACTIVE"}]}),
        encoding="utf-8")
    with pytest.raises(ValueError):
        load_trust_root(str(path))
