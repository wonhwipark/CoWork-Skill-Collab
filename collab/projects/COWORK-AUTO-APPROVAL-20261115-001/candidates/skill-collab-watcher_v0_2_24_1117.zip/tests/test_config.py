"""review_policy.enabled / dry_run parsing contract.

History: Config.load used to read the top-level key `enabled` for what the
README and every shipped config call `review_policy.enabled`, so setting
review_policy.enabled=true silently did nothing. These tests pin both
directions so neither "cannot be turned on" nor "turned on by accident"
can come back unnoticed.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from skill_collab_watcher.config import Config, ConfigError

REPO_ROOT = Path(__file__).resolve().parents[1]


def _load(tmp_path, top_level=None, review_policy=None) -> Config:
    raw = {
        "schema_version": 1,
        "baseline_id": "TEST-BASELINE",
        "remote_root": "/SKILL-COLLAB",
        "local_state_dir": str(tmp_path / "state"),
    }
    if top_level:
        raw.update(top_level)
    if review_policy is not None:
        raw["review_policy"] = review_policy
    path = tmp_path / "cfg.json"
    path.write_text(json.dumps(raw), encoding="utf-8")
    return Config.load(path)


def test_review_policy_enabled_true_is_honored(tmp_path):
    cfg = _load(tmp_path, review_policy={"enabled": True, "dry_run": False})
    assert cfg.review_policy.enabled is True
    assert cfg.review_policy.dry_run is False
    assert cfg.review_policy.dispatch_allowed is True
    assert cfg.review_policy.enabled_source == "review_policy.enabled"


def test_review_policy_enabled_false_is_honored(tmp_path):
    cfg = _load(tmp_path, review_policy={"enabled": False, "dry_run": False})
    assert cfg.review_policy.enabled is False
    assert cfg.review_policy.dispatch_allowed is False


def test_enabled_true_with_dry_run_true_still_blocks_dispatch(tmp_path):
    cfg = _load(tmp_path, review_policy={"enabled": True, "dry_run": True})
    assert cfg.review_policy.enabled is True
    assert cfg.review_policy.dispatch_allowed is False


def test_defaults_are_off_and_dry_run(tmp_path):
    cfg = _load(tmp_path, review_policy={})
    assert cfg.review_policy.enabled is False
    assert cfg.review_policy.dry_run is True
    assert cfg.review_policy.dispatch_allowed is False
    cfg = _load(tmp_path)  # no review_policy block at all
    assert cfg.review_policy.dispatch_allowed is False


def test_top_level_enabled_is_only_a_legacy_alias(tmp_path):
    cfg = _load(tmp_path, top_level={"enabled": True}, review_policy={"dry_run": False})
    assert cfg.review_policy.enabled is True
    assert cfg.review_policy.enabled_source == "top-level enabled (legacy alias)"


def test_review_policy_wins_when_top_level_agrees(tmp_path):
    cfg = _load(tmp_path, top_level={"enabled": True}, review_policy={"enabled": True, "dry_run": False})
    assert cfg.review_policy.enabled is True
    assert cfg.review_policy.enabled_source == "review_policy.enabled"


@pytest.mark.parametrize("top,nested", [(True, False), (False, True)])
def test_conflicting_enabled_keys_fail_closed(tmp_path, top, nested):
    cfg = _load(tmp_path, top_level={"enabled": top}, review_policy={"enabled": nested, "dry_run": False})
    assert cfg.review_policy.enabled is False
    assert cfg.review_policy.dispatch_allowed is False
    assert "CONFLICT" in cfg.review_policy.enabled_source


@pytest.mark.parametrize("bad", ["false", "true", "yes", 1, 0, "", []])
def test_non_boolean_enabled_is_rejected_not_coerced(tmp_path, bad):
    # bool("false") is True in Python: a quoted value must never enable reviews.
    with pytest.raises(ConfigError):
        _load(tmp_path, review_policy={"enabled": bad})


@pytest.mark.parametrize("bad", ["false", 0, "no"])
def test_non_boolean_dry_run_is_rejected(tmp_path, bad):
    with pytest.raises(ConfigError):
        _load(tmp_path, review_policy={"dry_run": bad})


def test_config_saved_with_a_utf8_bom_still_loads(tmp_path):
    path = tmp_path / "bom.json"
    path.write_bytes(b"\xef\xbb\xbf" + json.dumps(
        {"baseline_id": "B", "local_state_dir": str(tmp_path / "s"), "review_policy": {"enabled": False}}
    ).encode("utf-8"))
    assert Config.load(path).baseline_id == "B"


@pytest.mark.parametrize("text", ["{not json", "[]", ""])
def test_unreadable_config_is_a_config_error_not_a_traceback(tmp_path, text):
    path = tmp_path / "bad.json"
    path.write_text(text, encoding="utf-8")
    with pytest.raises(ConfigError):
        Config.load(path)


@pytest.mark.parametrize("name", ["reviewer.config.example.json"])
def test_shipped_configs_are_not_activated(name):
    # reviewer.config.json is the machine's own file (never packaged, see
    # test_release_packaging); it may legitimately be ON while operating.
    path = REPO_ROOT / "config" / name
    if not path.is_file():
        pytest.skip(f"{name} not present in this tree")
    cfg = Config.load(path)
    assert cfg.review_policy.enabled is False
    assert cfg.review_policy.dry_run is True
    assert cfg.review_policy.dispatch_allowed is False
