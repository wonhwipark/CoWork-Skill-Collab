"""GitHub provider pipeline against the synthetic REST fake. Numbers refer to the
acceptance matrix (T01-T38). No network, no model."""
from __future__ import annotations

import json

import pytest

from bundle import (
    REPO, ROOT, TOKEN, github_policy, key_for, make_transport, publish_bundle, sha256,
)
from conftest import make_package_zip
from fake_github import rp
from skill_collab_watcher.fake_runner import FakeReviewRunner
from skill_collab_watcher.models import JobState
from skill_collab_watcher.orchestrator import run_scan_cycle
from skill_collab_watcher.state_store import StateStore
from skill_collab_watcher.transport_base import AuthRequired, TransientTransportError, TransportError, UploadConflict


def run(env, policy=None, transport=None, allowed=True, exclusive=False):
    return run_scan_cycle(transport or make_transport(env.http), env.store,
                          policy or github_policy(), env.runner, allowed=allowed,
                          snapshot_root=env.snapshot_root, review_run_dir=env.review_run_dir,
                          remote_root=ROOT, exclusive=exclusive)


def events(store):
    return [(e, d or "") for _ts, e, _k, d in store.recent_events(500)]


def has_event(store, name, detail=""):
    return any(e == name and detail in d for e, d in events(store))


def restart(env):
    env.store.close()
    env.store = StateStore(env.tmp / "state.sqlite3")


# T01-T02: a package or a REQUEST alone never reaches the model
def test_T01_package_without_ready_costs_no_model_call(github_env):
    github_env.http.commit({rp("packages/test.zip"): make_package_zip("t01")})
    run(github_env)
    assert github_env.runner.calls == 0


def test_T02_request_without_ready_costs_no_model_call(github_env):
    github_env.http.commit({rp("requests/REQ-1/REQUEST.md"): (
        b"---\nschema: SKILL_COLLAB_REVIEW_REQUEST_V1\n---\n")})
    run(github_env)
    assert github_env.runner.calls == 0


# T03: READY visible before its package exists (commit A not yet verified)
def test_T03_ready_before_package_is_retried_without_claim(github_env):
    publish_bundle(github_env.http, include_package=False)
    run(github_env)
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "TRANSPORT_ERROR")
    assert not any(e == "CLAIMED" for e, _d in events(github_env.store))


# T04: READY.request_sha256 does not match the stored REQUEST bytes
def test_T04_ready_request_sha_mismatch_is_conflict_without_model(github_env):
    publish_bundle(github_env.http, ready_request_sha="0" * 64)
    run(github_env)
    assert github_env.runner.calls == 0


# T09: a READY that exists only on a side ref (PR head, fork) is never read
def test_T09_ready_on_side_ref_is_invisible_to_the_watcher(github_env):
    publish_bundle(github_env.http, side=True)
    run(github_env)
    assert github_env.runner.calls == 0
    assert github_env.store.get_job(key_for(sha256(make_package_zip("REQ-1")))) is None


# T10-T11: approved READY dispatches once; repeats and restarts do not
def test_T10_valid_approved_ready_dispatches_once_and_publishes(github_env):
    pkg = publish_bundle(github_env.http)
    run(github_env)
    assert github_env.runner.calls == 1
    assert github_env.store.get_job(key_for(pkg)).state == JobState.COMPLETED
    files = github_env.http.files()
    assert rp("reviews/REQ-1/REVIEW_RESULT_1.md") in files
    assert rp("receipts/REQ-1/RECEIPT_1.md") in files


def test_T11_repeat_poll_and_restart_do_not_redispatch(github_env):
    publish_bundle(github_env.http)
    run(github_env)
    run(github_env)
    assert github_env.runner.calls == 1
    restart(github_env)
    run(github_env)
    assert github_env.runner.calls == 1


# T12: the watcher dies during the model call; the next watcher seals it
def test_T12_interrupted_model_call_is_sealed_without_redispatch(github_env):
    pkg = publish_bundle(github_env.http)
    dead = github_env.store
    dead.create_job(key_for(pkg), "REQ-1", "1", pkg, JobState.VALIDATED)
    dead.update_job_state(key_for(pkg), JobState.REVIEW_RUNNING)
    dead.record_claim(key_for(pkg))
    restart(github_env)
    run(github_env, exclusive=True)
    assert github_env.runner.calls == 0
    assert github_env.store.get_job(key_for(pkg)).state == JobState.REVIEW_UNCERTAIN
    run(github_env, exclusive=True)
    assert github_env.runner.calls == 0
    assert sum(1 for e, _d in events(github_env.store) if e == "REVIEW_UNCERTAIN") == 1


# T13: result publication fails after the model answered; only the upload is retried
def test_T13_publish_failure_retries_upload_without_model_call(github_env):
    pkg = publish_bundle(github_env.http)
    github_env.http.inject("PUT", "/contents/collab/reviews/", status=503, times=1)
    run(github_env)
    assert github_env.runner.calls == 1
    assert github_env.store.get_job(key_for(pkg)).state == JobState.UPLOAD_PENDING
    run(github_env)
    assert github_env.runner.calls == 1
    assert github_env.store.get_job(key_for(pkg)).state == JobState.COMPLETED
    assert rp("reviews/REQ-1/REVIEW_RESULT_1.md") in github_env.http.files()


# T14: REVIEW_RESULT is up but RECEIPT is missing -> not complete, no completion event
def test_T14_missing_receipt_keeps_job_pending_and_completion_silent(github_env):
    pkg = publish_bundle(github_env.http)
    github_env.http.inject("PUT", "/contents/collab/receipts/", status=503, times=1)
    run(github_env)
    assert github_env.store.get_job(key_for(pkg)).state == JobState.UPLOAD_PENDING
    assert rp("reviews/REQ-1/REVIEW_RESULT_1.md") in github_env.http.files()
    assert rp("receipts/REQ-1/RECEIPT_1.md") not in github_env.http.files()
    assert not any(e == "COMPLETED" for e, _d in events(github_env.store))
    run(github_env)
    assert github_env.runner.calls == 1
    assert github_env.store.get_job(key_for(pkg)).state == JobState.COMPLETED


# T15: a receipt that names another job must not promote this job to COMPLETED
def test_T15_wrong_receipt_blocks_completion(github_env):
    pkg = publish_bundle(github_env.http)
    wrong = json.dumps({"processing_key": "REQ-1|1|" + "f" * 64 + "|1", "request_id": "REQ-1",
                        "request_revision": "1", "package_sha256": "f" * 64, "ok": True,
                        "watcher_version": "x"})
    github_env.http.commit({rp("receipts/REQ-1/RECEIPT_1.md"): wrong.encode("utf-8")})
    run(github_env)
    assert github_env.store.get_job(key_for(pkg)).state == JobState.CONFLICT
    assert not any(e == "COMPLETED" for e, _d in events(github_env.store))
    run(github_env)
    assert github_env.runner.calls == 1


# T16: reads come from the pinned commit; a moved head and tampered bytes are caught
def test_T16_download_reads_the_pinned_commit_not_the_moved_head(github_env):
    publish_bundle(github_env.http)
    transport = make_transport(github_env.http)
    expected = github_env.http.files()[rp("requests/REQ-1/REQUEST.md")]
    transport.pin_current()
    github_env.http.commit({rp("requests/REQ-1/REQUEST.md"): b"moved on"})
    data, _ = transport.download(f"{ROOT}/requests/REQ-1/REQUEST.md")
    assert data == expected
    transport.unpin()
    assert transport.current_pin() is None


def test_T16_tampered_pinned_bytes_are_detected_before_any_model_call(github_env):
    publish_bundle(github_env.http)
    github_env.http.corrupt(rp("requests/REQ-1/REQUEST.md"))
    run(github_env)
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "TRANSPORT_ERROR", "BLOB_SHA_MISMATCH")


# T17: add-only publication; a concurrent creation is a conflict, nothing is overwritten
def test_T17_upload_is_add_only_and_never_overwrites(github_env):
    transport = make_transport(github_env.http)
    transport.upload(f"{ROOT}/reviews/REQ-2/X.md", b"first", mode="add")
    with pytest.raises(UploadConflict):
        transport.upload(f"{ROOT}/reviews/REQ-2/X.md", b"second", mode="add")
    github_env.http.inject("PUT", "/contents/collab/reviews/REQ-3/", status=422, times=1)
    with pytest.raises(UploadConflict):
        transport.upload(f"{ROOT}/reviews/REQ-3/X.md", b"race", mode="add")
    assert github_env.http.files()[rp("reviews/REQ-2/X.md")] == b"first"
    assert {m for m, _u in github_env.http.calls} <= {"GET", "PUT"}


# T18: fail closed on credential, permission, rate limit and network errors
def test_T18_missing_credential_fails_closed_before_any_request(github_env):
    with pytest.raises(AuthRequired):
        make_transport(github_env.http, token="").ensure_auth()
    assert github_env.http.calls == []


def test_T18_forbidden_or_missing_repo_is_auth_required(github_env):
    from fake_github import REPO as FAKE_REPO
    github_env.http.inject("GET", f"/repos/{FAKE_REPO}", status=403, times=1)
    with pytest.raises(AuthRequired):
        make_transport(github_env.http).ensure_auth()
    github_env.http.inject("GET", f"/repos/{FAKE_REPO}", status=404, times=1)
    with pytest.raises(AuthRequired):
        make_transport(github_env.http).ensure_auth()


def test_T18_rate_limit_is_transient_with_retry_hint(github_env):
    publish_bundle(github_env.http)
    github_env.http.inject("GET", "/git/trees/", status=429, headers={"retry-after": "30"}, times=1)
    with pytest.raises(TransientTransportError) as info:
        make_transport(github_env.http).list_folder(ROOT)
    assert info.value.retry_after == 30


def test_T18_network_failure_is_logged_without_credential_and_no_model_call(github_env):
    publish_bundle(github_env.http)
    github_env.http.inject("GET", "/git/trees/", exc=TransportError("network error: URLError"), times=1)
    summary = run(github_env)
    assert summary.note == "TRANSPORT_ERROR"
    assert github_env.runner.calls == 0
    assert TOKEN not in json.dumps(events(github_env.store))


def test_T18_auth_failure_during_scan_is_fail_closed(github_env):
    publish_bundle(github_env.http)
    github_env.http.inject("GET", f"/repos/{REPO}", status=401, times=1)
    summary = run(github_env)
    assert summary.note == "AUTH_REQUIRED"
    assert github_env.runner.calls == 0


# T20: SHADOW reads, writes nothing, calls no model
def test_T20_shadow_store_and_remote_stay_untouched(github_env):
    publish_bundle(github_env.http)
    github_env.store.close()
    shadow = StateStore(github_env.tmp / "state.sqlite3", read_only=True)
    run_scan_cycle(make_transport(github_env.http), shadow, github_policy(require_approval=False),
                   github_env.runner, allowed=False, snapshot_root=github_env.snapshot_root,
                   review_run_dir=github_env.review_run_dir, remote_root=ROOT)
    assert shadow.shadow_log
    shadow.close()
    github_env.store = StateStore(github_env.tmp / "state.sqlite3")
    assert github_env.runner.calls == 0
    assert [m for m, _u in github_env.http.calls if m == "PUT"] == []
    assert github_env.store.conn.execute("SELECT COUNT(*) FROM jobs").fetchone()[0] == 0
    assert github_env.store.conn.execute("SELECT COUNT(*) FROM audit_log").fetchone()[0] == 0
