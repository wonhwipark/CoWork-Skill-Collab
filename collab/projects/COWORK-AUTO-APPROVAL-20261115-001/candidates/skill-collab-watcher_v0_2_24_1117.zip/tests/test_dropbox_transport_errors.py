"""Failure handling of DropboxTransport against the REAL dropbox SDK
exception classes (dropbox 12.2.4). Only the network client is replaced by a
scripted fake; no socket is opened and no credentials are used.
"""
from __future__ import annotations

import threading
from datetime import datetime
from types import SimpleNamespace

import pytest
import requests
from dropbox import auth, exceptions as dx, files

from skill_collab_watcher.dropbox_transport import DropboxTransport, summarize_exception
from skill_collab_watcher.transport_base import (
    AuthRequired, RemoteNotFound, TransientTransportError, TransportError, UploadConflict,
)


class FakeClient:
    """Each method pops the next scripted outcome: an exception to raise or a
    value to return. An unscripted call fails the test loudly."""

    def __init__(self, **script):
        self.script = {k: list(v) for k, v in script.items()}
        self.calls: list[tuple] = []

    def count(self, name: str) -> int:
        return sum(1 for c in self.calls if c[0] == name)

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)

        def method(*args, **kwargs):
            self.calls.append((name, args, kwargs))
            outcome = self.script[name].pop(0)
            if isinstance(outcome, BaseException):
                raise outcome
            return outcome

        return method


def make(client, **kwargs):
    sleeps: list[float] = []
    events: list[tuple[str, str]] = []
    transport = DropboxTransport(
        "app-key", "refresh-token", client=client, sleep=sleeps.append,
        observer=lambda event, detail: events.append((event, detail)), **kwargs,
    )
    return transport, sleeps, events


def listing(cursor="c1", has_more=False, entries=()):
    return SimpleNamespace(entries=list(entries), cursor=cursor, has_more=has_more)


def file_meta(path="/SKILL-COLLAB/x.md", size=3):
    now = datetime(2026, 11, 1)
    return files.FileMetadata(
        name=path.rsplit("/", 1)[-1], id="id:abc", client_modified=now, server_modified=now,
        rev="0123456789abc", size=size, path_lower=path.lower(), path_display=path, content_hash="a" * 64,
    )


def rate_limit(backoff=None):
    return dx.RateLimitError("req-1", None, backoff)


# --- rate limit / 5xx / network ------------------------------------------------


def test_rate_limit_is_retried_with_server_backoff_then_recovers():
    client = FakeClient(files_list_folder_continue=[rate_limit(7), rate_limit(None), listing()])
    t, sleeps, events = make(client)
    assert t.list_folder_continue("cur").cursor == "c1"
    assert sleeps == [7.0, 4.0]  # server hint first, then exponential (2 * 2**1)
    kinds = [e for e, _ in events]
    assert kinds == ["API_TRANSIENT_ERROR", "API_TRANSIENT_ERROR", "API_RETRY_RECOVERED"]


def test_rate_limit_retry_is_bounded_not_endless():
    client = FakeClient(files_list_folder_continue=[rate_limit(1)] * 10)
    t, sleeps, events = make(client, max_attempts=3)
    with pytest.raises(TransientTransportError) as info:
        t.list_folder_continue("cur")
    assert info.value.retry_after == 1.0
    assert client.count("files_list_folder_continue") == 3
    assert "API_RETRY_EXHAUSTED" in [e for e, _ in events]


def test_huge_retry_after_is_capped():
    client = FakeClient(files_list_folder_continue=[rate_limit(500), listing()])
    t, sleeps, _ = make(client)
    t.list_folder_continue("cur")
    assert sleeps == [60.0]


@pytest.mark.parametrize("exc", [
    requests.exceptions.ConnectionError("reset"),
    requests.exceptions.ReadTimeout("slow"),
    requests.exceptions.ConnectTimeout("slow"),
    requests.exceptions.ChunkedEncodingError("cut"),
    dx.InternalServerError("req-2", 503, "unavailable"),
    dx.HttpError("req-3", 408, "timeout"),
    OSError("socket"),
])
def test_network_and_server_faults_are_transient_and_recover(exc):
    client = FakeClient(files_list_folder=[exc, listing()])
    t, sleeps, events = make(client)
    assert t.list_folder("/SKILL-COLLAB").entries == []
    assert sleeps == [2.0]
    assert events[-1][0] == "API_RETRY_RECOVERED"


def test_unknown_exception_is_a_permanent_error_and_not_retried():
    client = FakeClient(files_list_folder=[ValueError("bug")])
    t, sleeps, _ = make(client)
    with pytest.raises(TransportError) as info:
        t.list_folder("/SKILL-COLLAB")
    assert not isinstance(info.value, TransientTransportError)
    assert client.count("files_list_folder") == 1 and sleeps == []


# --- authentication ----------------------------------------------------------


@pytest.mark.parametrize("tag", [auth.AuthError.invalid_access_token, auth.AuthError.expired_access_token])
def test_auth_errors_are_auth_required_and_never_retried(tag):
    client = FakeClient(files_list_folder=[dx.AuthError("req-4", tag)])
    t, sleeps, _ = make(client)
    with pytest.raises(AuthRequired):
        t.list_folder("/SKILL-COLLAB")
    assert client.count("files_list_folder") == 1 and sleeps == []


def test_bad_input_during_auth_probe_means_auth_required():
    # A wrong app key makes the token refresh answer 400 invalid_client.
    client = FakeClient(users_get_current_account=[dx.BadInputError("req-5", "invalid_client")])
    t, _, _ = make(client)
    with pytest.raises(AuthRequired):
        t.ensure_auth()


def test_bad_input_elsewhere_is_a_plain_permanent_error():
    client = FakeClient(files_list_folder=[dx.BadInputError("req-6", "malformed path")])
    t, _, _ = make(client)
    with pytest.raises(TransportError) as info:
        t.list_folder("/SKILL-COLLAB")
    assert not isinstance(info.value, (AuthRequired, TransientTransportError))


def test_successful_auth_probe_is_cached_and_failure_clears_the_cache():
    now = [0.0]
    client = FakeClient(users_get_current_account=[SimpleNamespace(), SimpleNamespace(), SimpleNamespace()],
                        files_list_folder=[dx.AuthError("req-7", auth.AuthError.invalid_access_token)])
    sleeps: list[float] = []
    t = DropboxTransport("k", "t", client=client, sleep=sleeps.append, clock=lambda: now[0], auth_cache_sec=900)
    t.ensure_auth()
    now[0] = 100
    t.ensure_auth()
    assert client.count("users_get_current_account") == 1  # served from cache
    with pytest.raises(AuthRequired):
        t.list_folder("/SKILL-COLLAB")
    t.ensure_auth()  # the AuthError dropped the cache -> probes again
    assert client.count("users_get_current_account") == 2
    now[0] = 2000
    t.ensure_auth()  # cache window expired
    assert client.count("users_get_current_account") == 3


def test_missing_credentials_are_auth_required_without_any_client():
    t = DropboxTransport("", "")
    with pytest.raises(AuthRequired):
        t.ensure_auth()


def test_error_text_never_carries_http_body_or_message():
    secret = "SECRET-BODY-abc123"
    for exc in (
        dx.AuthError("req-8", auth.AuthError.invalid_access_token, body=secret),
        dx.BadInputError("req-9", f"refresh_token={secret}"),
        dx.InternalServerError("req-10", 500, secret),
    ):
        assert secret not in summarize_exception(exc)
    client = FakeClient(users_get_current_account=[dx.AuthError("req-8", auth.AuthError.invalid_access_token, body=secret)])
    t, _, _ = make(client)
    with pytest.raises(AuthRequired) as info:
        t.ensure_auth()
    assert secret not in str(info.value)


# --- path / cursor errors ------------------------------------------------------


def test_missing_folder_is_remote_not_found():
    err = dx.ApiError("req-11", files.ListFolderError.path(files.LookupError.not_found), None, None)
    t, _, _ = make(FakeClient(files_list_folder=[err]))
    with pytest.raises(RemoteNotFound):
        t.list_folder("/SKILL-COLLAB/requests/GONE")


def test_get_metadata_not_found_is_none():
    err = dx.ApiError("req-12", files.GetMetadataError.path(files.LookupError.not_found), None, None)
    t, _, _ = make(FakeClient(files_get_metadata=[err]))
    assert t.get_metadata("/SKILL-COLLAB/nope") is None


def test_get_metadata_returns_file_meta_with_id_and_rev():
    t, _, _ = make(FakeClient(files_get_metadata=[file_meta()]))
    meta = t.get_metadata("/SKILL-COLLAB/x.md")
    assert (meta.file_id, meta.rev, meta.size) == ("id:abc", "0123456789abc", 3)


def test_cursor_reset_is_reported_as_cursor_reset():
    err = dx.ApiError("req-13", files.ListFolderContinueError.reset, None, None)
    t, _, _ = make(FakeClient(files_list_folder_continue=[err]))
    with pytest.raises(TransportError, match="CURSOR_RESET"):
        t.list_folder_continue("old")


def test_download_not_found_is_permanent():
    err = dx.ApiError("req-14", files.DownloadError.path(files.LookupError.not_found), None, None)
    t, sleeps, _ = make(FakeClient(files_download=[err]))
    with pytest.raises(TransportError, match="not found") as info:
        t.download("/SKILL-COLLAB/packages/x.zip")
    assert not isinstance(info.value, TransientTransportError) and sleeps == []


def test_download_returns_bytes_and_closes_the_response():
    closed = []
    response = SimpleNamespace(content=b"abc", close=lambda: closed.append(True))
    t, _, _ = make(FakeClient(files_download=[(file_meta(size=3), response)]))
    data, meta = t.download("/SKILL-COLLAB/x.md")
    assert data == b"abc" and meta.size == 3 and closed == [True]


def test_truncated_download_body_is_retried():
    class Broken:
        @property
        def content(self):
            raise requests.exceptions.ChunkedEncodingError("cut")

        def close(self):
            pass

    good = SimpleNamespace(content=b"abc", close=lambda: None)
    t, sleeps, _ = make(FakeClient(files_download=[(file_meta(), Broken()), (file_meta(), good)]))
    assert t.download("/SKILL-COLLAB/x.md")[0] == b"abc"
    assert sleeps == [2.0]


# --- longpoll -------------------------------------------------------------------


def test_longpoll_timeout_is_not_retried_inside_the_transport():
    client = FakeClient(files_list_folder_longpoll=[requests.exceptions.ReadTimeout("held too long")])
    t, sleeps, _ = make(client)
    with pytest.raises(TransientTransportError):
        t.longpoll("cur", 60)
    assert client.count("files_list_folder_longpoll") == 1 and sleeps == []


def test_longpoll_reports_changes_and_clamps_the_timeout():
    client = FakeClient(files_list_folder_longpoll=[
        SimpleNamespace(changes=True, backoff=None), SimpleNamespace(changes=False, backoff=None),
    ])
    t, _, _ = make(client)
    assert t.longpoll("cur", 1) is True
    assert t.longpoll("cur", 9999) is False
    assert [c[2]["timeout"] for c in client.calls] == [30, 480]


def test_longpoll_honours_server_backoff():
    client = FakeClient(files_list_folder_longpoll=[SimpleNamespace(changes=True, backoff=5)])
    t, sleeps, _ = make(client)
    assert t.longpoll("cur", 60) is True
    assert sleeps == [5.0]


def test_longpoll_reset_is_cursor_reset():
    err = dx.ApiError("req-15", files.ListFolderLongpollError.reset, None, None)
    t, _, _ = make(FakeClient(files_list_folder_longpoll=[err]))
    with pytest.raises(TransportError, match="CURSOR_RESET"):
        t.longpoll("old", 60)


# --- shutdown -------------------------------------------------------------------


def test_stop_request_cuts_a_backoff_wait_short():
    stop = threading.Event()
    stop.set()
    client = FakeClient(files_list_folder_continue=[rate_limit(30), listing()])
    t = DropboxTransport("k", "t", client=client, stop_event=stop,
                         observer=lambda *_: None)
    with pytest.raises(TransientTransportError):
        t.list_folder_continue("cur")
    assert client.count("files_list_folder_continue") == 1  # no second attempt after stop


def test_stop_request_is_reported_as_retry_aborted():
    stop = threading.Event()
    stop.set()
    events = []
    t = DropboxTransport("k", "t", client=FakeClient(files_list_folder=[rate_limit(1)]),
                         stop_event=stop, observer=lambda e, d: events.append(e))
    with pytest.raises(TransientTransportError):
        t.list_folder("/SKILL-COLLAB")
    assert "API_RETRY_ABORTED" in events


# --- upload -----------------------------------------------------------------------


def _conflict():
    reason = files.WriteError.conflict(files.WriteConflictError.file)
    return dx.ApiError("req-16", files.UploadError.path(files.UploadWriteFailed(reason=reason, upload_session_id="s")),
                       None, None)


def test_upload_conflict_maps_to_upload_conflict_and_is_not_retried():
    client = FakeClient(files_upload=[_conflict()])
    t, sleeps, _ = make(client)
    with pytest.raises(UploadConflict):
        t.upload("/SKILL-COLLAB/packages/a.zip", b"x", mode="add")
    assert client.count("files_upload") == 1 and sleeps == []


def test_upload_uses_add_mode_without_autorename():
    client = FakeClient(files_upload=[file_meta("/SKILL-COLLAB/packages/a.zip", 1)])
    t, _, _ = make(client)
    meta = t.upload("/SKILL-COLLAB/packages/a.zip", b"x", mode="add")
    kwargs = client.calls[0][2]
    assert kwargs["mode"].is_add() and kwargs["autorename"] is False
    assert meta.file_id == "id:abc"


def test_other_upload_api_error_is_permanent():
    err = dx.ApiError("req-17", files.UploadError.path(
        files.UploadWriteFailed(reason=files.WriteError.insufficient_space, upload_session_id="s")), None, None)
    t, sleeps, _ = make(FakeClient(files_upload=[err]))
    with pytest.raises(TransportError) as info:
        t.upload("/SKILL-COLLAB/packages/a.zip", b"x")
    assert not isinstance(info.value, (UploadConflict, TransientTransportError)) and sleeps == []


# --- SDK configuration --------------------------------------------------------------


def test_real_sdk_client_is_built_with_bounded_retries_and_timeout():
    """The SDK default for 429 is max_retries_on_rate_limit=None: retry forever
    inside an uninterruptible time.sleep. That must stay switched off."""
    t = DropboxTransport("app-key", "refresh-token")
    client = t._client()
    assert client._max_retries_on_rate_limit == 0
    assert client._max_retries_on_error == 0
    assert client._timeout == 60.0
