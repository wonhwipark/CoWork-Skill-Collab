"""Real Ed25519 approval checks with a throwaway key generated per test run.

The key lives only in memory and in a temporary trust-root file that is deleted
at the end of each test. Skipped (= NOT_RUN) when cryptography is not installed
in the environment; the isolated test venv install was not approved in this run.
"""
from __future__ import annotations

import base64
import json
import os
from datetime import datetime, timedelta, timezone

import pytest

cryptography = pytest.importorskip("cryptography")

from cryptography.hazmat.primitives import serialization  # noqa: E402
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey  # noqa: E402

from bundle import KEY_ID, REPO_ID, github_policy, publish_bundle  # noqa: E402
from conftest import make_package_zip  # noqa: E402
from skill_collab_watcher.approval import (  # noqa: E402
    TRUST_ROOT_SCHEMA, ApprovalRejected, canonical, fingerprint_of, load_trust_root, verify_approval,
)
from skill_collab_watcher.signature_backend import Ed25519Backend  # noqa: E402
from skill_collab_watcher.models import JobState  # noqa: E402
from test_phase1_github import has_event, run  # noqa: E402
from fake_github import rp  # noqa: E402


class Signer:
    def __init__(self) -> None:
        self._key = Ed25519PrivateKey.generate()
        raw = self._key.public_key().public_bytes(
            serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        self.key_id = KEY_ID
        self.public_key = base64.b64encode(raw).decode("ascii")
        self.fingerprint = fingerprint_of(self.public_key)

    def sign(self, message: bytes) -> str:
        return base64.b64encode(self._key.sign(message)).decode("ascii")

    def trust_file(self, tmp_path, status: str = "ACTIVE", key_id: str | None = None):
        path = tmp_path / "trust_root.json"
        path.write_text(json.dumps({"schema": TRUST_ROOT_SCHEMA, "repo_id": REPO_ID, "keys": [{
            "key_id": key_id or self.key_id, "algorithm": "ed25519", "public_key": self.public_key,
            "fingerprint": self.fingerprint, "status": status}]}), encoding="utf-8")
        return path


def _policy(tmp_path, signer, status="ACTIVE", key_id=None):
    trust = load_trust_root(str(signer.trust_file(tmp_path, status=status, key_id=key_id)))
    return github_policy(trust_root=trust, signature_backend=Ed25519Backend())


def _dispose(path) -> None:
    os.remove(path)
    assert not os.path.exists(path)


@pytest.fixture
def signer():
    return Signer()


def test_real_valid_signature_dispatches_once(github_env, tmp_path, signer):
    publish_bundle(github_env.http, signer=signer.sign)
    run(github_env, policy=_policy(tmp_path, signer))
    assert github_env.runner.calls == 1


def test_S02_forged_signature_is_rejected(github_env, tmp_path, signer):
    publish_bundle(github_env.http, signer=lambda m: base64.b64encode(b"\x00" * 64).decode())
    run(github_env, policy=_policy(tmp_path, signer))
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_REJECTED", "BAD_SIGNATURE")


def test_S02_payload_edited_after_signing_is_rejected(github_env, tmp_path, signer):
    publish_bundle(github_env.http, signer=signer.sign)
    path = rp("requests/REQ-1/APPROVAL_SIG.json")
    obj = json.loads(github_env.http.files()[path])
    obj["payload"]["nonce"] = "tampered-nonce-0123456789"
    github_env.http.commit({path: json.dumps(obj).encode("utf-8")})
    run(github_env, policy=_policy(tmp_path, signer))
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_REJECTED", "BAD_SIGNATURE")


def test_S03_signed_approval_for_another_repository_is_rejected(github_env, tmp_path, signer):
    publish_bundle(github_env.http, signer=signer.sign, payload_changes={"repo_id": "other-repo"})
    run(github_env, policy=_policy(tmp_path, signer))
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_REJECTED", "REPO_ID_MISMATCH")


def test_S04_signed_but_expired_approval_is_rejected(github_env, tmp_path, signer):
    past = (datetime.now(timezone.utc) - timedelta(minutes=10)).isoformat()
    publish_bundle(github_env.http, signer=signer.sign, payload_changes={"expires_at": past})
    run(github_env, policy=_policy(tmp_path, signer))
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_REJECTED", "APPROVAL_EXPIRED")


def test_S05_signed_source_commit_must_match_the_pin(github_env, tmp_path, signer):
    publish_bundle(github_env.http, signer=signer.sign, pin_commit="f" * 40)
    run(github_env, policy=_policy(tmp_path, signer))
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_REJECTED", "SOURCE_COMMIT_MISMATCH")


def test_S08_retired_key_is_rejected_even_with_a_valid_signature(github_env, tmp_path, signer):
    publish_bundle(github_env.http, signer=signer.sign)
    run(github_env, policy=_policy(tmp_path, signer, status="RETIRED"))
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_REJECTED", "KEY_RETIRED")


def test_S08_rotated_key_id_not_in_the_trust_root_is_rejected(github_env, tmp_path, signer):
    publish_bundle(github_env.http, signer=signer.sign)
    run(github_env, policy=_policy(tmp_path, signer, key_id="key-after-rotation"))
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_REJECTED", "UNKNOWN_KEY_ID")


def test_S09_signed_replay_under_a_new_policy_revision_is_rejected(github_env, tmp_path, signer):
    publish_bundle(github_env.http, signer=signer.sign)
    run(github_env, policy=github_policy(
        local_policy_revision="2", trust_root=load_trust_root(str(signer.trust_file(tmp_path))),
        signature_backend=Ed25519Backend()))
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_REJECTED", "BINDING_MISMATCH:local_policy_revision")


def test_S10_partial_real_bundle_waits_without_model_call(github_env, tmp_path, signer):
    publish_bundle(github_env.http, signer=signer.sign, omit=("pin",))
    run(github_env, policy=_policy(tmp_path, signer))
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_MISSING")


def test_S01_real_approval_with_an_empty_signature_is_rejected(github_env, tmp_path, signer):
    publish_bundle(github_env.http, signer=signer.sign, signature="")
    run(github_env, policy=_policy(tmp_path, signer))
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_REJECTED", "MISSING_SIGNATURE")


def test_S06_real_signature_over_other_request_bytes_is_rejected(github_env, tmp_path, signer):
    publish_bundle(github_env.http, signer=signer.sign, payload_changes={"request_sha256": "0" * 64})
    run(github_env, policy=_policy(tmp_path, signer))
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_REJECTED", "BINDING_MISMATCH:request_sha256")


def test_S07_real_signature_over_another_package_is_rejected(github_env, tmp_path, signer):
    publish_bundle(github_env.http, signer=signer.sign, payload_changes={"package_sha256": "1" * 64})
    run(github_env, policy=_policy(tmp_path, signer))
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_REJECTED", "BINDING_MISMATCH:package_sha256")


def test_S09_real_approval_replayed_after_completion_never_redispatches(github_env, tmp_path, signer):
    publish_bundle(github_env.http, signer=signer.sign)
    policy = _policy(tmp_path, signer)
    run(github_env, policy=policy)
    run(github_env, policy=policy)
    github_env.store.close()
    from skill_collab_watcher.state_store import StateStore
    github_env.store = StateStore(github_env.tmp / "state.sqlite3")
    run(github_env, policy=policy)
    assert github_env.runner.calls == 1


def _two_key_trust(tmp_path, old, new, old_status):
    path = tmp_path / "rotated_trust.json"
    keys = [{"key_id": "key-old", "public_key": old.public_key, "fingerprint": old.fingerprint,
             "status": old_status},
            {"key_id": "key-new", "public_key": new.public_key, "fingerprint": new.fingerprint,
             "status": "ACTIVE"}]
    path.write_text(json.dumps({"schema": TRUST_ROOT_SCHEMA, "repo_id": REPO_ID, "keys": keys}), encoding="utf-8")
    return load_trust_root(str(path))


def test_S08_after_rotation_the_new_key_works_and_the_retired_key_does_not(github_env, tmp_path):
    old, new = Signer(), Signer()
    trust = _two_key_trust(tmp_path, old, new, "RETIRED")
    policy = github_policy(trust_root=trust, signature_backend=Ed25519Backend())
    package = make_package_zip("shared")
    publish_bundle(github_env.http, "REQ-1", key_id="key-old", signer=old.sign, package=package)
    publish_bundle(github_env.http, "REQ-2", key_id="key-new", signer=new.sign, package=package)
    run(github_env, policy=policy)
    assert github_env.runner.calls == 1
    assert has_event(github_env.store, "APPROVAL_REJECTED", "KEY_RETIRED")


def test_S08_signature_made_by_a_different_key_under_the_same_id_is_rejected(github_env, tmp_path, signer):
    impostor = Signer()
    publish_bundle(github_env.http, signer=impostor.sign)
    run(github_env, policy=_policy(tmp_path, signer))
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_REJECTED", "BAD_SIGNATURE")


def test_S04_real_clock_skew_edges(signer, tmp_path):
    now = datetime.now(timezone.utc)
    trust = load_trust_root(str(signer.trust_file(tmp_path)))

    def make(issued_delta):
        payload = {"schema": "SKILL_COLLAB_APPROVAL_PAYLOAD_V1", "repo_id": REPO_ID, "source_commit": "c" * 40,
                   "nonce": "n" * 24, "issued_at": (now + issued_delta).isoformat(),
                   "expires_at": (now + timedelta(hours=2)).isoformat()}
        approval = json.dumps({"schema": "SKILL_COLLAB_APPROVAL_SIG_V1", "key_id": KEY_ID, "payload": payload,
                               "signature": signer.sign(canonical(payload))}).encode()
        pin = json.dumps({"schema": "SKILL_COLLAB_SOURCE_PIN_V1", "repo_id": REPO_ID,
                          "commit": "c" * 40}).encode()
        return approval, pin

    approval, pin = make(timedelta(minutes=4))
    verify_approval(approval, pin, trust=trust, backend=Ed25519Backend(), expected={}, now=now)
    approval, pin = make(timedelta(minutes=6))
    with pytest.raises(ApprovalRejected, match="APPROVAL_NOT_YET_VALID"):
        verify_approval(approval, pin, trust=trust, backend=Ed25519Backend(), expected={}, now=now)


def test_invalid_base64_signature_is_a_plain_rejection_not_a_crash(signer):
    backend = Ed25519Backend()
    assert backend.verify(signer.public_key, b"message", "%%% not base64 %%%") is False
    assert backend.verify("AAAA", b"message", base64.b64encode(b"\x00" * 64).decode()) is False


def test_verify_approval_with_real_key_and_clock(signer, tmp_path):
    now = datetime.now(timezone.utc)
    payload = {"schema": "SKILL_COLLAB_APPROVAL_PAYLOAD_V1", "repo_id": REPO_ID, "source_commit": "c" * 40,
               "nonce": "n" * 24, "issued_at": (now - timedelta(hours=1)).isoformat(),
               "expires_at": (now + timedelta(hours=1)).isoformat()}
    approval = json.dumps({"schema": "SKILL_COLLAB_APPROVAL_SIG_V1", "key_id": KEY_ID,
                           "payload": payload, "signature": signer.sign(canonical(payload))}).encode()
    pin = json.dumps({"schema": "SKILL_COLLAB_SOURCE_PIN_V1", "repo_id": REPO_ID, "commit": "c" * 40}).encode()
    trust = load_trust_root(str(signer.trust_file(tmp_path)))
    assert verify_approval(approval, pin, trust=trust, backend=Ed25519Backend(), expected={}, now=now)["nonce"]
    with pytest.raises(ApprovalRejected):
        verify_approval(approval, pin, trust=trust, backend=Ed25519Backend(), expected={},
                        now=now + timedelta(hours=2))
    _dispose(tmp_path / "trust_root.json")
