"""Pre-cutover gates: B-7 trust-root lifecycle, clock trust, SHADOW isolation.
Synthetic data and test-double signatures only; no network, no model."""
from __future__ import annotations

import base64
import hashlib
import json
import sys
from datetime import datetime, timedelta, timezone

import pytest

from bundle import KEY_ID, PUBLIC, REPO_ID, TRUST, DoubleBackend, github_policy, publish_bundle
from conftest import make_package_zip
from fake_github import FakeGitHub
from skill_collab_watcher import cli
from skill_collab_watcher.approval import (
    TRUST_ROOT_SCHEMA, ClockUntrusted, TrustedKey, TrustRoot, TrustRootError, check_clock,
    check_trust_root_acl, load_trust_root, parse_http_date, sddl_write_findings,
)
from skill_collab_watcher.config import Config
from skill_collab_watcher.models import JobState
from skill_collab_watcher.orchestrator import run_scan_cycle
from skill_collab_watcher.state_store import StateStore
from test_phase1_github import has_event, run

@pytest.fixture(autouse=True)
def _independent_trust_root_by_default(monkeypatch):
    """These tests are about pin, version and ACL rules. Whether the watcher's own account can change the
    trust root (S-2) has its own tests in test_phase5_independence; here the answer is 'no'."""
    monkeypatch.setattr(cli, "watcher_write_findings", lambda _items: [])


PUB_B64 = base64.b64encode(bytes(range(32))).decode()
FP = hashlib.sha256(bytes(range(32))).hexdigest()


def trust_file(tmp_path, **overrides):
    obj = {"schema": TRUST_ROOT_SCHEMA, "repo_id": REPO_ID, "version": 1, "keys": [
        {"key_id": "k1", "public_key": PUB_B64, "fingerprint": FP, "status": "ACTIVE"}]}
    obj.update(overrides)
    path = tmp_path / "trust_root.json"
    path.write_text(json.dumps(obj), encoding="utf-8")
    return path


# --- trust root file: pin, content, versions --------------------------------------------

def test_B7_v1_file_without_the_new_fields_still_loads_with_safe_defaults(tmp_path):
    root = load_trust_root(str(trust_file(tmp_path)))
    assert (root.version, root.frozen, root.max_approval_lifetime_sec) == (1, False, 86400)
    assert root.keys["k1"].purpose == "review-approval"


def test_B7_pin_must_match_the_exact_file_bytes(tmp_path):
    path = trust_file(tmp_path)
    good = hashlib.sha256(path.read_bytes()).hexdigest()
    assert load_trust_root(str(path), expected_sha256=good.upper()).version == 1
    with pytest.raises(TrustRootError, match="PIN_MISMATCH"):
        load_trust_root(str(path), expected_sha256="0" * 64)
    path.write_text(path.read_text(encoding="utf-8") + " ", encoding="utf-8")
    with pytest.raises(TrustRootError, match="PIN_MISMATCH"):
        load_trust_root(str(path), expected_sha256=good)


@pytest.mark.parametrize("mutation, message", [
    ({"keys": [{"key_id": "k1", "public_key": PUB_B64, "fingerprint": FP, "status": "MAYBE"}]}, "unknown key status"),
    ({"keys": [{"key_id": "k1", "public_key": PUB_B64, "fingerprint": "0" * 64, "status": "ACTIVE"}]}, "fingerprint"),
    ({"keys": [{"key_id": "k1", "public_key": "AAAA", "fingerprint": FP, "status": "ACTIVE"}]}, "malformed"),
    ({"keys": [{"key_id": "k1", "public_key": PUB_B64, "fingerprint": FP, "status": "ACTIVE"}] * 2}, "duplicate"),
    ({"version": 0}, "version"),
    ({"version": True}, "version"),
    ({"max_approval_lifetime_sec": 10}, "max_approval_lifetime_sec"),
    ({"max_approval_lifetime_sec": 10**9}, "max_approval_lifetime_sec"),
    ({"schema": "OTHER"}, "schema"),
    ({"keys": [{"key_id": "k1", "public_key": PUB_B64, "fingerprint": FP, "status": "ACTIVE",
                "not_before": "2026-01-01T00:00:00"}]}, "timezone"),
])
def test_B7_every_defect_in_the_trust_root_is_refused_not_partially_loaded(tmp_path, mutation, message):
    with pytest.raises(TrustRootError, match=message):
        load_trust_root(str(trust_file(tmp_path, **mutation)))


def test_B7_missing_or_garbage_files_are_refused(tmp_path):
    with pytest.raises(TrustRootError, match="UNREADABLE"):
        load_trust_root(str(tmp_path / "missing.json"))
    bad = tmp_path / "bad.json"
    bad.write_bytes(b"\xff\xfe not json")
    with pytest.raises(TrustRootError, match="NOT_JSON"):
        load_trust_root(str(bad))
    assert load_trust_root(None) is None


def test_B7_version_is_a_ratchet_a_lower_version_is_a_rollback(tmp_path):
    store = StateStore(tmp_path / "s.sqlite3")
    store.check_trust_version(3)
    store.check_trust_version(3)
    store.check_trust_version(4)
    with pytest.raises(TrustRootError, match="ROLLBACK"):
        store.check_trust_version(3)
    assert store.get_counter("trust_root_version") == 4
    store.close()


def test_B7_read_only_store_compares_but_never_records_the_version(tmp_path):
    rw = StateStore(tmp_path / "s.sqlite3")
    rw.check_trust_version(5)
    rw.close()
    ro = StateStore(tmp_path / "s.sqlite3", read_only=True)
    ro.check_trust_version(6)
    with pytest.raises(TrustRootError):
        ro.check_trust_version(4)
    assert ro.get_counter("trust_root_version") == 5
    ro.close()


# --- approvals against the lifecycle rules ------------------------------------------------

def _policy_with(**key_fields):
    key = TrustedKey(key_id=KEY_ID, public_key=PUBLIC, fingerprint="x" * 64, status="ACTIVE", **key_fields)
    return github_policy(trust_root=TrustRoot(repo_id=REPO_ID, keys={KEY_ID: key}))


def _reject(github_env, detail, policy=None, **bundle):
    publish_bundle(github_env.http, **bundle)
    run(github_env, policy=policy)
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_REJECTED", detail)


def test_B7_revoked_key_is_rejected_with_its_own_reason(github_env):
    key = TrustedKey(key_id=KEY_ID, public_key=PUBLIC, fingerprint="x" * 64, status="REVOKED")
    _reject(github_env, "KEY_REVOKED", policy=github_policy(trust_root=TrustRoot(REPO_ID, {KEY_ID: key})))


def test_B7_frozen_trust_root_rejects_everything_without_touching_keys(github_env):
    key = TrustedKey(key_id=KEY_ID, public_key=PUBLIC, fingerprint="x" * 64, status="ACTIVE")
    _reject(github_env, "TRUST_ROOT_FROZEN",
            policy=github_policy(trust_root=TrustRoot(REPO_ID, {KEY_ID: key}, frozen=True)))


def test_B7_key_for_another_purpose_is_rejected(github_env):
    _reject(github_env, "KEY_WRONG_PURPOSE", policy=_policy_with(purpose="release-signing"))


def test_B7_approval_issued_before_the_key_window_or_after_it_is_rejected(github_env):
    _reject(github_env, "KEY_NOT_YET_VALID", policy=_policy_with(
        not_before=(datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()))


def test_B7_key_past_its_not_after_is_rejected(github_env):
    _reject(github_env, "KEY_EXPIRED", policy=_policy_with(
        not_after=(datetime.now(timezone.utc) - timedelta(hours=2)).isoformat()))


def test_B7_approvals_cannot_outlive_the_trust_roots_lifetime_cap(github_env):
    far = (datetime.now(timezone.utc) + timedelta(days=3)).isoformat()
    _reject(github_env, "APPROVAL_LIFETIME_TOO_LONG", payload_changes={"expires_at": far})


def test_B7_a_lower_lifetime_cap_in_the_trust_root_applies(github_env):
    key = TrustedKey(key_id=KEY_ID, public_key=PUBLIC, fingerprint="x" * 64, status="ACTIVE")
    short = github_policy(trust_root=TrustRoot(REPO_ID, {KEY_ID: key}, max_approval_lifetime_sec=600))
    _reject(github_env, "APPROVAL_LIFETIME_TOO_LONG", policy=short)


# --- ACL parser --------------------------------------------------------------------------

SAFE_SDDL = "O:BAG:SYD:PAI(A;;FA;;;BA)(A;;FA;;;SY)(A;;0x1200a9;;;BU)(A;;FR;;;WD)"


def test_B7_read_only_access_for_broad_groups_is_acceptable():
    assert sddl_write_findings(SAFE_SDDL) == []


@pytest.mark.parametrize("ace", [
    "(A;;FA;;;WD)", "(A;;GW;;;AU)", "(A;;0x1301bf;;;BU)", "(A;;FW;;;S-1-5-21-1-2-3-513)",
    "(A;;GA;;;IU)", "(A;;WD;;;BU)", "(A;OICI;FA;;;S-1-1-0)",
])
def test_B7_write_like_rights_for_broad_groups_are_findings(ace):
    assert len(sddl_write_findings(SAFE_SDDL + ace)) == 1


@pytest.mark.parametrize("ace", ["(D;;FA;;;WD)", "(A;;FW;;;S-1-5-21-1-2-3-512)", "(A;;FR;;;AU)", "(A;;FX;;;BU)"])
def test_B7_deny_entries_and_non_broad_or_read_only_entries_are_not_findings(ace):
    assert sddl_write_findings(SAFE_SDDL + ace) == []


def test_B7_a_null_dacl_is_a_finding():
    assert sddl_write_findings("O:BAD:NO_ACCESS_CONTROL")


def test_B7_unreadable_permissions_are_a_finding_not_a_pass():
    def boom(_path):
        raise OSError("denied")

    assert check_trust_root_acl("x", read_sddl=boom) == ["the file permissions could not be read"]


@pytest.mark.skipif(sys.platform != "win32", reason="Windows security descriptors")
def test_B7_the_real_windows_api_reads_a_real_files_permissions(tmp_path):
    path = trust_file(tmp_path)
    from skill_collab_watcher.approval import _read_sddl
    assert _read_sddl(str(path)).startswith("D:")
    assert check_trust_root_acl(str(path)) == []


# --- clock trust --------------------------------------------------------------------------

def test_B7_check_clock_boundaries():
    now = datetime.now(timezone.utc)
    check_clock(now + timedelta(minutes=4), now)
    with pytest.raises(ClockUntrusted):
        check_clock(now + timedelta(minutes=6), now)
    with pytest.raises(ClockUntrusted):
        check_clock(now - timedelta(minutes=6), now)
    with pytest.raises(ClockUntrusted, match="unavailable"):
        check_clock(None, now)


def test_B7_http_date_parsing_is_defensive():
    assert parse_http_date("Tue, 10 Nov 2026 01:02:03 GMT").year == 2026
    assert parse_http_date("garbage") is None
    assert parse_http_date(None) is None


def test_B7_a_provider_clock_far_from_local_blocks_dispatch(github_env):
    github_env.http.clock_offset_sec = 900
    publish_bundle(github_env.http)
    run(github_env)
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_CLOCK_UNTRUSTED", "differs")


def test_B7_missing_provider_time_blocks_dispatch(github_env):
    github_env.http.send_date = False
    publish_bundle(github_env.http)
    run(github_env)
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_CLOCK_UNTRUSTED", "unavailable")


def test_B7_a_sane_clock_still_dispatches(github_env):
    publish_bundle(github_env.http)
    run(github_env)
    assert github_env.runner.calls == 1


# --- CLI integration: trust loading and SHADOW isolation ------------------------------------

def make_config(tmp_path, **github):
    state = tmp_path / "state"
    state.mkdir(exist_ok=True)
    token = tmp_path / "token.txt"
    token.write_text("synthetic-token-not-real", encoding="utf-8")
    raw = {"schema_version": 1, "baseline_id": "B", "transport": "github", "local_state_dir": str(state),
           "provider_mode": github.pop("provider_mode", "LIVE"),
           "review_policy": {"enabled": True, "dry_run": False, "known_run_policy_refs": ["POLICY-STATIC-V1"]},
           "github": {"repo": "owner/private-repo", "token_file": str(token), **github}}
    if raw["provider_mode"] == "SHADOW":
        raw["shadow"] = {"state_dir": str(tmp_path / "shadow-state")}
    path = tmp_path / "config.json"
    path.write_text(json.dumps(raw), encoding="utf-8")
    return Config.load(path)


def open_rt(cfg):
    import threading
    return cli._open_runtime(cfg, None, threading.Event())


def events_of(rt):
    return [(e, d or "") for _t, e, _k, d in rt.store.recent_events(50)]


def test_B7_live_without_a_pin_refuses_the_trust_root(tmp_path, monkeypatch):
    monkeypatch.setattr(cli, "check_trust_root_acl", lambda _p: [])
    rt = open_rt(make_config(tmp_path, trust_root_file=str(trust_file(tmp_path))))
    assert rt.policy.trust_root is None
    assert any(e == "TRUST_ROOT_REFUSED" and "NOT_PINNED" in d for e, d in events_of(rt))
    rt.close()


def test_B7_live_with_a_wrong_pin_refuses_the_trust_root(tmp_path, monkeypatch):
    monkeypatch.setattr(cli, "check_trust_root_acl", lambda _p: [])
    rt = open_rt(make_config(tmp_path, trust_root_file=str(trust_file(tmp_path)), trust_root_sha256="0" * 64))
    assert rt.policy.trust_root is None
    assert any(e == "TRUST_ROOT_REFUSED" and "PIN_MISMATCH" in d for e, d in events_of(rt))
    rt.close()


def test_B7_live_with_a_pinned_clean_root_loads_and_records_the_version(tmp_path, monkeypatch):
    monkeypatch.setattr(cli, "check_trust_root_acl", lambda _p: [])
    path = trust_file(tmp_path, version=7)
    rt = open_rt(make_config(tmp_path, trust_root_file=str(path),
                             trust_root_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    assert rt.policy.trust_root.version == 7 and rt.policy.require_approval
    assert rt.store.get_counter("trust_root_version") == 7
    rt.close()


def test_B7_a_writable_trust_root_file_is_refused(tmp_path, monkeypatch):
    monkeypatch.setattr(cli, "check_trust_root_acl", lambda _p: ["Everyone has write access"])
    path = trust_file(tmp_path)
    rt = open_rt(make_config(tmp_path, trust_root_file=str(path),
                             trust_root_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    assert rt.policy.trust_root is None
    assert any(e == "TRUST_ROOT_REFUSED" and "ACL" in d for e, d in events_of(rt))
    rt.close()


def test_B7_a_restored_older_trust_root_is_refused_after_a_newer_one_was_accepted(tmp_path, monkeypatch):
    monkeypatch.setattr(cli, "check_trust_root_acl", lambda _p: [])
    cfg_kwargs = {}
    new = trust_file(tmp_path, version=3)
    cfg = make_config(tmp_path, trust_root_file=str(new), trust_root_sha256=hashlib.sha256(new.read_bytes()).hexdigest())
    open_rt(cfg).close()
    old = trust_file(tmp_path, version=2)
    cfg = make_config(tmp_path, trust_root_file=str(old), trust_root_sha256=hashlib.sha256(old.read_bytes()).hexdigest())
    rt = open_rt(cfg)
    assert rt.policy.trust_root is None
    assert any(e == "TRUST_ROOT_REFUSED" and "ROLLBACK" in d for e, d in events_of(rt))
    rt.close()


def test_B7_no_trust_root_configured_means_approvals_cannot_verify(github_env):
    publish_bundle(github_env.http)
    run(github_env, policy=github_policy(trust_root=None))
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_UNVERIFIABLE")


def _digests(directory):
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(directory.glob("state.sqlite3*"))}


