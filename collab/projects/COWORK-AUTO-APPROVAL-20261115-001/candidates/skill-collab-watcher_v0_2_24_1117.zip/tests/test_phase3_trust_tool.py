"""The operator trust-root tool: public keys only, never overwrites, output loads exactly as the watcher does."""
from __future__ import annotations

import base64
import hashlib
import json

import pytest

from skill_collab_watcher.approval import load_trust_root
from tools import trust_root_tool

PUB = base64.b64encode(bytes(range(32))).decode()
PUB2 = base64.b64encode(bytes(range(1, 33))).decode()


def build(tmp_path, *extra, version="1"):
    out = tmp_path / "root.json"
    rc = trust_root_tool.main(["build", "--repo-id", "repo-1", "--out", str(out), "--version", version,
                               "--key", f"k1:{PUB}", *extra])
    return rc, out


def test_build_writes_a_file_the_watcher_loads_and_prints_its_pin(tmp_path, capsys):
    rc, out = build(tmp_path)
    assert rc == 0
    printed = capsys.readouterr().out
    pin = hashlib.sha256(out.read_bytes()).hexdigest()
    assert pin in printed
    root = load_trust_root(str(out), expected_sha256=pin)
    assert root.version == 1 and root.keys["k1"].status == "ACTIVE"


def test_build_supports_rotation_with_a_retired_and_a_new_key(tmp_path):
    out = tmp_path / "root.json"
    assert trust_root_tool.main(["build", "--repo-id", "r", "--out", str(out), "--version", "2",
                                 "--key", f"old:{PUB}:RETIRED", "--key", f"new:{PUB2}"]) == 0
    root = load_trust_root(str(out))
    assert {k: v.status for k, v in root.keys.items()} == {"old": "RETIRED", "new": "ACTIVE"}


def test_build_can_write_a_frozen_root_for_an_incident(tmp_path):
    rc, out = build(tmp_path, "--frozen", version="9")
    assert rc == 0 and load_trust_root(str(out)).frozen is True


def test_build_never_overwrites_an_existing_trust_root(tmp_path, capsys):
    rc, out = build(tmp_path)
    before = out.read_bytes()
    rc2, _ = build(tmp_path, version="2")
    assert rc2 == 2 and out.read_bytes() == before
    assert "higher version" in capsys.readouterr().err


@pytest.mark.parametrize("spec", ["k1", "k1:not-base64!!", f"k1:{PUB}:BOGUS", "k1:AAAA"])
def test_build_refuses_malformed_keys(tmp_path, spec, capsys):
    out = tmp_path / "root.json"
    rc = trust_root_tool.main(["build", "--repo-id", "r", "--out", str(out), "--version", "1", "--key", spec])
    assert rc == 2 and not out.exists()


def test_build_refuses_a_nonsense_version_and_leaves_no_file(tmp_path):
    rc, out = build(tmp_path, version="0")
    assert rc == 2 and not out.exists()


def test_inspect_reports_pin_mismatch_and_valid_files(tmp_path, capsys):
    rc, out = build(tmp_path)
    capsys.readouterr()
    assert trust_root_tool.main(["inspect", str(out), "--pin", "0" * 64]) == 1
    assert "PIN_MISMATCH" in capsys.readouterr().out
    assert trust_root_tool.main(["inspect", str(out)]) in (0, 1)
    text = capsys.readouterr().out
    assert "version=1" in text and "key k1: status=ACTIVE" in text


def test_the_tool_never_touches_private_key_material():
    source = open(trust_root_tool.__file__, encoding="utf-8").read().lower()
    assert "private" not in source.replace("neither command creates, reads or stores a private key or a token", "")
    assert "generate(" not in source and "sign(" not in source
