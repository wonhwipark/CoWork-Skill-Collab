"""Covers the scenario table in WATCHER_IMPLEMENT_PROMPT_r0001.md section 10.

Every test here uses MockTransport + FakeReviewRunner. FakeReviewRunner
never imports subprocess or touches claude_exe - `runner.calls` and the
store's `review_dispatch_count`/`claude_process_start_count` counters are
the audit evidence that zero additional review processes were started.
"""
from __future__ import annotations

import hashlib

from skill_collab_watcher.models import JobState
from skill_collab_watcher.orchestrator import run_scan_cycle
from skill_collab_watcher.transport_base import TransportError

from conftest import REMOTE_ROOT, push_valid_request, ready_md, request_md


def _scan(transport, store, policy, runner, allowed=True):
    return run_scan_cycle(
        transport, store, policy, runner, allowed,
        snapshot_root=_tmp_dir(store), review_run_dir=_tmp_dir(store), remote_root=REMOTE_ROOT,
    )


def _tmp_dir(store):
    # state_store fixture puts the sqlite file at tmp_path/state.sqlite3;
    # reuse the same parent for scratch snapshot/run dirs.
    from pathlib import Path
    p = Path(store.conn.execute("PRAGMA database_list").fetchall()[0][2]).parent
    return p


def test_1000_empty_cycles_zero_dispatch(transport, store, policy, runner):
    for _ in range(1000):
        _scan(transport, store, policy, runner, allowed=True)
    assert runner.calls == 0
    assert store.get_counter("review_dispatch_count") == 0
    assert store.get_counter("claude_process_start_count") == 0


def test_zip_only_no_request_zero_dispatch(transport, store, policy, runner):
    transport.push_file("/SKILL-COLLAB/packages/test.zip", b"PK\x03\x04fakezip")
    _scan(transport, store, policy, runner)
    assert runner.calls == 0


def test_request_only_no_ready_wait_input(transport, store, policy, runner):
    req_text = request_md(package_sha256="a" * 64, package_size=10)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/REQUEST.md", req_text.encode("utf-8"))
    _scan(transport, store, policy, runner)
    assert runner.calls == 0
    events = [e[1] for e in store.recent_events(50)]
    assert "WAIT_INPUT" in events


def test_template_draft_example_rejected(transport, store, policy, runner):
    req_text = request_md(state="DRAFT_EXAMPLE", package_sha256="a" * 64, package_size=10)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/REQUEST.md", req_text.encode("utf-8"))
    ready_text = ready_md("b" * 64, "a" * 64)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/READY.md", ready_text.encode("utf-8"))
    _scan(transport, store, policy, runner)
    assert runner.calls == 0
    events = [e[1] for e in store.recent_events(50)]
    assert "REJECTED" in events


def test_unknown_placeholder_fields_rejected(transport, store, policy, runner):
    req_text = request_md(package_sha256="UNKNOWN", package_size=10)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/REQUEST.md", req_text.encode("utf-8"))
    _scan(transport, store, policy, runner)
    assert runner.calls == 0


def test_ready_arrives_before_request_zero_dispatch(transport, store, policy, runner):
    ready_text = ready_md("a" * 64, "b" * 64)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/READY.md", ready_text.encode("utf-8"))
    _scan(transport, store, policy, runner)
    assert runner.calls == 0
    events = [e[1] for e in store.recent_events(50)]
    assert "WAIT_INPUT" in events


def test_package_size_sha_mismatch_conflict(transport, store, policy, runner):
    package = b"real-bytes"
    wrong_sha = hashlib.sha256(b"different-bytes").hexdigest()
    req_text = request_md(package_sha256=wrong_sha, package_size=len(package))
    req_sha = hashlib.sha256(req_text.encode("utf-8")).hexdigest()
    ready_text = ready_md(req_sha, wrong_sha)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/REQUEST.md", req_text.encode("utf-8"))
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/READY.md", ready_text.encode("utf-8"))
    transport.push_file("/SKILL-COLLAB/packages/test.zip", package)
    _scan(transport, store, policy, runner)
    assert runner.calls == 0
    events = [e[1] for e in store.recent_events(50)]
    assert "CONFLICT" in events


def test_request_revision_mismatch_between_ready_and_request_conflict(transport, store, policy, runner):
    package = b"bytes"
    sha = hashlib.sha256(package).hexdigest()
    req_text = request_md(request_revision=2, package_sha256=sha, package_size=len(package))
    req_sha = hashlib.sha256(req_text.encode("utf-8")).hexdigest()
    ready_text = ready_md(req_sha, sha, request_revision=1)  # mismatched revision
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/REQUEST.md", req_text.encode("utf-8"))
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/READY.md", ready_text.encode("utf-8"))
    transport.push_file("/SKILL-COLLAB/packages/test.zip", package)
    _scan(transport, store, policy, runner)
    assert runner.calls == 0


def test_stale_baseline_conflict(transport, store, policy, runner):
    package = b"bytes"
    sha = hashlib.sha256(package).hexdigest()
    req_text = request_md(package_sha256=sha, package_size=len(package))
    req_sha = hashlib.sha256(req_text.encode("utf-8")).hexdigest()
    ready_text = ready_md(req_sha, sha, baseline_id="SOME-OLD-BASELINE")
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/REQUEST.md", req_text.encode("utf-8"))
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/READY.md", ready_text.encode("utf-8"))
    transport.push_file("/SKILL-COLLAB/packages/test.zip", package)
    _scan(transport, store, policy, runner)
    assert runner.calls == 0
    events = [e[1] for e in store.recent_events(50)]
    assert "CONFLICT" in events


def test_unregistered_run_policy_ref_rejected(transport, store, policy, runner):
    package = b"bytes"
    sha = hashlib.sha256(package).hexdigest()
    req_text = request_md(package_sha256=sha, package_size=len(package), run_policy_ref="NOT-REGISTERED")
    req_sha = hashlib.sha256(req_text.encode("utf-8")).hexdigest()
    ready_text = ready_md(req_sha, sha)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/REQUEST.md", req_text.encode("utf-8"))
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/READY.md", ready_text.encode("utf-8"))
    transport.push_file("/SKILL-COLLAB/packages/test.zip", package)
    _scan(transport, store, policy, runner)
    assert runner.calls == 0


def test_unapproved_knowledge_ref_path_rejected(transport, store, policy, runner):
    package = b"bytes"
    sha = hashlib.sha256(package).hexdigest()
    refs = '[{path: "/SKILL-COLLAB/packages/not-knowledge.md", revision: r1, sha256: "' + "c" * 64 + '"}]'
    req_text = request_md(package_sha256=sha, package_size=len(package), knowledge_refs_yaml=refs)
    req_sha = hashlib.sha256(req_text.encode("utf-8")).hexdigest()
    ready_text = ready_md(req_sha, sha)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/REQUEST.md", req_text.encode("utf-8"))
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/READY.md", ready_text.encode("utf-8"))
    transport.push_file("/SKILL-COLLAB/packages/test.zip", package)
    _scan(transport, store, policy, runner)
    assert runner.calls == 0


def test_dry_run_or_off_blocks_valid_request(transport, store, policy, runner):
    push_valid_request(transport)
    _scan(transport, store, policy, runner, allowed=False)
    assert runner.calls == 0
    events = [e[1] for e in store.recent_events(50)]
    assert "DISPATCH_SKIPPED_NOT_ALLOWED" in events
    # still VALIDATED, not dispatched - allowing it later should dispatch exactly once
    _scan(transport, store, policy, runner, allowed=True)
    assert runner.calls == 1


def test_one_valid_new_request_dispatches_exactly_once(transport, store, policy, runner):
    push_valid_request(transport)
    summary = _scan(transport, store, policy, runner, allowed=True)
    assert runner.calls == 1
    assert summary.dispatched == 1
    assert store.get_counter("review_dispatch_count") == 1
    assert store.get_counter("claude_process_start_count") == 0  # FakeReviewRunner reports 0 real model_calls


def test_duplicate_redelivery_and_relisting_after_completion_zero_extra(transport, store, policy, runner):
    push_valid_request(transport)
    _scan(transport, store, policy, runner, allowed=True)
    assert runner.calls == 1
    # simulate: duplicate event, re-listing (cursor continue), restart (new scan)
    for _ in range(5):
        _scan(transport, store, policy, runner, allowed=True)
    assert runner.calls == 1


def test_upload_failure_then_retry_never_recalls_runner(transport, store, policy, runner):
    push_valid_request(transport)

    original_upload = transport.upload

    def failing_upload(path, data, mode="add"):
        if "/dispatch/" in path:
            return original_upload(path, data, mode)      # the reservation must succeed, or no model starts at all
        raise TransportError("simulated upload failure")

    transport.upload = failing_upload
    _scan(transport, store, policy, runner, allowed=True)
    assert runner.calls == 1  # review ran once
    events = [e[1] for e in store.recent_events(50)]
    assert "UPLOAD_FAILED" in events

    transport.upload = original_upload
    _scan(transport, store, policy, runner, allowed=True)
    assert runner.calls == 1  # still 1 - only the publish was retried
    events = [e[1] for e in store.recent_events(50)]
    assert "UPLOAD_RETRY_COMPLETED" in events


def test_crash_during_review_marks_uncertain_and_does_not_retry(transport, store, policy, runner):
    from skill_collab_watcher.models import ReviewResult

    class TimeoutRunner:
        def __init__(self):
            self.calls = 0

        def run(self, snapshot_dir, prompt_text, run_dir, max_budget_usd=None, effort=None):
            self.calls += 1
            return ReviewResult(ok=False, output_text="", output_format="json", exit_code=-1,
                                 model_calls=1, usage=None, error="timeout after 1800s")

    uncertain_runner = TimeoutRunner()
    push_valid_request(transport)
    _scan(transport, store, policy, uncertain_runner, allowed=True)
    assert uncertain_runner.calls == 1
    jobs = store.jobs_in_states([JobState.REVIEW_UNCERTAIN])
    assert len(jobs) == 1

    # restart / re-scan must not start a second review process for an uncertain job.
    _scan(transport, store, policy, uncertain_runner, allowed=True)
    assert uncertain_runner.calls == 1


def test_auth_expired_zero_dispatch(transport, store, policy, runner):
    push_valid_request(transport)
    transport.set_auth_ok(False)
    summary = _scan(transport, store, policy, runner, allowed=True)
    assert summary.note == "AUTH_REQUIRED"
    assert runner.calls == 0


def test_network_error_zero_dispatch(transport, store, policy, runner):
    push_valid_request(transport)
    transport.raise_network_error_once(TransportError("simulated 429"))
    summary = _scan(transport, store, policy, runner, allowed=True)
    assert summary.note == "TRANSPORT_ERROR"
    assert runner.calls == 0


def test_unrelated_knowledge_md_change_zero_dispatch(transport, store, policy, runner):
    transport.push_file("/SKILL-COLLAB/knowledge/SOME_DOC_r0003.md", b"unrelated content change")
    _scan(transport, store, policy, runner, allowed=True)
    assert runner.calls == 0


def test_cursor_reset_relists_without_double_dispatch(transport, store, policy, runner):
    push_valid_request(transport)
    _scan(transport, store, policy, runner, allowed=True)
    assert runner.calls == 1
    transport.reset_next_cursor()
    _scan(transport, store, policy, runner, allowed=True)  # forces list_folder_continue -> CURSOR_RESET -> re-list
    assert runner.calls == 1
