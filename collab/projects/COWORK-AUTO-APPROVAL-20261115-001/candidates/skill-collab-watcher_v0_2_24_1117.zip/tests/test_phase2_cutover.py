"""Cutover-rehearsal regressions: provider-scoped cursors and read-only opens."""
from __future__ import annotations

import hashlib
import shutil

import pytest

from bundle import ROOT, github_policy, make_transport, publish_bundle
from skill_collab_watcher.fake_runner import FakeReviewRunner
from skill_collab_watcher.models import JobState
from skill_collab_watcher.orchestrator import REMOTE_CURSOR_NAME, run_scan_cycle
from skill_collab_watcher.state_store import ProviderConflict, StateStore


def test_cursor_is_scoped_per_provider(github_env):
    run_scan_cycle(make_transport(github_env.http), github_env.store, github_policy(), FakeReviewRunner(),
                   allowed=False, snapshot_root=github_env.snapshot_root,
                   review_run_dir=github_env.review_run_dir, remote_root=ROOT)
    github_key = make_transport(github_env.http).cursor_name
    assert github_key != REMOTE_CURSOR_NAME
    assert github_env.store.get_cursor(github_key) == github_env.http.head()
    assert github_env.store.get_cursor(REMOTE_CURSOR_NAME) is None


def _github_scan(env):
    return run_scan_cycle(make_transport(env.http), env.store, github_policy(), env.runner, allowed=True,
                          snapshot_root=env.snapshot_root, review_run_dir=env.review_run_dir, remote_root=ROOT)


def test_C1_github_scan_does_not_consume_the_dropbox_backlog(github_env):
    store = github_env.store
    store.add_pending("REQ-OLD", "left from dropbox")
    publish_bundle(github_env.http)
    _github_scan(github_env)
    assert store.list_pending("dropbox") == ["REQ-OLD"]
    assert store.list_pending("github") == []
    assert github_env.runner.calls == 1


def test_C1_same_request_id_in_both_scopes_does_not_collide(github_env):
    store = github_env.store
    store.add_pending("REQ-1", "dropbox side")
    store.pending_scope = "github"
    store.add_pending("REQ-1", "github side")
    store.remove_pending("REQ-1")
    assert store.list_pending("dropbox") == ["REQ-1"]
    assert store.list_pending("github") == []


def test_C1_switch_is_refused_while_the_leaving_provider_has_a_backlog(github_env):
    store = github_env.store
    store.check_provider("dropbox", "LIVE")
    store.add_pending("REQ-OLD")
    with pytest.raises(ProviderConflict, match="unsettled pending"):
        store.switch_provider("dropbox", "github")
    assert store.list_pending("dropbox") == ["REQ-OLD"]
    assert store.conn.execute("SELECT provider FROM provider_lease").fetchone()[0] == "dropbox"


def test_C1_hold_pending_keeps_the_backlog_and_records_exactly_which_ids(github_env):
    store = github_env.store
    store.check_provider("dropbox", "LIVE")
    store.add_pending("REQ-OLD")
    store.add_pending("REQ-OLD2")
    store.switch_provider("dropbox", "github", hold_pending=True)
    held = [d for (_t, e, _k, d) in store.recent_events(50) if e == "PENDING_HELD"]
    assert held == ["dropbox: REQ-OLD, REQ-OLD2"]
    _github_scan(github_env)
    assert store.list_pending("dropbox") == ["REQ-OLD", "REQ-OLD2"]


def test_C1_held_request_is_still_processed_after_rollback_and_never_reviewed_twice(
        github_env, transport, snapshot_root, review_run_dir):
    from conftest import BASELINE, REMOTE_ROOT, RUN_POLICY_REF, push_valid_request
    from skill_collab_watcher.validator import LocalPolicy

    store = github_env.store
    store.check_provider("dropbox", "LIVE")
    push_valid_request(transport, "REQ-OLD")
    store.add_pending("REQ-OLD")
    store.switch_provider("dropbox", "github", hold_pending=True)
    _github_scan(github_env)
    store.switch_provider("github", "dropbox")
    policy = LocalPolicy(active_baseline_id=BASELINE, local_policy_revision="1",
                         known_run_policy_refs=[RUN_POLICY_REF])
    runner = FakeReviewRunner()
    for _ in range(2):
        run_scan_cycle(transport, store, policy, runner, allowed=True, snapshot_root=snapshot_root,
                       review_run_dir=review_run_dir, remote_root=REMOTE_ROOT)
    assert runner.calls == 1
    assert store.list_pending("dropbox") == []


def test_C1_reconciliation_manifest_accounts_for_every_backlog_id_and_job_state(github_env):
    store = github_env.store
    store.check_provider("dropbox", "LIVE")
    store.add_pending("REQ-A")
    store.pending_scope = "github"
    store.add_pending("REQ-B")
    store.create_job("K1", "REQ-A", "1", "aa", JobState.COMPLETED)
    manifest = store.reconciliation_manifest()
    assert manifest["pending"] == {"dropbox": ["REQ-A"], "github": ["REQ-B"]}
    assert manifest["jobs"] == {"COMPLETED": 1}
    assert manifest["lease"] == {"provider": "dropbox", "epoch": 1}


def test_C1_manifest_works_on_a_read_only_v015_style_database(tmp_path):
    import sqlite3

    path = tmp_path / "old.sqlite3"
    conn = sqlite3.connect(path)
    conn.executescript(
        "CREATE TABLE jobs (processing_key TEXT PRIMARY KEY, request_id TEXT, request_revision TEXT,"
        " package_sha256 TEXT, state TEXT, created_at TEXT, updated_at TEXT, attempt_count INT, last_error TEXT,"
        " result_path TEXT);"
        "CREATE TABLE pending_requests (request_id TEXT PRIMARY KEY, reason TEXT, updated_at TEXT);"
        "INSERT INTO pending_requests VALUES ('REQ-LEGACY', NULL, 'x');")
    conn.close()
    ro = StateStore(path, read_only=True)
    assert ro.reconciliation_manifest() == {"pending": {"dropbox": ["REQ-LEGACY"]}, "jobs": {}, "lease": None}
    ro.close()


def test_shadow_open_leaves_the_database_file_unchanged_while_wal_is_pending(tmp_path):
    live = tmp_path / "live"
    live.mkdir()
    writer = StateStore(live / "state.sqlite3")
    writer.create_job("K1", "REQ-1", "1", "aa", JobState.COMPLETED)
    writer.log_event("COMPLETED", processing_key="K1")
    copy = tmp_path / "copy"
    copy.mkdir()
    for name in ("state.sqlite3", "state.sqlite3-wal", "state.sqlite3-shm"):
        if (live / name).exists():
            shutil.copy2(live / name, copy / name)
    assert (copy / "state.sqlite3-wal").stat().st_size > 0
    main = copy / "state.sqlite3"
    before = hashlib.sha256(main.read_bytes()).hexdigest()
    shadow = StateStore(main, read_only=True)
    assert shadow.get_job("K1").state == JobState.COMPLETED
    shadow.close()
    assert hashlib.sha256(main.read_bytes()).hexdigest() == before
    writer.close()
