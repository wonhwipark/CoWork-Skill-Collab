"""S-1: SHADOW never opens the live database. Path guard, own-folder runtime, and an OS-level tripwire.

The tripwire holds the live database files open with sharing denied. Any attempt by the SHADOW code to open
them (SQLite, a copy, a hash, anything) fails with a sharing violation. This is proof at the file-handle
level for the code paths exercised here; it is not a trace of a real host process (that is NOT_RUN)."""
from __future__ import annotations

import ctypes
import hashlib
import json
import os
import subprocess
import sys
import threading
from ctypes import wintypes
from pathlib import Path

import pytest

from bundle import make_transport, publish_bundle
from fake_github import FakeGitHub
from skill_collab_watcher import cli
from skill_collab_watcher.config import Config, ConfigError
from skill_collab_watcher.shadow_guard import (
    ShadowDispatchRefused, ShadowIsolationError, ShadowRunner, assert_isolated, verify_after_create,
)
from skill_collab_watcher.state_store import StateStore
from skill_collab_watcher.transport_base import TransportError

win = pytest.mark.skipif(sys.platform != "win32", reason="Windows file handles and reparse points")


# --- path guard -------------------------------------------------------------------------------

def test_a_sibling_folder_is_isolated(tmp_path):
    live, shadow = tmp_path / "state", tmp_path / "state-shadow"
    live.mkdir()
    assert assert_isolated(live, shadow) == shadow.resolve()


@pytest.mark.parametrize("make", [
    lambda t: (t / "state", t / "state"),
    lambda t: (t / "state", t / "state" / "inner"),
    lambda t: (t / "state" / "inner", t / "state"),
    lambda t: (t / "state", t),
])
def test_equal_nested_and_enclosing_folders_are_refused(tmp_path, make):
    (tmp_path / "state" / "inner").mkdir(parents=True)
    live, shadow = make(tmp_path)
    with pytest.raises(ShadowIsolationError, match="OVERLAP"):
        assert_isolated(live, shadow)


def test_overlap_is_decided_case_insensitively(tmp_path):
    (tmp_path / "State").mkdir()
    with pytest.raises(ShadowIsolationError, match="OVERLAP"):
        assert_isolated(tmp_path / "State", tmp_path / "STATE" / "x")


@pytest.mark.parametrize("live, shadow, code", [
    ("", "C:\\x", "EMPTY_PATH"), ("C:\\x", "", "EMPTY_PATH"), ("C:\\x", "   ", "EMPTY_PATH"),
    ("\\\\server\\share\\live", "C:\\shadow", "UNC_PATH_REFUSED"),
    ("C:\\live", "\\\\server\\share\\shadow", "UNC_PATH_REFUSED"),
    ("C:\\live", "//server/share/shadow", "UNC_PATH_REFUSED"),
    ("relative\\live", "C:\\shadow", "RELATIVE_PATH_REFUSED"),
    ("C:\\live", "relative\\shadow", "RELATIVE_PATH_REFUSED"),
])
@win
def test_malformed_unc_and_relative_paths_are_refused(live, shadow, code):
    with pytest.raises(ShadowIsolationError, match=code):
        assert_isolated(live, shadow)


@win
def test_a_drive_root_is_refused():
    with pytest.raises(ShadowIsolationError, match="DRIVE_ROOT"):
        assert_isolated("C:\\somewhere\\live", "C:\\")


def _junction(link: Path, target: Path) -> bool:
    done = subprocess.run(["cmd", "/c", "mklink", "/J", str(link), str(target)], capture_output=True, text=True)
    return done.returncode == 0


@win
def test_a_junction_pointing_at_the_live_folder_is_refused(tmp_path):
    live = tmp_path / "live"
    live.mkdir()
    link = tmp_path / "looks-separate"
    if not _junction(link, live):
        pytest.skip("cannot create a junction here")
    try:
        with pytest.raises(ShadowIsolationError, match="REPARSE_POINT"):
            assert_isolated(live, link)
        with pytest.raises(ShadowIsolationError, match="REPARSE_POINT"):
            assert_isolated(live, link / "deeper")
    finally:
        os.rmdir(link)


@win
def test_a_junction_anywhere_above_the_shadow_folder_is_refused(tmp_path):
    live, elsewhere = tmp_path / "live", tmp_path / "elsewhere"
    live.mkdir()
    elsewhere.mkdir()
    link = tmp_path / "hop"
    if not _junction(link, elsewhere):
        pytest.skip("cannot create a junction here")
    try:
        with pytest.raises(ShadowIsolationError, match="REPARSE_POINT"):
            assert_isolated(live, link / "shadow")
    finally:
        os.rmdir(link)


@win
def test_the_8_3_short_name_of_the_live_folder_is_still_the_live_folder(tmp_path):
    live = tmp_path / "a long live folder name"
    live.mkdir()
    buf = ctypes.create_unicode_buffer(520)
    ctypes.windll.kernel32.GetShortPathNameW(str(live), buf, 520)
    if not buf.value or buf.value.lower() == str(live).lower():
        pytest.skip("8.3 names are disabled on this volume")
    with pytest.raises(ShadowIsolationError):
        assert_isolated(live, Path(buf.value) / "inside")


def _deny_looking_at(monkeypatch, forbidden: Path):
    """Make every look at `forbidden` (and below) fail with 'access denied', like an account that is not
    allowed into the live folder."""
    real_stat, real_exists = os.stat, Path.exists

    def deny_stat(p, *a, **k):
        if str(p).lower().startswith(str(forbidden).lower()):
            raise PermissionError(13, "Access is denied")
        return real_stat(p, *a, **k)

    def deny_exists(self):
        if str(self).lower().startswith(str(forbidden).lower()):
            raise PermissionError(13, "Access is denied")
        return real_exists(self)

    monkeypatch.setattr(os, "stat", deny_stat)
    monkeypatch.setattr(Path, "exists", deny_exists)


def test_a_live_folder_this_account_may_not_look_at_does_not_crash_the_guard(tmp_path, monkeypatch):
    """The intended topology: SHADOW runs as another account that cannot enter the live folder. The guard
    must accept a separate shadow folder (found on a real host: v0.2.8 crashed with PermissionError)."""
    live = tmp_path / "live"
    live.mkdir()
    _deny_looking_at(monkeypatch, live)
    assert assert_isolated(live, tmp_path / "shadow") == (tmp_path / "shadow").resolve()


def test_an_unreadable_live_folder_still_cannot_hide_an_overlap(tmp_path, monkeypatch):
    live = tmp_path / "live"
    live.mkdir()
    _deny_looking_at(monkeypatch, live)
    with pytest.raises(ShadowIsolationError, match="OVERLAP"):
        assert_isolated(live, live / "inner")
    with pytest.raises(ShadowIsolationError, match="OVERLAP"):
        assert_isolated(live / "inner", live)


def test_a_folder_listed_by_name_but_not_openable_has_no_identity_and_is_not_a_crash(tmp_path, monkeypatch):
    """Found on the host: an ancestor the account can list but not open reports file index 0."""
    live = tmp_path / "live"
    live.mkdir()
    real_stat = os.stat

    class Zero:
        def __init__(self, st):
            self.st_dev, self.st_ino = st.st_dev, 0

    def stat(p, *a, **k):
        st = real_stat(p, *a, **k)
        return Zero(st) if str(p).lower().rstrip("\\/") == str(tmp_path).lower() else st

    monkeypatch.setattr(os, "stat", stat)
    assert assert_isolated(live, tmp_path / "shadow") == (tmp_path / "shadow").resolve()


def test_the_full_shadow_runtime_starts_when_the_live_folder_is_off_limits(tmp_path, monkeypatch):
    (tmp_path / "live").mkdir()
    _deny_looking_at(monkeypatch, tmp_path / "live")
    rt = open_runtime(tmp_path)
    try:
        assert isinstance(rt.runner, ShadowRunner) and rt.allowed is False
    finally:
        rt.close()


def test_the_second_pass_after_creation_also_refuses_an_overlap(tmp_path):
    live = tmp_path / "state"
    live.mkdir()
    (live / "inner").mkdir()
    with pytest.raises(ShadowIsolationError, match="OVERLAP"):
        verify_after_create(live, live / "inner")


def test_the_live_folder_does_not_have_to_exist_and_is_not_created(tmp_path):
    shadow = assert_isolated(tmp_path / "live-not-there", tmp_path / "shadow")
    assert shadow == (tmp_path / "shadow").resolve()
    assert not (tmp_path / "live-not-there").exists()


# --- configuration -----------------------------------------------------------------------------

def write_config(tmp_path, **top):
    raw = {"schema_version": 1, "baseline_id": "B", "transport": "github", "local_state_dir": str(tmp_path / "live"),
           "provider_mode": "SHADOW", "shadow": {"state_dir": str(tmp_path / "shadow")},
           "review_policy": {"enabled": True, "dry_run": False, "known_run_policy_refs": ["P"]},
           "github": {"repo": "owner/repo", "token_file": str(tmp_path / "token.txt")}}
    raw.update(top)
    (tmp_path / "token.txt").write_text("synthetic-token-not-real", encoding="utf-8")
    path = tmp_path / "config.json"
    path.write_text(json.dumps(raw), encoding="utf-8")
    return path


def test_shadow_needs_its_own_folder_in_the_config(tmp_path):
    with pytest.raises(ConfigError, match="shadow.state_dir"):
        Config.load(write_config(tmp_path, shadow={}))
    with pytest.raises(ConfigError, match="shadow.state_dir"):
        Config.load(write_config(tmp_path, shadow={"state_dir": "  "}))


def test_shadow_is_only_defined_for_github(tmp_path):
    with pytest.raises(ConfigError, match="only defined for transport github"):
        Config.load(write_config(tmp_path, transport="dropbox"))


def test_live_mode_does_not_need_a_shadow_folder(tmp_path):
    cfg = Config.load(write_config(tmp_path, provider_mode="LIVE", shadow={}))
    assert cfg.shadow_state_dir is None


def test_a_bad_independence_setting_is_a_config_error(tmp_path):
    path = write_config(tmp_path, provider_mode="LIVE", shadow={})
    raw = json.loads(path.read_text(encoding="utf-8"))
    raw["github"]["trust_root_independence"] = "off"
    path.write_text(json.dumps(raw), encoding="utf-8")
    with pytest.raises(ConfigError, match="trust_root_independence"):
        Config.load(path)


# --- the runtime -------------------------------------------------------------------------------

def open_runtime(tmp_path):
    return cli._open_runtime(Config.load(write_config(tmp_path)), None, threading.Event())


def test_the_shadow_runtime_has_its_own_writable_database_and_cannot_dispatch_or_write(tmp_path):
    rt = open_runtime(tmp_path)
    try:
        assert rt.allowed is False and rt.policy.require_approval is False
        assert not rt.store.read_only
        assert isinstance(rt.runner, ShadowRunner)
        assert Path(rt.cfg.shadow_state_dir, "state.sqlite3").exists()
        assert str(rt.review_run_dir).startswith(str(Path(rt.cfg.shadow_state_dir).resolve()))
        assert str(rt.snapshot_root).startswith(str(Path(rt.cfg.shadow_state_dir).resolve()))
        with pytest.raises(ShadowDispatchRefused):
            rt.runner.run(None, "", None)
        assert rt.runner.preflight() == (False, "SHADOW_MODE")
        with pytest.raises(TransportError, match="READ_ONLY_TRANSPORT"):
            rt.transport.upload("/SKILL-COLLAB/reviews/X/Y.md", b"x")
    finally:
        rt.close()


def test_the_shadow_runtime_never_creates_the_live_folder(tmp_path):
    rt = open_runtime(tmp_path)
    rt.close()
    assert not (tmp_path / "live").exists()


def test_shadow_cursors_are_kept_in_its_own_database(tmp_path):
    rt = open_runtime(tmp_path)
    http = FakeGitHub()
    publish_bundle(http)
    rt.transport = make_transport(http)
    assert cli._one_cycle(rt).note == "OK"
    assert rt.store.get_cursor(rt.transport.cursor_name) == http.head()
    rt.close()
    again = open_runtime(tmp_path)
    again.transport = make_transport(http)
    calls_before = len(http.calls)
    cli._one_cycle(again)
    assert any("/compare/" in u or "/commits/" in u for _m, u in http.calls[calls_before:])
    assert [m for m, _u in http.calls if m != "GET"] == []
    again.close()


def test_status_and_reconcile_in_shadow_mode_read_the_shadow_database(tmp_path, capsys):
    rt = open_runtime(tmp_path)
    rt.store.add_pending("REQ-SHADOW")
    rt.close()
    args = type("A", (), {"config": str(tmp_path / "config.json")})()
    assert cli.cmd_reconcile(args) == cli.EXIT_OK
    out = json.loads(capsys.readouterr().out)
    assert "REQ-SHADOW" in json.dumps(out)
    assert not (tmp_path / "live").exists()


def test_a_shadow_folder_that_overlaps_the_live_one_stops_the_runtime_before_anything_is_created(tmp_path):
    (tmp_path / "live").mkdir()
    cfg = Config.load(write_config(tmp_path, shadow={"state_dir": str(tmp_path / "live" / "inner")}))
    with pytest.raises(ShadowIsolationError, match="OVERLAP"):
        cli._open_runtime(cfg, None, threading.Event())
    assert not (tmp_path / "live" / "inner").exists()


def test_the_shadow_code_never_reads_the_live_state_dir_property(tmp_path, monkeypatch):
    """Config.state_dir is the one property that creates and returns the live folder. If SHADOW touched it
    the test would fail on the spot."""
    def forbidden(self):
        raise AssertionError("SHADOW touched the live state_dir")

    path = write_config(tmp_path)
    cfg = Config.load(path)
    monkeypatch.setattr(Config, "state_dir", property(forbidden))
    rt = cli._open_runtime(cfg, None, threading.Event())
    http = FakeGitHub()
    publish_bundle(http)
    rt.transport = make_transport(http)
    assert cli._one_cycle(rt).note == "OK"
    rt.close()


def test_the_whole_watch_command_in_shadow_mode_uses_its_own_lock_and_leaves_the_live_folder_alone(tmp_path, monkeypatch):
    path = write_config(tmp_path)
    http = FakeGitHub()
    publish_bundle(http)
    monkeypatch.setattr(cli, "_build_transport", lambda cfg, store, stop: make_transport(http))
    rc = cli.main(["--config", str(path), "watch", "--max-cycles", "2", "--poll-interval", "1"])
    assert rc == cli.EXIT_OK
    shadow = tmp_path / "shadow"
    assert (shadow / "watch.lock").exists() and (shadow / "state.sqlite3").exists()
    assert not (tmp_path / "live").exists()
    assert [m for m, _u in http.calls if m != "GET"] == []


def test_two_shadow_watchers_cannot_run_at_once_but_a_live_one_would_not_be_blocked(tmp_path):
    from skill_collab_watcher.lock import SingleInstanceLock

    cfg = Config.load(write_config(tmp_path))
    shadow_lock = cli._work_dir(cfg) / "watch.lock"
    live_lock = tmp_path / "live" / "watch.lock"
    first, second, live = SingleInstanceLock(shadow_lock), SingleInstanceLock(shadow_lock), SingleInstanceLock(live_lock)
    assert first.acquire()
    try:
        assert second.acquire() is False
        assert live.acquire() is True
    finally:
        first.release()
        live.release()


def test_the_runbook_describes_the_design_the_code_actually_has():
    """The runbook ships inside the package; it must not describe an older design."""
    text = (Path(__file__).resolve().parents[1] / "docs" / "CUTOVER_RUNBOOK.md").read_text(encoding="utf-8")
    for needed in ("shadow.state_dir", "TRUST_ROOT_NOT_INDEPENDENT", "approval_signer", "REPARSE", "file identity",
                   "never opened", "tripwire", "high-water mark"):
        assert needed.lower().replace("reparse", "reparse point") in text.lower() or needed.lower() in text.lower(), needed
    for stale in ("<local_state_dir>-shadow", "opened with SQLite `mode=ro`", "(v0.2.4,"):
        assert stale not in text, stale
    import skill_collab_watcher

    assert f"(v{skill_collab_watcher.__version__}," in text, "the runbook title must name the shipped version"


# --- OS-level tripwire -------------------------------------------------------------------------

class HeldOpen:
    """Hold files open with sharing denied: nobody else, including this process, can open them."""

    GENERIC_READ, OPEN_EXISTING = 0x80000000, 3

    def __init__(self, paths):
        k = ctypes.WinDLL("kernel32", use_last_error=True)
        k.CreateFileW.restype = wintypes.HANDLE
        k.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD,
                                  wintypes.DWORD, wintypes.HANDLE]
        self._k, self._handles = k, []
        for p in paths:
            h = k.CreateFileW(str(p), self.GENERIC_READ, 0, None, self.OPEN_EXISTING, 0x80, None)
            assert h not in (None, wintypes.HANDLE(-1).value), f"could not lock {p.name}"
            self._handles.append(h)

    def close(self):
        for h in self._handles:
            self._k.CloseHandle(h)


@win
def test_tripwire_the_sentinel_really_blocks_every_other_open(tmp_path):
    f = tmp_path / "sentinel.bin"
    f.write_bytes(b"x")
    held = HeldOpen([f])
    try:
        with pytest.raises(PermissionError):
            f.read_bytes()
    finally:
        held.close()
    assert f.read_bytes() == b"x"


@win
def test_tripwire_a_full_shadow_cycle_never_touches_the_live_database_files(tmp_path):
    live = tmp_path / "live"
    writer_cfg = Config.load(write_config(tmp_path, provider_mode="LIVE", shadow={}))
    live_store = StateStore(writer_cfg.state_dir / "state.sqlite3")
    live_store.add_pending("REQ-LIVE-ONLY")
    live_store.close()
    files = sorted(live.glob("state.sqlite3*"))
    assert files
    before = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    listing_before = sorted(p.name for p in live.iterdir())

    held = HeldOpen(files)
    try:
        rt = open_runtime(tmp_path)
        http = FakeGitHub()
        publish_bundle(http)
        rt.transport = make_transport(http)
        for _ in range(3):
            assert cli._one_cycle(rt).note == "OK"
        rt.close()
    finally:
        held.close()

    assert {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in files} == before
    assert sorted(p.name for p in live.iterdir()) == listing_before
    assert [m for m, _u in http.calls if m != "GET"] == []
    check = StateStore(live / "state.sqlite3")
    assert check.list_pending("dropbox") == ["REQ-LIVE-ONLY"]
    check.close()


@win
def test_tripwire_a_runtime_pointed_at_the_live_files_is_stopped_by_the_guard_not_by_luck(tmp_path):
    live = tmp_path / "live"
    live.mkdir()
    StateStore(live / "state.sqlite3").close()
    files = sorted(live.glob("state.sqlite3*"))
    held = HeldOpen(files)
    try:
        cfg = Config.load(write_config(tmp_path, shadow={"state_dir": str(live)}))
        with pytest.raises(ShadowIsolationError, match="OVERLAP"):
            cli._open_runtime(cfg, None, threading.Event())
    finally:
        held.close()


# --- no command of a SHADOW / GitHub configuration touches the live folder or its secrets -------

@pytest.mark.parametrize("argv", [["config-check"], ["auth-check"], ["auth-init"], ["status"], ["reconcile"],
                                  ["recover"]])
def test_no_command_of_a_shadow_configuration_creates_or_reads_the_live_folder(tmp_path, monkeypatch, argv):
    """Found by reading every use of cfg.state_dir: config-check, auth-check and auth-init resolved the LIVE
    folder (creating it) and read or wrote its Dropbox secrets even for provider_mode SHADOW / GitHub."""
    touched = []
    for name in ("load_secrets", "save_secrets", "load_granted_scope"):
        monkeypatch.setattr(cli, name, lambda *a, _n=name, **k: touched.append(_n) or {})
    path = write_config(tmp_path)
    try:
        cli.main(["--config", str(path), *argv])
    except (SystemExit, Exception):
        pass
    assert touched == []
    assert not (tmp_path / "live").exists()


def test_the_dropbox_only_commands_refuse_a_github_configuration(tmp_path, capsys):
    path = write_config(tmp_path, provider_mode="LIVE", shadow={})
    assert cli.main(["--config", str(path), "auth-check"]) == cli.EXIT_REFUSED
    assert cli.main(["--config", str(path), "auth-init"]) == cli.EXIT_REFUSED
    assert "Dropbox provider only" in capsys.readouterr().out


def test_the_live_state_dir_is_referenced_only_by_the_audited_functions():
    """Static call-path guard: a new function that reaches the live folder must be added here on purpose,
    after checking it is unreachable in SHADOW."""
    import ast

    audited = {("cli.py", "_build_transport"), ("cli.py", "_work_dir"), ("cli.py", "cmd_auth_check"),
               ("cli.py", "cmd_auth_init"), ("cli.py", "cmd_config_check"), ("cli.py", "_open_runtime"), ("config.py", "state_dir")}
    found = set()
    for source in sorted(Path(cli.__file__).parent.glob("*.py")):
        tree = ast.parse(source.read_text(encoding="utf-8"))
        for fn in (n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))):
            if any(isinstance(n, ast.Attribute) and n.attr in ("state_dir", "local_state_dir") for n in ast.walk(fn)):
                found.add((source.name, fn.name))
    assert found == audited


def test_building_the_github_transport_never_reads_the_live_secrets(tmp_path, monkeypatch):
    called = []
    monkeypatch.setattr(cli, "load_secrets", lambda *a, **k: called.append(a) or {})
    cfg = Config.load(write_config(tmp_path))
    cli._build_transport(cfg, None, None)
    assert called == [] and not (tmp_path / "live").exists()


# --- the account SHADOW runs as must not be able to reach the live folder ------------------------

from skill_collab_watcher.shadow_guard import account_reach  # noqa: E402

ALL = 0x1F01FF
READ_ONLY = 0x120089
NOTHING_THAT_TOUCHES_DATA = 0x120000


def _live(tmp_path, with_files=True):
    live = tmp_path / "live"
    live.mkdir()
    if with_files:
        for name in ("state.sqlite3", "state.sqlite3-wal", "state.sqlite3-shm", "watch.lock"):
            (live / name).write_bytes(b"")
    return live


def test_a_live_folder_that_is_not_there_is_reported_as_absent_not_as_safe(tmp_path):
    assert account_reach(tmp_path / "nope", mask_of=lambda _p: ALL) == ("LIVE_FOLDER_ABSENT", [])


def test_an_operating_system_denial_is_the_strongest_status(tmp_path):
    def deny(_p):
        raise PermissionError(13, "Access is denied")

    assert account_reach(tmp_path, stat=deny, mask_of=lambda _p: ALL) == ("DENIED_BY_OS", [])


@pytest.mark.parametrize("mask", [ALL, READ_ONLY, 0x2, 0x80, 0x10000])
def test_any_right_that_touches_the_data_is_a_finding_for_the_folder_and_its_files(tmp_path, mask):
    status, findings = account_reach(_live(tmp_path), mask_of=lambda _p: mask)
    assert status == "ACCESSIBLE" and len(findings) == 5
    assert all(str(tmp_path) not in f for f in findings)


def test_an_acl_that_grants_nothing_but_read_control_is_not_a_finding(tmp_path):
    assert account_reach(_live(tmp_path), mask_of=lambda _p: NOTHING_THAT_TOUCHES_DATA) == ("NO_RIGHTS_ON_ACL", [])


def test_unreadable_permissions_on_a_reachable_folder_are_a_finding(tmp_path):
    def boom(_p):
        raise OSError("denied")

    status, findings = account_reach(_live(tmp_path), mask_of=boom)
    assert status == "ACCESSIBLE" and all("could not be read" in f for f in findings)


def test_a_file_that_does_not_exist_inside_a_reachable_folder_is_skipped_by_stat_not_by_a_guess(tmp_path):
    def only_folder(path):
        if path.endswith("live"):
            return ALL
        raise FileNotFoundError(path)

    status, findings = account_reach(_live(tmp_path, with_files=False), mask_of=only_folder)
    assert status == "ACCESSIBLE" and findings == ["live folder: this account holds access rights"]


def _isolation_config(tmp_path, mode):
    path = write_config(tmp_path, shadow={"state_dir": str(tmp_path / "shadow"), "account_isolation": mode})
    return Config.load(path)


def test_a_bad_account_isolation_setting_is_a_config_error(tmp_path):
    with pytest.raises(ConfigError, match="account_isolation"):
        _isolation_config(tmp_path, "off")


def test_enforce_refuses_to_start_when_this_account_can_reach_the_live_folder(tmp_path):
    _live(tmp_path)   # same account created it, so it holds rights: exactly the wrong topology
    with pytest.raises(ShadowIsolationError, match="ACCOUNT_CAN_REACH_LIVE_FOLDER"):
        cli._open_runtime(_isolation_config(tmp_path, "enforce"), None, threading.Event())
    assert not (tmp_path / "shadow").exists()


def test_enforce_through_the_command_line_ends_with_a_refusal_not_a_traceback(tmp_path, capsys):
    _live(tmp_path)
    path = write_config(tmp_path, shadow={"state_dir": str(tmp_path / "shadow"), "account_isolation": "enforce"})
    assert cli.main(["--config", str(path), "scan"]) == cli.EXIT_REFUSED
    assert "SHADOW REFUSED: ACCOUNT_CAN_REACH_LIVE_FOLDER" in capsys.readouterr().err


def test_warn_is_the_default_and_records_the_finding_without_stopping(tmp_path):
    _live(tmp_path)
    cfg = Config.load(write_config(tmp_path))
    assert cfg.shadow_account_isolation == "warn"
    rt = cli._open_runtime(cfg, None, threading.Event())
    try:
        events = [(e, d or "") for _t, e, _k, d in rt.store.recent_events(20)]
    finally:
        rt.close()
    assert any(e == "SHADOW_ACCOUNT_ISOLATION" and d.startswith("ACCESSIBLE") for e, d in events)


def test_enforce_starts_when_the_operating_system_denies_this_account(tmp_path, monkeypatch):
    _live(tmp_path)
    cfg = _isolation_config(tmp_path, "enforce")
    _deny_looking_at(monkeypatch, tmp_path / "live")
    rt = cli._open_runtime(cfg, None, threading.Event())
    try:
        assert any(e == "SHADOW_ACCOUNT_ISOLATION" and d.startswith("DENIED_BY_OS") for _t, e, _k, d in rt.store.recent_events(20))
    finally:
        rt.close()


def test_enforce_starts_when_there_is_no_live_folder_to_protect(tmp_path):
    rt = cli._open_runtime(_isolation_config(tmp_path, "enforce"), None, threading.Event())
    rt.close()


def test_a_live_mode_runtime_does_not_run_the_account_check(tmp_path):
    cfg = Config.load(write_config(tmp_path, provider_mode="LIVE", shadow={}))
    rt = cli._open_runtime(cfg, None, threading.Event())
    try:
        assert not any(e == "SHADOW_ACCOUNT_ISOLATION" for _t, e, _k, _d in rt.store.recent_events(20))
    finally:
        rt.close()
