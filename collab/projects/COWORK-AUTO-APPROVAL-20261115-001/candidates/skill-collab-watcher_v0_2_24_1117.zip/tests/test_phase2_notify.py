"""Notification rules (N-2, C-2, T12, T20, T22) with a fake sender. Nothing is sent to Telegram."""
from __future__ import annotations

import json

import pytest

from skill_collab_watcher.notify_events import (
    NotifyNotInitialized, NotifyState, build_message, read_legacy_last_id, run_once,
)
from skill_collab_watcher.state_store import StateStore


class FakeSender:
    def __init__(self, fail_on: int | None = None):
        self.messages: list[str] = []
        self._fail_on = fail_on

    def __call__(self, text: str) -> None:
        if self._fail_on is not None and len(self.messages) + 1 == self._fail_on:
            self._fail_on = None
            raise OSError("simulated send failure")
        self.messages.append(text)


def _store(tmp_path):
    return StateStore(tmp_path / "state.sqlite3")


def _history(store, n=65):
    for i in range(n):
        store.log_event("COMPLETED", processing_key=f"OLD-{i}|1|abc|1")


def _go(store, state, sender, provider="dropbox", repo=None, epoch=1, **kw):
    return run_once(store.conn, state, provider=provider, repo=repo, send=sender, epoch=epoch, **kw)


# --- C-2: past events are never replayed --------------------------------------------

def test_C2_fresh_state_refuses_to_send_anything(tmp_path):
    store = _store(tmp_path)
    _history(store)
    sender = FakeSender()
    with pytest.raises(NotifyNotInitialized):
        _go(store, NotifyState(), sender)
    assert sender.messages == []
    store.close()


def test_C2_bootstrap_skips_65_past_events_and_sends_only_new_ones_once(tmp_path):
    store = _store(tmp_path)
    _history(store, 65)
    state, sender = NotifyState(), FakeSender()
    assert state.bootstrap(store.conn, "github", 2) is True
    assert state.bootstrap(store.conn, "github", 2) is False
    assert _go(store, state, sender, provider="github", repo="owner/repo", epoch=2) == 0
    store.log_event("COMPLETED", processing_key="REQ-9|1|abc|1")
    assert _go(store, state, sender, provider="github", repo="owner/repo", epoch=2) == 1
    assert _go(store, state, sender, provider="github", repo="owner/repo", epoch=2) == 0
    assert len(sender.messages) == 1
    store.close()


def test_C2_legacy_watermark_does_not_skip_events_the_running_notifier_never_sent(tmp_path):
    store = _store(tmp_path)
    _history(store, 10)
    legacy = store.conn.execute("SELECT MAX(id) FROM audit_log").fetchone()[0] - 3  # 3 not yet delivered
    state, sender = NotifyState(), FakeSender()
    state.bootstrap(store.conn, "dropbox", 3, legacy_last_id=legacy)
    assert _go(store, state, sender, epoch=3) == 3
    assert _go(store, state, sender, epoch=3) == 0
    store.close()


def test_C2_legacy_watermark_beyond_the_log_is_clamped(tmp_path):
    store = _store(tmp_path)
    _history(store, 2)
    state = NotifyState()
    state.bootstrap(store.conn, "dropbox", 1, legacy_last_id=10_000)
    assert state.watermarks["dropbox:1"] == 2
    store.close()


def test_C2_read_legacy_last_id_from_the_running_notifiers_state_file(tmp_path):
    path = tmp_path / "notify_state.json"
    path.write_text(json.dumps({"last_id": 17745}), encoding="utf-8")
    assert read_legacy_last_id(path) == 17745
    assert read_legacy_last_id(tmp_path / "missing.json") is None
    path.write_text("not json", encoding="utf-8")
    assert read_legacy_last_id(path) is None


def test_C2_each_provider_and_epoch_keeps_its_own_position(tmp_path):
    store = _store(tmp_path)
    state, sender = NotifyState(), FakeSender()
    state.bootstrap(store.conn, "dropbox", 1)
    state.bootstrap(store.conn, "github", 2)
    store.log_event("COMPLETED", processing_key="REQ-1|1|abc|1")
    assert _go(store, state, sender, provider="dropbox", epoch=1) == 1
    assert _go(store, state, sender, provider="github", repo="o/r", epoch=2) == 1
    assert len(sender.messages) == 2
    store.close()


def test_C2_restart_after_a_partial_run_resumes_without_duplicates(tmp_path):
    store = _store(tmp_path)
    state_path = tmp_path / "notify_state.json"
    state = NotifyState()
    state.bootstrap(store.conn, "dropbox", 1)
    for n in range(3):
        store.log_event("COMPLETED", processing_key=f"REQ-{n}|1|abc|1")
    sender = FakeSender(fail_on=3)
    with pytest.raises(OSError):
        _go(store, state, sender, persist=lambda: state.save(state_path))
    assert len(sender.messages) == 2
    resumed = NotifyState.load(state_path)
    assert _go(store, resumed, sender, persist=lambda: resumed.save(state_path)) == 1
    assert len(sender.messages) == 3
    assert len({m for m in sender.messages}) == 3
    store.close()


# --- N-2: provider-specific wording ---------------------------------------------------

def test_T22_completion_is_announced_once_per_job(tmp_path):
    store = _store(tmp_path)
    state, sender = NotifyState(), FakeSender()
    state.bootstrap(store.conn, "github", 2)
    store.log_event("COMPLETED", processing_key="REQ-1|1|abc|1")
    assert _go(store, state, sender, provider="github", repo="owner/private-repo", epoch=2) == 1
    assert _go(store, state, sender, provider="github", repo="owner/private-repo", epoch=2) == 0
    assert "collab/reviews/REQ-1/REVIEW_RESULT_1.md" in sender.messages[0]
    store.close()


def test_N2_github_messages_name_the_github_location_not_dropbox():
    text = build_message("COMPLETED", "REQ-1|1|abc|1", None, "github", "owner/private-repo")
    assert "https://github.com/owner/private-repo/blob/main/collab/reviews/REQ-1/REVIEW_RESULT_1.md" in text
    assert "Dropbox" not in text


def test_N2_dropbox_messages_keep_the_dropbox_location():
    text = build_message("COMPLETED", "REQ-1|1|abc|1", None, "dropbox")
    assert "Dropbox reviews/REQ-1/REVIEW_RESULT_1.md" in text
    assert "github.com" not in text


def test_T12_uncertain_review_is_announced_once_and_says_it_was_not_rerun(tmp_path):
    store = _store(tmp_path)
    state, sender = NotifyState(), FakeSender()
    state.bootstrap(store.conn, "github", 2)
    store.log_event("REVIEW_UNCERTAIN", processing_key="REQ-1|1|abc|1", detail="sealed at startup")
    _go(store, state, sender, provider="github", repo="o/r", epoch=2)
    _go(store, state, sender, provider="github", repo="o/r", epoch=2)
    assert len(sender.messages) == 1
    assert "자동 재실행하지 않았습니다" in sender.messages[0]
    store.close()


def test_held_backlog_is_announced_so_it_is_not_forgotten(tmp_path):
    store = _store(tmp_path)
    state, sender = NotifyState(), FakeSender()
    state.bootstrap(store.conn, "dropbox", 1)
    store.log_event("PENDING_HELD", detail="dropbox: REQ-7")
    _go(store, state, sender)
    assert len(sender.messages) == 1 and "REQ-7" in sender.messages[0]
    store.close()


def test_a_failed_send_is_retried_on_the_next_run(tmp_path):
    store = _store(tmp_path)
    state = NotifyState()
    state.bootstrap(store.conn, "dropbox", 1)
    store.log_event("COMPLETED", processing_key="REQ-1|1|abc|1")
    sender = FakeSender(fail_on=1)
    with pytest.raises(OSError):
        _go(store, state, sender)
    assert state.watermarks["dropbox:1"] == 0
    assert _go(store, state, sender) == 1
    store.close()


def test_T20_a_shadow_scan_produces_no_notifications(tmp_path, transport, runner, snapshot_root, review_run_dir):
    from conftest import BASELINE, REMOTE_ROOT, RUN_POLICY_REF, push_valid_request
    from skill_collab_watcher.orchestrator import run_scan_cycle
    from skill_collab_watcher.validator import LocalPolicy

    push_valid_request(transport)
    writer = _store(tmp_path)
    policy = LocalPolicy(active_baseline_id=BASELINE, local_policy_revision="1",
                         known_run_policy_refs=[RUN_POLICY_REF])
    run_scan_cycle(transport, writer, policy, runner, allowed=True, snapshot_root=snapshot_root,
                   review_run_dir=review_run_dir, remote_root=REMOTE_ROOT)
    writer.close()
    shadow = StateStore(tmp_path / "state.sqlite3", read_only=True)
    before = shadow.conn.execute("SELECT COUNT(*) FROM audit_log").fetchone()[0]
    calls = runner.calls
    run_scan_cycle(transport, shadow, policy, runner, allowed=False, snapshot_root=snapshot_root,
                   review_run_dir=review_run_dir, remote_root=REMOTE_ROOT)
    assert runner.calls == calls
    assert shadow.conn.execute("SELECT COUNT(*) FROM audit_log").fetchone()[0] == before
    state, sender = NotifyState(), FakeSender()
    state.bootstrap(shadow.conn, "dropbox", 1)
    assert _go(shadow, state, sender) == 0
    assert sender.messages == []
    shadow.close()
