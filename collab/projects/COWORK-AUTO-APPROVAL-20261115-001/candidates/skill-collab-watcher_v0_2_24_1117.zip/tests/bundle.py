"""Shared builders for the GitHub-provider tests. Synthetic data only."""
from __future__ import annotations

import hashlib
from datetime import datetime, timedelta, timezone

from conftest import BASELINE, RUN_POLICY_REF, make_package_zip, ready_md, request_md
from fake_github import REPO, TOKEN, j, rp
from skill_collab_watcher.approval import (
    APPROVAL_SCHEMA, PAYLOAD_SCHEMA, PIN_SCHEMA, TrustedKey, TrustRoot, canonical, knowledge_refs_hash,
)
from skill_collab_watcher.github_transport import GitHubTransport
from skill_collab_watcher.validator import LocalPolicy

ROOT = "/SKILL-COLLAB"
REPO_ID = "repo-synthetic-1"
KEY_ID = "key-synthetic-1"
PUBLIC = "SYNTHETIC-PUBLIC-KEY-NOT-A-SECRET"
NONCE = "synthetic-nonce-0123456789"
APPROVAL_PATH = "requests/{rid}/APPROVAL_SIG.json"
PIN_PATH = "requests/{rid}/SOURCE_PIN.json"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sig_for(message: bytes) -> str:
    return "TESTSIG:" + sha256(PUBLIC.encode() + message)


class DoubleBackend:
    """Test double only: not a signature scheme and not a production key."""

    def verify(self, public_key: str, message: bytes, signature: str) -> bool:
        return public_key == PUBLIC and signature == sig_for(message)


TRUST = TrustRoot(repo_id=REPO_ID, keys={KEY_ID: TrustedKey(
    key_id=KEY_ID, public_key=PUBLIC, fingerprint=sha256(PUBLIC.encode()), status="ACTIVE")})


def make_transport(http, token: str = TOKEN) -> GitHubTransport:
    return GitHubTransport(repo=REPO, branch="main", remote_root=ROOT,
                           token_provider=lambda: token, http=http, sleep=lambda _s: None)


def github_policy(**overrides) -> LocalPolicy:
    values = dict(active_baseline_id=BASELINE, local_policy_revision="1",
                  known_run_policy_refs=[RUN_POLICY_REF], require_approval=True,
                  trust_root=TRUST, signature_backend=DoubleBackend())
    values.update(overrides)
    return LocalPolicy(**values)


def publish_bundle(http, request_id: str = "REQ-1", revision: int = 1, *,
                   package: bytes | None = None, payload_changes: dict | None = None,
                   signature: str | None = None, key_id: str = KEY_ID, pin_commit: str | None = None,
                   omit: tuple[str, ...] = (), include_package: bool = True,
                   ready_request_sha: str | None = None, side: bool = False, signer=None) -> str:
    """Commit A carries REQUEST and the package; commit B carries READY,
    APPROVAL_SIG.json and SOURCE_PIN.json. side=True puts everything in one
    commit that no branch points to."""
    package = package if package is not None else make_package_zip(request_id)
    pkg_sha = sha256(package)
    req_raw = request_md(request_id=request_id, request_revision=revision,
                         package_sha256=pkg_sha, package_size=len(package)).encode("utf-8")
    req_sha = sha256(req_raw)
    ready_raw = ready_md(ready_request_sha or req_sha, pkg_sha, request_id=request_id,
                         request_revision=revision).encode("utf-8")
    ready_sha = sha256(ready_raw)
    now = datetime.now(timezone.utc)
    files_a = {rp(f"requests/{request_id}/REQUEST.md"): req_raw}
    if include_package:
        files_a[rp("packages/test.zip")] = package
    commit_a_files = dict(files_a)
    commit_a = None if side else http.commit(commit_a_files)
    payload = {
        "schema": PAYLOAD_SCHEMA, "repo_id": REPO_ID, "request_id": request_id,
        "request_revision": str(revision), "request_sha256": req_sha, "ready_sha256": ready_sha,
        "package_path": f"{ROOT}/packages/test.zip", "package_sha256": pkg_sha,
        "package_size_bytes": len(package), "local_policy_revision": "1",
        "run_policy_ref": RUN_POLICY_REF, "knowledge_refs_hash": knowledge_refs_hash([]),
        "source_commit": commit_a or http.head(), "nonce": NONCE,
        "issued_at": (now - timedelta(minutes=1)).isoformat(),
        "expires_at": (now + timedelta(hours=1)).isoformat(),
    }
    payload.update(payload_changes or {})
    approval = {"schema": APPROVAL_SCHEMA, "key_id": key_id, "payload": payload,
                "signature": signature if signature is not None
                else (signer(canonical(payload)) if signer else sig_for(canonical(payload)))}
    pin = {"schema": PIN_SCHEMA, "repo_id": REPO_ID, "commit": pin_commit or payload["source_commit"]}
    files_b = {rp(f"requests/{request_id}/READY.md"): ready_raw}
    if "approval" not in omit:
        files_b[rp(APPROVAL_PATH.format(rid=request_id))] = j(approval)
    if "pin" not in omit:
        files_b[rp(PIN_PATH.format(rid=request_id))] = j(pin)
    if side:
        http.commit_side({**files_a, **files_b})
    else:
        http.commit(files_b)
    return pkg_sha


def key_for(pkg_sha: str, revision: str = "1", policy_rev: str = "1", request_id: str = "REQ-1") -> str:
    return f"{request_id}|{revision}|{pkg_sha}|{policy_rev}"
