"""Cursor / pending-request durability.

A delta from Dropbox is delivered once. If the watcher advanced its cursor
and then failed (download error, crash, READY arriving in a later delta than
REQUEST, dry-run turned off later), the request used to be forgotten. The
pending_requests table makes "I have seen this request id and it is not
finished" durable independent of the cursor.
"""
from __future__ import annotations

import hashlib
from pathlib import Path

import pytest

from skill_collab_watcher import orchestrator
from skill_collab_watcher.models import JobState
from skill_collab_watcher.orchestrator import run_scan_cycle
from skill_collab_watcher.state_store import StateStore
from skill_collab_watcher.transport_base import AuthRequired, TransportError

from conftest import REMOTE_ROOT, make_package_zip, ready_md, request_md


def _scan(transport, store, policy, runner, allowed=True):
    base = Path(store.conn.execute("PRAGMA database_list").fetchall()[0][2]).parent
    return run_scan_cycle(transport, store, policy, runner, allowed, base / "snap", base / "runs", REMOTE_ROOT)


def _valid_files(request_id="REQ-1"):
    package = make_package_zip(request_id)
    sha = hashlib.sha256(package).hexdigest()
    req = request_md(request_id=request_id, package_sha256=sha, package_size=len(package))
    ready = ready_md(hashlib.sha256(req.encode("utf-8")).hexdigest(), sha, request_id=request_id)
    return req.encode("utf-8"), ready.encode("utf-8"), package


def _push_request(transport, request_id="REQ-1"):
    req, ready, package = _valid_files(request_id)
    transport.push_file(f"{REMOTE_ROOT}/requests/{request_id}/REQUEST.md", req)
    transport.push_file("/SKILL-COLLAB/packages/test.zip", package)
    return ready


def test_ready_arriving_in_a_later_delta_than_request_still_dispatches(transport, store, policy, runner):
    ready = _push_request(transport)
    _scan(transport, store, policy, runner)
    assert runner.calls == 0  # WAIT_INPUT: no READY yet
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/READY.md", ready)
    _scan(transport, store, policy, runner)  # this delta contains READY only
    assert runner.calls == 1


def test_request_arriving_after_ready_still_dispatches(transport, store, policy, runner):
    req, ready, package = _valid_files()
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/READY.md", ready)
    transport.push_file("/SKILL-COLLAB/packages/test.zip", package)
    _scan(transport, store, policy, runner)
    assert runner.calls == 0
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/REQUEST.md", req)
    _scan(transport, store, policy, runner)
    assert runner.calls == 1


def test_download_failure_does_not_lose_the_request(transport, store, policy, runner):
    ready = _push_request(transport)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/READY.md", ready)
    transport.fail_next("download", TransportError("simulated outage"))
    summary = _scan(transport, store, policy, runner)  # must not raise
    assert runner.calls == 0
    assert summary.note in ("OK", "TRANSPORT_ERROR")
    _scan(transport, store, policy, runner)  # delta is empty now; pending must carry it
    assert runner.calls == 1


def test_auth_lost_mid_group_reports_auth_required_and_keeps_request(transport, store, policy, runner):
    ready = _push_request(transport)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/READY.md", ready)
    transport.fail_next("download", AuthRequired("token revoked"))
    summary = _scan(transport, store, policy, runner)
    assert summary.note == "AUTH_REQUIRED"
    assert runner.calls == 0
    assert store.list_pending() == ["REQ-1"]
    _scan(transport, store, policy, runner)
    assert runner.calls == 1


def test_crash_after_cursor_commit_before_processing_is_recovered_after_restart(
    transport, store, policy, runner, tmp_path, monkeypatch
):
    ready = _push_request(transport)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/READY.md", ready)

    real = orchestrator.process_request_group

    class SimulatedCrash(BaseException):
        """Not an Exception: stands in for the process being killed."""

    def crash(*args, **kwargs):
        raise SimulatedCrash()

    monkeypatch.setattr(orchestrator, "process_request_group", crash)
    with pytest.raises(SimulatedCrash):
        _scan(transport, store, policy, runner)
    store.close()

    # "restart": brand new StateStore on the same file, original code path back.
    monkeypatch.setattr(orchestrator, "process_request_group", real)
    reopened = StateStore(tmp_path / "state.sqlite3")
    try:
        assert reopened.list_pending() == ["REQ-1"]
        _scan(transport, reopened, policy, runner)
        assert runner.calls == 1
    finally:
        reopened.close()


def test_dry_run_then_enabling_dispatches_without_any_new_remote_change(transport, store, policy, runner):
    ready = _push_request(transport)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/READY.md", ready)
    _scan(transport, store, policy, runner, allowed=False)
    assert runner.calls == 0
    _scan(transport, store, policy, runner, allowed=False)
    assert runner.calls == 0
    _scan(transport, store, policy, runner, allowed=True)
    assert runner.calls == 1


def test_dry_run_does_not_redownload_the_package_every_cycle(transport, store, policy, runner):
    ready = _push_request(transport)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/READY.md", ready)
    _scan(transport, store, policy, runner, allowed=False)
    after_first = transport.download_calls
    for _ in range(5):
        _scan(transport, store, policy, runner, allowed=False)
    # REQUEST and READY are small and re-read; the package itself must not be.
    assert transport.download_calls - after_first <= 5 * 2


def test_completed_request_leaves_pending_and_costs_no_more_downloads(transport, store, policy, runner):
    ready = _push_request(transport)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/READY.md", ready)
    _scan(transport, store, policy, runner)
    assert runner.calls == 1
    assert store.get_job(store.jobs_in_states([JobState.COMPLETED])[0].processing_key) is not None
    assert store.list_pending() == []
    before = transport.download_calls
    for _ in range(5):
        _scan(transport, store, policy, runner)
    assert transport.download_calls == before
    assert runner.calls == 1


def test_all_pages_are_consumed_in_a_single_cycle(transport, store, policy, runner):
    transport.page_size = 2
    for i in range(7):
        transport.push_file(f"/SKILL-COLLAB/knowledge/DOC_{i}.md", b"x")
    ready = _push_request(transport)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/READY.md", ready)
    _scan(transport, store, policy, runner)
    assert runner.calls == 1
    # And the cursor now points at the end: nothing is re-delivered.
    before = transport.download_calls
    _scan(transport, store, policy, runner)
    assert transport.download_calls == before


def test_deleted_request_folder_stops_being_pending(transport, store, policy, runner):
    _push_request(transport)  # REQUEST only -> WAIT_INPUT -> pending
    _scan(transport, store, policy, runner)
    assert store.list_pending() == ["REQ-1"]
    transport.delete_folder(f"{REMOTE_ROOT}/requests/REQ-1")
    summary = _scan(transport, store, policy, runner)
    assert summary.note == "OK"
    assert store.list_pending() == []
    assert runner.calls == 0


def test_one_broken_request_does_not_stop_the_others(transport, store, policy, runner, monkeypatch):
    for rid in ("REQ-A", "REQ-B"):
        req, ready, package = _valid_files(rid)
        transport.push_file(f"{REMOTE_ROOT}/requests/{rid}/REQUEST.md", req)
        transport.push_file(f"{REMOTE_ROOT}/requests/{rid}/READY.md", ready)
        transport.push_file(f"/SKILL-COLLAB/packages/test.zip", package)

    real = orchestrator.process_request_group

    def flaky(transport_, store_, policy_, runner_, allowed, snap, runs, root, request_id, group):
        if request_id == "REQ-A":
            raise ValueError("unexpected parser bug")
        return real(transport_, store_, policy_, runner_, allowed, snap, runs, root, request_id, group)

    monkeypatch.setattr(orchestrator, "process_request_group", flaky)
    summary = _scan(transport, store, policy, runner)  # must not raise
    assert summary.note == "TRANSPORT_ERROR"  # surfaced to the watch loop as "not a clean cycle"
    assert "REQ-A" in store.list_pending()
    events = [e[1] for e in store.recent_events(50)]
    assert "GROUP_ERROR" in events


def test_pending_and_cursor_survive_reopening_the_database(tmp_path):
    db = tmp_path / "durable.sqlite3"
    s = StateStore(db)
    s.add_pending("REQ-9", "delta")
    s.set_cursor("skill_collab_root", "cursor-42")
    s.increment_counter("api_recoveries", 3)
    s.close()
    s = StateStore(db)
    try:
        assert s.list_pending() == ["REQ-9"]
        assert s.get_cursor("skill_collab_root") == "cursor-42"
        assert s.get_counter("api_recoveries") == 3
        s.remove_pending("REQ-9")
        assert s.list_pending() == []
    finally:
        s.close()


def test_unexpected_transport_error_listing_does_not_advance_cursor(transport, store, policy, runner):
    _scan(transport, store, policy, runner)  # establishes a cursor
    cursor_before = store.get_cursor(orchestrator.REMOTE_CURSOR_NAME)
    ready = _push_request(transport)
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/READY.md", ready)
    transport.fail_next("list_folder_continue", TransportError("boom"))
    summary = _scan(transport, store, policy, runner)
    assert summary.note == "TRANSPORT_ERROR"
    assert store.get_cursor(orchestrator.REMOTE_CURSOR_NAME) == cursor_before
    _scan(transport, store, policy, runner)
    assert runner.calls == 1
