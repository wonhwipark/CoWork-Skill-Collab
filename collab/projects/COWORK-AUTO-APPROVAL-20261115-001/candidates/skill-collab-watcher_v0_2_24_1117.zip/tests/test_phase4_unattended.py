"""Unattended operation: login preflight, daily ceilings, remote pause, dead-man alert.
No real CLI, no network, no model: the real runner's subprocess call is replaced."""
from __future__ import annotations

import dataclasses
import json
import subprocess
from datetime import datetime, timedelta, timezone

import pytest

from bundle import ROOT, github_policy, make_transport, publish_bundle
from conftest import REMOTE_ROOT, push_valid_request
from skill_collab_watcher import review_runner
from skill_collab_watcher.config import Config, ConfigError
from skill_collab_watcher.fake_runner import FakeReviewRunner
from skill_collab_watcher.models import JobState, ReviewResult
from skill_collab_watcher.notify_events import NotifyState, build_message, check_stalled, run_once
from skill_collab_watcher.orchestrator import PAUSE_FILE, run_scan_cycle
from skill_collab_watcher.review_runner import RealReviewRunner
from skill_collab_watcher.state_store import StateStore


def push_requests(transport, *request_ids):
    """Several requests that share one package. push_valid_request writes the same
    packages/test.zip path for each call, so only the last of several would match."""
    import hashlib

    from conftest import make_package_zip, ready_md, request_md

    package = make_package_zip("shared-package")
    sha = hashlib.sha256(package).hexdigest()
    transport.push_file("/SKILL-COLLAB/packages/test.zip", package)
    for rid in request_ids:
        req = request_md(request_id=rid, package_sha256=sha, package_size=len(package)).encode("utf-8")
        transport.push_file(f"{REMOTE_ROOT}/requests/{rid}/REQUEST.md", req)
        transport.push_file(f"{REMOTE_ROOT}/requests/{rid}/READY.md",
                            ready_md(hashlib.sha256(req).hexdigest(), sha, request_id=rid).encode("utf-8"))


def scan(transport, store, policy, runner, snapshot_root, review_run_dir):
    return run_scan_cycle(transport, store, policy, runner, allowed=True, snapshot_root=snapshot_root,
                          review_run_dir=review_run_dir, remote_root=REMOTE_ROOT)


def names(store):
    return [(e, d or "") for _t, e, _k, d in store.recent_events(500)]


# --- login preflight ---------------------------------------------------------------------

def test_expired_login_pauses_the_queue_without_consuming_the_request(
        transport, store, policy, snapshot_root, review_run_dir):
    push_valid_request(transport)
    runner = FakeReviewRunner(preflight_reason="CLAUDE_NOT_LOGGED_IN")
    scan(transport, store, policy, runner, snapshot_root, review_run_dir)
    assert runner.calls == 0 and runner.preflight_calls == 1
    assert any(e == "CLAUDE_AUTH_REQUIRED" and "NOT_LOGGED_IN" in d for e, d in names(store))
    assert not any(e == "CLAIMED" for e, _d in names(store))
    assert store.list_pending() == ["REQ-1"]
    assert store.jobs_in_states([JobState.CLAIMED, JobState.REVIEW_RUNNING, JobState.FAILED]) == []


def test_after_the_login_is_restored_the_same_request_runs_exactly_once(
        transport, store, policy, snapshot_root, review_run_dir):
    push_valid_request(transport)
    runner = FakeReviewRunner(preflight_reason="CLAUDE_NOT_LOGGED_IN")
    for _ in range(3):
        scan(transport, store, policy, runner, snapshot_root, review_run_dir)
    assert runner.calls == 0
    runner.preflight_reason = None
    scan(transport, store, policy, runner, snapshot_root, review_run_dir)
    scan(transport, store, policy, runner, snapshot_root, review_run_dir)
    assert runner.calls == 1
    assert store.list_pending() == []


def test_the_login_check_is_not_made_when_nothing_would_be_dispatched(
        transport, store, policy, snapshot_root, review_run_dir):
    runner = FakeReviewRunner()
    scan(transport, store, policy, runner, snapshot_root, review_run_dir)
    assert runner.preflight_calls == 0


class Done:
    def __init__(self, stdout="", returncode=0):
        self.stdout, self.returncode = stdout, returncode


def real_runner():
    return RealReviewRunner("claude", None, ["Read"], 1.0, 60)


def patch_run(monkeypatch, result):
    seen = []

    def fake_run(argv, **kwargs):
        seen.append((argv, kwargs))
        if isinstance(result, BaseException):
            raise result
        return result

    monkeypatch.setattr(review_runner, "_run", fake_run)
    return seen


def test_real_preflight_accepts_only_an_explicit_logged_in_true(monkeypatch):
    seen = patch_run(monkeypatch, Done(json.dumps({"loggedIn": True, "email": "synthetic-account-name"})))
    assert real_runner().preflight() == (True, "ok")
    argv, kwargs = seen[0]
    assert argv == ["claude", "auth", "status", "--json"] and "-p" not in argv
    assert kwargs["shell"] is False and kwargs["timeout"] == review_runner.PREFLIGHT_TIMEOUT_SEC


@pytest.mark.parametrize("result, reason", [
    (Done(json.dumps({"loggedIn": False})), "CLAUDE_NOT_LOGGED_IN"),
    (Done(json.dumps({"loggedIn": "true"})), "CLAUDE_NOT_LOGGED_IN"),
    (Done(json.dumps({})), "CLAUDE_NOT_LOGGED_IN"),
    (Done(json.dumps({"loggedIn": True}), returncode=1), "CLAUDE_NOT_LOGGED_IN"),
    (Done("Not logged in"), "CLAUDE_STATUS_UNREADABLE"),
    (Done(""), "CLAUDE_STATUS_UNREADABLE"),
    (subprocess.TimeoutExpired("claude", 30), "CLAUDE_CLI_TIMEOUT"),
    (FileNotFoundError("claude"), "CLAUDE_CLI_NOT_FOUND"),
])
def test_real_preflight_fails_closed_with_a_reason_code(monkeypatch, result, reason):
    patch_run(monkeypatch, result)
    assert real_runner().preflight() == (False, reason)


def test_the_preflight_reason_never_carries_account_details(monkeypatch):
    patch_run(monkeypatch, Done(json.dumps({"loggedIn": False, "email": "synthetic-account-name", "orgId": "x"})))
    ok, reason = real_runner().preflight()
    assert "synthetic" not in reason and "account" not in reason


# --- daily ceilings ----------------------------------------------------------------------

def test_daily_dispatch_ceiling_blocks_the_next_request_and_keeps_it_pending(
        transport, store, policy, runner, snapshot_root, review_run_dir):
    capped = dataclasses.replace(policy, max_dispatches_per_day=1)
    push_requests(transport, "REQ-A", "REQ-B")
    scan(transport, store, capped, runner, snapshot_root, review_run_dir)
    assert runner.calls == 1
    assert any(e == "DAILY_LIMIT_BLOCKED" for e, _d in names(store))
    assert len(store.list_pending()) == 1


def test_the_ceiling_is_a_rolling_window_not_a_calendar_day(
        transport, store, policy, runner, snapshot_root, review_run_dir):
    capped = dataclasses.replace(policy, max_dispatches_per_day=1)
    push_requests(transport, "REQ-A", "REQ-B")
    scan(transport, store, capped, runner, snapshot_root, review_run_dir)
    old = (datetime.now(timezone.utc) - timedelta(hours=25)).isoformat()
    store.conn.execute("UPDATE audit_log SET ts=? WHERE event='REVIEW_DISPATCHED'", (old,))
    scan(transport, store, capped, runner, snapshot_root, review_run_dir)
    assert runner.calls == 2


def test_daily_budget_counts_an_unrecorded_cost_at_its_cap(
        transport, store, policy, runner, snapshot_root, review_run_dir):
    capped = dataclasses.replace(policy, daily_budget_usd=1.5, run_budgets_usd={"POLICY-STATIC-V1": 1.0})
    push_requests(transport, "REQ-A", "REQ-B")
    scan(transport, store, capped, runner, snapshot_root, review_run_dir)
    assert runner.calls == 1  # first: 0 + 1.0 <= 1.5; its cost was never recorded, so it counts as 1.0
    assert store.spend_since() == 1.0
    assert any(e == "DAILY_BUDGET_BLOCKED" for e, _d in names(store))


def test_daily_budget_uses_the_recorded_cost_when_there_is_one(
        transport, store, policy, snapshot_root, review_run_dir):
    runner = FakeReviewRunner(canned_result=ReviewResult(
        ok=True, output_text="x", output_format="json", exit_code=0, model_calls=1,
        usage={"total_cost_usd": 0.2, "num_turns": 3, "subtype": "success"}))
    capped = dataclasses.replace(policy, daily_budget_usd=1.5, run_budgets_usd={"POLICY-STATIC-V1": 1.0})
    push_requests(transport, "REQ-A", "REQ-B")
    scan(transport, store, capped, runner, snapshot_root, review_run_dir)
    assert runner.calls == 2
    assert abs(store.spend_since() - 0.4) < 1e-9


def test_spend_since_ignores_old_rows_and_malformed_details(tmp_path):
    store = StateStore(tmp_path / "s.sqlite3")
    old = (datetime.now(timezone.utc) - timedelta(hours=30)).isoformat()
    store.conn.execute("INSERT INTO audit_log (ts, event, processing_key, detail) VALUES (?, 'REVIEW_DISPATCHED', 'K0', ?)",
                       (old, json.dumps({"max_budget_usd": 9})))
    store.log_event("REVIEW_DISPATCHED", processing_key="K1", detail=json.dumps({"max_budget_usd": 1.0}))
    store.log_event("REVIEW_COST", processing_key="K1", detail=json.dumps({"total_cost_usd": 0.3}))
    store.log_event("REVIEW_DISPATCHED", processing_key="K2", detail=json.dumps({"max_budget_usd": 3.0}))
    store.log_event("REVIEW_DISPATCHED", processing_key="K3", detail="not json")
    assert abs(store.spend_since() - 3.3) < 1e-9
    assert store.dispatches_since() == 3
    store.close()


def test_without_ceilings_nothing_changes(transport, store, policy, runner, snapshot_root, review_run_dir):
    push_requests(transport, "REQ-A", "REQ-B", "REQ-C")
    scan(transport, store, policy, runner, snapshot_root, review_run_dir)
    assert runner.calls == 3


def write_config(tmp_path, **review):
    path = tmp_path / "config.json"
    path.write_text(json.dumps({"schema_version": 1, "baseline_id": "B", "local_state_dir": str(tmp_path / "state"),
                                "review_policy": {"known_run_policy_refs": ["P"], **review}}), encoding="utf-8")
    return path


def test_ceilings_default_to_off_and_parse_when_present(tmp_path):
    cfg = Config.load(write_config(tmp_path))
    assert cfg.review_policy.daily_budget_usd is None and cfg.review_policy.max_dispatches_per_day is None
    cfg = Config.load(write_config(tmp_path, daily_budget_usd=3, max_dispatches_per_day=4))
    assert (cfg.review_policy.daily_budget_usd, cfg.review_policy.max_dispatches_per_day) == (3.0, 4)


@pytest.mark.parametrize("review", [
    {"daily_budget_usd": 0}, {"daily_budget_usd": "3"}, {"daily_budget_usd": -1}, {"daily_budget_usd": True},
    {"max_dispatches_per_day": 0}, {"max_dispatches_per_day": 2.5}, {"max_dispatches_per_day": "2"},
])
def test_a_wrong_ceiling_stops_the_program_instead_of_disabling_the_cap(tmp_path, review):
    with pytest.raises(ConfigError):
        Config.load(write_config(tmp_path, **review))


def test_the_ceilings_reach_the_policy_the_orchestrator_uses(tmp_path):
    from skill_collab_watcher import cli

    cfg = Config.load(write_config(tmp_path, daily_budget_usd=2, max_dispatches_per_day=5))
    policy = cli._build_policy(cfg)
    assert (policy.daily_budget_usd, policy.max_dispatches_per_day) == (2.0, 5)


# --- remote pause ------------------------------------------------------------------------

def test_a_pause_marker_stops_new_reviews_and_removing_it_resumes_them(
        transport, store, policy, runner, snapshot_root, review_run_dir):
    push_valid_request(transport)
    transport.push_file(f"{REMOTE_ROOT}/{PAUSE_FILE}", b"pause")
    scan(transport, store, policy, runner, snapshot_root, review_run_dir)
    assert runner.calls == 0 and runner.preflight_calls == 0
    assert any(e == "REVIEWS_PAUSED" for e, _d in names(store))
    assert store.list_pending() == ["REQ-1"]
    transport.delete_file(f"{REMOTE_ROOT}/{PAUSE_FILE}")
    scan(transport, store, policy, runner, snapshot_root, review_run_dir)
    assert runner.calls == 1


def test_a_pause_marker_in_the_github_repository_stops_an_approved_review(github_env):
    from fake_github import rp
    from test_phase1_github import run

    publish_bundle(github_env.http)
    github_env.http.commit({rp(PAUSE_FILE): b"pause"})
    run(github_env)
    assert github_env.runner.calls == 0
    assert any(e == "REVIEWS_PAUSED" for e, _d in names(github_env.store))


def test_a_pause_marker_does_not_disturb_requests_that_are_already_finished(
        transport, store, policy, runner, snapshot_root, review_run_dir):
    push_valid_request(transport)
    scan(transport, store, policy, runner, snapshot_root, review_run_dir)
    transport.push_file(f"{REMOTE_ROOT}/{PAUSE_FILE}", b"pause")
    scan(transport, store, policy, runner, snapshot_root, review_run_dir)
    assert runner.calls == 1
    assert store.get_job(next(iter(store.conn.execute("select processing_key from jobs")))[0]).state == JobState.COMPLETED


# --- dead-man alert ----------------------------------------------------------------------

class Sink:
    def __init__(self):
        self.messages = []

    def __call__(self, text):
        self.messages.append(text)


def put_scan(store, minutes_ago, now):
    ts = (now - timedelta(minutes=minutes_ago)).isoformat()
    store.conn.execute("INSERT INTO audit_log (ts, event) VALUES (?, 'SCAN_START')", (ts,))


def test_no_scan_history_is_not_an_outage(tmp_path):
    store = StateStore(tmp_path / "s.sqlite3")
    sink = Sink()
    assert check_stalled(store.conn, NotifyState(), now=datetime.now(timezone.utc), send=sink) is None
    assert sink.messages == []
    store.close()


def test_a_fresh_scan_is_quiet(tmp_path):
    store = StateStore(tmp_path / "s.sqlite3")
    now = datetime.now(timezone.utc)
    put_scan(store, 1, now)
    sink = Sink()
    assert check_stalled(store.conn, NotifyState(), now=now, send=sink) is None
    assert sink.messages == []
    store.close()


def test_one_alert_per_outage_and_one_message_on_recovery(tmp_path):
    store = StateStore(tmp_path / "s.sqlite3")
    now = datetime.now(timezone.utc)
    state, sink = NotifyState(), Sink()
    put_scan(store, 40, now)
    assert check_stalled(store.conn, state, now=now, send=sink) == "STALLED"
    assert check_stalled(store.conn, state, now=now + timedelta(minutes=5), send=sink) is None
    assert len(sink.messages) == 1 and "40" in sink.messages[0]
    put_scan(store, 0, now + timedelta(minutes=10))
    assert check_stalled(store.conn, state, now=now + timedelta(minutes=10), send=sink) == "RECOVERED"
    assert check_stalled(store.conn, state, now=now + timedelta(minutes=11), send=sink) is None
    assert len(sink.messages) == 2
    put_scan(store, 0, now + timedelta(hours=3))
    later = now + timedelta(hours=3, minutes=30)
    assert check_stalled(store.conn, state, now=later, send=sink) == "STALLED"
    assert len(sink.messages) == 3
    store.close()


def test_the_alert_state_survives_a_notifier_restart(tmp_path):
    store = StateStore(tmp_path / "s.sqlite3")
    now = datetime.now(timezone.utc)
    put_scan(store, 90, now)
    path = tmp_path / "notify.json"
    first, sink = NotifyState(), Sink()
    check_stalled(store.conn, first, now=now, send=sink, persist=lambda: first.save(path))
    second = NotifyState.load(path)
    assert check_stalled(store.conn, second, now=now, send=sink) is None
    assert len(sink.messages) == 1
    store.close()


def test_the_new_events_are_announced_once_with_plain_wording(tmp_path):
    store = StateStore(tmp_path / "s.sqlite3")
    state, sink = NotifyState(), Sink()
    state.bootstrap(store.conn, "github", 2)
    store.log_event("CLAUDE_AUTH_REQUIRED", processing_key="REQ-1|1|abc|1", detail="CLAUDE_NOT_LOGGED_IN")
    store.log_event("DAILY_BUDGET_BLOCKED", processing_key="REQ-2|1|abc|1")
    store.log_event("DAILY_LIMIT_BLOCKED", processing_key="REQ-3|1|abc|1")
    assert run_once(store.conn, state, provider="github", repo="o/r", send=sink, epoch=2) == 3
    assert run_once(store.conn, state, provider="github", repo="o/r", send=sink, epoch=2) == 0
    assert "로그인" in sink.messages[0] and "모델도 호출하지 않았습니다" in sink.messages[0]
    assert all("Dropbox" not in m for m in sink.messages)
    store.close()


def test_pause_is_not_announced_because_the_user_asked_for_it():
    assert build_message("REVIEWS_PAUSED", "REQ-1|1|a|1", None, "github", "o/r").startswith("[REVIEWS_PAUSED]")
    from skill_collab_watcher.notify_events import NOTIFY_EVENTS
    assert "REVIEWS_PAUSED" not in NOTIFY_EVENTS


# --- the whole unattended path -------------------------------------------------------------

def test_approved_github_review_runs_unattended_once_and_publishes(github_env):
    from test_phase1_github import run

    pkg = publish_bundle(github_env.http)
    run(github_env)
    run(github_env)
    assert github_env.runner.calls == 1 and github_env.runner.preflight_calls == 1
    from bundle import key_for
    assert github_env.store.get_job(key_for(pkg)).state == JobState.COMPLETED
