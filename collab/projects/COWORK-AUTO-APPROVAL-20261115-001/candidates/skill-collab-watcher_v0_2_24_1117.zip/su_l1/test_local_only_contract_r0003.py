import pytest

pytest.importorskip("cryptography", reason="Ed25519 tests need the optional cryptography package")
import hashlib
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

import local_only_contract_r0003 as c

HERE = os.path.dirname(os.path.abspath(__file__))
WORKER = os.path.join(HERE, "ledger_worker_r0003.py")
NOW = datetime(2026, 11, 14, 12, 0, tzinfo=timezone.utc)
ZIP_BYTES = b"pretend this is the confidential source archive"
ZIP_SHA = hashlib.sha256(ZIP_BYTES).hexdigest()


def keypair():
    key = Ed25519PrivateKey.generate()
    return (key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption()),
            key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw))


class Base(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp(prefix="ledger-r0003-")
        self.addCleanup(shutil.rmtree, self.dir, ignore_errors=True)
        self.db, self.anchor = os.path.join(self.dir, "ledger.sqlite"), os.path.join(self.dir, "ledger.anchor")
        self.start = os.path.join(self.dir, "go")

    def fresh(self):
        return c.Ledger.bootstrap(self.db, self.anchor, acknowledge=c.BOOTSTRAP_ACK)

    def spawn(self, op, key, extra="", n=1, release=True):
        procs = [subprocess.Popen([sys.executable, "-I", WORKER, op, self.db, self.anchor, key, self.start] + ([extra] if extra else []),
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) for _ in range(n)]
        if release:
            open(self.start, "w").close()
        return procs

    def collect(self, procs):
        out = []
        for p in procs:
            stdout, stderr = p.communicate(timeout=60)
            out.append((p.returncode, stdout.strip().splitlines(), stderr.strip()))
        return out


class Bootstrap(Base):
    def test_first_creation_needs_the_explicit_acknowledgement(self):
        with self.assertRaisesRegex(c.ContractError, "BOOTSTRAP_NOT_ACKNOWLEDGED"):
            c.Ledger.bootstrap(self.db, self.anchor, acknowledge="yes")
        self.assertFalse(os.path.exists(self.db))

    def test_opening_without_any_state_never_creates_one(self):
        with self.assertRaisesRegex(c.ContractError, "NOT_INITIALIZED_FAIL_CLOSED"):
            c.Ledger.open(self.db, self.anchor)
        self.assertFalse(os.path.exists(self.db) or os.path.exists(self.anchor))

    def test_bootstrap_refuses_to_run_over_remains(self):
        self.fresh()
        os.remove(self.anchor)
        with self.assertRaisesRegex(c.ContractError, "BOOTSTRAP_REFUSED"):
            c.Ledger.bootstrap(self.db, self.anchor, acknowledge=c.BOOTSTRAP_ACK)


class Race(Base):
    """Exactly-once across real OS processes (the r0002 defect)."""

    def test_the_same_nonce_in_six_processes_is_accepted_exactly_once(self):
        self.fresh()
        results = self.collect(self.spawn("nonce", "N-SAME", n=6))
        lines = [r[1][-1] for r in results]
        self.assertEqual(lines.count("OK"), 1, results)
        self.assertEqual(sum(1 for x in lines if x == "ERR NONCE_REPLAY"), 5, results)
        self.assertTrue(all(r[0] == 0 for r in results), results)
        counts = c.Ledger.open(self.db, self.anchor).counts()
        self.assertEqual((counts["nonces"], counts["log"]), (1, 1))

    def test_the_same_receipt_in_six_processes_is_accepted_exactly_once(self):
        led = self.fresh()
        led.consume_nonce("N-1", "REQ-R1")
        results = self.collect(self.spawn("receipt", "REQ-R1", n=6))
        lines = [r[1][-1] for r in results]
        self.assertEqual(lines.count("OK"), 1, results)
        self.assertEqual(lines.count("ERR DUPLICATE_RECEIPT"), 5, results)
        self.assertEqual(led.counts()["accepted"], 1)

    def test_parallel_different_nonces_lose_no_update(self):
        self.fresh()
        procs = [subprocess.Popen([sys.executable, "-I", WORKER, "nonce", self.db, self.anchor, f"N-{i}", self.start],
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) for i in range(8)]
        open(self.start, "w").close()
        results = self.collect(procs)
        self.assertEqual([r[1][-1] for r in results], ["OK"] * 8, results)
        led = c.Ledger.open(self.db, self.anchor)           # open() verifies the anchor against the log
        counts = led.counts()
        self.assertEqual((counts["nonces"], counts["log"]), (8, 8))
        self.assertEqual(c._read_anchor(self.anchor)["seq"], 8)

    def test_two_processes_reserving_the_same_review_get_exactly_one_reservation(self):
        led = self.fresh()
        led.consume_nonce("N-1", "REQ-1")
        results = self.collect(self.spawn("reserve", "REQ-1", n=4))
        outs = [r[1][-1] for r in results]
        self.assertEqual(outs.count("OK"), 1, results)
        self.assertEqual(sum(1 for o in outs if o == "ERR REVIEW_ALREADY_RESERVED_NO_RETRY"), 3, results)

    def test_no_fixed_tmp_file_is_left_behind(self):
        self.fresh()
        self.collect(self.spawn("nonce", "N-X", n=4))
        self.assertEqual([f for f in os.listdir(self.dir) if f.endswith(".tmp")], [])


class Restart(Base):
    def test_replay_after_restart_is_refused(self):
        led = self.fresh()
        led.consume_nonce("N-1", "REQ-1")
        led.accept_receipt("REQ-1")
        again = c.Ledger.open(self.db, self.anchor)
        with self.assertRaisesRegex(c.ContractError, "NONCE_REPLAY"):
            again.consume_nonce("N-1", "REQ-2")
        with self.assertRaisesRegex(c.ContractError, "DUPLICATE_RECEIPT"):
            again.accept_receipt("REQ-1")

    def test_a_receipt_for_a_request_that_was_never_registered_is_refused(self):
        led = self.fresh()
        with self.assertRaisesRegex(c.ContractError, "REQUEST_NOT_REGISTERED"):
            led.accept_receipt("REQ-GHOST")
        with self.assertRaisesRegex(c.ContractError, "REQUEST_NOT_REGISTERED"):
            led.reserve_review("REQ-GHOST")


class StateLoss(Base):
    """The second r0002 defect: a missing file looked like a first start."""

    def test_deleting_the_database_after_use_is_fail_closed_not_a_fresh_start(self):
        led = self.fresh()
        led.consume_nonce("N-1", "REQ-1")
        os.remove(self.db)
        with self.assertRaisesRegex(c.ContractError, "STATE_MISSING_AFTER_INITIALIZATION"):
            c.Ledger.open(self.db, self.anchor)
        self.assertFalse(os.path.exists(self.db), "open() must not recreate an empty ledger")

    def test_deleting_the_anchor_is_fail_closed(self):
        self.fresh()
        os.remove(self.anchor)
        with self.assertRaisesRegex(c.ContractError, "ANCHOR_MISSING_FAIL_CLOSED"):
            c.Ledger.open(self.db, self.anchor)

    def test_restoring_an_older_copy_of_the_database_is_detected(self):
        led = self.fresh()
        led.consume_nonce("N-1", "REQ-1")
        old = os.path.join(self.dir, "old.sqlite")
        shutil.copy(self.db, old)
        led.consume_nonce("N-2", "REQ-2")
        shutil.copy(old, self.db)                               # roll the database back, anchor stays
        with self.assertRaisesRegex(c.ContractError, "STATE_ROLLBACK_DETECTED"):
            c.Ledger.open(self.db, self.anchor)

    def test_a_database_from_another_ledger_is_refused(self):
        self.fresh()
        other = tempfile.mkdtemp(prefix="ledger-other-")
        self.addCleanup(shutil.rmtree, other, ignore_errors=True)
        c.Ledger.bootstrap(os.path.join(other, "l.sqlite"), os.path.join(other, "l.anchor"), acknowledge=c.BOOTSTRAP_ACK)
        shutil.copy(os.path.join(other, "l.sqlite"), self.db)
        with self.assertRaisesRegex(c.ContractError, "GENESIS_MISMATCH"):
            c.Ledger.open(self.db, self.anchor)

    def test_a_history_that_differs_at_the_anchored_sequence_is_refused(self):
        led = self.fresh()
        led.consume_nonce("N-1", "REQ-1")
        con = sqlite3.connect(self.db)
        con.execute("UPDATE log SET head=? WHERE seq=1", ("f" * 64,))
        con.commit()
        con.close()
        with self.assertRaisesRegex(c.ContractError, "HISTORY_MISMATCH"):
            c.Ledger.open(self.db, self.anchor)

    def test_corrupt_files_fail_closed(self):
        self.fresh()
        with open(self.anchor, "w") as fh:
            fh.write("{ torn")
        with self.assertRaisesRegex(c.ContractError, "ANCHOR_UNREADABLE"):
            c.Ledger.open(self.db, self.anchor)
        shutil.rmtree(self.dir)
        os.makedirs(self.dir)
        self.fresh()
        with open(self.db, "wb") as fh:
            fh.write(b"this is not an sqlite file" * 50)
        with self.assertRaisesRegex(c.ContractError, "STATE_UNREADABLE"):
            c.Ledger.open(self.db, self.anchor)

    def test_after_state_loss_no_new_review_can_be_reserved(self):
        led = self.fresh()
        led.consume_nonce("N-1", "REQ-1")
        led.reserve_review("REQ-1")
        led.complete_review("REQ-1")
        os.remove(self.db)
        model_calls = []
        try:
            c.Ledger.open(self.db, self.anchor).reserve_review("REQ-1")
            model_calls.append("called")
        except c.ContractError:
            pass
        self.assertEqual(model_calls, [])


class CrashAndUncertain(Base):
    def test_a_review_whose_process_died_is_sealed_uncertain_and_never_rerun(self):
        led = self.fresh()
        led.consume_nonce("N-1", "REQ-1")
        results = self.collect(self.spawn("reserve", "REQ-1", "crash_after_reserve"))
        self.assertEqual(results[0][0], 7)
        self.assertEqual(led.review_state("REQ-1"), "RESERVED")
        self.assertEqual(led.recover_uncertain(), ["REQ-1"])
        self.assertEqual(led.review_state("REQ-1"), "UNCERTAIN")
        calls = []
        with self.assertRaisesRegex(c.ContractError, "REVIEW_ALREADY_RESERVED_NO_RETRY"):
            led.reserve_review("REQ-1")
            calls.append("model")
        self.assertEqual(calls, [])
        self.assertEqual(led.recover_uncertain(), [], "an UNCERTAIN review stays UNCERTAIN")

    def test_a_live_owner_is_not_sealed(self):
        led = self.fresh()
        led.consume_nonce("N-1", "REQ-1")
        led.reserve_review("REQ-1")
        self.assertEqual(led.recover_uncertain(), [])
        self.assertEqual(led.review_state("REQ-1"), "RESERVED")

    def test_crash_after_commit_but_before_the_anchor_update_keeps_the_nonce_used(self):
        self.fresh()
        results = self.collect(self.spawn("crash_before_anchor", "N-CRASH"))
        self.assertEqual(results[0][0], 9)
        self.assertEqual(c._read_anchor(self.anchor)["seq"], 0, "the anchor lags, which is the safe direction")
        led = c.Ledger.open(self.db, self.anchor)               # a lagging anchor is accepted
        with self.assertRaisesRegex(c.ContractError, "NONCE_REPLAY"):
            led.consume_nonce("N-CRASH", "REQ-OTHER")

    def test_an_action_that_raises_commits_nothing(self):
        led = self.fresh()

        def boom(con):
            con.execute("INSERT INTO nonces VALUES('N-HALF','REQ-HALF')")
            raise RuntimeError("simulated failure inside the transaction")
        with self.assertRaises(RuntimeError):
            led._mutate("X", "REQ-HALF", boom)
        self.assertEqual(led.counts(), {"nonces": 0, "accepted": 0, "reviews": 0, "log": 0})
        led.consume_nonce("N-HALF", "REQ-HALF")                 # not poisoned

    def test_an_os_error_while_replacing_the_anchor_is_fail_closed_and_loses_no_ledger_data(self):
        led = self.fresh()
        real = os.replace
        try:
            os.replace = lambda *a, **k: (_ for _ in ()).throw(PermissionError("simulated"))
            c_sleep, c.time.sleep = c.time.sleep, lambda s: None
            with self.assertRaisesRegex(c.ContractError, "ANCHOR_REPLACE_FAILED"):
                led.consume_nonce("N-1", "REQ-1")
        finally:
            os.replace = real
            c.time.sleep = c_sleep
        self.assertEqual([f for f in os.listdir(self.dir) if f.endswith(".tmp")], [])
        again = c.Ledger.open(self.db, self.anchor)             # committed row is there, anchor lags: still safe
        with self.assertRaisesRegex(c.ContractError, "NONCE_REPLAY"):
            again.consume_nonce("N-1", "REQ-2")


class LockOwnership(Base):
    def test_a_lock_held_by_a_process_that_dies_is_released(self):
        led = self.fresh()
        holder = self.spawn("hold_lock_then_die", "-", "0.4")[0]
        self.assertEqual(holder.stdout.readline().strip(), "LOCKED")
        led.consume_nonce("N-1", "REQ-1")                       # waits for the dying holder, then succeeds
        self.assertEqual(holder.wait(timeout=30), 5)

    def test_a_lock_held_by_a_live_process_times_out_fail_closed(self):
        led = self.fresh()
        holder = self.spawn("hold_lock_alive", "-", "3")[0]
        self.assertEqual(holder.stdout.readline().strip(), "LOCKED")
        old = c.LOCK_TIMEOUT_SECONDS
        c.LOCK_TIMEOUT_SECONDS = 0.5
        try:
            with self.assertRaisesRegex(c.ContractError, "LEDGER_LOCK_TIMEOUT_FAIL_CLOSED"):
                led.consume_nonce("N-1", "REQ-1")
        finally:
            c.LOCK_TIMEOUT_SECONDS = old
            holder.wait(timeout=30)
        self.assertEqual(led.counts()["nonces"], 0)


class WithContract(Base):
    """r0002's signature, window, cost and locality checks still apply on top of the ledger."""

    def setUp(self):
        super().setUp()
        self.ap, ap_pub = keypair()
        self.rp, rp_pub = keypair()
        self.signer_keys, self.reviewer_keys = {"approver-1": ap_pub}, {"reviewer-1": rp_pub}
        self.salt = c.new_salt()
        self.commit = c.artifact_commitment(ZIP_SHA, self.salt)
        self.ledger = self.fresh()

    def request(self, **o):
        a = dict(request_id="REQ-1", opaque_artifact_id=c.new_opaque_id(), commitment=self.commit, policy_revision=1, cost_cap_usd="0.00",
                 nonce="nonce-0123456789", issued_at=(NOW - timedelta(minutes=1)).isoformat(), expires_at=(NOW + timedelta(hours=12)).isoformat(),
                 repo_id="repo-1", signer_key_id="approver-1", signer_private=self.ap)
        a.update(o)
        return c.make_request(**a)

    def receipt(self, doc, **o):
        a = dict(request_doc=doc, verdict="PASS", reviewer_id="local", reviewer_locality="ON_PREM", review_text=b"local text",
                 finding_counts={"blocking": 0}, issued_at=NOW.isoformat(), reviewer_key_id="reviewer-1", reviewer_private=self.rp,
                 runtime_attestation_sha256="ab" * 32)
        a.update(o)
        return c.make_receipt(**a)

    def test_full_path_and_restart(self):
        doc = c.check_request(self.request(), self.signer_keys, now=NOW, ledger=self.ledger)
        c.bind_to_local_artifact(doc, ZIP_SHA, self.salt)
        self.ledger.reserve_review(doc["request_id"])
        c.accept_receipt(self.receipt(doc), self.reviewer_keys, doc, ledger=self.ledger)
        self.ledger.complete_review(doc["request_id"])
        again = c.Ledger.open(self.db, self.anchor)
        with self.assertRaisesRegex(c.ContractError, "NONCE_REPLAY"):
            c.check_request(self.request(request_id="REQ-2"), self.signer_keys, now=NOW, ledger=again)
        with self.assertRaisesRegex(c.ContractError, "DUPLICATE_RECEIPT"):
            c.accept_receipt(self.receipt(doc, verdict="FAIL"), self.reviewer_keys, doc, ledger=again)

    def test_a_bad_request_does_not_consume_the_nonce(self):
        with self.assertRaisesRegex(c.ContractError, "COST_NOT_ZERO"):
            c.check_request(self.request(cost_cap_usd="1.00"), self.signer_keys, now=NOW, ledger=self.ledger)
        c.check_request(self.request(), self.signer_keys, now=NOW, ledger=self.ledger)      # same nonce still usable

    def test_external_api_receipt_is_still_refused_and_not_recorded(self):
        doc = c.check_request(self.request(), self.signer_keys, now=NOW, ledger=self.ledger)
        with self.assertRaisesRegex(c.ContractError, "LOCALITY_NOT_ALLOWED"):
            c.accept_receipt(self.receipt(doc, reviewer_locality="EXTERNAL_API"), self.reviewer_keys, doc, ledger=self.ledger)
        self.assertEqual(self.ledger.counts()["accepted"], 0)

    def test_the_ledger_files_hold_no_digest_commitment_salt_or_review_text(self):
        doc = c.check_request(self.request(), self.signer_keys, now=NOW, ledger=self.ledger)
        c.accept_receipt(self.receipt(doc), self.reviewer_keys, doc, ledger=self.ledger)
        blob = b"".join(open(p, "rb").read() for p in (self.db, self.anchor))
        for secret in (ZIP_SHA, self.salt, self.commit, "local text"):
            self.assertNotIn(secret.encode(), blob)


if __name__ == "__main__":
    unittest.main()
