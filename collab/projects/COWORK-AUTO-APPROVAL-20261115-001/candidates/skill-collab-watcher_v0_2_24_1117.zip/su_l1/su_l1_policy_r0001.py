#!/usr/bin/env python3
"""SU-L1 single-user LOCAL_ONLY policy engine, prototype r0001 (design evidence; feature flag DEFAULT OFF).

Authority comes from an administrator-protected LOCAL policy file plus the local OS user - never from anything read
from GitHub. A GitHub request (READY, commit, author, write access) is only a CANDIDATE: without a verified local
policy it is denied. No Ed25519 key is needed in this mode; that is the point of SU-L1 for a single operator.

Honest limit: policy, watcher and the operator's administrator account live on ONE PC. If that administrator
account is compromised nothing here separates approval from execution. This engine does not claim otherwise.

Not wired into the watcher product, no service account / ACL / task is created by it (HOST_APPLIED=NOT_RUN).
Every decision is fail-closed and returns a stable code, never a path or a digest.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
from dataclasses import dataclass
from datetime import datetime, timezone

import local_only_contract_r0003 as ledger_mod

POLICY_SCHEMA = "SU_L1_POLICY_V1"
REQUEST_SCHEMA = "SU_L1_REQUEST_V1"
POLICY_FIELDS = {"schema", "policy_epoch", "repo_id", "branch", "allowed_work_ids", "artifact_dir", "reviewer_runner_id",
                 "reviewer_locality", "allowed_principal", "mode", "cost_cap_usd", "max_active_jobs", "max_attempts",
                 "issued_at", "expires_at"}
REQUEST_FIELDS = {"schema", "request_id", "work_id", "opaque_artifact_id", "artifact_commitment", "repo_id", "branch",
                  "nonce", "issued_at", "expires_at", "policy_epoch"}
ALLOWED_LOCALITY = ("ON_PREM", "HUMAN")
ADMIN_PRINCIPALS = ("NT AUTHORITY\\SYSTEM", "BUILTIN\\ADMINISTRATORS", "NT SERVICE\\TRUSTEDINSTALLER")
WRITE_MARKERS = re.compile(r"\((?:[^)]*,)?(?:F|M|W|WD|AD|WDAC|WO|GA|GW|DC)(?:,[^)]*)?\)")


@dataclass(frozen=True)
class Decision:
    allowed: bool
    code: str

    def __bool__(self):
        return self.allowed


def _deny(code: str) -> Decision:
    return Decision(False, code)


def _utc(text: str) -> datetime:
    value = datetime.fromisoformat(text.replace("Z", "+00:00"))
    if value.tzinfo is None:
        raise ValueError("tz")
    return value.astimezone(timezone.utc)


# ---- admin-protection check: injectable, with a read-only Windows implementation -------------------------------------
def parse_icacls(text: str, path: str) -> dict:
    """Parse `icacls <file>` output. Returns {'writers': [non-admin principals with a write-class right]}.
    Read-only; it never changes an ACL."""
    writers = []
    for raw in text.splitlines():
        line = raw.strip()
        if path and line.startswith(path):
            line = line[len(path):].strip()
        if ":(" not in line:
            continue
        principal, _, rights = line.partition(":(")
        rights = "(" + rights
        who = principal.strip()
        if who.upper() in ADMIN_PRINCIPALS:
            continue
        if "(DENY)" in rights.upper() or rights.upper().startswith("(DENY"):
            continue
        if WRITE_MARKERS.search(rights):
            writers.append(who)
    return {"writers": writers}


def windows_acl_checker(path: str) -> dict:
    out = subprocess.run(["icacls", path], capture_output=True, text=True, timeout=30)
    if out.returncode != 0:
        raise OSError("icacls failed")
    return parse_icacls(out.stdout, path)


def _local_principal() -> str:
    return f"{os.environ.get('USERDOMAIN', '')}\\{os.environ.get('USERNAME', '')}".strip("\\")


# ---- policy ------------------------------------------------------------------------------------------------------------
def load_policy(policy_path: str, *, now: datetime, acl_checker=windows_acl_checker) -> tuple[dict | None, Decision]:
    if not os.path.isfile(policy_path):
        return None, _deny("POLICY_MISSING_FAIL_CLOSED")
    try:
        report = acl_checker(policy_path)
    except Exception:
        return None, _deny("POLICY_ACL_UNVERIFIABLE_FAIL_CLOSED")
    if report.get("writers"):
        return None, _deny("POLICY_NOT_ADMIN_PROTECTED")
    try:
        with open(policy_path, "r", encoding="utf-8") as fh:
            policy = json.load(fh)
        if not isinstance(policy, dict) or set(policy) != POLICY_FIELDS or policy["schema"] != POLICY_SCHEMA:
            return None, _deny("POLICY_SCHEMA_INVALID")
        if policy["mode"] != "LOCAL_ONLY" or policy["cost_cap_usd"] != "0.00":
            return None, _deny("POLICY_MODE_OR_COST_INVALID")
        if policy["max_active_jobs"] != 1 or policy["max_attempts"] != 1:
            return None, _deny("POLICY_LIMITS_INVALID")
        if policy["reviewer_locality"] not in ALLOWED_LOCALITY:
            return None, _deny("POLICY_LOCALITY_INVALID")
        if not isinstance(policy["policy_epoch"], int) or isinstance(policy["policy_epoch"], bool) or policy["policy_epoch"] < 1:
            return None, _deny("POLICY_EPOCH_INVALID")
        if not isinstance(policy["allowed_work_ids"], list) or not policy["allowed_work_ids"] or not all(isinstance(w, str) and w for w in policy["allowed_work_ids"]):
            return None, _deny("POLICY_WORK_IDS_INVALID")
        for key in ("repo_id", "branch", "artifact_dir", "reviewer_runner_id", "allowed_principal"):
            if not isinstance(policy[key], str) or not policy[key]:
                return None, _deny("POLICY_SCHEMA_INVALID")
        if not _utc(policy["issued_at"]) <= now < _utc(policy["expires_at"]):
            return None, _deny("POLICY_EXPIRED_OR_NOT_YET_VALID")
    except (OSError, ValueError, KeyError, TypeError):
        return None, _deny("POLICY_UNREADABLE_FAIL_CLOSED")
    return policy, Decision(True, "POLICY_OK")


def _inside(base_dir: str, target: str) -> bool:
    base_real, target_real = os.path.realpath(base_dir), os.path.realpath(target)
    try:
        return os.path.commonpath([base_real, target_real]) == base_real and target_real != base_real
    except ValueError:                                      # different drives
        return False


def authorize(request: dict, *, enabled: bool, policy_path: str, kill_switch_path: str, ledger: "ledger_mod.Ledger",
              now: datetime, reviewer_runner_id: str, artifact_path: str, artifact_salt_hex: str,
              local_principal: str | None = None, acl_checker=windows_acl_checker) -> Decision:
    """Everything that must hold before ONE local review may start. On success the nonce is consumed and the review is
    atomically reserved (cap: 1 active job); the caller may then run the reviewer exactly once."""
    if enabled is not True:
        return _deny("SU_L1_DISABLED")                      # feature flag, default off
    if os.path.exists(kill_switch_path):
        return _deny("KILL_SWITCH_ACTIVE")
    policy, decision = load_policy(policy_path, now=now, acl_checker=acl_checker)
    if policy is None:
        return decision
    who = (local_principal if local_principal is not None else _local_principal()).lower()
    if who != policy["allowed_principal"].lower():
        return _deny("PRINCIPAL_NOT_ALLOWED")
    if reviewer_runner_id != policy["reviewer_runner_id"]:
        return _deny("REVIEWER_NOT_ALLOWED")
    if not isinstance(request, dict) or set(request) != REQUEST_FIELDS or request["schema"] != REQUEST_SCHEMA:
        return _deny("REQUEST_FIELDS_INVALID")              # also rejects any 'approved'/'authorized' field riding along
    if request["repo_id"] != policy["repo_id"] or request["branch"] != policy["branch"]:
        return _deny("REPO_OR_BRANCH_NOT_ALLOWED")
    if request["work_id"] not in policy["allowed_work_ids"]:
        return _deny("WORK_ID_NOT_ALLOWED")
    if request["policy_epoch"] != policy["policy_epoch"]:
        return _deny("POLICY_EPOCH_MISMATCH")
    try:
        if not _utc(request["issued_at"]) <= now < _utc(request["expires_at"]):
            return _deny("REQUEST_NOT_IN_VALIDITY_WINDOW")
    except (ValueError, TypeError):
        return _deny("REQUEST_FIELDS_INVALID")
    if not _inside(policy["artifact_dir"], artifact_path) or os.path.islink(artifact_path) or not os.path.isfile(artifact_path):
        return _deny("ARTIFACT_OUTSIDE_APPROVED_DIR")
    try:
        digest = hashlib.sha256(open(artifact_path, "rb").read()).hexdigest()
        ledger_mod.bind_to_local_artifact(request, digest, artifact_salt_hex)
    except (ledger_mod.ContractError, OSError):
        return _deny("ARTIFACT_DOES_NOT_MATCH_COMMITMENT")
    try:
        ledger.bind_policy_epoch(policy["policy_epoch"])
        ledger.consume_nonce(request["nonce"], request["request_id"])
        ledger.reserve_review(request["request_id"], max_active=policy["max_active_jobs"])
    except ledger_mod.ContractError as err:
        return _deny(str(err))
    return Decision(True, "AUTHORIZED_ONE_LOCAL_REVIEW")
