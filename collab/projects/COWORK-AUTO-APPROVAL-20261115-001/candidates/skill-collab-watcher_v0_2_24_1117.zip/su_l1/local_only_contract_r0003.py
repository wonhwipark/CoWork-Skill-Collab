#!/usr/bin/env python3
"""LOCAL_ONLY review contract, prototype r0003 (supersedes r0002; r0001/r0002 stay as history).

Design evidence for the single-user SU-L1 LOCAL_ONLY mode, NOT a deployed protocol and NOT wired into the watcher
product (CONTRACT_INTEGRATION=NOT_RUN). It fixes the two operational risks found in r0002 by GPT's static review:

 (a) r0002 kept used nonces / accepted receipts in an in-memory set and rewrote a JSON file through ONE fixed
     ".tmp" name with no cross-process lock: two processes could both accept the same nonce or receipt.
     r0003 keeps them in a private SQLite ledger. Every mutation runs under an OS file lock AND BEGIN IMMEDIATE, and
     the uniqueness is enforced by PRIMARY KEYs, so exactly one process wins.
 (b) r0002 started with empty sets when the state file was MISSING, so deleting the file re-enabled every old nonce.
     r0003 separates first creation from loss: the ledger needs an explicit one-time bootstrap, then an out-of-database
     ANCHOR file (genesis id + sequence + hash-chain head). A missing / older / foreign ledger is FAIL_CLOSED.

This ledger is a NEW private file pair. It never opens or touches the watcher's operating database.
What it still cannot prove: that a reviewer really ran on-premises (a signed CLAIM, ATTESTED_NOT_VERIFIED), and it
cannot stop an attacker who controls both ledger and anchor on the same host (same-host trust limit, see SU-L1 text).
"""
from __future__ import annotations

import hashlib
import json
import os
import secrets
import sqlite3
import sys
import time
from datetime import datetime

import local_only_contract_r0002 as base

ContractError = base.ContractError
BOOTSTRAP_ACK = "BOOTSTRAP_NEW_LEDGER_NO_PRIOR_STATE_EXISTS"
LOCK_TIMEOUT_SECONDS = 30.0
GENESIS_HEAD = "0" * 64
REVIEW_STATES = ("RESERVED", "COMPLETED", "UNCERTAIN")

_SCHEMA = """
CREATE TABLE meta(k TEXT PRIMARY KEY, v TEXT NOT NULL);
CREATE TABLE nonces(nonce TEXT PRIMARY KEY, request_id TEXT NOT NULL UNIQUE);
CREATE TABLE accepted(request_id TEXT PRIMARY KEY);
CREATE TABLE reviews(request_id TEXT PRIMARY KEY, state TEXT NOT NULL, owner_pid INTEGER NOT NULL);
CREATE TABLE log(seq INTEGER PRIMARY KEY, op TEXT NOT NULL, key TEXT NOT NULL, head TEXT NOT NULL);
"""


class _FileLock:
    """Cross-process lock on a side file (msvcrt on Windows, fcntl elsewhere). Released automatically if the holder dies."""

    def __init__(self, path: str):
        self.path, self.fd = path, None

    def __enter__(self):
        self.fd = os.open(self.path, os.O_RDWR | os.O_CREAT)
        if os.fstat(self.fd).st_size == 0:
            os.write(self.fd, b"L")
        deadline = time.monotonic() + LOCK_TIMEOUT_SECONDS
        while True:
            try:
                if sys.platform == "win32":
                    import msvcrt
                    os.lseek(self.fd, 0, 0)
                    msvcrt.locking(self.fd, msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                return self
            except OSError:
                if time.monotonic() > deadline:
                    os.close(self.fd)
                    raise ContractError("LEDGER_LOCK_TIMEOUT_FAIL_CLOSED") from None
                time.sleep(0.01)

    def __exit__(self, *exc):
        try:
            if sys.platform == "win32":
                import msvcrt
                os.lseek(self.fd, 0, 0)
                msvcrt.locking(self.fd, msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.fd, fcntl.LOCK_UN)
        finally:
            os.close(self.fd)


def _chain(prev_head: str, op: str, key: str) -> str:
    return hashlib.sha256(f"{prev_head}|{op}|{key}".encode("utf-8")).hexdigest()


def _read_anchor(path: str) -> dict:
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if set(data) != {"genesis", "seq", "head"} or not isinstance(data["seq"], int):
            raise ValueError
        return data
    except (OSError, ValueError, TypeError):
        raise ContractError("ANCHOR_UNREADABLE_FAIL_CLOSED") from None


def _write_anchor(path: str, data: dict) -> None:
    """Unique temp name per writer (r0002 shared one fixed '.tmp', so two writers could clobber each other)."""
    temp = f"{path}.{os.getpid()}.{secrets.token_hex(4)}.tmp"
    with open(temp, "w", encoding="utf-8") as fh:
        json.dump(data, fh)
        fh.flush()
        os.fsync(fh.fileno())
    for attempt in range(50):                       # a concurrent reader can briefly block os.replace on Windows
        try:
            os.replace(temp, path)
            return
        except PermissionError:
            time.sleep(0.02)
    try:
        os.unlink(temp)
    except OSError:
        pass
    raise ContractError("ANCHOR_REPLACE_FAILED_FAIL_CLOSED")


class Ledger:
    """Durable, multi-process-safe ledger of used nonces, accepted receipts and review reservations."""

    def __init__(self, db_path: str, anchor_path: str, *, _verified: bool):
        if not _verified:
            raise ContractError("USE_Ledger.open_OR_Ledger.bootstrap")
        self.db_path, self.anchor_path = db_path, anchor_path
        self.lock_path = db_path + ".lock"

    # ---- lifecycle -------------------------------------------------------------------------------------------
    @classmethod
    def bootstrap(cls, db_path: str, anchor_path: str, *, acknowledge: str) -> "Ledger":
        """The ONE explicit first creation. Refuses when either file already exists, so a lost file can never be
        'fixed' by re-bootstrapping over the remains; a deliberate re-seed must be done offline by the operator."""
        if acknowledge != BOOTSTRAP_ACK:
            raise ContractError("BOOTSTRAP_NOT_ACKNOWLEDGED")
        if os.path.exists(db_path) or os.path.exists(anchor_path):
            raise ContractError("BOOTSTRAP_REFUSED_STATE_ALREADY_EXISTS")
        genesis = secrets.token_hex(16)
        con = sqlite3.connect(db_path, isolation_level=None)
        try:
            con.execute("PRAGMA synchronous=FULL")
            con.executescript(_SCHEMA)
            con.execute("INSERT INTO meta VALUES('genesis',?)", (genesis,))
            con.execute("INSERT INTO meta VALUES('seq','0')")
            con.execute("INSERT INTO meta VALUES('head',?)", (GENESIS_HEAD,))
        finally:
            con.close()
        _write_anchor(anchor_path, {"genesis": genesis, "seq": 0, "head": GENESIS_HEAD})
        return cls.open(db_path, anchor_path)

    @classmethod
    def open(cls, db_path: str, anchor_path: str) -> "Ledger":
        have_db, have_anchor = os.path.exists(db_path), os.path.exists(anchor_path)
        if not have_db and not have_anchor:
            raise ContractError("LEDGER_NOT_INITIALIZED_FAIL_CLOSED")
        if not have_db:
            raise ContractError("STATE_MISSING_AFTER_INITIALIZATION")
        if not have_anchor:
            raise ContractError("ANCHOR_MISSING_FAIL_CLOSED")
        ledger = cls(db_path, anchor_path, _verified=True)
        ledger._verify()
        return ledger

    def _connect(self) -> sqlite3.Connection:
        if not os.path.exists(self.db_path):             # sqlite3.connect would silently CREATE an empty ledger
            raise ContractError("STATE_MISSING_AFTER_INITIALIZATION")
        con = sqlite3.connect(self.db_path, timeout=LOCK_TIMEOUT_SECONDS, isolation_level=None)
        con.execute("PRAGMA synchronous=FULL")
        return con

    def _verify(self) -> None:
        anchor = _read_anchor(self.anchor_path)
        try:
            con = self._connect()
            try:
                meta = dict(con.execute("SELECT k,v FROM meta").fetchall())
                if con.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                    raise ContractError("STATE_UNREADABLE_FAIL_CLOSED")
                seq = int(meta["seq"])
                if meta["genesis"] != anchor["genesis"]:
                    raise ContractError("LEDGER_GENESIS_MISMATCH_FAIL_CLOSED")
                if seq < anchor["seq"]:
                    raise ContractError("STATE_ROLLBACK_DETECTED_FAIL_CLOSED")
                if anchor["seq"] > 0:
                    row = con.execute("SELECT head FROM log WHERE seq=?", (anchor["seq"],)).fetchone()
                    if row is None or row[0] != anchor["head"]:
                        raise ContractError("LEDGER_HISTORY_MISMATCH_FAIL_CLOSED")
                elif anchor["head"] != GENESIS_HEAD:
                    raise ContractError("LEDGER_HISTORY_MISMATCH_FAIL_CLOSED")
            finally:
                con.close()
        except ContractError:                            # ContractError is a ValueError: keep the specific reason
            raise
        except sqlite3.Error:
            raise ContractError("STATE_UNREADABLE_FAIL_CLOSED") from None
        except (KeyError, ValueError):
            raise ContractError("STATE_UNREADABLE_FAIL_CLOSED") from None

    # ---- atomic mutation -------------------------------------------------------------------------------------
    def _mutate(self, op: str, key: str, action) -> None:
        """Lock -> verify anchor -> BEGIN IMMEDIATE -> action -> bump seq/head -> COMMIT -> raise anchor.
        If `action` raises, nothing is committed."""
        with _FileLock(self.lock_path):
            self._verify()
            con = self._connect()
            try:
                con.execute("BEGIN IMMEDIATE")
                try:
                    action(con)
                    seq = int(con.execute("SELECT v FROM meta WHERE k='seq'").fetchone()[0]) + 1
                    head = _chain(con.execute("SELECT v FROM meta WHERE k='head'").fetchone()[0], op, key)
                    con.execute("INSERT INTO log VALUES(?,?,?,?)", (seq, op, key, head))
                    con.execute("UPDATE meta SET v=? WHERE k='seq'", (str(seq),))
                    con.execute("UPDATE meta SET v=? WHERE k='head'", (head,))
                    genesis = con.execute("SELECT v FROM meta WHERE k='genesis'").fetchone()[0]
                    con.execute("COMMIT")
                except BaseException:
                    if con.in_transaction:
                        con.execute("ROLLBACK")
                    raise
            finally:
                con.close()
            _write_anchor(self.anchor_path, {"genesis": genesis, "seq": seq, "head": head})

    def consume_nonce(self, nonce: str, request_id: str) -> None:
        def action(con):
            try:
                con.execute("INSERT INTO nonces VALUES(?,?)", (nonce, request_id))
            except sqlite3.IntegrityError:
                raise ContractError("NONCE_REPLAY") from None
        self._mutate("NONCE", request_id, action)

    def accept_receipt(self, request_id: str) -> None:
        def action(con):
            if con.execute("SELECT 1 FROM nonces WHERE request_id=?", (request_id,)).fetchone() is None:
                raise ContractError("REQUEST_NOT_REGISTERED")
            try:
                con.execute("INSERT INTO accepted VALUES(?)", (request_id,))
            except sqlite3.IntegrityError:
                raise ContractError("DUPLICATE_RECEIPT") from None
        self._mutate("RECEIPT", request_id, action)

    def reserve_review(self, request_id: str, *, max_active: int | None = None) -> None:
        """Atomic, one-per-request reservation made BEFORE any reviewer is started. Max one attempt: a second call for
        the same request is refused whatever the first outcome was (including a crash), so the model cannot be
        called twice automatically. `max_active` caps concurrently RESERVED reviews inside the same transaction
        (check and reserve are one atomic step, so two processes cannot both slip under the cap)."""
        def action(con):
            if con.execute("SELECT 1 FROM nonces WHERE request_id=?", (request_id,)).fetchone() is None:
                raise ContractError("REQUEST_NOT_REGISTERED")
            if max_active is not None and con.execute("SELECT COUNT(*) FROM reviews WHERE state='RESERVED'").fetchone()[0] >= max_active:
                raise ContractError("ACTIVE_JOB_LIMIT_REACHED")
            try:
                con.execute("INSERT INTO reviews VALUES(?,?,?)", (request_id, "RESERVED", os.getpid()))
            except sqlite3.IntegrityError:
                raise ContractError("REVIEW_ALREADY_RESERVED_NO_RETRY") from None
        self._mutate("RESERVE", request_id, action)

    def bind_policy_epoch(self, epoch: int) -> None:
        """The policy epoch only moves forward: an older (rolled-back) policy file can never become active again."""
        def action(con):
            row = con.execute("SELECT v FROM meta WHERE k='policy_epoch'").fetchone()
            if row is not None and int(row[0]) > epoch:
                raise ContractError("POLICY_EPOCH_ROLLBACK")
            if row is None:
                con.execute("INSERT INTO meta VALUES('policy_epoch',?)", (str(epoch),))
            elif int(row[0]) != epoch:
                con.execute("UPDATE meta SET v=? WHERE k='policy_epoch'", (str(epoch),))
        self._mutate("EPOCH", str(epoch), action)

    def complete_review(self, request_id: str) -> None:
        def action(con):
            n = con.execute("UPDATE reviews SET state='COMPLETED' WHERE request_id=? AND state='RESERVED'", (request_id,)).rowcount
            if n != 1:
                raise ContractError("REVIEW_NOT_IN_RESERVED_STATE")
        self._mutate("COMPLETE", request_id, action)

    def recover_uncertain(self, is_alive=None) -> list[str]:
        """After a crash/restart: every RESERVED row whose owner process is gone is sealed UNCERTAIN. Never re-reserved,
        never re-run; the operator decides what an UNCERTAIN review means."""
        alive = is_alive or _pid_alive
        sealed: list[str] = []

        def action(con):
            for rid, pid in con.execute("SELECT request_id, owner_pid FROM reviews WHERE state='RESERVED'").fetchall():
                if not alive(pid):
                    con.execute("UPDATE reviews SET state='UNCERTAIN' WHERE request_id=?", (rid,))
                    sealed.append(rid)
        self._mutate("RECOVER", "-", action)
        return sealed

    # ---- reads -------------------------------------------------------------------------------------------------
    def review_state(self, request_id: str):
        self._verify()
        con = self._connect()
        try:
            row = con.execute("SELECT state FROM reviews WHERE request_id=?", (request_id,)).fetchone()
        finally:
            con.close()
        return row[0] if row else None

    def counts(self) -> dict:
        self._verify()
        con = self._connect()
        try:
            return {t: con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in ("nonces", "accepted", "reviews", "log")}
        finally:
            con.close()


def _pid_alive(pid: int) -> bool:
    if pid == os.getpid():
        return True
    if sys.platform == "win32":
        import ctypes
        handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))      # PROCESS_QUERY_LIMITED_INFORMATION
        if not handle:
            return False
        code = ctypes.c_ulong()
        ok = ctypes.windll.kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
        ctypes.windll.kernel32.CloseHandle(handle)
        return bool(ok) and code.value == 259                                       # STILL_ACTIVE
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


# ---- request / receipt checks: signature, fields, window, cost and locality are r0002's; state is the ledger ------
def check_request(envelope: dict, signer_keys: dict, *, now: datetime, ledger: Ledger) -> dict:
    doc = base.check_request(envelope, signer_keys, now=now, seen_nonces=set())      # stateless checks only
    ledger.consume_nonce(doc["nonce"], doc["request_id"])
    return doc


def accept_receipt(envelope: dict, reviewer_keys: dict, request_doc: dict, *, ledger: Ledger) -> dict:
    doc = base.ReceiptLedger().accept(envelope, reviewer_keys, request_doc)           # stateless checks only
    ledger.accept_receipt(doc["request_id"])
    return doc


# pure helpers re-exported unchanged
canonical, new_salt, new_opaque_id = base.canonical, base.new_salt, base.new_opaque_id
artifact_commitment, bind_to_local_artifact = base.artifact_commitment, base.bind_to_local_artifact
assert_publishable, make_request, make_receipt = base.assert_publishable, base.make_request, base.make_receipt
