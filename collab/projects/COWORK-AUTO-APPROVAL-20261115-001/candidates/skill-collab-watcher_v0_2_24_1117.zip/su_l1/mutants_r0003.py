"""Mutation check for local_only_contract_r0003: each mutant must make the test-suite FAIL (so the tests have teeth)."""
import os, shutil, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = open(os.path.join(HERE, "local_only_contract_r0003.py"), encoding="utf-8").read()
M = {
 "nonce_replay_ignored": ('con.execute("INSERT INTO nonces VALUES(?,?)", (nonce, request_id))', 'con.execute("INSERT OR IGNORE INTO nonces VALUES(?,?)", (nonce, request_id))'),
 "duplicate_receipt_ignored": ('con.execute("INSERT INTO accepted VALUES(?)", (request_id,))', 'con.execute("INSERT OR IGNORE INTO accepted VALUES(?)", (request_id,))'),
 "review_re_reservation_allowed": ('con.execute("INSERT INTO reviews VALUES(?,?,?)", (request_id, "RESERVED", os.getpid()))', 'con.execute("INSERT OR REPLACE INTO reviews VALUES(?,?,?)", (request_id, "RESERVED", os.getpid()))'),
 "missing_db_treated_as_fresh": ('            raise ContractError("STATE_MISSING_AFTER_INITIALIZATION")', '            return cls.bootstrap(db_path, anchor_path, acknowledge=BOOTSTRAP_ACK) if False else cls._fresh_for_mutant(db_path, anchor_path)'),
 "missing_anchor_tolerated": ('            raise ContractError("ANCHOR_MISSING_FAIL_CLOSED")', '            pass'),
 "rollback_not_checked": ('if seq < anchor["seq"]:', 'if False:'),
 "genesis_not_checked": ('if meta["genesis"] != anchor["genesis"]:', 'if False:'),
 "history_not_checked": ('if row is None or row[0] != anchor["head"]:', 'if False:'),
 "uncertain_never_sealed": ('if not alive(pid):', 'if False:'),
 "dead_owner_never_detected_live_sealed": ('if not alive(pid):', 'if alive(pid):'),
 "reason_masked_as_unreadable": ('        except ContractError:                            # ContractError is a ValueError: keep the specific reason\n            raise\n', ''),
 "nonce_consumed_before_stateless_checks": ('    doc = base.check_request(envelope, signer_keys, now=now, seen_nonces=set())      # stateless checks only\n    ledger.consume_nonce(doc["nonce"], doc["request_id"])',
                                              '    ledger.consume_nonce(envelope["document"]["nonce"], envelope["document"]["request_id"])\n    doc = base.check_request(envelope, signer_keys, now=now, seen_nonces=set())'),
 "receipt_without_registered_request": ('            if con.execute("SELECT 1 FROM nonces WHERE request_id=?", (request_id,)).fetchone() is None:\n                raise ContractError("REQUEST_NOT_REGISTERED")\n            try:\n                con.execute("INSERT INTO accepted', '            try:\n                con.execute("INSERT INTO accepted'),
 "transaction_not_rolled_back": ('                    if con.in_transaction:\n                        con.execute("ROLLBACK")\n                    raise', '                    con.execute("COMMIT")\n                    raise'),
}
FRESH = '''
    @classmethod
    def _fresh_for_mutant(cls, db_path, anchor_path):
        for p in (db_path, anchor_path):
            if os.path.exists(p): os.remove(p)
        return cls.bootstrap(db_path, anchor_path, acknowledge=BOOTSTRAP_ACK)
'''
survived = []
for name, (old, new) in M.items():
    if old not in SRC:
        print("MUTANT TEXT NOT FOUND:", name); survived.append(name + "(not-applied)"); continue
    d = tempfile.mkdtemp(prefix="mut-")
    try:
        for f in os.listdir(HERE):
            if f.endswith(".py") and f != "mutants_r0003.py":
                shutil.copy(os.path.join(HERE, f), d)
        code = SRC.replace(old, new)
        if "_fresh_for_mutant" in code:
            code = code.replace("    # ---- lifecycle", FRESH + "\n    # ---- lifecycle", 1)
        open(os.path.join(d, "local_only_contract_r0003.py"), "w", encoding="utf-8").write(code)
        r = subprocess.run([sys.executable, "-m", "unittest", "test_local_only_contract_r0003"], cwd=d, capture_output=True, text=True, timeout=300)
        killed = r.returncode != 0
        print(("KILLED  " if killed else "SURVIVED"), name)
        if not killed: survived.append(name)
    finally:
        shutil.rmtree(d, ignore_errors=True)
print("mutants:", len(M), "survived:", survived)
sys.exit(1 if survived else 0)
