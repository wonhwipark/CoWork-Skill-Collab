"""Test helper process for local_only_contract_r0003 (spawned by the tests; never a product entry point).
Usage: ledger_worker_r0003.py <op> <db> <anchor> <key> <start_file> [extra]
Waits until <start_file> exists so several workers hit the ledger at the same moment, prints one result line."""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import local_only_contract_r0003 as c  # noqa: E402

op, db, anchor, key, start = sys.argv[1:6]
extra = sys.argv[6] if len(sys.argv) > 6 else ""
deadline = time.monotonic() + 30
while not os.path.exists(start) and time.monotonic() < deadline:
    time.sleep(0.002)
try:
    if op == "nonce":
        c.Ledger.open(db, anchor).consume_nonce(key, "REQ-" + (extra or key))
    elif op == "receipt":
        c.Ledger.open(db, anchor).accept_receipt(key)
    elif op == "reserve":
        c.Ledger.open(db, anchor).reserve_review(key)
        print("OK", flush=True)
        if extra == "crash_after_reserve":
            os._exit(7)                      # the process dies with the reservation still RESERVED (a crash mid-review)
        sys.exit(0)
    elif op == "crash_before_anchor":
        c._write_anchor = lambda *a, **k: os._exit(9)   # commit succeeded, the process dies before the anchor is raised
        c.Ledger.open(db, anchor).consume_nonce(key, "REQ-" + key)
    elif op == "hold_lock_then_die":
        lock = c._FileLock(db + ".lock")
        lock.__enter__()
        print("LOCKED", flush=True)
        time.sleep(float(extra or "0.3"))
        os._exit(5)                          # dies while holding the OS lock
    elif op == "hold_lock_alive":
        lock = c._FileLock(db + ".lock")
        lock.__enter__()
        print("LOCKED", flush=True)
        time.sleep(float(extra or "3"))
        lock.__exit__(None, None, None)
    print("OK")
except c.ContractError as err:
    print("ERR", err)
