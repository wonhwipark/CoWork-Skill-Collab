import copy
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone

import local_only_contract_r0003 as L
import su_l1_policy_r0001 as P

NOW = datetime(2026, 11, 14, 12, 0, tzinfo=timezone.utc)
ZIP = b"pretend confidential source archive"
PROTECTED = lambda path: {"writers": []}                    # noqa: E731  (administrator-only ACL)
USER = "PC\\operator"


class Env(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp(prefix="sul1-")
        self.addCleanup(shutil.rmtree, self.dir, ignore_errors=True)
        self.art_dir = os.path.join(self.dir, "vault")
        os.makedirs(self.art_dir)
        self.artifact = os.path.join(self.art_dir, "candidate.zip")
        open(self.artifact, "wb").write(ZIP)
        self.salt = L.new_salt()
        self.commit = L.artifact_commitment(hashlib.sha256(ZIP).hexdigest(), self.salt)
        self.policy_path = os.path.join(self.dir, "review-policy.json")
        self.kill = os.path.join(self.dir, "KILL")
        self.policy = {"schema": P.POLICY_SCHEMA, "policy_epoch": 3, "repo_id": "R_kgDOabc", "branch": "main",
                       "allowed_work_ids": ["WORK-1"], "artifact_dir": self.art_dir, "reviewer_runner_id": "onprem-runner-1",
                       "reviewer_locality": "ON_PREM", "allowed_principal": USER, "mode": "LOCAL_ONLY", "cost_cap_usd": "0.00",
                       "max_active_jobs": 1, "max_attempts": 1, "issued_at": (NOW - timedelta(days=1)).isoformat(),
                       "expires_at": (NOW + timedelta(days=30)).isoformat()}
        self.write_policy()
        db, anchor = os.path.join(self.dir, "l.sqlite"), os.path.join(self.dir, "l.anchor")
        self.ledger = L.Ledger.bootstrap(db, anchor, acknowledge=L.BOOTSTRAP_ACK)

    def write_policy(self, **override):
        doc = dict(self.policy, **override)
        json.dump(doc, open(self.policy_path, "w"))

    def request(self, **o):
        r = {"schema": P.REQUEST_SCHEMA, "request_id": "REQ-1", "work_id": "WORK-1", "opaque_artifact_id": L.new_opaque_id(),
             "artifact_commitment": self.commit, "repo_id": "R_kgDOabc", "branch": "main", "nonce": "nonce-000000000001",
             "issued_at": (NOW - timedelta(minutes=1)).isoformat(), "expires_at": (NOW + timedelta(hours=6)).isoformat(), "policy_epoch": 3}
        r.update(o)
        return r

    def go(self, request=None, **o):
        args = dict(enabled=True, policy_path=self.policy_path, kill_switch_path=self.kill, ledger=self.ledger, now=NOW,
                    reviewer_runner_id="onprem-runner-1", artifact_path=self.artifact, artifact_salt_hex=self.salt,
                    local_principal=USER, acl_checker=PROTECTED)
        args.update(o)
        return P.authorize(request if request is not None else self.request(), **args)


class Authorize(Env):
    def test_a_fully_valid_local_request_is_authorised_once_and_reserves_the_review(self):
        d = self.go()
        self.assertTrue(d, d.code)
        self.assertEqual(d.code, "AUTHORIZED_ONE_LOCAL_REVIEW")
        self.assertEqual(self.ledger.review_state("REQ-1"), "RESERVED")

    def test_the_feature_flag_defaults_to_off(self):
        import inspect
        self.assertEqual(self.go(enabled=False).code, "SU_L1_DISABLED")
        self.assertEqual(self.go(enabled=None).code, "SU_L1_DISABLED")
        self.assertEqual(self.go(enabled="true").code, "SU_L1_DISABLED")
        self.assertIsNone(self.ledger.review_state("REQ-1"))

    def test_a_github_request_without_a_local_policy_is_never_authorised(self):
        os.remove(self.policy_path)
        self.assertEqual(self.go().code, "POLICY_MISSING_FAIL_CLOSED")

    def test_a_request_cannot_carry_its_own_approval(self):
        for extra in ("approved", "authorized", "ready", "signature"):
            r = self.request()
            r[extra] = True
            self.assertEqual(self.go(r).code, "REQUEST_FIELDS_INVALID", extra)

    def test_policy_that_a_non_admin_can_write_is_refused(self):
        self.assertEqual(self.go(acl_checker=lambda p: {"writers": ["PC\\operator"]}).code, "POLICY_NOT_ADMIN_PROTECTED")

    def test_an_acl_check_that_cannot_run_is_fail_closed(self):
        def broken(path):
            raise OSError("no icacls")
        self.assertEqual(self.go(acl_checker=broken).code, "POLICY_ACL_UNVERIFIABLE_FAIL_CLOSED")

    def test_kill_switch_stops_everything(self):
        open(self.kill, "w").close()
        self.assertEqual(self.go().code, "KILL_SWITCH_ACTIVE")

    def test_expired_not_yet_valid_and_malformed_policy_are_refused(self):
        self.write_policy(expires_at=(NOW - timedelta(seconds=1)).isoformat())
        self.assertEqual(self.go().code, "POLICY_EXPIRED_OR_NOT_YET_VALID")
        self.write_policy(issued_at=(NOW + timedelta(hours=1)).isoformat())
        self.assertEqual(self.go().code, "POLICY_EXPIRED_OR_NOT_YET_VALID")
        open(self.policy_path, "w").write("{ nope")
        self.assertEqual(self.go().code, "POLICY_UNREADABLE_FAIL_CLOSED")

    def test_policy_limits_are_enforced_by_schema(self):
        cases = (("cost_cap_usd", "0.01", "POLICY_MODE_OR_COST_INVALID"), ("mode", "EXTERNAL_API", "POLICY_MODE_OR_COST_INVALID"),
                 ("max_active_jobs", 2, "POLICY_LIMITS_INVALID"), ("max_attempts", 3, "POLICY_LIMITS_INVALID"),
                 ("reviewer_locality", "EXTERNAL_API", "POLICY_LOCALITY_INVALID"), ("policy_epoch", 0, "POLICY_EPOCH_INVALID"),
                 ("allowed_work_ids", [], "POLICY_WORK_IDS_INVALID"))
        for key, value, code in cases:
            self.write_policy(**{key: value})
            self.assertEqual(self.go().code, code, key)
        doc = dict(self.policy)
        doc["extra"] = 1
        json.dump(doc, open(self.policy_path, "w"))
        self.assertEqual(self.go().code, "POLICY_SCHEMA_INVALID")

    def test_other_os_user_other_reviewer_repo_branch_work_epoch_are_refused(self):
        self.assertEqual(self.go(local_principal="PC\\someone-else").code, "PRINCIPAL_NOT_ALLOWED")
        self.assertEqual(self.go(local_principal="pc\\OPERATOR").code, "AUTHORIZED_ONE_LOCAL_REVIEW")   # case-insensitive
        self.assertEqual(self.go(reviewer_runner_id="claude-code-dev-session").code, "REVIEWER_NOT_ALLOWED")
        self.assertEqual(self.go(self.request(repo_id="R_other")).code, "REPO_OR_BRANCH_NOT_ALLOWED")
        self.assertEqual(self.go(self.request(branch="dev", nonce="n-2")).code, "REPO_OR_BRANCH_NOT_ALLOWED")
        self.assertEqual(self.go(self.request(work_id="WORK-X", nonce="n-3")).code, "WORK_ID_NOT_ALLOWED")
        self.assertEqual(self.go(self.request(policy_epoch=2, nonce="n-4")).code, "POLICY_EPOCH_MISMATCH")

    def test_expired_request_is_refused(self):
        r = self.request(expires_at=(NOW - timedelta(minutes=1)).isoformat())
        self.assertEqual(self.go(r).code, "REQUEST_NOT_IN_VALIDITY_WINDOW")

    def test_artifact_must_be_inside_the_approved_directory_and_match_the_commitment(self):
        outside = os.path.join(self.dir, "elsewhere.zip")
        open(outside, "wb").write(ZIP)
        self.assertEqual(self.go(artifact_path=outside).code, "ARTIFACT_OUTSIDE_APPROVED_DIR")
        self.assertEqual(self.go(artifact_path=os.path.join(self.art_dir, "..", "elsewhere.zip")).code, "ARTIFACT_OUTSIDE_APPROVED_DIR")
        open(self.artifact, "wb").write(ZIP + b"tampered")
        self.assertEqual(self.go().code, "ARTIFACT_DOES_NOT_MATCH_COMMITMENT")
        open(self.artifact, "wb").write(ZIP)
        self.assertEqual(self.go(artifact_salt_hex=L.new_salt()).code, "ARTIFACT_DOES_NOT_MATCH_COMMITMENT")

    def test_a_symlink_that_escapes_the_approved_directory_is_refused(self):
        outside = os.path.join(self.dir, "secret.zip")
        open(outside, "wb").write(ZIP)
        link = os.path.join(self.art_dir, "link.zip")
        try:
            os.symlink(outside, link)
        except (OSError, NotImplementedError):
            self.skipTest("symlink creation needs a privilege on this host (recorded as SKIP, not PASS)")
        self.assertEqual(self.go(artifact_path=link).code, "ARTIFACT_OUTSIDE_APPROVED_DIR")

    def test_replay_second_job_and_policy_rollback_are_refused_by_the_ledger(self):
        self.assertTrue(self.go())
        self.assertEqual(self.go().code, "NONCE_REPLAY")
        self.assertEqual(self.go(self.request(request_id="REQ-2", nonce="nonce-000000000002")).code, "ACTIVE_JOB_LIMIT_REACHED")
        self.ledger.complete_review("REQ-1")
        self.assertTrue(self.go(self.request(request_id="REQ-3", nonce="nonce-000000000003")))
        self.write_policy(policy_epoch=2)
        self.assertEqual(self.go(self.request(request_id="REQ-4", nonce="nonce-000000000004", policy_epoch=2)).code, "POLICY_EPOCH_ROLLBACK")

    def test_after_ledger_state_loss_nothing_is_authorised(self):
        os.remove(self.ledger.db_path)
        with self.assertRaisesRegex(L.ContractError, "STATE_MISSING_AFTER_INITIALIZATION"):
            L.Ledger.open(self.ledger.db_path, self.ledger.anchor_path)
        self.assertEqual(self.go().code, "STATE_MISSING_AFTER_INITIALIZATION")      # the stale handle is denied too
        self.assertFalse(os.path.exists(self.ledger.db_path), "a stale handle must not recreate an empty ledger")


class AclParsing(unittest.TestCase):
    ADMIN_ONLY = "C:\\p\\policy.json NT AUTHORITY\\SYSTEM:(I)(F)\n                  BUILTIN\\Administrators:(I)(F)\n                  PC\\operator:(I)(RX)\n\nSuccessfully processed 1 files"
    USER_WRITE = "C:\\p\\policy.json PC\\operator:(I)(F)\n                  BUILTIN\\Users:(I)(RX)"
    MODIFY = "C:\\p\\policy.json BUILTIN\\Users:(I)(M)"
    WRITE_LIST = "C:\\p\\policy.json PC\\svc:(R,W)"
    INHERIT = "C:\\p\\policy.json PC\\ops:(OI)(CI)(RX,WD)"

    def test_read_only_for_non_admins_is_protected(self):
        self.assertEqual(P.parse_icacls(self.ADMIN_ONLY, "C:\\p\\policy.json")["writers"], [])

    def test_any_non_admin_write_class_right_is_reported(self):
        for text, who in ((self.USER_WRITE, "PC\\operator"), (self.MODIFY, "BUILTIN\\Users"), (self.WRITE_LIST, "PC\\svc"), (self.INHERIT, "PC\\ops")):
            self.assertEqual(P.parse_icacls(text, "C:\\p\\policy.json")["writers"], [who], text)

    @unittest.skipUnless(sys.platform == "win32", "icacls is Windows only")
    def test_host_real_icacls_on_a_temp_file_reports_the_current_user_as_a_writer(self):
        """HOST_REAL, read-only: an ordinary user-owned file is NOT admin-protected, so the real checker must deny."""
        d = tempfile.mkdtemp(prefix="sul1-acl-")
        self.addCleanup(shutil.rmtree, d, ignore_errors=True)
        path = os.path.join(d, "p.json")
        open(path, "w").write("{}")
        report = P.windows_acl_checker(path)
        self.assertTrue(report["writers"], "a freshly created user file must have a non-admin writer")
        self.assertEqual(P.load_policy(path, now=NOW)[1].code, "POLICY_NOT_ADMIN_PROTECTED")


class Concurrency(Env):
    def test_two_processes_authorising_different_requests_cannot_both_pass_the_one_job_cap(self):
        worker = os.path.join(self.dir, "w.py")
        here = os.path.dirname(os.path.abspath(__file__))
        open(worker, "w").write(
            "import sys,os,time,json\nsys.path.insert(0,%r)\nimport local_only_contract_r0003 as L\n"
            "db,anchor,rid,go=sys.argv[1:5]\n"
            "while not os.path.exists(go): time.sleep(0.001)\n"
            "led=L.Ledger.open(db,anchor)\n"
            "try:\n    led.consume_nonce('n-'+rid,rid); led.reserve_review(rid,max_active=1); print('RESERVED')\n"
            "except L.ContractError as e: print('ERR',e)\n" % here)
        go = os.path.join(self.dir, "go")
        procs = [subprocess.Popen([sys.executable, "-I", worker, self.ledger.db_path, self.ledger.anchor_path, f"REQ-{i}", go],
                                  stdout=subprocess.PIPE, text=True) for i in range(6)]
        open(go, "w").close()
        outs = [p.communicate(timeout=60)[0].strip() for p in procs]
        self.assertEqual(outs.count("RESERVED"), 1, outs)
        self.assertEqual(outs.count("ERR ACTIVE_JOB_LIMIT_REACHED"), 5, outs)


if __name__ == "__main__":
    unittest.main()
