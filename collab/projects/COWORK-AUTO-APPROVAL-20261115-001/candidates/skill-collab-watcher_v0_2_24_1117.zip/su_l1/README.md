# su_l1 - single-user LOCAL_ONLY review control (v0.2.13, feature OFF, NOT wired into the watcher)

Standalone modules (flat imports, run from this folder):
- `local_only_contract_r0002.py` signature/field/window/cost/locality checks (history, reused by r0003).
- `local_only_contract_r0003.py` durable multi-process ledger: one-time bootstrap, anchor file, rollback/loss detection,
  atomic nonce/receipt/review reservation, UNCERTAIN sealing. Uses its OWN private SQLite pair; never opens the watcher DB.
- `su_l1_policy_r0001.py` administrator-protected local policy + OS user + artifact binding; GitHub text alone never authorises.
- tests and mutation checkers: `python -m unittest test_local_only_contract_r0003 test_su_l1_policy_r0001`.

Nothing here creates an account, ACL, task or key. It is not enabled by any setting of the watcher in this version.
The same-host limit applies: an attacker with the operator's administrator account defeats it.
