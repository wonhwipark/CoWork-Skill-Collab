"""SIMULATION of publishing a LOCAL_ONLY receipt to GitHub with only public-allowed fields (no network, no token).
A fake in-memory 'remote' stands in for the repo so the add-only rule, the leak check and the bytes readback can be
tested offline. Nothing here talks to GitHub."""
from __future__ import annotations

import hashlib

import local_only_contract_r0003 as L

PUBLISH_FIELDS = {"schema", "request_id", "artifact_commitment", "verdict", "reviewer_locality", "finding_counts", "issued_at", "reviewer_key_id"}


class FakeRemote:
    """Add-only store keyed by path; a second write of a different body to the same path is refused (like our publish rule)."""

    def __init__(self):
        self.files: dict[str, bytes] = {}

    def put(self, path: str, body: bytes) -> str:
        if path in self.files and self.files[path] != body:
            raise L.ContractError("ADD_ONLY_VIOLATION_DIFFERENT_BYTES")
        self.files[path] = body
        return hashlib.sha1(b"blob %d\0" % len(body) + body).hexdigest()     # git blob id, like the Contents API returns

    def get(self, path: str) -> bytes:
        return self.files[path]


def publishable_receipt(receipt_envelope: dict, forbidden: list[str]) -> bytes:
    """Minimum public projection of a receipt: drops the result digest and the runtime attestation (local-only evidence)."""
    doc = receipt_envelope["document"]
    public = {k: doc[k] for k in PUBLISH_FIELDS}
    L.assert_publishable(public, forbidden)
    return L.canonical(public)


def publish_and_readback(remote: FakeRemote, receipt_envelope: dict, forbidden: list[str]) -> str:
    body = publishable_receipt(receipt_envelope, forbidden)
    path = f"collab/receipts/{receipt_envelope['document']['request_id']}.json"
    blob = remote.put(path, body)
    back = remote.get(path)
    if back != body or hashlib.sha1(b"blob %d\0" % len(back) + back).hexdigest() != blob:
        raise L.ContractError("READBACK_MISMATCH")
    return blob
