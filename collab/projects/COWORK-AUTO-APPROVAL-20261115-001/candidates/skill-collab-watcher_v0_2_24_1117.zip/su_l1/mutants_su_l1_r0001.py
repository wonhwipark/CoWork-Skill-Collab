"""Mutation check for su_l1_policy_r0001: each mutant must make test_su_l1_policy_r0001 FAIL."""
import os, shutil, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = open(os.path.join(HERE, "su_l1_policy_r0001.py"), encoding="utf-8").read()
M = {
 "flag_default_on": ('if enabled is not True:', 'if False:'),
 "kill_switch_ignored": ('if os.path.exists(kill_switch_path):', 'if False:'),
 "acl_not_checked": ('if report.get("writers"):', 'if False:'),
 "acl_error_tolerated": ('    except Exception:\n        return None, _deny("POLICY_ACL_UNVERIFIABLE_FAIL_CLOSED")', '    except Exception:\n        report = {"writers": []}'),
 "principal_not_checked": ('if who != policy["allowed_principal"].lower():', 'if False:'),
 "reviewer_not_checked": ('if reviewer_runner_id != policy["reviewer_runner_id"]:', 'if False:'),
 "extra_request_fields_allowed": ('set(request) != REQUEST_FIELDS or ', ''),
 "repo_not_checked": ('if request["repo_id"] != policy["repo_id"] or request["branch"] != policy["branch"]:', 'if False:'),
 "work_id_not_checked": ('if request["work_id"] not in policy["allowed_work_ids"]:', 'if False:'),
 "epoch_mismatch_allowed": ('if request["policy_epoch"] != policy["policy_epoch"]:', 'if False:'),
 "artifact_dir_not_enforced": ('if not _inside(policy["artifact_dir"], artifact_path) or ', 'if '),
 "commitment_not_bound": ('ledger_mod.bind_to_local_artifact(request, digest, artifact_salt_hex)', 'pass'),
 "cost_not_checked": ('or policy["cost_cap_usd"] != "0.00"', ''),
 "limits_not_checked": ('if policy["max_active_jobs"] != 1 or policy["max_attempts"] != 1:', 'if False:'),
 "policy_expiry_ignored": ('if not _utc(policy["issued_at"]) <= now < _utc(policy["expires_at"]):', 'if False:'),
 "active_cap_not_passed": ('max_active=policy["max_active_jobs"]', 'max_active=None'),
 "epoch_rollback_not_bound": ('ledger.bind_policy_epoch(policy["policy_epoch"])', 'pass'),
 "write_right_M_not_detected": ('(?:F|M|W|WD|AD|WDAC|WO|GA|GW|DC)', '(?:F|W|WD|AD|WDAC|WO|GA|GW|DC)'),
}
survived = []
for name, (old, new) in M.items():
    if old not in SRC:
        print("NOT-FOUND", name); survived.append(name); continue
    d = tempfile.mkdtemp(prefix="mut-")
    try:
        for f in os.listdir(HERE):
            if f.endswith(".py") and not f.startswith("mutants"):
                shutil.copy(os.path.join(HERE, f), d)
        open(os.path.join(d, "su_l1_policy_r0001.py"), "w", encoding="utf-8").write(SRC.replace(old, new))
        r = subprocess.run([sys.executable, "-W", "ignore", "-m", "unittest", "test_su_l1_policy_r0001"], cwd=d, capture_output=True, text=True, timeout=300)
        print("KILLED  " if r.returncode else "SURVIVED", name)
        if not r.returncode: survived.append(name)
    finally:
        shutil.rmtree(d, ignore_errors=True)
print("mutants:", len(M), "survived:", survived)
sys.exit(1 if survived else 0)
