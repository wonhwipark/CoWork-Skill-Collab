import hashlib, unittest
from datetime import datetime, timedelta, timezone
import local_only_contract_r0003 as L
import receipt_publish_sim_r0001 as S
from test_local_only_contract_r0003 import keypair, NOW, ZIP_BYTES, ZIP_SHA


class Sim(unittest.TestCase):
    def setUp(self):
        self.ap, ap_pub = keypair(); self.rp, rp_pub = keypair()
        self.salt = L.new_salt(); self.commit = L.artifact_commitment(ZIP_SHA, self.salt)
        req = L.make_request(request_id="REQ-1", opaque_artifact_id=L.new_opaque_id(), commitment=self.commit, policy_revision=1, cost_cap_usd="0.00",
                             nonce="nonce-0123456789", issued_at=(NOW - timedelta(minutes=1)).isoformat(), expires_at=(NOW + timedelta(hours=1)).isoformat(),
                             repo_id="repo-1", signer_key_id="approver-1", signer_private=self.ap)
        self.req_doc = req["document"]
        self.text = b"local review text that must not leave"
        self.rec = L.make_receipt(request_doc=self.req_doc, verdict="PASS", reviewer_id="local", reviewer_locality="ON_PREM", review_text=self.text,
                                  finding_counts={"blocking": 0, "suggestion": 1}, issued_at=NOW.isoformat(), reviewer_key_id="reviewer-1",
                                  reviewer_private=self.rp, runtime_attestation_sha256="ab" * 32)
        self.forbidden = [ZIP_SHA, self.salt, str(len(ZIP_BYTES)), "source.zip", "c:/users/x",hashlib.sha256(self.text).hexdigest(), "ab" * 32]

    def test_public_projection_drops_the_result_digest_and_runtime_attestation_and_leaks_nothing(self):
        body = S.publishable_receipt(self.rec, self.forbidden)
        for item in self.forbidden:
            if item.isdigit():          # a size is only a leak as a WHOLE field value; as a substring it matches random hex
                continue
            self.assertNotIn(item.encode(), body)

    def test_publish_then_readback_bytes_match_and_blob_id_matches(self):
        remote = S.FakeRemote()
        blob = S.publish_and_readback(remote, self.rec, self.forbidden)
        self.assertEqual(len(blob), 40)

    def test_republishing_identical_bytes_is_idempotent_but_different_bytes_are_refused(self):
        remote = S.FakeRemote()
        first = S.publish_and_readback(remote, self.rec, self.forbidden)
        self.assertEqual(S.publish_and_readback(remote, self.rec, self.forbidden), first)
        other = L.make_receipt(request_doc=self.req_doc, verdict="FAIL", reviewer_id="local", reviewer_locality="ON_PREM", review_text=self.text,
                               finding_counts={"blocking": 1}, issued_at=NOW.isoformat(), reviewer_key_id="reviewer-1", reviewer_private=self.rp,
                               runtime_attestation_sha256="ab" * 32)
        with self.assertRaisesRegex(L.ContractError, "ADD_ONLY_VIOLATION"):
            S.publish_and_readback(remote, other, self.forbidden)

    def test_a_forbidden_value_in_a_public_field_blocks_the_publish(self):
        bad = L.make_receipt(request_doc=self.req_doc, verdict="PASS", reviewer_id="local", reviewer_locality="ON_PREM", review_text=self.text,
                             finding_counts={"note": ZIP_SHA}, issued_at=NOW.isoformat(), reviewer_key_id="reviewer-1", reviewer_private=self.rp,
                             runtime_attestation_sha256="ab" * 32)
        with self.assertRaisesRegex(L.ContractError, "FORBIDDEN"):
            S.publish_and_readback(S.FakeRemote(), bad, self.forbidden)


if __name__ == "__main__":
    unittest.main()
