from __future__ import annotations

import json
import os
import stat
from pathlib import Path

APP_KEY_ENV = "SKILL_COLLAB_DROPBOX_APP_KEY"
REFRESH_TOKEN_ENV = "SKILL_COLLAB_DROPBOX_REFRESH_TOKEN"


class SecretsUnavailable(Exception):
    pass


def secrets_file_path(state_dir: Path) -> Path:
    return state_dir / "secrets.json"


def load_secrets(state_dir: Path) -> dict[str, str]:
    """App key / refresh token only. Env vars win over the local file.

    Never log or print the returned values. The file lives under
    local_state_dir, which must stay outside any Dropbox-synced path.
    """
    app_key = os.environ.get(APP_KEY_ENV)
    refresh_token = os.environ.get(REFRESH_TOKEN_ENV)
    if app_key and refresh_token:
        return {"app_key": app_key, "refresh_token": refresh_token}

    path = secrets_file_path(state_dir)
    if not path.is_file():
        return {}
    data = json.loads(path.read_text(encoding="utf-8"))
    return {
        "app_key": app_key or data.get("app_key", ""),
        "refresh_token": refresh_token or data.get("refresh_token", ""),
    }


def load_granted_scope(state_dir: Path) -> list[str]:
    """Scope names recorded at authorization time (not secret). Empty if the
    file predates scope recording or credentials come from the environment."""
    path = secrets_file_path(state_dir)
    if not path.is_file():
        return []
    scope = json.loads(path.read_text(encoding="utf-8")).get("scope") or ""
    return scope.split() if isinstance(scope, str) else list(scope)


def save_secrets(state_dir: Path, app_key: str, refresh_token: str, scope=None) -> Path:
    state_dir.mkdir(parents=True, exist_ok=True)
    path = secrets_file_path(state_dir)
    payload = {"app_key": app_key, "refresh_token": refresh_token}
    if scope:
        payload["scope"] = scope if isinstance(scope, str) else " ".join(scope)
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    try:
        os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass
    return path


def redact(text: str, secrets: dict[str, str]) -> str:
    out = text
    for value in secrets.values():
        if value:
            out = out.replace(value, "***REDACTED***")
    return out
