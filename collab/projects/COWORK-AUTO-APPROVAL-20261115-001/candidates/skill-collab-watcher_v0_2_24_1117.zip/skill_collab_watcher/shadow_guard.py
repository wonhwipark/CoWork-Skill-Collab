"""SHADOW isolation (S-1): the shadow watcher never opens the operating database.

SQLite's read-only mode still touches the `-shm` index of a WAL database, so "read-only" is not "untouched".
SHADOW therefore gets its own state folder (own database, lock, runs, snapshots, cursors) and must prove it is
physically separate from the live folder before anything is created. Every doubt refuses to start (fail closed).

Checks, on the paths exactly as configured and on what they resolve to:
  - not empty, not a drive root, no network (UNC) path for either side;
  - no reparse point (junction, symlink, mount point) anywhere in the shadow path;
  - neither folder equals, contains or sits inside the other;
  - file identity (volume + file index) of the shadow folder is not the identity of the live folder or of any
    ancestor of it, and the other way round: this catches aliases that string comparison cannot (8.3 names,
    junctions, subst drives, hard-linked folders on other mount points).
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

REPARSE_POINT = 0x400


class ShadowIsolationError(RuntimeError):
    """The shadow folder cannot be proven separate from the live folder."""


class ShadowDispatchRefused(RuntimeError):
    """A SHADOW process tried to start a review."""


def _is_unc(text: str) -> bool:
    t = text.replace("/", "\\")
    return t.startswith("\\\\")


def _is_reparse(path: Path) -> bool:
    if sys.platform == "win32":
        import ctypes

        attrs = ctypes.windll.kernel32.GetFileAttributesW(str(path))
        if attrs == 0xFFFFFFFF:  # INVALID_FILE_ATTRIBUTES: the component does not exist (yet)
            return False
        return bool(attrs & REPARSE_POINT)
    return path.is_symlink()


def _exists(path: Path) -> bool:
    """False for 'not there' AND for 'this account may not look'. The SHADOW account normally cannot
    read the live folder (that is the point of running it as a different account); that must not crash
    the guard. The operating system's own permission is a stronger barrier than any path comparison."""
    try:
        return path.exists()
    except OSError:
        return False


def _identity(path: Path) -> tuple[int, int] | None:
    """(volume, file index), or None when the account cannot look at it."""
    try:
        st = os.stat(path)
    except OSError:
        return None
    if not st.st_ino:
        return None   # Windows reports index 0 for a folder it may list by name but not open
    return (st.st_dev, st.st_ino)


def _chain(path: Path) -> list[Path]:
    return [path, *path.parents]


def _existing_identities(path: Path) -> set[tuple[int, int]]:
    found: set[tuple[int, int]] = set()
    for p in _chain(path):
        identity = _identity(p)
        if identity is not None:
            found.add(identity)
    return found


def _norm(path: Path) -> tuple[str, ...]:
    return tuple(part.lower() for part in path.parts)


def _is_within(inner: tuple[str, ...], outer: tuple[str, ...]) -> bool:
    return len(inner) >= len(outer) and inner[: len(outer)] == outer


def assert_isolated(live_dir: str | os.PathLike, shadow_dir: str | os.PathLike) -> Path:
    """Return the resolved shadow folder, or raise ShadowIsolationError. Nothing is created or opened."""
    live_text, shadow_text = str(live_dir or ""), str(shadow_dir or "")
    if not live_text.strip() or not shadow_text.strip():
        raise ShadowIsolationError("EMPTY_PATH")
    if _is_unc(live_text) or _is_unc(shadow_text):
        raise ShadowIsolationError("UNC_PATH_REFUSED")
    live_raw, shadow_raw = Path(live_text), Path(shadow_text)
    if not shadow_raw.is_absolute() or not live_raw.is_absolute():
        raise ShadowIsolationError("RELATIVE_PATH_REFUSED")
    if shadow_raw == Path(shadow_raw.anchor):
        raise ShadowIsolationError("DRIVE_ROOT_REFUSED")

    for component in _chain(shadow_raw):
        if _exists(component) and _is_reparse(component):
            raise ShadowIsolationError("REPARSE_POINT_IN_SHADOW_PATH")

    live, shadow = live_raw.resolve(), shadow_raw.resolve()
    a, b = _norm(live), _norm(shadow)
    if _is_within(a, b) or _is_within(b, a):
        raise ShadowIsolationError("OVERLAP")

    live_ids, shadow_ids = _existing_identities(live), _existing_identities(shadow)
    if (live_ids & shadow_ids) - _common_ancestor_ids(live, shadow):
        raise ShadowIsolationError("ALIAS_BY_FILE_IDENTITY")
    shadow_id, live_id = _identity(shadow), _identity(live)
    if shadow_id is None and _exists(shadow):
        raise ShadowIsolationError("IDENTITY_UNAVAILABLE_FOR_SHADOW_FOLDER")
    if shadow_id is not None and shadow_id == live_id:
        raise ShadowIsolationError("SAME_FOLDER_BY_FILE_IDENTITY")
    return shadow


def _common_ancestor_ids(live: Path, shadow: Path) -> set[tuple[int, int]]:
    """Folders that are legitimately above both (a shared parent is fine). Anything that is the
    live folder itself, an ancestor of live that is not above shadow, or the reverse, is an alias."""
    shared = set(_chain(live)[1:]) & set(_chain(shadow)[1:])
    ids = {i for i in (_identity(p) for p in shared) if i is not None}
    # file identities of the two shared-by-path chains are excluded; identity overlap beyond them is an alias
    return ids


def verify_after_create(live_dir: str | os.PathLike, shadow_dir: str | os.PathLike) -> Path:
    """Second pass after the shadow folder exists (closes the check-then-create gap)."""
    shadow = assert_isolated(live_dir, shadow_dir)
    try:
        is_dir = shadow.is_dir()
    except OSError:
        is_dir = False
    if not is_dir:
        raise ShadowIsolationError("SHADOW_FOLDER_MISSING")
    return shadow


LIVE_FILE_NAMES = ("state.sqlite3", "state.sqlite3-wal", "state.sqlite3-shm", "watch.lock")
_NOT_ACCESS = 0x120000   # READ_CONTROL and SYNCHRONIZE do not let anyone touch the data


def account_reach(live_dir: str | os.PathLike, stat=None, mask_of=None) -> tuple[str, list[str]]:
    """Can THIS process's account reach the live folder? Looks at attributes and the DACL only: no file is
    opened for reading or writing. Returns (status, findings). Findings name roles, never paths.
      LIVE_FOLDER_ABSENT  nothing to protect here (not a proof about other hosts)
      DENIED_BY_OS        the operating system refuses this account (the strongest evidence)
      NO_RIGHTS_ON_ACL    attributes readable but the DACL grants nothing that touches the data
      ACCESSIBLE          the account holds rights: running SHADOW as this account is NOT isolated
      NOT_ASSESSED        not Windows."""
    if mask_of is None:
        if sys.platform != "win32":
            return "NOT_ASSESSED", []
        from .approval import _effective_mask as mask_of
    stat = stat or os.stat
    live = Path(live_dir)
    try:
        stat(live)
    except FileNotFoundError:
        return "LIVE_FOLDER_ABSENT", []
    except PermissionError:
        return "DENIED_BY_OS", []
    except OSError:
        return "ACCESSIBLE", ["live folder: cannot be examined, so isolation is not proven"]
    findings: list[str] = []
    for role, path in [("live folder", live), *[(f"live {name}", live / name) for name in LIVE_FILE_NAMES]]:
        try:
            stat(path)          # a file that is not there, or that the system hides from this account, is not reachable
        except (FileNotFoundError, PermissionError):
            continue
        except OSError:
            findings.append(f"{role}: reachable, but its permissions could not be read")
            continue
        try:
            rights = mask_of(str(path))
        except FileNotFoundError:
            continue
        except OSError:
            findings.append(f"{role}: reachable, but its permissions could not be read")
            continue
        if rights & ~_NOT_ACCESS:
            findings.append(f"{role}: this account holds access rights")
    return ("ACCESSIBLE" if findings else "NO_RIGHTS_ON_ACL"), findings


class ShadowRunner:
    """The runner of a SHADOW process: it can never start a review."""

    def run(self, *args, **kwargs):
        raise ShadowDispatchRefused("SHADOW never starts a review")

    def preflight(self) -> tuple[bool, str]:
        return False, "SHADOW_MODE"
