"""GitHub PRIVATE repository transport for the review watcher.

Implements the same Transport contract the Dropbox transport implements.
Reads go through the REST API pinned to a commit; nothing is checked out, so
the bytes a REQUEST/READY/ZIP is hashed from are exactly the stored blob bytes
(B-6). Every blob is verified against its git object id before use. Writes are
add-only (no overwrite) and happen only through the contents API.

Repository layout: the watcher's virtual root (remote_root, default
/SKILL-COLLAB) maps onto the repository folder "collab/". Existing validator
path rules therefore keep working unchanged.
"""
from __future__ import annotations

import base64
import hashlib
import json
import time
import re
from datetime import datetime
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Callable

from .transport_base import (
    AuthRequired, EntryMeta, ListResult, RemoteNotFound, Transport,
    TransientTransportError, TransportError, UploadConflict,
)

API = "https://api.github.com"
REPO_FOLDER = "collab/"
INLINE_LIMIT = 1024 * 1024
COMPARE_FILE_LIMIT = 300


class UrllibHttp:
    """Plain HTTPS client used in production. Tests inject a fake."""

    def request(self, method: str, url: str, headers: dict[str, str], body: bytes | None = None):
        req = urllib.request.Request(url, data=body, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return resp.status, {k.lower(): v for k, v in resp.headers.items()}, resp.read()
        except urllib.error.HTTPError as exc:
            return exc.code, {k.lower(): v for k, v in exc.headers.items()}, exc.read()
        except (urllib.error.URLError, OSError) as exc:
            raise TransportError(f"network error: {type(exc).__name__}") from exc


def blob_sha(data: bytes) -> str:
    return hashlib.sha1(b"blob %d\x00" % len(data) + data).hexdigest()


class GitHubTransport(Transport):
    def __init__(
        self,
        *,
        repo: str,
        branch: str = "main",
        remote_root: str = "/SKILL-COLLAB",
        token_provider: Callable[[], str],
        http: Any = None,
        sleep: Callable[[float], None] = time.sleep,
        clock: Callable[[], float] = time.monotonic,
        read_only: bool = False,
    ) -> None:
        self.read_only = read_only  # SHADOW: the object itself cannot write, whatever the caller asks
        self.repo = repo
        self.branch = branch
        self.remote_root = remote_root.rstrip("/")
        self._token_provider = token_provider
        self._http = http or UrllibHttp()
        self._sleep = sleep
        self._clock = clock
        self._etag: str | None = None
        self._etag_sha: str | None = None
        self._pin: str | None = None
        self._server_date: str | None = None

    @property
    def provider_name(self) -> str:
        return "github"

    @property
    def cursor_name(self) -> str:
        return f"github:{self.repo}:{self.branch}"

    # --- path mapping ------------------------------------------------------

    def _repo_path(self, path: str) -> str:
        low = path.lower()
        if not low.startswith(self.remote_root.lower() + "/") or "\\" in path or ".." in path.split("/"):
            raise TransportError("OUT_OF_SCOPE_PATH")
        return REPO_FOLDER + path[len(self.remote_root) + 1:]

    def _virtual(self, repo_path: str) -> str:
        return self.remote_root + "/" + repo_path[len(REPO_FOLDER):]

    # --- HTTP helpers -------------------------------------------------------

    def _headers(self) -> dict[str, str]:
        token = self._token_provider()
        if not token:
            raise AuthRequired("no GitHub credential configured")
        return {
            "Authorization": "Bearer " + token,
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "skill-collab-watcher",
        }

    def _get(self, api_path: str, extra: dict[str, str] | None = None) -> tuple[int, dict[str, str], bytes]:
        headers = self._headers()
        headers.update(extra or {})
        status, hdrs, body = self._http.request("GET", API + api_path, headers, None)
        self._note_server_date(hdrs)
        self._raise_for(status, hdrs, api_path)
        return status, hdrs, body

    def _note_server_date(self, hdrs: dict[str, str]) -> None:
        self._server_date = hdrs.get("date") or self._server_date

    def server_time(self):
        from .approval import parse_http_date

        return parse_http_date(self._server_date)

    def _raise_for(self, status: int, hdrs: dict[str, str], where: str) -> None:
        if status in (200, 201, 304):
            return
        if status == 403 and (hdrs.get("x-ratelimit-remaining") == "0" or "retry-after" in hdrs):
            raise TransientTransportError("GitHub rate limit", _retry_after(hdrs))
        if status in (401, 403):
            raise AuthRequired(f"GitHub HTTP {status}")
        if status == 404:
            raise RemoteNotFound(f"not found: {where.split('?')[0][:120]}")
        if status == 429 or status >= 500:
            raise TransientTransportError(f"GitHub HTTP {status}", _retry_after(hdrs))
        raise TransportError(f"GitHub HTTP {status}")

    def _json(self, raw: bytes) -> dict[str, Any]:
        try:
            obj = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as exc:
            raise TransportError("GitHub returned non-JSON") from exc
        if not isinstance(obj, dict):
            raise TransportError("GitHub returned an unexpected shape")
        return obj

    # --- Transport contract ---------------------------------------------------

    def ensure_auth(self) -> None:
        try:
            self._get(f"/repos/{self.repo}")
        except RemoteNotFound as exc:
            raise AuthRequired("repository is not visible to this credential") from exc

    def repository_id(self) -> str:
        """The numeric repository id as GitHub's server reports it NOW. Never cached: the watch process lives for days while the
        name `owner/name` can be repointed to another repository (deleted and recreated), which gets a new id."""
        try:
            _, _, body = self._get(f"/repos/{self.repo}")
        except RemoteNotFound as exc:
            raise AuthRequired("repository is not visible to this credential") from exc
        value = self._json(body).get("id")
        if isinstance(value, bool) or not isinstance(value, (int, str)) or not str(value).strip():
            raise TransportError("GitHub returned no repository id")
        return str(value).strip()

    def head_sha(self) -> str:
        extra = {"If-None-Match": self._etag} if self._etag else None
        status, hdrs, body = self._get(f"/repos/{self.repo}/commits/{self.branch}", extra)
        if status == 304 and self._etag_sha:
            return self._etag_sha
        sha = self._json(body).get("sha")
        if not isinstance(sha, str) or len(sha) != 40:
            raise TransportError("GitHub returned no commit sha")
        self._etag, self._etag_sha = hdrs.get("etag"), sha
        return sha

    def pin_current(self) -> str | None:
        self._pin = self.head_sha()
        return self._pin

    def unpin(self) -> None:
        self._pin = None

    def current_pin(self) -> str | None:
        return self._pin

    def _ref(self) -> str:
        return self._pin or self.head_sha()

    def list_folder(self, path: str) -> ListResult:
        head = self.head_sha()
        _, _, body = self._get(f"/repos/{self.repo}/git/trees/{head}?recursive=1")
        tree = self._json(body)
        if tree.get("truncated"):
            raise TransportError("TREE_TRUNCATED")
        prefix = path.rstrip("/").lower() + "/"
        entries = []
        for item in tree.get("tree", []):
            if item.get("type") != "blob" or not str(item.get("path", "")).startswith(REPO_FOLDER):
                continue
            virtual = self._virtual(item["path"])
            if not virtual.lower().startswith(prefix):
                continue
            entries.append(EntryMeta(path=virtual, rev=head, size=int(item.get("size") or 0),
                                     content_hash=item["sha"], file_id=item["sha"]))
        return ListResult(entries=entries, cursor=head, has_more=False)

    def list_folder_continue(self, cursor: str) -> ListResult:
        head = self.head_sha()
        if head == cursor:
            return ListResult(entries=[], cursor=head, has_more=False)
        try:
            _, _, body = self._get(f"/repos/{self.repo}/compare/{cursor}...{head}")
        except RemoteNotFound as exc:
            raise TransportError("CURSOR_RESET: base commit is no longer reachable") from exc
        files = self._json(body).get("files", [])
        if len(files) >= COMPARE_FILE_LIMIT:
            raise TransportError("CURSOR_RESET: compare result truncated")
        entries: list[EntryMeta] = []
        for f in files:
            name = str(f.get("filename", ""))
            if not name.startswith(REPO_FOLDER):
                continue
            if f.get("status") == "removed":
                entries.append(EntryMeta(path=self._virtual(name), rev=head, size=0, content_hash="", is_deleted=True))
                continue
            if f.get("status") == "renamed" and f.get("previous_filename", "").startswith(REPO_FOLDER):
                entries.append(EntryMeta(path=self._virtual(f["previous_filename"]), rev=head, size=0,
                                         content_hash="", is_deleted=True))
            entries.append(EntryMeta(path=self._virtual(name), rev=head, size=0,
                                     content_hash=str(f.get("sha") or ""), file_id=str(f.get("sha") or "")))
        return ListResult(entries=entries, cursor=head, has_more=False)

    def longpoll(self, cursor: str, timeout_sec: int) -> bool:
        deadline = self._clock() + max(0, timeout_sec)
        while True:
            if self.head_sha() != cursor:
                return True
            remaining = deadline - self._clock()
            if remaining <= 0:
                return False
            self._sleep(min(5.0, remaining))

    def download(self, path: str) -> tuple[bytes, EntryMeta]:
        repo_path = self._repo_path(path)
        ref = self._ref()
        _, _, body = self._get(f"/repos/{self.repo}/contents/{urllib.parse.quote(repo_path)}?ref={ref}")
        meta = self._json(body)
        if meta.get("type") != "file" or not isinstance(meta.get("sha"), str):
            raise TransportError("NOT_A_FILE")
        if meta.get("encoding") == "base64" and meta.get("content") and int(meta.get("size") or 0) <= INLINE_LIMIT:
            encoded = meta["content"]
        else:
            _, _, blob = self._get(f"/repos/{self.repo}/git/blobs/{meta['sha']}")
            encoded = self._json(blob).get("content", "")
        try:
            data = base64.b64decode(str(encoded).replace("\n", ""), validate=False)
        except ValueError as exc:
            raise TransportError("BLOB_NOT_BASE64") from exc
        if blob_sha(data) != meta["sha"] or len(data) != int(meta.get("size") or -1):
            raise TransportError("BLOB_SHA_MISMATCH")
        return data, EntryMeta(path=path, rev=ref, size=len(data), content_hash=meta["sha"], file_id=meta["sha"])

    def download_latest(self, path: str) -> tuple[bytes, EntryMeta]:
        saved, self._pin = self._pin, None
        try:
            return self.download(path)
        finally:
            self._pin = saved

    def download_at_commit(self, path: str, commit: str) -> tuple[bytes, EntryMeta]:
        if not re.fullmatch(r"[0-9a-f]{40}", str(commit)):
            raise TransportError("BAD_COMMIT_ID")
        saved, self._pin = self._pin, commit
        try:
            return self.download(path)
        finally:
            self._pin = saved

    def commit_time(self, commit: str) -> float:
        if not re.fullmatch(r"[0-9a-f]{40}", str(commit)):
            raise TransportError("BAD_COMMIT_ID")
        _, _, body = self._get(f"/repos/{self.repo}/commits/{commit}")
        date = ((self._json(body).get("commit") or {}).get("committer") or {}).get("date")
        try:
            return datetime.fromisoformat(str(date).replace("Z", "+00:00")).timestamp()
        except ValueError as exc:
            raise TransportError("COMMIT_TIME_UNREADABLE") from exc

    def get_metadata(self, path: str) -> EntryMeta | None:
        repo_path = self._repo_path(path)
        try:
            _, _, body = self._get(f"/repos/{self.repo}/contents/{urllib.parse.quote(repo_path)}?ref={self._ref()}")
        except RemoteNotFound:
            return None
        meta = self._json(body)
        return EntryMeta(path=path, rev=self._ref(), size=int(meta.get("size") or 0),
                         content_hash=str(meta.get("sha") or ""), file_id=str(meta.get("sha") or ""))

    def upload(self, path: str, data: bytes, mode: str = "add") -> EntryMeta:
        if self.read_only:
            raise TransportError("READ_ONLY_TRANSPORT: this transport was opened for SHADOW and cannot write")
        if mode != "add":
            raise TransportError("only add mode is supported")
        repo_path = self._repo_path(path)
        if self.get_metadata(path) is not None:
            raise UploadConflict(path)
        payload = json.dumps({
            "message": f"watcher: add {repo_path.rsplit('/', 1)[-1]}",
            "content": base64.b64encode(data).decode("ascii"),
            "branch": self.branch,
        }).encode("utf-8")
        status, hdrs, body = self._http.request(
            "PUT", f"{API}/repos/{self.repo}/contents/{urllib.parse.quote(repo_path)}", self._headers(), payload)
        if status in (409, 422):
            raise UploadConflict(path)
        self._raise_for(status, hdrs, path)
        created = self._json(body).get("content") or {}
        sha = str(created.get("sha") or "")
        self._etag = None  # the branch moved; the next head read must not reuse the old etag
        return EntryMeta(path=path, rev=self.head_sha(), size=len(data), content_hash=sha, file_id=sha)


def _retry_after(hdrs: dict[str, str]) -> float | None:
    try:
        return float(hdrs["retry-after"])
    except (KeyError, ValueError):
        return None
