from __future__ import annotations

import os
from pathlib import Path


class SingleInstanceLock:
    """Exclusive OS-level lock on a byte range of a file (Windows msvcrt).

    The lock is held for the lifetime of the open file handle, so it is
    released automatically by the OS even if this process crashes - no
    stale-PID guessing needed.
    """

    def __init__(self, path: Path):
        self.path = path
        self._fh = None

    def acquire(self) -> bool:
        import msvcrt

        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            # "a+b" leaves the lockable byte offset ambiguous across
            # processes/handles on Windows; always pre-create a 1-byte
            # file and open it "r+b" so every acquirer locks byte 0.
            self.path.write_bytes(b"0")
        fh = open(self.path, "r+b")
        fh.seek(0)
        try:
            msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            fh.close()
            return False
        fh.seek(1)
        fh.truncate(1)
        fh.write(str(os.getpid()).encode("ascii"))
        fh.flush()
        self._fh = fh
        return True

    def release(self) -> None:
        if self._fh is None:
            return
        import msvcrt

        try:
            self._fh.seek(0)
            msvcrt.locking(self._fh.fileno(), msvcrt.LK_UNLCK, 1)
        except OSError:
            pass
        self._fh.close()
        self._fh = None

    def __enter__(self) -> "SingleInstanceLock":
        if not self.acquire():
            raise RuntimeError(f"another watcher instance already holds {self.path}")
        return self

    def __exit__(self, *exc) -> None:
        self.release()
