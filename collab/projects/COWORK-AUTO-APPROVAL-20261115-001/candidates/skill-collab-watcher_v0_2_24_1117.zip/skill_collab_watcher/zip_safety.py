from __future__ import annotations

import io
import re
import zipfile
from pathlib import Path


class UnsafeZip(ValueError):
    pass


MAX_TOTAL_UNCOMPRESSED = 200 * 1024 * 1024  # 200 MiB guard against zip bombs
MAX_ENTRIES = 5000


def safe_extract(zip_bytes: bytes, dest_dir: Path) -> None:
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest_resolved = dest_dir.resolve()

    import io

    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
        infos = zf.infolist()
        if len(infos) > MAX_ENTRIES:
            raise UnsafeZip(f"too many entries: {len(infos)}")

        total = 0
        for info in infos:
            name = info.filename
            if name.startswith("/") or name.startswith("\\"):
                raise UnsafeZip(f"absolute path in zip: {name}")
            if ".." in Path(name).parts:
                raise UnsafeZip(f"path escape in zip: {name}")
            mode = (info.external_attr >> 16) & 0xFFFF
            import stat as _stat
            if _stat.S_ISLNK(mode):
                raise UnsafeZip(f"symlink entry rejected: {name}")
            total += info.file_size
            if total > MAX_TOTAL_UNCOMPRESSED:
                raise UnsafeZip("uncompressed size exceeds guard limit")

        for info in infos:
            target = (dest_dir / info.filename).resolve()
            if not str(target).startswith(str(dest_resolved)):
                raise UnsafeZip(f"resolved path escapes destination: {info.filename}")

        zf.extractall(dest_dir)


CREDENTIAL_SHAPES = {
    "dropbox access token": re.compile(rb"\bsl\.[A-Za-z0-9_\-]{30,}"),
    "json credential field": re.compile(
        rb'"(?:refresh_token|access_token|app_secret|client_secret|password)"\s*:\s*"[^"\s]{16,}"', re.I),
    "authorization header": re.compile(rb"authorization\s*:\s*bearer\s+[A-Za-z0-9._\-]{16,}", re.I),
    "private key block": re.compile(rb"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    "github token": re.compile(rb"\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})"),
}


def package_secret_findings(zip_bytes: bytes) -> list[str]:
    """Names of entries that contain credential-shaped text. Nothing is
    extracted; the package is refused before any model call if this is non-empty."""
    findings: list[str] = []
    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            if info.file_size > MAX_TOTAL_UNCOMPRESSED:
                raise UnsafeZip(f"entry too large to scan: {info.filename}")
            data = zf.read(info)
            for label, pattern in CREDENTIAL_SHAPES.items():
                if pattern.search(data):
                    findings.append(f"{info.filename}: {label}")
    return findings
