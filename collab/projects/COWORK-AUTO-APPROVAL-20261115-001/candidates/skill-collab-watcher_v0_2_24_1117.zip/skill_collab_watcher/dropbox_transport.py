from __future__ import annotations

import threading
import time
from typing import Callable

from .transport_base import (
    AuthRequired, EntryMeta, ListResult, RemoteNotFound, TransientTransportError, Transport,
    TransportError, UploadConflict,
)

Observer = Callable[[str, str], None]

# Defaults chosen so one failing call costs at most ~6s of waiting
# (2s + 4s) before the watch loop's own, longer backoff takes over.
DEFAULT_MAX_ATTEMPTS = 3
DEFAULT_BASE_DELAY = 2.0
DEFAULT_MAX_DELAY = 60.0
DEFAULT_REQUEST_TIMEOUT = 60.0
DEFAULT_AUTH_CACHE_SEC = 900.0


def _meta_from_file_entry(entry) -> EntryMeta:
    return EntryMeta(
        path=entry.path_display or entry.path_lower,
        rev=getattr(entry, "rev", ""),
        size=getattr(entry, "size", 0),
        content_hash=getattr(entry, "content_hash", "") or "",
        is_deleted=False,
        is_folder=False,
        file_id=getattr(entry, "id", "") or "",
    )


def summarize_exception(exc: BaseException) -> str:
    """Class name, HTTP status and Dropbox request id only. Never the HTTP
    body or message text: those can echo request parameters."""
    parts = [type(exc).__name__]
    status = getattr(exc, "status_code", None)
    if status:
        parts.append(f"http={status}")
    error = getattr(exc, "error", None)
    if error is not None:
        parts.append(f"error={str(error)[:120]}")
    request_id = getattr(exc, "request_id", None)
    if request_id:
        parts.append(f"request_id={request_id}")
    return " ".join(parts)


def _is_not_found_path_error(error) -> bool:
    try:
        return bool(error.is_path() and error.get_path().is_not_found())
    except AttributeError:
        return False


def _is_reset(error) -> bool:
    return bool(getattr(error, "is_reset", lambda: False)())


def _is_upload_conflict(error) -> bool:
    # UploadError.path -> UploadWriteFailed, whose .reason is the WriteError.
    # (UploadWriteFailed itself has no is_conflict(); the first version of
    # this check called it there and could never match.)
    try:
        return bool(error.is_path() and error.get_path().reason.is_conflict())
    except AttributeError:
        return False


class DropboxTransport(Transport):
    """Thin wrapper around the official Dropbox SDK.

    Every method here is plain SDK/network code - none of them may import
    or call anything that starts a claude process. review_runner.py is the
    only module allowed to do that.

    Failure model (all verified against dropbox 12.2.4 source):
      * RateLimitError, InternalServerError, requests Timeout/ConnectionError
        -> TransientTransportError, retried here with bounded backoff.
      * AuthError (incl. refresh-token invalid_grant) -> AuthRequired.
      * BadInputError during the auth probe (wrong app key) -> AuthRequired.
      * everything else -> TransportError (not retried).
    The SDK's own retry loops are switched off: for 429 its default is to
    retry forever with an uninterruptible time.sleep().
    """

    def __init__(
        self,
        app_key: str,
        refresh_token: str,
        *,
        max_attempts: int = DEFAULT_MAX_ATTEMPTS,
        base_delay: float = DEFAULT_BASE_DELAY,
        max_delay: float = DEFAULT_MAX_DELAY,
        request_timeout: float = DEFAULT_REQUEST_TIMEOUT,
        auth_cache_sec: float = DEFAULT_AUTH_CACHE_SEC,
        sleep: Callable[[float], None] = time.sleep,
        clock: Callable[[], float] = time.monotonic,
        observer: Observer | None = None,
        stop_event: threading.Event | None = None,
        client=None,
    ):
        import dropbox  # imported lazily so mock-only test runs don't need it installed
        import requests

        self._dropbox = dropbox
        self._requests = requests
        self._app_key = app_key
        self._refresh_token = refresh_token
        self._max_attempts = max(1, max_attempts)
        self._base_delay = base_delay
        self._max_delay = max_delay
        self._request_timeout = request_timeout
        self._auth_cache_sec = auth_cache_sec
        self._sleep = sleep
        self._clock = clock
        self._observer = observer
        self._stop = stop_event
        self._dbx = client  # injected only by tests
        self._auth_ok_at: float | None = None

    # --- plumbing ----------------------------------------------------------

    def _client(self):
        if self._dbx is None:
            if not (self._app_key and self._refresh_token):
                raise AuthRequired("missing app_key/refresh_token")
            self._dbx = self._dropbox.Dropbox(
                app_key=self._app_key,
                oauth2_refresh_token=self._refresh_token,
                max_retries_on_error=0,
                max_retries_on_rate_limit=0,
                timeout=self._request_timeout,
            )
        return self._dbx

    def _note(self, event: str, detail: str) -> None:
        if self._observer is None:
            return
        try:
            self._observer(event, detail)
        except Exception:  # an audit-log failure must never change transport behaviour
            pass

    def _wait(self, seconds: float) -> bool:
        """Sleep that a shutdown request can cut short. True = stop requested."""
        if self._stop is not None:
            return self._stop.wait(seconds)
        self._sleep(seconds)
        return False

    def _delay(self, attempt: int, retry_after: float | None) -> float:
        wanted = retry_after if retry_after is not None else self._base_delay * (2 ** (attempt - 1))
        return min(self._max_delay, max(0.0, float(wanted)))

    def _classify(self, exc: Exception, bad_input_is_auth: bool) -> Exception:
        d = self._dropbox.exceptions
        if isinstance(exc, (AuthRequired, TransportError, UploadConflict)):
            return exc
        summary = summarize_exception(exc)
        if isinstance(exc, d.AuthError):
            return AuthRequired(summary)
        if isinstance(exc, d.RateLimitError):
            backoff = getattr(exc, "backoff", None)
            return TransientTransportError(summary, retry_after=float(backoff) if backoff else None)
        if isinstance(exc, d.BadInputError):
            return AuthRequired(summary) if bad_input_is_auth else TransportError(summary)
        if isinstance(exc, d.InternalServerError):
            return TransientTransportError(summary)
        if isinstance(exc, d.PathRootError):
            return TransportError(summary)
        if isinstance(exc, d.HttpError):
            if exc.status_code in (408, 425, 429) or exc.status_code >= 500:
                return TransientTransportError(summary)
            return TransportError(summary)
        if isinstance(exc, d.ApiError):
            return TransportError(summary)
        # requests.* (ConnectTimeout, ReadTimeout, ConnectionError,
        # ChunkedEncodingError ...) and socket-level errors. The SDK does not
        # translate these, they surface as-is.
        if isinstance(exc, (self._requests.exceptions.RequestException, OSError)):
            return TransientTransportError(summary)
        return TransportError(summary)

    def _call(self, op: str, fn: Callable[[], object], *, bad_input_is_auth: bool = False,
              attempts: int | None = None):
        limit = max(1, attempts if attempts is not None else self._max_attempts)
        for attempt in range(1, limit + 1):
            try:
                result = fn()
            except UploadConflict:
                raise
            except Exception as exc:
                err = self._classify(exc, bad_input_is_auth)
                if isinstance(err, AuthRequired):
                    self._auth_ok_at = None
                if not isinstance(err, TransientTransportError):
                    if err is exc:
                        raise
                    raise err from exc
                self._note("API_TRANSIENT_ERROR", f"{op} attempt {attempt}/{limit}: {err}")
                if attempt >= limit:
                    self._note("API_RETRY_EXHAUSTED", f"{op}: {err}")
                    raise err from exc
                if self._wait(self._delay(attempt, err.retry_after)):
                    self._note("API_RETRY_ABORTED", f"{op}: shutdown requested")
                    raise err from exc
                continue
            if attempt > 1:
                self._note("API_RETRY_RECOVERED", f"{op} after {attempt} attempts")
            return result
        raise AssertionError("unreachable")  # pragma: no cover

    def _list_result(self, result) -> ListResult:
        dropbox = self._dropbox
        entries = [
            _meta_from_file_entry(e)
            for e in result.entries
            if isinstance(e, dropbox.files.FileMetadata)
        ]
        return ListResult(entries=entries, cursor=result.cursor, has_more=result.has_more)

    # --- Transport API -----------------------------------------------------

    def ensure_auth(self) -> None:
        if self._auth_ok_at is not None and self._clock() - self._auth_ok_at < self._auth_cache_sec:
            return
        self._call(
            "users_get_current_account",
            lambda: self._client().users_get_current_account(),
            bad_input_is_auth=True,
        )
        self._auth_ok_at = self._clock()

    def list_folder(self, path: str) -> ListResult:
        dropbox = self._dropbox

        def go():
            try:
                return self._list_result(self._client().files_list_folder(path, recursive=True))
            except dropbox.exceptions.ApiError as exc:
                if _is_not_found_path_error(exc.error):
                    raise RemoteNotFound(path) from exc
                raise

        return self._call("files_list_folder", go)

    def list_folder_continue(self, cursor: str) -> ListResult:
        dropbox = self._dropbox

        def go():
            try:
                return self._list_result(self._client().files_list_folder_continue(cursor))
            except dropbox.exceptions.ApiError as exc:
                if _is_reset(exc.error):
                    raise TransportError("CURSOR_RESET") from exc
                raise

        return self._call("files_list_folder_continue", go)

    def longpoll(self, cursor: str, timeout_sec: int) -> bool:
        """Block until something under the cursor changes or the timeout ends.

        The SDK widens the socket timeout to timeout+90s for this route
        itself, so a quiet folder returns changes=False rather than raising.
        Not retried here: the caller's loop decides what to do next."""
        dropbox = self._dropbox
        timeout_sec = max(30, min(480, int(timeout_sec)))

        def go():
            try:
                return self._client().files_list_folder_longpoll(cursor, timeout=timeout_sec)
            except dropbox.exceptions.ApiError as exc:
                if _is_reset(exc.error):
                    raise TransportError("CURSOR_RESET") from exc
                raise

        result = self._call("files_list_folder_longpoll", go, attempts=1)
        backoff = getattr(result, "backoff", None)
        if backoff:  # Dropbox asks callers to pause before polling again
            self._wait(min(float(backoff), self._max_delay))
        return bool(result.changes)

    def download(self, path: str) -> tuple[bytes, EntryMeta]:
        dropbox = self._dropbox

        def go():
            try:
                metadata, response = self._client().files_download(path)
            except dropbox.exceptions.ApiError as exc:
                if _is_not_found_path_error(exc.error):
                    raise TransportError(f"not found: {path}") from exc
                raise
            try:
                data = response.content
            finally:
                response.close()
            return data, _meta_from_file_entry(metadata)

        return self._call("files_download", go)

    def get_metadata(self, path: str) -> EntryMeta | None:
        dropbox = self._dropbox

        def go():
            try:
                metadata = self._client().files_get_metadata(path)
            except dropbox.exceptions.ApiError as exc:
                if _is_not_found_path_error(exc.error):
                    return None
                raise
            if not isinstance(metadata, dropbox.files.FileMetadata):
                return None
            return _meta_from_file_entry(metadata)

        return self._call("files_get_metadata", go)

    def upload(self, path: str, data: bytes, mode: str = "add") -> EntryMeta:
        dropbox = self._dropbox
        write_mode = dropbox.files.WriteMode.add if mode == "add" else dropbox.files.WriteMode.overwrite

        def go():
            try:
                metadata = self._client().files_upload(data, path, mode=write_mode, autorename=False)
            except dropbox.exceptions.ApiError as exc:
                if mode == "add" and _is_upload_conflict(exc.error):
                    raise UploadConflict(path) from exc
                raise
            return _meta_from_file_entry(metadata)

        return self._call("files_upload", go)
