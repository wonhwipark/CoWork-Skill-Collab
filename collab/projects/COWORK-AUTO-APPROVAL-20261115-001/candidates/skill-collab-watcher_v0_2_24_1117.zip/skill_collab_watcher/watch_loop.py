from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Callable, Protocol

from .transport_base import TransportError


class _HasNote(Protocol):
    note: str


@dataclass
class WatchResult:
    reason: str = ""
    cycles: int = 0
    ok_cycles: int = 0
    transport_error_cycles: int = 0
    recoveries: int = 0  # failing cycles followed by a clean one
    max_consecutive_failures: int = 0
    backoff_waits: int = 0
    longpoll_calls: int = 0
    longpoll_changes: int = 0
    longpoll_errors: int = 0
    auth_required: bool = False
    elapsed_sec: float = 0.0


def compute_backoff(consecutive_failures: int, base: float, cap: float) -> float:
    """base, 2*base, 4*base ... never above cap. 0 failures -> 0."""
    if consecutive_failures <= 0:
        return 0.0
    exponent = min(consecutive_failures - 1, 30)  # avoid huge ints; cap applies anyway
    return min(float(cap), float(base) * (2 ** exponent))


def run_watch(
    *,
    run_cycle: Callable[[], _HasNote],
    stop: threading.Event,
    poll_interval: float,
    max_backoff: float = 300.0,
    max_cycles: int | None = None,
    max_runtime_sec: float | None = None,
    longpoll: Callable[[int], bool] | None = None,
    longpoll_timeout: int = 60,
    min_cycle_gap: float = 5.0,
    clock: Callable[[], float] = time.monotonic,
    on_event: Callable[[str, str], None] | None = None,
) -> WatchResult:
    """Repeat scan cycles until told to stop. Waiting always goes through
    stop.wait(), so a shutdown request ends any wait immediately; the only
    thing that can delay shutdown is a single in-flight network call, which
    the transport bounds with its own request timeout.

    note values from run_cycle:
      OK               clean cycle
      TRANSPORT_ERROR  retryable problem -> bounded exponential backoff
      AUTH_REQUIRED    credentials gone -> stop (a human has to act)
      STOPPING         a stop request interrupted the cycle
    """
    emit = on_event or (lambda event, detail: None)
    result = WatchResult()
    start = clock()
    consecutive = 0

    def remaining() -> float | None:
        return None if max_runtime_sec is None else max_runtime_sec - (clock() - start)

    while True:
        if stop.is_set():
            result.reason = "STOP_REQUESTED"
            break
        left = remaining()
        if left is not None and left <= 0:
            result.reason = "MAX_RUNTIME"
            break

        cycle_started = clock()
        summary = run_cycle()
        result.cycles += 1
        note = summary.note

        if note == "AUTH_REQUIRED":
            result.auth_required = True
            result.reason = "AUTH_REQUIRED"
            break
        if note == "OK":
            result.ok_cycles += 1
            if consecutive > 0:
                result.recoveries += 1
                emit("WATCH_RECOVERED", f"clean cycle after {consecutive} failed cycle(s)")
            consecutive = 0
        elif note == "TRANSPORT_ERROR":
            result.transport_error_cycles += 1
            consecutive += 1
            result.max_consecutive_failures = max(result.max_consecutive_failures, consecutive)

        if max_cycles and result.cycles >= max_cycles:
            result.reason = "MAX_CYCLES"
            break
        if stop.is_set():
            continue  # top of loop records STOP_REQUESTED

        if consecutive > 0:
            delay = compute_backoff(consecutive, poll_interval, max_backoff)
            result.backoff_waits += 1
            emit("WATCH_BACKOFF", f"{consecutive} consecutive failed cycle(s); waiting {delay:.0f}s")
        else:
            delay = poll_interval
            left = remaining()
            # Only long-poll when it cannot overrun the run budget by much
            # (the server may hold the request up to timeout + 90s).
            if longpoll is not None and (left is None or left > longpoll_timeout + 120):
                try:
                    result.longpoll_calls += 1
                    if longpoll(longpoll_timeout):
                        result.longpoll_changes += 1
                    delay = max(0.0, min_cycle_gap - (clock() - cycle_started))
                except TransportError as exc:
                    result.longpoll_errors += 1
                    emit("LONGPOLL_ERROR", str(exc)[:200])
                    delay = poll_interval  # fall back to plain polling for this round

        left = remaining()
        if left is not None:
            delay = min(delay, max(0.0, left))
        if delay > 0:
            stop.wait(delay)

    result.elapsed_sec = clock() - start
    return result
