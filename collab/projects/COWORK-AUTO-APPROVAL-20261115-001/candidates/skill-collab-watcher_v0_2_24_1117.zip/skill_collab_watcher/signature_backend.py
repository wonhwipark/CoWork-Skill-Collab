"""Ed25519 verification through the cryptography package.

The import is lazy: without cryptography installed, default_backend() returns
None and every approval check fails closed (see approval.verify_approval).
"""
from __future__ import annotations

import base64

from .approval import NotConfigured


class Ed25519Backend:
    def __init__(self) -> None:
        try:
            from cryptography.exceptions import InvalidSignature
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        except ImportError as exc:
            raise NotConfigured("cryptography is not installed") from exc
        self._invalid = InvalidSignature
        self._key_class = Ed25519PublicKey

    def verify(self, public_key: str, message: bytes, signature: str) -> bool:
        try:
            key = self._key_class.from_public_bytes(base64.b64decode(public_key, validate=True))
            key.verify(base64.b64decode(signature, validate=True), message)
            return True
        except (self._invalid, ValueError, TypeError):
            return False


def default_backend() -> Ed25519Backend | None:
    try:
        return Ed25519Backend()
    except NotConfigured:
        return None
