from __future__ import annotations

import hashlib
from dataclasses import dataclass, field

from .transport_base import (
    AuthRequired, EntryMeta, ListResult, RemoteNotFound, Transport, TransportError, UploadConflict,
)


@dataclass
class _File:
    data: bytes
    rev: str


@dataclass
class MockTransport(Transport):
    """Deterministic in-memory stand-in for Dropbox, for tests only.

    Like the real Dropbox cursor API, list_folder() returns the whole tree
    and list_folder_continue(cursor) returns ONLY the files that changed
    after that cursor. (An earlier version re-delivered the full snapshot on
    every continue, which hid any bug that depends on a request being seen
    in a single delta.)

    Call sequence is fully controlled by the test: push_file() to simulate
    a new/changed remote file, set_auth_ok(False) to simulate AUTH_REQUIRED,
    raise_network_error_once() / fail_next() to simulate transient failures.
    """

    files: dict[str, _File] = field(default_factory=dict)
    page_size: int = 0  # 0 = single page; >0 splits listings and sets has_more
    _seq: int = 0
    _changed_at: dict[str, int] = field(default_factory=dict)
    _folders: set[str] = field(default_factory=lambda: {"/SKILL-COLLAB"})
    _pages: dict[str, tuple[list[EntryMeta], str]] = field(default_factory=dict)
    _page_seq: int = 0
    _auth_ok: bool = True
    _pending_network_error: Exception | None = None
    _scripted: dict[str, list[Exception]] = field(default_factory=dict)
    _reset_next_cursor: bool = False
    list_folder_calls: int = 0
    list_folder_continue_calls: int = 0
    longpoll_calls: int = 0
    download_calls: int = 0

    # --- test controls -----------------------------------------------------

    def push_file(self, path: str, data: bytes) -> None:
        self._seq += 1
        self.files[path] = _File(data=data, rev=f"rev{self._seq}")
        self._changed_at[path] = self._seq
        parent = path.rsplit("/", 1)[0]
        while parent and parent not in self._folders:
            self._folders.add(parent)
            parent = parent.rsplit("/", 1)[0]

    def delete_file(self, path: str) -> None:
        self._seq += 1
        self.files.pop(path, None)
        self._changed_at.pop(path, None)

    def delete_folder(self, path: str) -> None:
        self._seq += 1
        for p in [p for p in self.files if p.startswith(path.rstrip("/") + "/")]:
            self.files.pop(p)
            self._changed_at.pop(p, None)
        self._folders.discard(path)

    def set_auth_ok(self, ok: bool) -> None:
        self._auth_ok = ok

    def raise_network_error_once(self, exc: Exception) -> None:
        self._pending_network_error = exc

    def fail_next(self, method: str, exc: Exception, times: int = 1) -> None:
        """Make the next `times` calls to one specific method raise exc."""
        self._scripted.setdefault(method, []).extend([exc] * times)

    def reset_next_cursor(self) -> None:
        self._reset_next_cursor = True

    # --- internals ---------------------------------------------------------

    def _maybe_raise(self, method: str) -> None:
        queue = self._scripted.get(method)
        if queue:
            raise queue.pop(0)
        if self._pending_network_error is not None:
            exc = self._pending_network_error
            self._pending_network_error = None
            raise exc
        if not self._auth_ok:
            raise AuthRequired("mock auth not configured")

    def _meta(self, path: str) -> EntryMeta:
        f = self.files[path]
        return EntryMeta(
            path=path, rev=f.rev, size=len(f.data),
            content_hash=hashlib.sha256(f.data).hexdigest(), file_id=f"id:{path}",
        )

    def _page(self, entries: list[EntryMeta]) -> ListResult:
        final_cursor = f"cursor-{self._seq}"
        if self.page_size <= 0 or len(entries) <= self.page_size:
            return ListResult(entries=entries, cursor=final_cursor, has_more=False)
        first, rest = entries[: self.page_size], entries[self.page_size:]
        self._page_seq += 1
        token = f"page-{self._page_seq}"
        self._pages[token] = (rest, final_cursor)
        return ListResult(entries=first, cursor=token, has_more=True)

    # --- Transport API -----------------------------------------------------

    def ensure_auth(self) -> None:
        self._maybe_raise("ensure_auth")

    def list_folder(self, path: str) -> ListResult:
        self._maybe_raise("list_folder")
        self.list_folder_calls += 1
        root = path.rstrip("/")
        if root and root not in self._folders:
            raise RemoteNotFound(path)
        entries = [self._meta(p) for p in sorted(self.files) if p.startswith(root + "/")]
        return self._page(entries)

    def list_folder_continue(self, cursor: str) -> ListResult:
        self._maybe_raise("list_folder_continue")
        self.list_folder_continue_calls += 1
        if self._reset_next_cursor:
            self._reset_next_cursor = False
            raise TransportError("CURSOR_RESET")
        if cursor in self._pages:
            rest, final_cursor = self._pages.pop(cursor)
            if self.page_size > 0 and len(rest) > self.page_size:
                first, rest2 = rest[: self.page_size], rest[self.page_size:]
                self._page_seq += 1
                token = f"page-{self._page_seq}"
                self._pages[token] = (rest2, final_cursor)
                return ListResult(entries=first, cursor=token, has_more=True)
            return ListResult(entries=rest, cursor=final_cursor, has_more=False)
        since = int(cursor.split("-", 1)[1])
        entries = [self._meta(p) for p in sorted(self.files) if self._changed_at.get(p, 0) > since]
        return self._page(entries)

    def longpoll(self, cursor: str, timeout_sec: int) -> bool:
        self._maybe_raise("longpoll")
        self.longpoll_calls += 1
        return True

    def download(self, path: str) -> tuple[bytes, EntryMeta]:
        self._maybe_raise("download")
        self.download_calls += 1
        f = self.files.get(path)
        if f is None:
            raise TransportError(f"not found: {path}")
        return f.data, self._meta(path)

    def get_metadata(self, path: str) -> EntryMeta | None:
        self._maybe_raise("get_metadata")
        if path not in self.files:
            return None
        return self._meta(path)

    def upload(self, path: str, data: bytes, mode: str = "add") -> EntryMeta:
        self._maybe_raise("upload")
        if mode == "add" and path in self.files:
            raise UploadConflict(path)
        self.push_file(path, data)
        return self._meta(path)
