from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from .models import ReviewResult


@dataclass
class FakeReviewRunner:
    """Test double used by every automated test in this project. Never
    imports subprocess and never touches claude_exe - calls are just
    counted so tests can assert exactly how many review dispatches an
    orchestrator decision produced."""

    calls: int = 0
    preflight_calls: int = 0
    preflight_reason: str | None = None  # None = logged in; otherwise the reason code returned
    last_budget: float | None = None
    last_effort: str | None = None
    canned_result: ReviewResult = field(
        default_factory=lambda: ReviewResult(
            ok=True, output_text="FAKE_REVIEW_OK", output_format="json",
            exit_code=0, model_calls=0, usage=None,
        )
    )

    def preflight(self) -> tuple[bool, str]:
        self.preflight_calls += 1
        return (self.preflight_reason is None, self.preflight_reason or "ok")

    def run(
        self, snapshot_dir: Path, prompt_text: str, run_dir: Path,
        max_budget_usd: float | None = None, effort: str | None = None,
    ) -> ReviewResult:
        self.calls += 1
        self.last_budget = max_budget_usd
        self.last_effort = effort
        return self.canned_result
