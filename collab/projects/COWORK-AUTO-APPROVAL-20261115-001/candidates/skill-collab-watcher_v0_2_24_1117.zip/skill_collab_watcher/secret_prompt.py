"""Hidden-input dialog for the Dropbox authorization code.

Why a dialog: on Windows, getpass() reads the console in a mode that does not
accept clipboard paste reliably, and the code is long and meant to be pasted.
A Tk entry with show="*" accepts Ctrl+V / Shift+Insert / right-click paste and
never echoes the value.

Rules this module keeps:
  * the value is returned to the caller and nowhere else: it is not printed,
    logged, put in an exception message or passed on a command line;
  * the clipboard is never read by this program - only the user's own paste
    action inside the dialog puts text into the field;
  * if no dialog can be shown, it fails with PromptUnavailable. It does NOT
    fall back to input()/getpass(), which would echo or mishandle the code.
"""
from __future__ import annotations

from typing import Callable


class PromptError(Exception):
    """Base class; messages never contain the entered value."""


class PromptUnavailable(PromptError):
    """No GUI could be opened (tkinter missing, no display, headless session)."""


class PromptCancelled(PromptError):
    """The user closed the dialog or pressed Cancel."""


class PromptEmpty(PromptError):
    """The user pressed OK with nothing (or only whitespace) in the field."""


def _tk_ask(title: str, prompt: str, _driver: Callable | None = None) -> str | None:
    """Show the dialog. Returns the text on OK ('' if empty) or None on Cancel.

    _driver is a test seam: it is called with the hidden root window shortly
    after the dialog opens, so a test can type into it and press a button."""
    try:
        import tkinter as tk
        from tkinter import simpledialog
    except ImportError as exc:  # tkinter not installed with this Python
        raise PromptUnavailable(
            "tkinter is not available in this Python installation, so the secure input window cannot open."
        ) from exc

    try:
        root = tk.Tk()
    except tk.TclError as exc:  # no display / headless / blocked desktop
        raise PromptUnavailable(
            "Could not open a window for the authorization code (no usable display). "
            "Run auth-init from a normal desktop session."
        ) from exc

    try:
        # A 1x1 transparent topmost parent: the dialog is transient to it, so
        # it opens in front of the console instead of behind it.
        root.title(title)
        root.attributes("-topmost", True)
        root.attributes("-alpha", 0.0)
        root.geometry("1x1+0+0")
        root.update()
        if _driver is not None:
            root.after(200, lambda: _driver(root))
        return simpledialog.askstring(title, prompt, show="*", parent=root)
    finally:
        try:
            root.destroy()
        except tk.TclError:  # already destroyed (window closed from outside)
            pass


def ask_authorization_code(
    title: str = "Dropbox authorization code",
    prompt: str = "Paste the authorization code shown by Dropbox\n(Ctrl+V works; the text is hidden):",
    *,
    ask: Callable[[str, str], str | None] = _tk_ask,
) -> str:
    """Return the stripped code, or raise PromptCancelled / PromptEmpty /
    PromptUnavailable. `ask` is replaceable for tests."""
    answer = ask(title, prompt)
    if answer is None:
        raise PromptCancelled("authorization code entry was cancelled")
    answer = answer.strip()
    if not answer:
        raise PromptEmpty("no authorization code was entered")
    return answer
