"""Approval bundle checks for the GitHub provider (B-1, B-7).

A READY file alone never authorises a model call. The approval must be signed
by an ACTIVE key of a trust root that lives outside the repository, bound to
the exact bytes it approves, and fresh. Without a trust root or a signature
backend every check fails closed with NotConfigured, so no model call starts.

Signed message: canonical(payload) = JSON with sorted keys, compact separators,
UTF-8, no BOM. The signature is base64 over that message.

Trust root (SKILL_COLLAB_TRUST_ROOT_V1) lifecycle, enforced here and in the CLI:
  - kept outside the repository, pinned by SHA-256 in the local config, readable
    only by trusted principals (ACL check on Windows);
  - monotonic `version`: the watcher refuses a lower version than it has accepted
    (rollback protection); recovery from a compromise is always a HIGHER version;
  - per-key status ACTIVE | RETIRED | REVOKED, optional not_before/not_after;
  - `frozen: true` rejects every approval without touching keys (incident stop);
  - approvals may not live longer than `max_approval_lifetime_sec`.
"""
from __future__ import annotations

import base64
import hashlib
import json
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any, Callable, Protocol

APPROVAL_SCHEMA = "SKILL_COLLAB_APPROVAL_SIG_V1"
PAYLOAD_SCHEMA = "SKILL_COLLAB_APPROVAL_PAYLOAD_V1"
PIN_SCHEMA = "SKILL_COLLAB_SOURCE_PIN_V1"
TRUST_ROOT_SCHEMA = "SKILL_COLLAB_TRUST_ROOT_V1"
CLOCK_SKEW = timedelta(minutes=5)
MAX_SERVER_CLOCK_SKEW = timedelta(minutes=5)
KEY_STATUSES = ("ACTIVE", "RETIRED", "REVOKED")
KEY_PURPOSE = "review-approval"
DEFAULT_MAX_LIFETIME_SEC = 24 * 3600
MIN_NONCE_LENGTH = 16


class NotConfigured(Exception):
    """No trust root or signature backend: the approval cannot be verified."""


class ApprovalRejected(Exception):
    """The approval exists but does not match what it claims to approve."""


class TrustRootError(ValueError):
    """The trust root file is unusable (pin mismatch, rollback, bad content)."""


class ClockUntrusted(Exception):
    """The local clock cannot be trusted against the provider's clock."""


class SignatureBackend(Protocol):
    def verify(self, public_key: str, message: bytes, signature: str) -> bool: ...


@dataclass(frozen=True)
class TrustedKey:
    key_id: str
    public_key: str
    fingerprint: str
    status: str
    purpose: str = KEY_PURPOSE
    not_before: str | None = None
    not_after: str | None = None


@dataclass(frozen=True)
class TrustRoot:
    repo_id: str
    keys: dict[str, TrustedKey] = field(default_factory=dict)
    version: int = 1
    frozen: bool = False
    max_approval_lifetime_sec: int = DEFAULT_MAX_LIFETIME_SEC


def canonical(payload: dict[str, Any]) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def fingerprint_of(public_key_b64: str) -> str:
    raw = base64.b64decode(public_key_b64, validate=True)
    if len(raw) != 32:
        raise ValueError("Ed25519 public key must be 32 bytes")
    return hashlib.sha256(raw).hexdigest()


def _aware(text: str, what: str) -> datetime:
    try:
        value = datetime.fromisoformat(str(text))
    except ValueError as exc:
        raise TrustRootError(f"{what} is not an ISO timestamp") from exc
    if value.tzinfo is None:
        raise TrustRootError(f"{what} has no timezone")
    return value


def load_trust_root(path: str | None, *, expected_sha256: str | None = None) -> TrustRoot | None:
    """None when no trust root file is configured. Every defect is a TrustRootError,
    never a partial root. expected_sha256 pins the exact file bytes."""
    if not path:
        return None
    try:
        data = Path(path).read_bytes()
    except OSError as exc:
        raise TrustRootError("TRUST_ROOT_UNREADABLE") from exc
    if expected_sha256 is not None and hashlib.sha256(data).hexdigest() != expected_sha256.strip().lower():
        raise TrustRootError("TRUST_ROOT_PIN_MISMATCH")
    try:
        obj = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise TrustRootError("TRUST_ROOT_NOT_JSON") from exc
    if not isinstance(obj, dict) or obj.get("schema") != TRUST_ROOT_SCHEMA:
        raise TrustRootError("trust root schema mismatch")
    keys: dict[str, TrustedKey] = {}
    for item in obj.get("keys") or []:
        status = str(item.get("status"))
        if status not in KEY_STATUSES:
            raise TrustRootError(f"unknown key status {status!r}")
        key = TrustedKey(
            key_id=str(item["key_id"]), public_key=str(item["public_key"]),
            fingerprint=str(item["fingerprint"]).lower(), status=status,
            purpose=str(item.get("purpose", KEY_PURPOSE)),
            not_before=item.get("not_before"), not_after=item.get("not_after"),
        )
        try:
            fp = fingerprint_of(key.public_key)
        except ValueError as exc:
            raise TrustRootError("trust root public key is malformed") from exc
        if fp != key.fingerprint:
            raise TrustRootError("trust root fingerprint does not match its public key")
        if key.key_id in keys:
            raise TrustRootError("duplicate key_id in trust root")
        for name, value in (("not_before", key.not_before), ("not_after", key.not_after)):
            if value is not None:
                _aware(value, f"key {name}")
        keys[key.key_id] = key
    version = obj.get("version", 1)
    lifetime = obj.get("max_approval_lifetime_sec", DEFAULT_MAX_LIFETIME_SEC)
    if not isinstance(version, int) or isinstance(version, bool) or version < 1:
        raise TrustRootError("trust root version must be a positive integer")
    if not isinstance(lifetime, int) or isinstance(lifetime, bool) or not 60 <= lifetime <= 7 * 24 * 3600:
        raise TrustRootError("max_approval_lifetime_sec must be between 60 and 604800")
    return TrustRoot(repo_id=str(obj["repo_id"]), keys=keys, version=version,
                     frozen=bool(obj.get("frozen", False)), max_approval_lifetime_sec=lifetime)


# --- trust root file permissions (Windows) -----------------------------------------------

#
# The check reads the file's security descriptor through the Windows API (no child
# process is started: review_runner.py stays the only place that spawns processes).

_BROAD_SIDS = {
    "WD": "Everyone", "S-1-1-0": "Everyone",
    "BU": "Users", "S-1-5-32-545": "Users",
    "AU": "Authenticated Users", "S-1-5-11": "Authenticated Users",
    "IU": "Interactive", "S-1-5-4": "Interactive",
    "DU": "Domain Users",
}
_RIGHT_BITS = {
    "FA": 0x1F01FF, "FW": 0x120116, "FR": 0x120089, "FX": 0x1200A0,
    "GA": 0x10000000, "GW": 0x40000000, "GR": 0x80000000, "GX": 0x20000000,
    "SD": 0x10000, "RC": 0x20000, "WD": 0x40000, "WO": 0x80000, "DC": 0x40,
    "CC": 0x1, "DT": 0x2, "LC": 0x4, "SW": 0x8, "RP": 0x10, "WP": 0x20, "LO": 0x80, "CR": 0x100,
}
# FILE_WRITE_DATA, FILE_APPEND_DATA, FILE_WRITE_EA, FILE_DELETE_CHILD, FILE_WRITE_ATTRIBUTES,
# DELETE, WRITE_DAC, WRITE_OWNER, GENERIC_ALL, GENERIC_WRITE
_WRITE_MASK = 0x2 | 0x4 | 0x10 | 0x40 | 0x100 | 0x10000 | 0x40000 | 0x80000 | 0x10000000 | 0x40000000
_ACE = re.compile(r"\(([A-Z]+);([^;]*);([^;]*);([^;]*);([^;]*);([^)]*)\)")


def _rights_mask(text: str) -> int:
    text = text.strip()
    if text.lower().startswith("0x"):
        return int(text, 16)
    return sum(_RIGHT_BITS.get(text[i:i + 2], 0) for i in range(0, len(text), 2))


def sddl_write_findings(sddl: str) -> list[str]:
    """Broad principals granted write-like rights by an ALLOW entry in the DACL.
    Pure function over an SDDL string so it is testable on any platform."""
    dacl = sddl.split("D:", 1)[1] if "D:" in sddl else ""
    dacl = dacl.split("S:", 1)[0]
    if "NO_ACCESS_CONTROL" in dacl:
        return ["the file has no access control (everyone can modify it)"]
    findings: list[str] = []
    for ace_type, _flags, rights, _guid, _inherit, sid in _ACE.findall(dacl):
        if ace_type != "A":
            continue
        name = _BROAD_SIDS.get(sid.strip())
        if name is None and re.fullmatch(r"S-1-5-21(?:-\d+)+-513", sid.strip()):
            name = "Domain Users"
        if name is not None and _rights_mask(rights) & _WRITE_MASK:
            findings.append(f"{name} has write access")
    return findings


def _read_sddl(path: str) -> str:
    import ctypes
    from ctypes import wintypes

    advapi = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    advapi.GetNamedSecurityInfoW.argtypes = [wintypes.LPCWSTR, ctypes.c_int, wintypes.DWORD] + [ctypes.c_void_p] * 4 \
        + [ctypes.POINTER(ctypes.c_void_p)]
    advapi.GetNamedSecurityInfoW.restype = wintypes.DWORD
    advapi.ConvertSecurityDescriptorToStringSecurityDescriptorW.argtypes = [
        ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(wintypes.ULONG)]
    advapi.ConvertSecurityDescriptorToStringSecurityDescriptorW.restype = wintypes.BOOL
    descriptor = ctypes.c_void_p()
    if advapi.GetNamedSecurityInfoW(str(path), 1, 4, None, None, None, None, ctypes.byref(descriptor)) != 0:
        raise OSError("GetNamedSecurityInfoW failed")
    try:
        text_ptr = ctypes.c_void_p()
        if not advapi.ConvertSecurityDescriptorToStringSecurityDescriptorW(descriptor, 1, 4, ctypes.byref(text_ptr), None):
            raise OSError("ConvertSecurityDescriptorToStringSecurityDescriptorW failed")
        try:
            return ctypes.wstring_at(text_ptr.value)
        finally:
            kernel.LocalFree(text_ptr)
    finally:
        kernel.LocalFree(descriptor)


def check_trust_root_acl(path: str, read_sddl: Callable[[str], str] | None = None) -> list[str]:
    """Empty list when no broad group can modify the file. A file whose permissions
    cannot be read is a finding, not a pass. Non-Windows hosts report none (the
    watcher is a Windows service)."""
    if read_sddl is None:
        if sys.platform != "win32":
            return []
        read_sddl = _read_sddl
    try:
        return sddl_write_findings(read_sddl(str(path)))
    except OSError:
        return ["the file permissions could not be read"]


def _effective_mask(path: str) -> int:
    """Rights the CURRENT process's account (the user and every group it belongs to) has on a file or
    folder, from the DACL via GetEffectiveRightsFromAclW. No child process, nothing is written."""
    import ctypes
    from ctypes import wintypes

    advapi = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    advapi.OpenProcessToken.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE)]
    advapi.GetTokenInformation.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD,
                                           ctypes.POINTER(wintypes.DWORD)]
    advapi.GetNamedSecurityInfoW.argtypes = [wintypes.LPCWSTR, ctypes.c_int, wintypes.DWORD, ctypes.c_void_p,
                                             ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p), ctypes.c_void_p,
                                             ctypes.POINTER(ctypes.c_void_p)]
    advapi.GetNamedSecurityInfoW.restype = wintypes.DWORD
    advapi.BuildTrusteeWithSidW.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    advapi.GetEffectiveRightsFromAclW.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.POINTER(wintypes.DWORD)]
    advapi.GetEffectiveRightsFromAclW.restype = wintypes.DWORD

    class TRUSTEE(ctypes.Structure):
        _fields_ = [("pMultipleTrustee", ctypes.c_void_p), ("MultipleTrusteeOperation", ctypes.c_int),
                    ("TrusteeForm", ctypes.c_int), ("TrusteeType", ctypes.c_int), ("ptstrName", ctypes.c_void_p)]

    token = wintypes.HANDLE()
    if not advapi.OpenProcessToken(kernel.GetCurrentProcess(), 0x8, ctypes.byref(token)):  # TOKEN_QUERY
        raise OSError("OpenProcessToken failed")
    descriptor = ctypes.c_void_p()
    try:
        needed = wintypes.DWORD(0)
        advapi.GetTokenInformation(token, 1, None, 0, ctypes.byref(needed))  # TokenUser: ask for the size
        buf = ctypes.create_string_buffer(needed.value)
        if not advapi.GetTokenInformation(token, 1, buf, needed, ctypes.byref(needed)):
            raise OSError("GetTokenInformation failed")
        sid = ctypes.c_void_p.from_buffer(buf).value
        dacl = ctypes.c_void_p()
        if advapi.GetNamedSecurityInfoW(str(path), 1, 4, None, None, ctypes.byref(dacl), None,
                                        ctypes.byref(descriptor)) != 0:
            raise OSError("GetNamedSecurityInfoW failed")
        trustee = TRUSTEE()
        advapi.BuildTrusteeWithSidW(ctypes.byref(trustee), sid)
        mask = wintypes.DWORD(0)
        if advapi.GetEffectiveRightsFromAclW(dacl, ctypes.byref(trustee), ctypes.byref(mask)) != 0:
            raise OSError("GetEffectiveRightsFromAclW failed")
        return int(mask.value)
    finally:
        if descriptor.value:
            kernel.LocalFree(descriptor)
        kernel.CloseHandle(token)


def watcher_write_findings(items: list[tuple[str, str]],
                           effective_mask: Callable[[str], int] | None = None) -> list[str]:
    """S-2: the account the watcher runs as must not be able to change what it trusts. items are
    (role, path) pairs. A missing item or an unreadable permission is a finding, not a pass.
    Roles are reported, never paths. Non-Windows hosts report none (the watcher is a Windows service)."""
    if effective_mask is None:
        if sys.platform != "win32":
            return []
        effective_mask = _effective_mask
    findings: list[str] = []
    for role, path in items:
        try:
            present = Path(path).exists()
        except OSError:  # access denied: the account cannot even look, which is a finding, not a crash
            findings.append(f"{role}: permissions could not be read")
            continue
        if not present:
            findings.append(f"{role} does not exist")
            continue
        try:
            mask = effective_mask(str(path))
        except OSError:
            findings.append(f"{role}: permissions could not be read")
            continue
        if mask & _WRITE_MASK:
            findings.append(f"{role} can be modified by the watcher's own account")
    return findings


# --- clock -------------------------------------------------------------------------------

def check_clock(server_time: datetime | None, now: datetime, max_skew: timedelta = MAX_SERVER_CLOCK_SKEW) -> None:
    """Fail closed when the provider's clock is unknown or far from the local one,
    so an attacker (or a dead battery) cannot stretch an expired approval."""
    if server_time is None:
        raise ClockUntrusted("provider time unavailable")
    if abs(now.astimezone(timezone.utc) - server_time.astimezone(timezone.utc)) > max_skew:
        raise ClockUntrusted("local clock differs from the provider clock")


def parse_http_date(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = parsedate_to_datetime(value)
    except (TypeError, ValueError):
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def knowledge_refs_hash(refs: list[Any]) -> str:
    """Binds the pinned knowledge files (path and sha256) into the approval."""
    normalized = [
        {"path": str(r.get("path")), "sha256": str(r.get("sha256")).lower()}
        for r in refs if isinstance(r, dict)
    ]
    return hashlib.sha256(canonical({"refs": normalized})).hexdigest()


def _parse(raw: bytes, schema: str, label: str) -> dict[str, Any]:
    try:
        obj = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise ApprovalRejected(f"{label}_NOT_JSON") from exc
    if not isinstance(obj, dict) or obj.get("schema") != schema:
        raise ApprovalRejected(f"{label}_SCHEMA_MISMATCH")
    return obj


def verify_approval(
    approval_raw: bytes,
    pin_raw: bytes,
    *,
    trust: TrustRoot | None,
    backend: SignatureBackend | None,
    expected: dict[str, Any],
    now: datetime,
) -> dict[str, Any]:
    if trust is None:
        raise NotConfigured("trust root is not configured")
    if backend is None:
        raise NotConfigured("signature backend is not configured")
    if trust.frozen:
        raise ApprovalRejected("TRUST_ROOT_FROZEN")

    approval = _parse(approval_raw, APPROVAL_SCHEMA, "APPROVAL")
    pin = _parse(pin_raw, PIN_SCHEMA, "PIN")
    payload = approval.get("payload")
    signature = approval.get("signature")
    if not isinstance(payload, dict) or payload.get("schema") != PAYLOAD_SCHEMA:
        raise ApprovalRejected("APPROVAL_PAYLOAD_SCHEMA_MISMATCH")
    if not isinstance(signature, str) or not signature:
        raise ApprovalRejected("MISSING_SIGNATURE")
    key = trust.keys.get(str(approval.get("key_id")))
    if key is None:
        raise ApprovalRejected("UNKNOWN_KEY_ID")
    if key.status == "REVOKED":
        raise ApprovalRejected("KEY_REVOKED")
    if key.status != "ACTIVE":
        raise ApprovalRejected("KEY_RETIRED")
    if key.purpose != KEY_PURPOSE:
        raise ApprovalRejected("KEY_WRONG_PURPOSE")
    if not backend.verify(key.public_key, canonical(payload), signature):
        raise ApprovalRejected("BAD_SIGNATURE")

    if payload.get("repo_id") != trust.repo_id or pin.get("repo_id") != trust.repo_id:
        raise ApprovalRejected("REPO_ID_MISMATCH")
    for name, want in expected.items():
        if payload.get(name) != want:
            raise ApprovalRejected(f"BINDING_MISMATCH:{name}")
    # The source commit A (where the artifacts were committed) must agree with
    # the pin. The approval lives in a later commit, so the pinned head is not
    # compared; the artifact bytes are bound by their hashes instead.
    if pin.get("commit") != payload.get("source_commit"):
        raise ApprovalRejected("SOURCE_COMMIT_MISMATCH")
    nonce = payload.get("nonce")
    if not isinstance(nonce, str) or len(nonce) < MIN_NONCE_LENGTH:
        raise ApprovalRejected("NONCE_MISSING")

    try:
        issued = datetime.fromisoformat(str(payload["issued_at"]))
        expires = datetime.fromisoformat(str(payload["expires_at"]))
    except (KeyError, ValueError) as exc:
        raise ApprovalRejected("APPROVAL_TIME_INVALID") from exc
    if issued.tzinfo is None or expires.tzinfo is None:
        raise ApprovalRejected("APPROVAL_TIME_NOT_TIMEZONE_AWARE")
    if expires - issued > timedelta(seconds=trust.max_approval_lifetime_sec):
        raise ApprovalRejected("APPROVAL_LIFETIME_TOO_LONG")
    if key.not_before is not None and issued < _aware(key.not_before, "key not_before"):
        raise ApprovalRejected("KEY_NOT_YET_VALID")
    if key.not_after is not None and issued > _aware(key.not_after, "key not_after"):
        raise ApprovalRejected("KEY_EXPIRED")
    now_utc = now.astimezone(timezone.utc)
    if now_utc < issued.astimezone(timezone.utc) - CLOCK_SKEW:
        raise ApprovalRejected("APPROVAL_NOT_YET_VALID")
    if now_utc >= expires.astimezone(timezone.utc):
        raise ApprovalRejected("APPROVAL_EXPIRED")
    return payload
