"""Dropbox OAuth parameters, kept free of I/O so they can be unit-tested.

The app registered in the Dropbox App Console must have exactly these four
permissions enabled (Scoped access, "Full Dropbox" so that /SKILL-COLLAB is
reachable at its real path). The authorization request names them
explicitly instead of defaulting to "every scope the app has", so a team
scope that happens to be ticked on the app is never requested.
"""
from __future__ import annotations

import re

REQUIRED_SCOPES: tuple[str, ...] = (
    "account_info.read",   # users_get_current_account (the auth probe)
    "files.metadata.read",  # list_folder, get_metadata, longpoll
    "files.content.read",   # download
    "files.content.write",  # upload reviews / receipts / packages
)

# Anything a personal single-user watcher has no business holding.
_TEAM_SCOPE_PREFIXES = (
    "team_", "members.", "groups.", "sessions.", "events.", "files.team_metadata.", "team_data.",
)


MAX_CODE_ATTEMPTS = 3

_OAUTH_ERROR = re.compile(r"[a-z_]{1,40}")

# What the OAuth error code usually means for THIS flow. Only the code itself
# (a fixed vocabulary, not a secret) is ever shown from the server reply.
_TOKEN_ERROR_HINTS = {
    "invalid_grant": (
        "The code is wrong, expired, already used, or belongs to an earlier auth-init run. "
        "Every run prints a NEW URL and only the code from THAT URL works. Copy the whole code "
        "(no spaces, nothing missing) from the page Dropbox shows after you press Allow."
    ),
    "invalid_client": (
        "Dropbox does not recognise this app key, or the app does not allow public clients. "
        "Check the key, and in the App Console (Settings tab) set "
        "'Allow public clients (Implicit Grant & PKCE)' to Allow."
    ),
    "unauthorized_client": (
        "The app is not allowed to use this flow. In the App Console (Settings tab) set "
        "'Allow public clients (Implicit Grant & PKCE)' to Allow."
    ),
    "invalid_request": "Dropbox could not parse the request; run auth-init again from the start.",
    "invalid_scope": "The app's permissions do not include all four required scopes (Permissions tab).",
}


def describe_token_failure(exc: BaseException) -> tuple[str, str]:
    """(summary, hint) for a failed code-for-token exchange.

    Uses only the exception type, the HTTP status and the OAuth `error`
    token, and only if that token is a plain lowercase word. The reply's
    error_description is never used: it can repeat request details."""
    response = getattr(exc, "response", None)
    status = getattr(response, "status_code", None)
    error = None
    if response is not None:
        try:
            body = response.json()
        except ValueError:
            body = None
        candidate = body.get("error") if isinstance(body, dict) else None
        if isinstance(candidate, str) and _OAUTH_ERROR.fullmatch(candidate):
            error = candidate
    parts = [type(exc).__name__]
    if status:
        parts.append(f"HTTP {status}")
    if error:
        parts.append(error)
    hint = _TOKEN_ERROR_HINTS.get(error or "", "Codes are single-use and expire quickly; try again with a fresh one.")
    return " ".join(parts), hint


def build_flow(app_key: str, flow_cls):
    """PKCE (no app secret stored), offline (refresh token), explicit scopes."""
    return flow_cls(
        app_key,
        use_pkce=True,
        token_access_type="offline",
        scope=list(REQUIRED_SCOPES),
    )


def _as_set(scope) -> set[str]:
    if not scope:
        return set()
    if isinstance(scope, str):
        return set(scope.split())
    return set(scope)


def validate_grant(granted_scope, refresh_token: str | None) -> list[str]:
    """Problems with what Dropbox actually granted. Empty list = fine.
    Never includes the token itself."""
    problems: list[str] = []
    granted = _as_set(granted_scope)
    if not refresh_token:
        problems.append("no refresh token was returned (offline access was not granted)")
    missing = [s for s in REQUIRED_SCOPES if s not in granted]
    if missing:
        problems.append(f"missing required scope(s): {', '.join(missing)} - enable them under the app's Permissions tab")
    team = sorted(s for s in granted if s.startswith(_TEAM_SCOPE_PREFIXES))
    if team:
        problems.append(f"team-level scope(s) were granted and must not be: {', '.join(team)}")
    return problems
