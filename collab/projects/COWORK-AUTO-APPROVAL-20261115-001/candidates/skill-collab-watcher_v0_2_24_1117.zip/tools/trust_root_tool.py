"""Operator tool for the approval trust root. It handles PUBLIC keys only.

    python -m tools.trust_root_tool build --repo-id ID --out FILE --version N \
        --key KEY_ID:PUBLIC_KEY_BASE64[:ACTIVE|RETIRED|REVOKED] [--key ...] [--frozen]
    python -m tools.trust_root_tool inspect FILE [--pin SHA256]

`build` writes the file and prints the SHA-256 to pin in the local configuration.
`inspect` loads the file exactly as the watcher does and reports its permissions.
Neither command creates, reads or stores a private key or a token.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from skill_collab_watcher.approval import (  # noqa: E402
    KEY_STATUSES, TRUST_ROOT_SCHEMA, TrustRootError, check_trust_root_acl, fingerprint_of, load_trust_root,
)


def cmd_build(args) -> int:
    keys = []
    for spec in args.key:
        parts = spec.split(":")
        if len(parts) not in (2, 3):
            print("REFUSED: --key must be KEY_ID:PUBLIC_KEY_BASE64[:STATUS]", file=sys.stderr)
            return 2
        key_id, public_key = parts[0], parts[1]
        status = parts[2] if len(parts) == 3 else "ACTIVE"
        if status not in KEY_STATUSES:
            print(f"REFUSED: status must be one of {KEY_STATUSES}", file=sys.stderr)
            return 2
        try:
            fingerprint = fingerprint_of(public_key)
        except ValueError:
            print("REFUSED: not a base64 Ed25519 public key (32 bytes)", file=sys.stderr)
            return 2
        keys.append({"key_id": key_id, "algorithm": "ed25519", "public_key": public_key,
                     "fingerprint": fingerprint, "status": status, "purpose": "review-approval"})
    document = {"schema": TRUST_ROOT_SCHEMA, "repo_id": args.repo_id, "version": args.version,
                "frozen": bool(args.frozen), "max_approval_lifetime_sec": args.max_lifetime_sec, "keys": keys}
    out = Path(args.out)
    if out.exists():
        print("REFUSED: output exists; a trust root is never overwritten in place (publish a higher version)",
              file=sys.stderr)
        return 2
    data = (json.dumps(document, indent=2, sort_keys=True) + "\n").encode("utf-8")
    out.write_bytes(data)
    try:
        load_trust_root(str(out))
    except TrustRootError as exc:
        out.unlink()
        print(f"REFUSED: {exc}", file=sys.stderr)
        return 2
    print(f"written: {out.name}  bytes={len(data)}")
    print(f"pin this in the local config as github.trust_root_sha256: {hashlib.sha256(data).hexdigest()}")
    return 0


def cmd_inspect(args) -> int:
    try:
        root = load_trust_root(args.file, expected_sha256=args.pin)
    except TrustRootError as exc:
        print(f"REFUSED: {exc}")
        return 1
    print(f"version={root.version} frozen={root.frozen} max_approval_lifetime_sec={root.max_approval_lifetime_sec}")
    for key in root.keys.values():
        print(f"  key {key.key_id}: status={key.status} purpose={key.purpose} fingerprint={key.fingerprint[:16]}...")
    findings = check_trust_root_acl(args.file)
    print("permissions: " + ("ok (no broad group can write)" if not findings else "; ".join(findings)))
    print(f"file sha256: {hashlib.sha256(Path(args.file).read_bytes()).hexdigest()}")
    return 0 if not findings else 1


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = parser.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build")
    b.add_argument("--repo-id", required=True)
    b.add_argument("--out", required=True)
    b.add_argument("--version", type=int, required=True)
    b.add_argument("--key", action="append", required=True)
    b.add_argument("--frozen", action="store_true")
    b.add_argument("--max-lifetime-sec", type=int, default=86400)
    b.set_defaults(f=cmd_build)
    i = sub.add_parser("inspect")
    i.add_argument("file")
    i.add_argument("--pin")
    i.set_defaults(f=cmd_inspect)
    args = parser.parse_args(argv)
    return args.f(args)


if __name__ == "__main__":
    sys.exit(main())
