"""Build and check the distributable ZIP of this project.

    python -m tools.build_release --out dist/skill-collab-watcher_v0_1_1_1101.zip

The build is deterministic (sorted entries, fixed timestamps and modes, no
directory entries) so building the same tree twice yields byte-identical
files - which is what lets a published ZIP be verified by hash later and
guarantees we never publish "the same name with different bytes".

Only an allow-list of top-level locations is packaged. Local state, virtual
environments, caches, credentials and the machine-specific reviewer.config.json
are never included.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import os
import re
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

INCLUDE_FILES = ("README.md", "CHANGELOG.md", "requirements.txt", "requirements-crypto-test.lock")
INCLUDE_DIRS = ("skill_collab_watcher", "tests", "tools", "windows", "prompts", "config", "docs", "su_l1")

EXCLUDE_DIR_NAMES = {
    ".venv", "venv", "__pycache__", ".pytest_cache", ".git", "dist", "build", "runs", "snapshots", ".mypy_cache",
}
EXCLUDE_FILE_NAMES = {
    "secrets.json", "reviewer.config.json", "state.sqlite3", "watch.lock", ".env",
}
EXCLUDE_SUFFIXES = (".pyc", ".pyo", ".sqlite3", ".sqlite3-wal", ".sqlite3-shm", ".db", ".log")

FIXED_TIME = (2026, 11, 1, 0, 0, 0)  # ZIP cannot store dates before 1980; any constant works
FILE_MODE = 0o100644 << 16

# Credential shapes. Test fixtures in this repo are written so they do not
# match (their dummy values contain no long quoted token after a key name).
SECRET_PATTERNS = {
    "dropbox access token (sl.…)": re.compile(rb"\bsl\.[A-Za-z0-9_\-]{30,}"),
    "json credential field": re.compile(
        rb'"(?:refresh_token|access_token|app_secret|client_secret|password)"\s*:\s*"[^"\s]{16,}"', re.I),
    "authorization header": re.compile(rb"authorization\s*:\s*bearer\s+[A-Za-z0-9._\-]{16,}", re.I),
    "private key block": re.compile(rb"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
}


@dataclass
class ScanReport:
    files_scanned: int = 0
    bytes_scanned: int = 0
    findings: list[str] = field(default_factory=list)
    known_secret_values_checked: int = 0

    @property
    def clean(self) -> bool:
        return not self.findings


def _excluded(path: Path) -> bool:
    if any(part in EXCLUDE_DIR_NAMES for part in path.parts):
        return True
    return path.name in EXCLUDE_FILE_NAMES or path.name.endswith(EXCLUDE_SUFFIXES)


def collect_files(root: Path = ROOT) -> list[Path]:
    """Relative paths of everything that goes into the ZIP, sorted."""
    found: list[Path] = []
    for name in INCLUDE_FILES:
        if (root / name).is_file():
            found.append(Path(name))
    for dirname in INCLUDE_DIRS:
        base = root / dirname
        if not base.is_dir():
            continue
        for path in sorted(base.rglob("*")):
            rel = path.relative_to(root)
            if path.is_file() and not _excluded(rel):
                found.append(rel)
    return sorted(set(found), key=lambda p: p.as_posix())


def build_zip(root: Path, out_path: Path, prefix: str = "") -> tuple[str, int]:
    """Write the ZIP; returns (sha256, size). Refuses to replace an existing
    file with different bytes."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for rel in collect_files(root):
            info = zipfile.ZipInfo((prefix + rel.as_posix()), date_time=FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = FILE_MODE
            info.create_system = 3  # fixed, so the bytes do not depend on the build OS
            zf.writestr(info, (root / rel).read_bytes())
    data = buf.getvalue()
    if out_path.exists() and out_path.read_bytes() != data:
        raise FileExistsError(f"{out_path} exists with different bytes; choose a new name")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(data)
    return hashlib.sha256(data).hexdigest(), len(data)


def scan_zip(zip_path: Path, known_secrets: list[str] | None = None) -> ScanReport:
    """Look inside the finished ZIP (not the source tree) for credentials."""
    report = ScanReport()
    needles = [s.encode("utf-8") for s in (known_secrets or []) if s and len(s) >= 8]
    report.known_secret_values_checked = len(needles)
    with zipfile.ZipFile(zip_path) as zf:
        for info in zf.infolist():
            name = Path(info.filename)
            report.files_scanned += 1
            if name.name in EXCLUDE_FILE_NAMES or name.name.endswith(EXCLUDE_SUFFIXES) or any(
                part in EXCLUDE_DIR_NAMES for part in name.parts
            ):
                report.findings.append(f"{info.filename}: file that must never be packaged")
                continue
            data = zf.read(info)
            report.bytes_scanned += len(data)
            for label, pattern in SECRET_PATTERNS.items():
                if pattern.search(data):
                    report.findings.append(f"{info.filename}: looks like {label}")
            for needle in needles:
                if needle in data:
                    report.findings.append(f"{info.filename}: contains a credential value stored on this machine")
    return report


def local_secret_values() -> list[str]:
    """Credential values present on this machine, so the scan can prove none
    of them ended up in the ZIP. Never printed."""
    values: list[str] = []
    for var in ("SKILL_COLLAB_DROPBOX_APP_KEY", "SKILL_COLLAB_DROPBOX_REFRESH_TOKEN"):
        if os.environ.get(var):
            values.append(os.environ[var])
    base = os.environ.get("LOCALAPPDATA")
    if base:
        path = Path(base) / "skill-collab-watcher" / "secrets.json"
        if path.is_file():
            try:
                import json

                data = json.loads(path.read_text(encoding="utf-8"))
                values.extend(str(data[k]) for k in ("app_key", "refresh_token") if data.get(k))
            except (OSError, ValueError):
                pass
    return values


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--out", required=True, help="ZIP path to create (must not exist with other bytes)")
    parser.add_argument("--prefix", default="", help="folder name inside the ZIP, e.g. 'skill-collab-watcher/'")
    args = parser.parse_args(argv)

    out = Path(args.out)
    sha, size = build_zip(ROOT, out, prefix=args.prefix)
    report = scan_zip(out, local_secret_values())
    with zipfile.ZipFile(out) as zf:
        bad = zf.testzip()
        names = [i.filename for i in zf.infolist()]
    print(f"zip: {out}")
    print(f"size: {size}")
    print(f"sha256: {sha}")
    print(f"entries: {len(names)}")
    print(f"zip integrity (testzip): {'OK' if bad is None else 'BAD ' + bad}")
    print(
        f"secret scan: files={report.files_scanned} bytes={report.bytes_scanned} "
        f"local_credential_values_checked={report.known_secret_values_checked} "
        f"findings={len(report.findings)}"
    )
    for finding in report.findings:
        print(f"  FINDING: {finding}")
    return 0 if (report.clean and bad is None) else 1


if __name__ == "__main__":
    sys.exit(main())
