@echo off
setlocal
set ROOT=%~dp0..
cd /d "%ROOT%"
"%ROOT%\.venv\Scripts\python.exe" -m skill_collab_watcher.cli --config "%ROOT%\config\reviewer.config.json" auth-init %*
set RC=%errorlevel%
pause
exit /b %RC%
