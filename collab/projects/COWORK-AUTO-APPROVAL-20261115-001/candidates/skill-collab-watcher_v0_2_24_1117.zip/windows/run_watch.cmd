@echo off
setlocal
set ROOT=%~dp0..
cd /d "%ROOT%"
echo This starts a manual watch loop in THIS window.
echo Closing the window (or Ctrl+C) stops it. No Windows service or
echo scheduled/startup task is registered by this script.
"%ROOT%\.venv\Scripts\python.exe" -m skill_collab_watcher.cli --config "%ROOT%\config\reviewer.config.json" watch %*
set RC=%errorlevel%
pause
exit /b %RC%
