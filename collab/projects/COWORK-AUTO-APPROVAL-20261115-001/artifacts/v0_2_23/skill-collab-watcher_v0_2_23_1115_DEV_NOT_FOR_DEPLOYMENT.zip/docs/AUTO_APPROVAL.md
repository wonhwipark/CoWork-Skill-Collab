# Bounded automatic approval (v0.2.21, development_not_for_deployment)

Goal: a REQUEST that GPT publishes to the PRIVATE repository gets its `APPROVAL_SIG.json` and `READY.md` from the existing Windows signer without a
Telegram button or a manual Claude Code step, and the SAME single GitHub LIVE watcher then runs exactly one independent review.

**Default: the feature does not exist.** Without an `auto_approval` section in the watcher config nothing changes. With the section but the protected
delegation file saying `enabled: false` (the default), nothing is signed. **Nothing written to GitHub can enable, widen or extend it.**

## What it may do, and what it may never do
- May: for a REQUEST that has no READY yet, inside a local delegation, publish `APPROVAL_SIG.json` (create-only, read back) and then `READY.md`
  (create-only, LAST, read back). The existing `SOURCE_PIN.json` that GPT published is used as it is and never overwritten.
- Never: start a review (the unchanged READY checks, the N1 remote dispatch reservation and the single model call stay as they are), change a key,
  the trust root, a ceiling or a policy, or retry blindly after a doubt.

## Order of every decision (all read-only until the reservation)
1. Delegation file readable, ACL protected (no Everyone/Users/Authenticated Users write on the file or its folder; read through the Win32 DACL, SID
   based), schema `AUTO_DELEGATION_V1`, `enabled: true`, not expired.
2. The REQUEST was FIRST SEEN while the delegation was enabled, and its pinned commit A is not older than `enabled_at` (no retroactive start; a
   request seen while the feature was off stays excluded forever).
3. Repository: the numeric id the server reports now = `SOURCE_PIN.repo_id` = `delegation.repo_id`; `SOURCE_PIN` schema/commit well formed.
4. Package: size and sha256 equal the REQUEST, ZIP CRC, the engine's credential scan, `safe_extract`, size limit 5 MiB.
5. Commit A: the REQUEST and the package bytes at the pinned commit equal the bytes on `main` today.
6. No earlier history: no APPROVAL_SIG/READY/dispatch/receipt/result on the remote, no local job, no earlier reservation.
7. The pure gate `auto_policy.assess` (GPT prototype, byte-identical): scope allow-lists, `POLICY-STATIC-V1` only, 1 call, attempt 1, per request <= $1,
   day <= 2 calls / $3, month <= $10 (limits can only be equal to or stricter than the product ceilings), counting the watcher's own recorded dispatches.
8. The official validator on the READY text that WILL be published (bytes fixed before signing).
9. Atomic reservation (`BEGIN IMMEDIATE`, one row per request and revision, day/month ceilings inside the same transaction).
10. Re-check (delegation still enabled and unexpired, repository id unchanged) -> sign with the existing `tools.approval_signer` -> verify with the
    watcher's own `verify_approval` -> store the approval and READY bytes -> re-check -> publish approval -> re-check -> publish READY last.

## Stops
Any failure after the reservation ends in `UNCERTAIN` (event `AUTO_SIGNING_UNCERTAIN`, listed in the notification events): no automatic retry, no
re-signature. The only automatic resumes: a reservation without a stored signature may sign ONE more time (nothing was ever published); a stored,
unexpired approval or READY is published with the same bytes. An expired stored approval is never re-signed.

## Configuration (example, nothing secret)
```json
"auto_approval": {
  "delegation_file": "C:/ProgramData/cowork/auto_delegation.json",
  "valid_hours": 2,
  "signer": {"private_key_file": "...approver.key.enc", "key_id": "cowork-approver-1", "repo_id": "1451933830",
             "passphrase_dpapi_file": "...approver.pass.dpapi", "dpapi_entropy": "cowork-approver-v1"}
}
```
`delegation_file` (protected, written by the user, never by GitHub or this program):
```json
{"schema": "AUTO_DELEGATION_V1", "enabled": false, "repo_id": "1451933830", "branch": "main",
 "projects": ["<explicit work ids>"], "skills": ["<explicit skill ids>"], "policy": "POLICY-STATIC-V1",
 "enabled_at": "2026-11-16T00:00:00+09:00", "expires_at": "2026-12-16T00:00:00+09:00",
 "max_request_usd": 1.0, "max_day_calls": 2, "max_day_usd": 3.0, "max_month_usd": 10.0}
```
`config-check` prints the state without any path of a secret. `acl_check: "skip"` exists for isolated tests only and is printed as a warning.

## Enabling procedure (after an explicit user approval; not part of this candidate)
install with `enabled: false` -> let one watch cycle pass (every pending REQUEST is recorded as "seen while off") -> set `enabled: true` and
`enabled_at` to now. Revoke by setting `enabled: false` (takes effect at the next check, also between signing and publishing).

## Rollback
Remove the `auto_approval` section (or keep `enabled: false`) and restart; the two new tables stay unused. Restore the previous package folder from
its ZIP (byte copy). Nothing else of the operating watcher, database, Task, Notifier or key is changed by this feature.

## Known limits (see the result document)
The signing capability runs inside the watcher process of the same Windows account that reads GitHub-controlled input; the protection is the
delegation gate plus the fail-closed order above, not a separate trust domain. The installed Notifier has its own event list: add
`AUTO_SIGNING_UNCERTAIN` there when the feature is enabled.
