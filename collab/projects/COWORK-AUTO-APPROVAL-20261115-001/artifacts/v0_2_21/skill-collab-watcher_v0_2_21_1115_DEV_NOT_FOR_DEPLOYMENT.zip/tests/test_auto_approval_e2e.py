"""Isolated SHADOW-style end-to-end test of automatic approval through the REAL command-line entry point (separate process).

Real: cli.main, Config.load (the `auto_approval` section), runtime wiring, the delegation reader, the existing signer tool with a THROW-AWAY key,
Ed25519 verification, GitHubTransport, the orchestrator, RealReviewRunner (argv, stdin, JSON), the SQLite state store, the single-instance lock.
Replaced: the network (loopback synthetic GitHub, so remote writes go nowhere), the `claude` executable (a counting stub, so no paid model), and there
is no Telegram code path in the watcher at all. The operating database, Tasks, Notifier and key are never touched."""
from __future__ import annotations

import base64
import json
import time

import pytest

pytest.importorskip("cryptography", reason="real Ed25519")

from cryptography.hazmat.primitives import serialization  # noqa: E402

from auto_helpers import iso, make_request, write_delegation  # noqa: E402
from bundle import KEY_ID, REPO_ID  # noqa: E402
from fake_github import rp  # noqa: E402
from skill_collab_watcher.models import JobState  # noqa: E402
from test_cli_entrypoint_e2e import e2e  # noqa: E402,F401  (fixture)


def configure(e2e, enabled=True, **delegation):
    raw = e2e.key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())
    keyfile = e2e.tmp / "throwaway.key"
    keyfile.write_text(base64.b64encode(raw).decode() + "\n", encoding="ascii")
    delegation_file = e2e.tmp / "delegation.json"
    write_delegation(delegation_file, enabled=enabled, **delegation)
    cfg = json.loads(e2e.cfg_path.read_text(encoding="utf-8"))
    cfg["review_policy"]["known_run_policy_refs"] = {"POLICY-STATIC-V1": {"max_budget_usd": 1.0, "effort": "medium"}}
    cfg["auto_approval"] = {"delegation_file": str(delegation_file), "acl_check": "skip", "valid_hours": 2,
                            "signer": {"private_key_file": str(keyfile), "key_id": KEY_ID, "repo_id": REPO_ID, "allow_plaintext_key": True}}
    e2e.cfg_path.write_text(json.dumps(cfg), encoding="utf-8")
    return delegation_file


def watch(e2e, cycles=4):
    p = e2e.popen("watch", "--max-cycles", str(cycles), "--poll-interval", "1")
    out, err = p.communicate(timeout=240)
    return p.returncode, out, err


def has_file(e2e, rel):
    return e2e.repo_has(rel)


def puts(e2e, needle):
    return [u for m, u in e2e.fake.calls if m == "PUT" and needle in u]


def test_enabled_delegation_signs_posts_and_the_unchanged_watcher_reviews_exactly_once(e2e):
    configure(e2e)
    info = make_request(e2e.fake, "REQ-1", project="test-project", skill="test-skill")
    code, out, err = watch(e2e)
    assert code == 0, (out + err)[-300:]
    assert has_file(e2e, "requests/REQ-1/APPROVAL_SIG.json") and has_file(e2e, "requests/REQ-1/READY.md")
    assert e2e.model_calls == 1
    s = e2e.store()
    try:
        assert [st for _k, st in s.auto_jobs_for("REQ-1", "1")] == [JobState.COMPLETED.value]
        assert s.auto_get_claim("REQ-1", "1")["stage"] == "READY_POSTED"
    finally:
        s.close()
    assert has_file(e2e, "reviews/REQ-1/REVIEW_RESULT_1.md") and has_file(e2e, "receipts/REQ-1/RECEIPT_1.md") and has_file(e2e, "dispatch/REQ-1/DISPATCH_1.md")
    order = [u.rsplit("/", 1)[-1] for u in puts(e2e, "requests/REQ-1/")]
    assert order == ["APPROVAL_SIG.json", "READY.md"]


def test_disabled_delegation_through_the_real_cli_does_nothing(e2e):
    configure(e2e, enabled=False)
    make_request(e2e.fake, "REQ-1")
    code, out, err = watch(e2e, 3)
    assert code == 0
    assert not has_file(e2e, "requests/REQ-1/APPROVAL_SIG.json") and not has_file(e2e, "requests/REQ-1/READY.md") and e2e.model_calls == 0
    assert not puts(e2e, "requests/")


def test_restarts_and_repeated_runs_neither_sign_nor_review_again(e2e):
    configure(e2e)
    make_request(e2e.fake, "REQ-1")
    watch(e2e)
    assert e2e.model_calls == 1
    for _ in range(2):
        code, _o, _e = watch(e2e, 3)                                           # two restarts
        assert code == 0
    assert e2e.model_calls == 1
    assert len(puts(e2e, "APPROVAL_SIG.json")) == 1 and len(puts(e2e, "READY.md")) == 1


def test_a_second_watcher_is_refused_and_only_one_approval_exists(e2e):
    configure(e2e)
    make_request(e2e.fake, "REQ-1")
    first = e2e.popen("watch", "--max-cycles", "6", "--poll-interval", "1", sleep="3")
    time.sleep(2)
    code, out, err = watch(e2e, 2)
    first.communicate(timeout=240)
    assert code == 3 and "already holds" in (out + err).lower()
    assert len(puts(e2e, "APPROVAL_SIG.json")) <= 1 and e2e.model_calls <= 1


def test_requests_present_before_the_feature_was_switched_on_are_never_started(e2e):
    delegation = configure(e2e, enabled=False)
    make_request(e2e.fake, "REQ-OLD")
    watch(e2e, 2)                                                              # first sight with the delegation off
    write_delegation(delegation, enabled=True)
    make_request(e2e.fake, "REQ-NEW")
    watch(e2e, 4)
    assert not has_file(e2e, "requests/REQ-OLD/APPROVAL_SIG.json") and not has_file(e2e, "requests/REQ-OLD/READY.md")
    assert has_file(e2e, "requests/REQ-NEW/READY.md") and e2e.model_calls == 1


def test_a_request_outside_the_delegation_is_never_signed_through_the_real_cli(e2e):
    configure(e2e)
    make_request(e2e.fake, "REQ-1", project="some-other-project")
    watch(e2e, 3)
    assert not has_file(e2e, "requests/REQ-1/APPROVAL_SIG.json") and e2e.model_calls == 0


def test_config_check_reports_the_feature_without_secrets(e2e):
    configure(e2e, enabled=False)
    p = e2e.popen("config-check")
    out, err = p.communicate(timeout=120)
    text = out + err
    assert p.returncode == 0 and "auto_approval: configured" in text and "enabled=False" in text and "signer configured" in text
    assert "throwaway.key" not in text and "BEGIN" not in text


def test_without_the_section_config_check_says_the_feature_does_not_exist(e2e):
    p = e2e.popen("config-check")
    out, err = p.communicate(timeout=120)
    assert "auto_approval: not configured" in (out + err)
