"""Shared fixtures for the automatic-approval tests. Synthetic data and a THROW-AWAY Ed25519 key only; never the operating key."""
from __future__ import annotations

import base64
import json
import time
from datetime import datetime, timezone
from types import SimpleNamespace

import pytest

pytest.importorskip("cryptography", reason="the automatic-approval tests use real Ed25519 signatures")

from cryptography.hazmat.primitives import serialization  # noqa: E402
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey  # noqa: E402

from bundle import KEY_ID, REPO_ID, github_policy  # noqa: E402
from conftest import BASELINE, make_package_zip  # noqa: E402
from fake_github import j, rp  # noqa: E402
from skill_collab_watcher.approval import PIN_SCHEMA, TrustedKey, TrustRoot, fingerprint_of  # noqa: E402
from skill_collab_watcher.auto_approval import AutoApprover, AutoSettings, ToolSigner  # noqa: E402
from skill_collab_watcher.signature_backend import Ed25519Backend  # noqa: E402
from test_phase1_github import run  # noqa: E402


class Crash(BaseException):
    """The process dies here."""


def iso(epoch: float) -> str:
    return datetime.fromtimestamp(epoch, timezone.utc).isoformat()


def write_delegation(path, **over):
    now = time.time()
    data = {"schema": "AUTO_DELEGATION_V1", "enabled": True, "repo_id": REPO_ID, "branch": "main", "projects": ["test-project"], "skills": ["test-skill"],
            "policy": "POLICY-STATIC-V1", "enabled_at": iso(now - 60), "expires_at": iso(now + 30 * 86400), "max_request_usd": 1.0,
            "max_day_calls": 2, "max_day_usd": 3.0, "max_month_usd": 10.0}
    data.update(over)
    for k in [k for k, v in data.items() if v is None]:
        del data[k]
    path.write_text(json.dumps(data), encoding="utf-8")
    return data


class CountingSigner(ToolSigner):
    calls = 0

    def sign(self, *a, **k):
        type(self).calls += 1
        return super().sign(*a, **k)


def make_request(http, rid="REQ-A", rev=1, *, state="REQUESTED", package=None, policy_ref="POLICY-STATIC-V1", project="test-project", skill="test-skill",
                 pin=True, size_delta=0, body_extra="", package_path=None, sha_override=None, pin_repo_id=None):
    """REQUEST + package in commit A, SOURCE_PIN (data only, as GPT publishes it) in a later commit. Returns what a test needs to tamper with."""
    package = package if package is not None else make_package_zip(rid)
    sha = sha_override or __import__("hashlib").sha256(package).hexdigest()
    pkg_path = package_path or f"/SKILL-COLLAB/packages/{rid}.zip"
    req = f"""---
schema: SKILL_COLLAB_REVIEW_REQUEST_V1
state: {state}
request_id: {rid}
request_revision: {rev}
project_id: {project}
work_id: {project}
skill_id: {skill}
package_path: {pkg_path}
package_file_id: github:{rid}
package_rev: design-r0001
package_sha256: {sha}
package_size_bytes: {len(package) + size_delta}
baseline_package_ref: null
knowledge_refs: []
consumer_profiles: [work-to-knowledge-design]
reviewer_os: WINDOWS
test_policy: STATIC_ONLY
run_policy_ref: {policy_ref}
output_contract: SKILL_COLLAB_REVIEW_RESULT_V1
goal: synthetic
---

# body
user_approved: true
cost: 0
{body_extra}
""".encode("utf-8")
    files = {rp(f"requests/{rid}/REQUEST.md"): req, rp(pkg_path.replace("/SKILL-COLLAB/", "")): package}
    commit_a = http.commit(files)
    if pin:
        http.commit({rp(f"requests/{rid}/SOURCE_PIN.json"): j({"schema": PIN_SCHEMA, "repo_id": pin_repo_id or REPO_ID, "commit": commit_a})})
    return SimpleNamespace(rid=rid, rev=rev, commit_a=commit_a, request=req, package=package, package_path=pkg_path)


@pytest.fixture
def auto(github_env, tmp_path):
    key = Ed25519PrivateKey.generate()
    raw_private = key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())
    public_b64 = base64.b64encode(key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)).decode()
    keyfile = tmp_path / "approver.key"
    keyfile.write_text(base64.b64encode(raw_private).decode() + "\n", encoding="ascii")
    trust = TrustRoot(repo_id=REPO_ID, keys={KEY_ID: TrustedKey(key_id=KEY_ID, public_key=public_b64, fingerprint=fingerprint_of(public_b64), status="ACTIVE")})
    delegation = tmp_path / "delegation.json"
    write_delegation(delegation)
    CountingSigner.calls = 0
    signer = CountingSigner(keyfile, KEY_ID, REPO_ID, allow_plaintext_key=True)
    policy = github_policy(trust_root=trust, signature_backend=Ed25519Backend(), run_budgets_usd={"POLICY-STATIC-V1": 1.0})
    now = {"offset": 0.0}
    settings = AutoSettings(delegation, 2, "skip", None, race_retries=2)
    ns = SimpleNamespace(env=github_env, policy=policy, signer=signer, settings=settings, delegation=delegation, trust=trust, now=now, keyfile=keyfile)

    def build(store=None):
        policy.auto_approver = AutoApprover(settings, store or github_env.store, signer=signer, now_fn=lambda: time.time() + now["offset"], sleep=lambda _s: None)
        ns.approver = policy.auto_approver
    ns.build = build
    ns.cycle = lambda **kw: run(github_env, policy=policy, **kw)
    build()
    return ns


def puts(env, needle):
    return [u for m, u in env.http.calls if m == "PUT" and needle in u]


def events(env):
    return [(e, d or "") for _t, e, _k, d in env.store.recent_events(1000)]


def has(env, name, detail=""):
    return any(e == name and detail in d for e, d in events(env))


def remote(env, rel):
    return env.http.files().get(rp(rel))
