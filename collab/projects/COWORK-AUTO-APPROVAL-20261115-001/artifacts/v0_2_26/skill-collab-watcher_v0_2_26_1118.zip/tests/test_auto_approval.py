"""Bounded automatic approval (v0.2.21): policy file, contract with the real signer and verifier, duplicates, limits, retroactivity, spoofing,
crash recovery, races. The automatic part may only publish an APPROVAL_SIG.json and a READY.md; the unchanged watcher decides and dispatches.
Synthetic data, a throw-away key, a fake GitHub. No model, no operating state."""
from __future__ import annotations

import hashlib
import json
import sys
import threading
import time
import zipfile
import io

import pytest

from auto_helpers import Crash, auto, events, has, iso, make_request, puts, remote, write_delegation  # noqa: F401,E402
from bundle import REPO_ID, make_transport  # noqa: E402
from conftest import make_package_zip  # noqa: E402
from fake_github import rp  # noqa: E402
from skill_collab_watcher import auto_approval, orchestrator  # noqa: E402
from skill_collab_watcher.auto_approval import AutoApprover, AutoSettings, ToolSigner, aces_allow_broad_write, load_delegation, windows_acl_ok  # noqa: E402
from skill_collab_watcher.models import JobState  # noqa: E402
from skill_collab_watcher.state_store import StateStore  # noqa: E402
from skill_collab_watcher.transport_base import TransportError  # noqa: E402
from test_phase1_github import run  # noqa: E402

REQ = "requests/{rid}/"


def direct(auto, rid, info, store=None, approver=None):
    """Call the approver the way a cycle does: the transport has talked to the server first (that is where the server time comes from)."""
    transport = make_transport(auto.env.http)
    transport.ensure_auth()
    return (approver or auto.approver).process(transport, store or auto.env.store, auto.policy, "/SKILL-COLLAB", rid, info.request.decode(), info.request).status


def denied_for(env, reason):
    """A ceiling refusal is recorded either by the gate (AUTO_NOT_ELIGIBLE) or by the atomic reservation (AUTO_LIMIT_BLOCKED)."""
    return has(env, "AUTO_LIMIT_BLOCKED", reason) or has(env, "AUTO_NOT_ELIGIBLE", reason)


def approval_posted(env, rid="REQ-A"):
    return remote(env, REQ.format(rid=rid) + "APPROVAL_SIG.json") is not None


def ready_posted(env, rid="REQ-A"):
    return remote(env, REQ.format(rid=rid) + "READY.md") is not None


# ================================ delegation file and ACL =========================================================================================

def test_a_valid_enabled_delegation_loads(tmp_path):
    path = tmp_path / "d.json"
    write_delegation(path)
    d, why = load_delegation(path, time.time(), "skip")
    assert d is not None and d.enabled and d.max_request_cents == 150 and d.max_day_calls == 0 and d.max_day_cents == 0 and d.max_month_cents == 0


@pytest.mark.parametrize("over", [
    {"schema": "OTHER"}, {"enabled": "true"}, {"enabled": 1}, {"projects": "x"}, {"skills": [""]}, {"policy": "POLICY-STATIC-V1-LARGE"},
    {"expires_at": "tomorrow"}, {"expires_at": "2030-01-01T00:00:00"}, {"enabled_at": None}, {"repo_id": None}, {"max_request_usd": -1}, {"max_day_usd": "3"},
])
def test_a_malformed_delegation_is_unusable_not_enabled(tmp_path, over):
    path = tmp_path / "d.json"
    write_delegation(path, **over)
    d, why = load_delegation(path, time.time(), "skip")
    assert d is None


@pytest.mark.parametrize("content", ["", "{", "[]", "null"])
def test_garbage_or_missing_delegation_is_unusable(tmp_path, content):
    path = tmp_path / "d.json"
    if content:
        path.write_text(content, encoding="utf-8")
    assert load_delegation(path, time.time(), "skip")[0] is None


def test_the_acl_rule_flags_every_broad_group_with_a_write_right():
    EVERYONE, USERS, AUTH, ME = "S-1-1-0", "S-1-5-32-545", "S-1-5-11", "S-1-5-21-1-2-3-1001"
    assert aces_allow_broad_write([(0, EVERYONE, 0x2)])                       # FILE_WRITE_DATA
    assert aces_allow_broad_write([(0, USERS, 0x1301bf)])                     # modify
    assert aces_allow_broad_write([(0, AUTH, 0x40000)])                       # WRITE_DAC
    assert aces_allow_broad_write([(0, EVERYONE, 0x10000000)])                # GENERIC_ALL
    assert not aces_allow_broad_write([(0, USERS, 0x1200a9)])                 # read and execute only
    assert not aces_allow_broad_write([(0, ME, 0x1f01ff)])                    # the owner may write
    assert not aces_allow_broad_write([(1, EVERYONE, 0x1f01ff)])              # a DENY entry is not a grant
    assert not aces_allow_broad_write([])


@pytest.mark.skipif(sys.platform != "win32", reason="Win32 ACL")
def test_the_real_acl_reader_accepts_a_private_file_and_refuses_a_file_everyone_can_write(tmp_path):
    import subprocess
    f = tmp_path / "d.json"
    f.write_text("{}", encoding="utf-8")
    assert windows_acl_ok(f) == (True, "ok")
    subprocess.run(["icacls", str(f), "/grant", "*S-1-1-0:(W)"], capture_output=True, check=True)
    assert windows_acl_ok(f) == (False, "ACL_BROAD_WRITE")
    assert load_delegation(f, time.time(), "windows") == (None, "ACL_BROAD_WRITE")


def test_a_missing_file_fails_the_acl_check_closed(tmp_path):
    assert windows_acl_ok(tmp_path / "nope.json")[0] is False


def test_settings_reject_bad_values():
    for bad in (None, {}, {"delegation_file": ""}, {"delegation_file": "x", "valid_hours": 0}, {"delegation_file": "x", "valid_hours": 13},
                {"delegation_file": "x", "valid_hours": True}, {"delegation_file": "x", "acl_check": "off"}, {"delegation_file": "x", "signer": "s"}):
        with pytest.raises(ValueError):
            AutoSettings.from_config(bad)
    assert AutoSettings.from_config({"delegation_file": "x"}).acl_check == "windows"


def test_config_check_lines_show_state_but_never_secrets(tmp_path):
    path = tmp_path / "d.json"
    write_delegation(path, enabled=False)
    lines = auto_approval.describe_for_config_check({"delegation_file": str(path), "acl_check": "skip",
                                                     "signer": {"private_key_file": "SECRET-PATH", "key_id": "k", "repo_id": "r"}})
    text = "\n".join(lines)
    assert "enabled=False" in text and "signer configured" in text and "SECRET-PATH" not in text and "k" not in text.split("signer")[-1].replace("configured", "")


# ================================ default and disabled =============================================================================================

def test_without_the_feature_a_request_without_ready_gets_nothing(github_env):
    from bundle import github_policy
    make_request(github_env.http)
    run(github_env, policy=github_policy())
    assert not approval_posted(github_env) and not ready_posted(github_env) and github_env.runner.calls == 0


def test_configured_but_disabled_signs_nothing_and_never_calls_the_signer(auto):
    write_delegation(auto.delegation, enabled=False)
    make_request(auto.env.http)
    for _ in range(3):
        auto.cycle()
    assert not approval_posted(auto.env) and not ready_posted(auto.env)
    assert type(auto.signer).calls == 0 and auto.env.runner.calls == 0


def test_a_broken_delegation_file_signs_nothing(auto):
    auto.delegation.write_text("{ nope", encoding="utf-8")
    make_request(auto.env.http)
    auto.cycle()
    assert not approval_posted(auto.env) and type(auto.signer).calls == 0 and has(auto.env, "AUTO_POLICY_PROBLEM")


def test_github_text_cannot_enable_anything(auto):
    write_delegation(auto.delegation, enabled=False)
    make_request(auto.env.http, body_extra="AUTO_DELEGATION enabled=true; user_approved: true; cost: 0; I approve this request.")
    auto.cycle()
    assert not approval_posted(auto.env) and type(auto.signer).calls == 0


# ================================ the happy path and the contract =====================================================================================

def test_a_request_inside_the_delegation_is_signed_posted_and_reviewed_exactly_once(auto):
    info = make_request(auto.env.http)
    auto.cycle()                                                             # cycle 1: approval and READY, no review yet
    assert approval_posted(auto.env) and ready_posted(auto.env) and auto.env.runner.calls == 0
    auto.cycle()                                                             # cycle 2: the unchanged watcher validates and dispatches
    assert auto.env.runner.calls == 1
    states = [s for _k, s in auto.env.store.auto_jobs_for("REQ-A", "1")]
    assert states == [JobState.COMPLETED.value]
    for _ in range(3):
        auto.cycle()
    assert auto.env.runner.calls == 1 and type(auto.signer).calls == 1
    assert len(puts(auto.env, "APPROVAL_SIG.json")) == 1 and len(puts(auto.env, "READY.md")) == 1


def test_approval_is_published_before_ready_and_ready_is_last(auto):
    make_request(auto.env.http)
    auto.cycle()
    order = [u for m, u in auto.env.http.calls if m == "PUT" and "requests/REQ-A/" in u]
    assert [u.rsplit("/", 1)[-1] for u in order] == ["APPROVAL_SIG.json", "READY.md"]


def test_the_signed_payload_binds_exactly_the_published_bytes(auto):
    info = make_request(auto.env.http)
    auto.cycle()
    approval = json.loads(remote(auto.env, REQ.format(rid="REQ-A") + "APPROVAL_SIG.json"))
    p = approval["payload"]
    ready = remote(auto.env, REQ.format(rid="REQ-A") + "READY.md")
    assert p["ready_sha256"] == hashlib.sha256(ready).hexdigest()
    assert p["request_sha256"] == hashlib.sha256(info.request).hexdigest()
    assert p["package_sha256"] == hashlib.sha256(info.package).hexdigest() and p["package_size_bytes"] == len(info.package)
    assert p["source_commit"] == info.commit_a and p["repo_id"] == REPO_ID and p["run_policy_ref"] == "POLICY-STATIC-V1"
    assert p["package_path"] == info.package_path and p["local_policy_revision"] == auto.policy.local_policy_revision
    issued, expires = (time.mktime(time.strptime(p[k][:19], "%Y-%m-%dT%H:%M:%S")) for k in ("issued_at", "expires_at"))
    assert 0 < expires - issued <= 2 * 3600 + 5
    assert has(auto.env, "AUTO_RESERVED") and has(auto.env, "AUTO_SIGNED_LOCAL") and has(auto.env, "AUTO_APPROVAL_POSTED") and has(auto.env, "AUTO_READY_POSTED")


def test_the_published_ready_passes_the_official_validator_and_the_official_verifier(auto):
    from skill_collab_watcher.approval import verify_approval
    from skill_collab_watcher.models import ValidationOutcome
    from skill_collab_watcher.validator import validate
    info = make_request(auto.env.http)
    auto.cycle()
    base = REQ.format(rid="REQ-A")
    ready = remote(auto.env, base + "READY.md")
    approval = remote(auto.env, base + "APPROVAL_SIG.json")
    pin = remote(auto.env, base + "SOURCE_PIN.json")
    r = validate(info.request.decode(), ready.decode(), (len(info.package), hashlib.sha256(info.package).hexdigest()), auto.policy,
                 expected_request_id="REQ-A", request_bytes=info.request)
    assert r.outcome == ValidationOutcome.VALIDATED
    from skill_collab_watcher.approval import knowledge_refs_hash
    from datetime import datetime, timezone
    expected = {"request_id": "REQ-A", "request_revision": "1", "request_sha256": hashlib.sha256(info.request).hexdigest(),
                "ready_sha256": hashlib.sha256(ready).hexdigest(), "package_path": info.package_path,
                "package_sha256": hashlib.sha256(info.package).hexdigest(), "package_size_bytes": len(info.package),
                "local_policy_revision": "1", "run_policy_ref": "POLICY-STATIC-V1", "knowledge_refs_hash": knowledge_refs_hash([])}
    verify_approval(approval, pin, trust=auto.trust, backend=auto.policy.signature_backend, expected=expected, now=datetime.now(timezone.utc))


@pytest.mark.parametrize("state", ["REQUESTED", "SUBMITTED"])
def test_requested_and_submitted_are_both_accepted(auto, state):
    make_request(auto.env.http, state=state)
    auto.cycle()
    auto.cycle()
    assert auto.env.runner.calls == 1


def test_the_existing_source_pin_is_never_overwritten(auto):
    info = make_request(auto.env.http)
    before = remote(auto.env, REQ.format(rid="REQ-A") + "SOURCE_PIN.json")
    auto.cycle()
    assert remote(auto.env, REQ.format(rid="REQ-A") + "SOURCE_PIN.json") == before and not puts(auto.env, "SOURCE_PIN.json")


def test_the_automatic_part_alone_never_starts_a_review(auto, monkeypatch):
    make_request(auto.env.http)
    monkeypatch.setattr(orchestrator, "_reserve_dispatch", lambda *a, **k: (_ for _ in ()).throw(AssertionError("a dispatch started in the signing cycle")))
    auto.cycle()
    assert approval_posted(auto.env) and ready_posted(auto.env) and auto.env.runner.calls == 0


# ================================ scope, retroactivity, limits ======================================================================================

def test_a_request_seen_while_the_feature_was_off_is_never_started_later(auto):
    write_delegation(auto.delegation, enabled=False)
    make_request(auto.env.http)
    auto.cycle()                                                            # first sight, delegation off
    write_delegation(auto.delegation, enabled=True)
    for _ in range(3):
        auto.cycle()
    assert not approval_posted(auto.env) and type(auto.signer).calls == 0 and has(auto.env, "AUTO_PRE_EXISTING_REQUEST")


def test_a_request_older_than_the_delegation_is_retroactive(auto):
    info = make_request(auto.env.http)
    auto.env.http.set_commit_time(info.commit_a, time.time() - 7200)         # committed two hours ago; the delegation starts one minute ago
    auto.cycle()
    assert not approval_posted(auto.env) and has(auto.env, "AUTO_NOT_ELIGIBLE", "RETROACTIVE")


def test_a_request_dated_in_the_future_is_refused(auto):
    info = make_request(auto.env.http)
    auto.env.http.set_commit_time(info.commit_a, time.time() + 3600)
    auto.cycle()
    assert not approval_posted(auto.env) and has(auto.env, "AUTO_NOT_ELIGIBLE", "RETROACTIVE_OR_FUTURE")


@pytest.mark.parametrize("over, kw", [
    ({"expires_at": iso(time.time() - 10)}, {}),
    ({}, {"project": "other-project"}),
    ({}, {"skill": "other-skill"}),
    ({"projects": ["x"], "skills": ["y"]}, {}),
    ({}, {"policy_ref": "POLICY-STATIC-V1-LARGE"}),
    ({"projects": []}, {}),
    ({"skills": []}, {}),
    ({"max_request_usd": 0.0}, {}),
    
    
    ({"repo_id": "another-repository"}, {}),
    ({"branch": "develop"}, {}),
])
def test_scope_expiry_policy_and_limit_violations_sign_nothing(auto, over, kw):
    write_delegation(auto.delegation, **over)
    make_request(auto.env.http, **kw)
    auto.cycle()
    assert not approval_posted(auto.env) and not ready_posted(auto.env) and type(auto.signer).calls == 0 and auto.env.runner.calls == 0


def test_no_day_count_or_cost_ceiling_is_applied(auto):
    for rid in ("REQ-A", "REQ-B", "REQ-C", "REQ-D"):
        make_request(auto.env.http, rid)
    auto.cycle()
    assert all(approval_posted(auto.env, r) for r in ("REQ-A", "REQ-B", "REQ-C", "REQ-D"))
    assert type(auto.signer).calls == 4


def test_the_day_cost_limit_counts_reservations(auto):
    write_delegation(auto.delegation, max_day_calls=2, max_day_usd=1.5)           # below the product ceiling of 3: allowed, stricter
    auto.policy.run_budgets_usd["POLICY-STATIC-V1"] = 1.0
    make_request(auto.env.http, "REQ-A")
    make_request(auto.env.http, "REQ-B")
    auto.cycle()
    assert approval_posted(auto.env, "REQ-A") and approval_posted(auto.env, "REQ-B")


def test_the_month_limit_spans_days(auto):
    """Direct calls (no watcher dispatch in between), so that the MONTH ceiling is the one that decides."""
    write_delegation(auto.delegation, max_month_usd=2.0, expires_at=iso(time.time() + 90 * 86400))
    statuses = []
    for i, rid in enumerate(("REQ-A", "REQ-B", "REQ-C")):
        info = make_request(auto.env.http, rid)
        auto.now["offset"] = i * 86400                                            # a new KST day each time, same month
        statuses.append(direct(auto, rid, info))
    assert statuses == ["READY_POSTED"] * 3
    assert not denied_for(auto.env, "MONTH_COST_LIMIT")


def test_a_new_kst_month_starts_a_new_month_budget(auto):
    write_delegation(auto.delegation, max_month_usd=1.0, expires_at=iso(time.time() + 120 * 86400))
    statuses = []
    for i, rid in enumerate(("REQ-A", "REQ-B", "REQ-C")):
        info = make_request(auto.env.http, rid)
        auto.now["offset"] = i * 40 * 86400                                       # a different month every time
        statuses.append(direct(auto, rid, info))
    assert statuses == ["READY_POSTED"] * 3


def test_real_dispatches_of_the_watcher_count_against_the_day(auto):
    for n in (1, 2):
        auto.env.store.log_event("REVIEW_DISPATCHED", processing_key=f"old{n}|1|x|1", detail="{}")
    make_request(auto.env.http)
    auto.cycle()
    assert approval_posted(auto.env)  # dispatch count with no recorded cost is not a cost gate


# ================================ spoofing and input checks ===========================================================================================

def test_a_missing_source_pin_signs_nothing_and_reserves_nothing(auto):
    make_request(auto.env.http, pin=False)
    auto.cycle()
    assert not approval_posted(auto.env) and auto.env.store.auto_get_claim("REQ-A", "1") is None and has(auto.env, "AUTO_NOT_ELIGIBLE", "SOURCE_PIN.json")


def test_a_pin_for_another_repository_is_refused(auto):
    make_request(auto.env.http, pin_repo_id="some-other-repository")
    auto.cycle()
    assert not approval_posted(auto.env) and has(auto.env, "AUTO_NOT_ELIGIBLE", "PIN_MISMATCH")


def test_a_server_that_reports_another_repository_id_is_refused(auto):
    make_request(auto.env.http)
    auto.env.http.repo_id = "the-name-now-points-elsewhere"
    auto.cycle()
    assert not approval_posted(auto.env) and type(auto.signer).calls == 0


def test_an_unreadable_repository_identity_waits(auto, monkeypatch):
    from skill_collab_watcher.github_transport import GitHubTransport
    make_request(auto.env.http)
    monkeypatch.setattr(GitHubTransport, "repository_id", lambda self: (_ for _ in ()).throw(TransportError("synthetic")))
    auto.cycle()
    assert not approval_posted(auto.env) and type(auto.signer).calls == 0


def test_a_pin_that_points_at_a_commit_with_other_bytes_is_refused(auto):
    info = make_request(auto.env.http, pin=False)
    later = auto.env.http.commit({rp(f"requests/REQ-A/REQUEST.md"): info.request + b"\nedited after the pin\n"})
    from skill_collab_watcher.approval import PIN_SCHEMA
    from fake_github import j
    auto.env.http.commit({rp("requests/REQ-A/SOURCE_PIN.json"): j({"schema": PIN_SCHEMA, "repo_id": REPO_ID, "commit": info.commit_a})})
    auto.cycle()                                                            # the REQUEST on main no longer equals the REQUEST at commit A
    assert not approval_posted(auto.env) and has(auto.env, "AUTO_NOT_ELIGIBLE", "COMMIT_A_MISMATCH")


def test_a_package_replaced_after_the_pin_is_refused(auto):
    info = make_request(auto.env.http)
    auto.env.http.commit({rp(info.package_path.replace("/SKILL-COLLAB/", "")): make_package_zip("a different package")})
    auto.cycle()
    assert not approval_posted(auto.env) and has(auto.env, "AUTO_NOT_ELIGIBLE", "PACKAGE_INVALID")


def test_a_wrong_package_sha_in_the_request_is_refused(auto):
    make_request(auto.env.http, sha_override="0" * 64)
    auto.cycle()
    assert not approval_posted(auto.env) and has(auto.env, "AUTO_NOT_ELIGIBLE", "PACKAGE_INVALID")


def test_a_wrong_package_size_in_the_request_is_refused(auto):
    make_request(auto.env.http, size_delta=1)
    auto.cycle()
    assert not approval_posted(auto.env) and has(auto.env, "AUTO_NOT_ELIGIBLE", "PACKAGE_INVALID")


def _zip(entries, corrupt=False):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for name, data in entries:
            zf.writestr(zipfile.ZipInfo(name, date_time=(2026, 11, 1, 0, 0, 0)), data)
    raw = buf.getvalue()
    if corrupt:
        i = raw.index(entries[0][1].encode() if isinstance(entries[0][1], str) else entries[0][1])
        raw = raw[:i] + bytes([raw[i] ^ 0xFF]) + raw[i + 1:]
    return raw


@pytest.mark.parametrize("label, package", [
    ("zip-slip", _zip([("../evil.txt", "x")])),
    ("absolute path", _zip([("/abs.txt", "x")])),
    ("secret-shaped text", _zip([("a.md", '{"refresh_token": "' + "a" * 40 + '"}')])),
    ("corrupt CRC", _zip([("a.md", "design text that will be damaged")], corrupt=True)),
    ("not a zip", b"this is not a zip file"),
])
def test_an_unsafe_or_damaged_package_is_refused(auto, label, package):
    make_request(auto.env.http, package=package)
    auto.cycle()
    assert not approval_posted(auto.env) and type(auto.signer).calls == 0


def test_a_package_over_the_size_limit_is_refused(auto, monkeypatch):
    monkeypatch.setattr(auto_approval, "MAX_PACKAGE_BYTES", 10)
    make_request(auto.env.http)
    auto.cycle()
    assert not approval_posted(auto.env)


def test_a_package_path_outside_packages_is_refused(auto):
    make_request(auto.env.http, package_path="/SKILL-COLLAB/other/REQ-A.zip")
    auto.cycle()
    assert not approval_posted(auto.env) and type(auto.signer).calls == 0


# ================================ duplicates ===========================================================================================================

def test_a_request_that_already_has_an_approval_is_left_alone(auto):
    make_request(auto.env.http)
    auto.env.http.commit({rp("requests/REQ-A/APPROVAL_SIG.json"): b"{}"})
    auto.cycle()
    assert not ready_posted(auto.env) and type(auto.signer).calls == 0 and has(auto.env, "AUTO_DUPLICATE_BLOCKED")


def test_a_request_whose_result_already_exists_is_never_signed(auto):
    make_request(auto.env.http)
    auto.env.http.commit({rp("reviews/REQ-A/REVIEW_RESULT_1.md"): b"old"})
    auto.cycle()
    assert not approval_posted(auto.env) and type(auto.signer).calls == 0


def test_a_request_with_a_dispatch_record_is_never_signed(auto):
    make_request(auto.env.http)
    auto.env.http.commit({rp("dispatch/REQ-A/DISPATCH_1.md"): b"{}"})
    auto.cycle()
    assert not approval_posted(auto.env) and type(auto.signer).calls == 0


def test_a_request_with_a_local_job_is_never_signed(auto):
    make_request(auto.env.http)
    auto.env.store.create_job("REQ-A|1|x|1", "REQ-A", "1", "x", JobState.COMPLETED)
    auto.cycle()
    assert not approval_posted(auto.env) and type(auto.signer).calls == 0


def test_two_scans_of_the_same_request_sign_once(auto):
    make_request(auto.env.http)
    other = StateStore(auto.env.tmp / "state.sqlite3")
    try:
        second = AutoApprover(auto.settings, other, signer=auto.signer, now_fn=time.time, sleep=lambda _s: None)
        auto.cycle()
        run_policy = auto.policy.auto_approver
        auto.policy.auto_approver = second
        run(auto.env, policy=auto.policy)
        auto.policy.auto_approver = run_policy
    finally:
        other.close()
    assert type(auto.signer).calls == 1 and len(puts(auto.env, "APPROVAL_SIG.json")) == 1


def test_racing_threads_reserve_exactly_one_signature(auto):
    make_request(auto.env.http)
    results, errors = [], []
    info = auto.env.http.files()[rp("requests/REQ-A/REQUEST.md")]

    def worker():
        try:
            store = StateStore(auto.env.tmp / "state.sqlite3")                    # a SQLite connection belongs to its own thread
            approver = AutoApprover(auto.settings, store, signer=auto.signer, now_fn=time.time, sleep=lambda _s: None)
            transport = make_transport(auto.env.http)
            transport.ensure_auth()
            results.append(approver.process(transport, store, auto.policy, "/SKILL-COLLAB", "REQ-A", info.decode(), info).status)
            store.close()
        except Exception as exc:                                                  # noqa: BLE001
            errors.append(repr(exc))

    threads = [threading.Thread(target=worker) for _ in range(4)]
    [t.start() for t in threads]
    [t.join() for t in threads]
    assert not errors, errors
    assert type(auto.signer).calls == 1 and len(puts(auto.env, "APPROVAL_SIG.json")) == 1
    assert results.count("READY_POSTED") == 1


def test_after_a_total_local_state_loss_published_files_block_any_new_signature(auto):
    make_request(auto.env.http)
    auto.cycle()
    auto.cycle()
    assert type(auto.signer).calls == 1 and auto.env.runner.calls == 1
    auto.env.store.close()
    for suffix in ("", "-wal", "-shm"):
        p = auto.env.tmp / f"state.sqlite3{suffix}"
        if p.exists():
            p.unlink()
    auto.env.store = StateStore(auto.env.tmp / "state.sqlite3")
    auto.build(auto.env.store)
    for _ in range(3):
        auto.cycle()
    assert type(auto.signer).calls == 1 and auto.env.runner.calls == 1


def test_restoring_an_old_backup_never_signs_again(auto):
    import shutil
    make_request(auto.env.http)
    auto.env.store.conn.execute("PRAGMA wal_checkpoint(FULL)")
    backup = auto.env.tmp / "old.sqlite3"
    shutil.copyfile(auto.env.tmp / "state.sqlite3", backup)                    # a backup from BEFORE the claim
    auto.cycle()
    auto.cycle()
    auto.env.store.close()
    for suffix in ("-wal", "-shm"):
        p = auto.env.tmp / f"state.sqlite3{suffix}"
        if p.exists():
            p.unlink()
    shutil.copyfile(backup, auto.env.tmp / "state.sqlite3")
    auto.env.store = StateStore(auto.env.tmp / "state.sqlite3")
    auto.build(auto.env.store)
    for _ in range(3):
        auto.cycle()
    assert type(auto.signer).calls == 1 and auto.env.runner.calls == 1


# ================================ crash recovery =======================================================================================================

def test_a_crash_before_the_claim_costs_nothing_and_the_next_scan_signs(auto, monkeypatch):
    make_request(auto.env.http)
    real = auto.env.store.auto_claim
    monkeypatch.setattr(type(auto.env.store), "auto_claim", lambda *a, **k: (_ for _ in ()).throw(Crash()))
    with pytest.raises(Crash):
        auto.cycle()
    monkeypatch.undo()
    assert type(auto.signer).calls == 0
    auto.cycle()
    assert approval_posted(auto.env) and ready_posted(auto.env) and type(auto.signer).calls == 1


def test_a_crash_after_the_claim_before_the_signature_allows_one_more_signature_only(auto, monkeypatch):
    make_request(auto.env.http)
    monkeypatch.setattr(ToolSigner, "sign", lambda *a, **k: (_ for _ in ()).throw(Crash()))
    with pytest.raises(Crash):
        auto.cycle()
    claim = auto.env.store.auto_get_claim("REQ-A", "1")
    assert claim["stage"] == "RESERVED" and not approval_posted(auto.env)
    auto.env.store.close()
    auto.env.store = StateStore(auto.env.tmp / "state.sqlite3")                 # the process was restarted
    auto.build(auto.env.store)
    with pytest.raises(Crash):
        auto.cycle()                                                            # the one extra attempt dies as well
    monkeypatch.undo()
    auto.cycle()                                                                # a third try is refused: UNCERTAIN, never re-signed automatically
    claim = auto.env.store.auto_get_claim("REQ-A", "1")
    assert claim["stage"] == "UNCERTAIN" and not approval_posted(auto.env) and has(auto.env, "AUTO_SIGNING_UNCERTAIN")


def test_a_crash_after_the_signature_before_the_approval_is_posted_resumes_with_the_same_bytes(auto, monkeypatch):
    make_request(auto.env.http)
    monkeypatch.setattr(AutoApprover, "_post_create_only", lambda *a, **k: (_ for _ in ()).throw(Crash()))
    with pytest.raises(Crash):
        auto.cycle()
    stored = auto.env.store.auto_get_claim("REQ-A", "1")["approval_text"]
    monkeypatch.undo()
    auto.cycle()
    assert remote(auto.env, REQ.format(rid="REQ-A") + "APPROVAL_SIG.json") == stored.encode() and ready_posted(auto.env)
    assert type(auto.signer).calls == 1


def test_a_crash_between_approval_and_ready_publishes_only_the_stored_ready(auto, monkeypatch):
    make_request(auto.env.http)
    real = AutoApprover._post_create_only
    state = {"n": 0}

    def flaky(self, transport, path, data):
        state["n"] += 1
        if path.endswith("READY.md"):
            raise Crash()
        return real(self, transport, path, data)
    monkeypatch.setattr(AutoApprover, "_post_create_only", flaky)
    with pytest.raises(Crash):
        auto.cycle()
    assert approval_posted(auto.env) and not ready_posted(auto.env)
    stored_ready = auto.env.store.auto_get_claim("REQ-A", "1")["ready_text"]
    monkeypatch.undo()
    auto.cycle()
    assert remote(auto.env, REQ.format(rid="REQ-A") + "READY.md") == stored_ready.encode() and type(auto.signer).calls == 1
    auto.cycle()
    assert auto.env.runner.calls == 1


def test_a_stored_approval_that_expired_is_never_re_signed(auto, monkeypatch):
    make_request(auto.env.http)
    monkeypatch.setattr(AutoApprover, "_post_create_only", lambda *a, **k: (_ for _ in ()).throw(Crash()))
    with pytest.raises(Crash):
        auto.cycle()
    monkeypatch.undo()
    claim = auto.env.store.auto_get_claim("REQ-A", "1")
    approval = json.loads(claim["approval_text"])
    approval["payload"]["expires_at"] = iso(time.time() - 5)
    auto.env.store.auto_update("REQ-A", "1", int(time.time()), approval_text=json.dumps(approval))
    auto.cycle()
    assert not approval_posted(auto.env) and type(auto.signer).calls == 1
    assert auto.env.store.auto_get_claim("REQ-A", "1")["stage"] == "UNCERTAIN"


def test_a_crash_after_ready_before_the_watcher_still_reviews_exactly_once(auto, monkeypatch):
    make_request(auto.env.http)
    auto.cycle()                                                              # READY posted; the process "dies" before the next cycle
    auto.env.store.close()
    auto.env.store = StateStore(auto.env.tmp / "state.sqlite3")
    auto.build(auto.env.store)
    for _ in range(3):
        auto.cycle()
    assert auto.env.runner.calls == 1 and type(auto.signer).calls == 1


def test_a_failed_result_upload_after_dispatch_neither_resigns_nor_re_reviews(auto):
    make_request(auto.env.http)
    auto.cycle()
    auto.env.http.inject("PUT", "/contents/collab/reviews/", status=500, times=100)
    auto.cycle()                                                              # review runs; its result cannot be uploaded
    assert auto.env.runner.calls == 1
    auto.env.http._inject.clear()
    for _ in range(3):
        auto.cycle()
    assert auto.env.runner.calls == 1 and type(auto.signer).calls == 1


# ================================ remote errors and races ==========================================================================================

def test_a_branch_head_race_on_the_approval_is_retried_a_bounded_number_of_times(auto):
    make_request(auto.env.http)
    auto.env.http.inject("PUT", "requests/REQ-A/APPROVAL_SIG.json", status=422, times=1)
    auto.cycle()
    assert approval_posted(auto.env) and ready_posted(auto.env) and type(auto.signer).calls == 1


def test_a_persistent_conflict_stops_after_the_bound_and_publishes_no_ready(auto):
    make_request(auto.env.http)
    auto.env.http.inject("PUT", "requests/REQ-A/APPROVAL_SIG.json", status=422, times=100)
    auto.cycle()
    assert not ready_posted(auto.env) and len(puts(auto.env, "APPROVAL_SIG.json")) <= 3
    assert auto.env.store.auto_get_claim("REQ-A", "1")["stage"] == "UNCERTAIN" and has(auto.env, "AUTO_SIGNING_UNCERTAIN")
    for _ in range(3):
        auto.cycle()
    assert type(auto.signer).calls == 1 and not ready_posted(auto.env)


def test_a_server_error_while_posting_stops_without_ready(auto):
    make_request(auto.env.http)
    auto.env.http.inject("PUT", "requests/REQ-A/", status=503, times=100)
    auto.cycle()
    assert not ready_posted(auto.env) and auto.env.store.auto_get_claim("REQ-A", "1")["stage"] == "UNCERTAIN"


def test_a_different_file_already_at_the_approval_path_stops_everything(auto):
    make_request(auto.env.http)
    real_post = AutoApprover._post_create_only

    def planted(self, transport, path, data):
        if path.endswith("APPROVAL_SIG.json"):
            self_http = auto.env.http
            self_http.commit({rp("requests/REQ-A/APPROVAL_SIG.json"): b"somebody else's file"})
        return real_post(self, transport, path, data)
    AutoApprover._post_create_only = planted
    try:
        auto.cycle()
    finally:
        AutoApprover._post_create_only = real_post
    assert not ready_posted(auto.env) and auto.env.store.auto_get_claim("REQ-A", "1")["stage"] == "UNCERTAIN"


def test_the_delegation_switched_off_before_posting_stops_the_publication(auto, monkeypatch):
    make_request(auto.env.http)
    real_sign = ToolSigner.sign

    def sign_then_switch_off(self, *a, **k):
        out = real_sign(self, *a, **k)
        write_delegation(auto.delegation, enabled=False)
        return out
    monkeypatch.setattr(ToolSigner, "sign", sign_then_switch_off)
    auto.cycle()
    assert not approval_posted(auto.env) and not ready_posted(auto.env)
    assert auto.env.store.auto_get_claim("REQ-A", "1")["stage"] == "POLICY_STOPPED"


def test_a_repository_that_changes_before_posting_stops_the_publication(auto, monkeypatch):
    make_request(auto.env.http)
    real_sign = ToolSigner.sign

    def sign_then_swap_repository(self, *a, **k):
        out = real_sign(self, *a, **k)
        auto.env.http.repo_id = "replaced-repository"
        return out
    monkeypatch.setattr(ToolSigner, "sign", sign_then_swap_repository)
    auto.cycle()
    assert not approval_posted(auto.env) and not ready_posted(auto.env)


# ================================ signer and trust failures ============================================================================================

def test_a_signer_that_fails_leaves_an_uncertain_claim_and_nothing_remote(auto, monkeypatch):
    make_request(auto.env.http)
    monkeypatch.setattr(ToolSigner, "sign", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("synthetic")))
    auto.cycle()
    assert not approval_posted(auto.env) and auto.env.store.auto_get_claim("REQ-A", "1")["stage"] == "UNCERTAIN"


def test_a_key_that_is_not_in_the_trust_root_signs_nothing(auto):
    from skill_collab_watcher.approval import TrustRoot
    auto.policy.trust_root = TrustRoot(repo_id=REPO_ID, keys={})
    make_request(auto.env.http)
    auto.cycle()
    assert not approval_posted(auto.env) and type(auto.signer).calls == 0


def test_without_a_signature_backend_nothing_is_signed(auto):
    auto.policy.signature_backend = None
    make_request(auto.env.http)
    auto.cycle()
    assert not approval_posted(auto.env) and type(auto.signer).calls == 0


def test_a_signature_that_does_not_verify_against_the_trust_root_is_never_published(auto):
    import base64
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    other = Ed25519PrivateKey.generate().public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    from skill_collab_watcher.approval import TrustedKey, TrustRoot, fingerprint_of
    from bundle import KEY_ID
    pub = base64.b64encode(other).decode()
    auto.policy.trust_root = TrustRoot(repo_id=REPO_ID, keys={KEY_ID: TrustedKey(key_id=KEY_ID, public_key=pub, fingerprint=fingerprint_of(pub), status="ACTIVE")})
    make_request(auto.env.http)
    auto.cycle()
    assert not approval_posted(auto.env) and auto.env.store.auto_get_claim("REQ-A", "1")["stage"] == "UNCERTAIN"


def test_the_signer_refuses_a_plaintext_key_unless_explicitly_allowed(auto):
    signer = ToolSigner(auto.keyfile, "k", REPO_ID)
    with pytest.raises(PermissionError):
        signer.sign(b"r", b"y", b"p", "/SKILL-COLLAB/packages/x.zip", "a" * 40, "1", 2)


def test_the_signer_refuses_an_encrypted_key_without_a_passphrase_provider(auto, tmp_path):
    from skill_collab_watcher.approval import ApprovalRejected  # noqa: F401
    tool = ToolSigner._tool()
    enc = tmp_path / "enc.key"
    raw = b"\x01" * 32
    enc.write_text(tool.encrypt_private(raw, "a long passphrase for the test"), encoding="ascii")
    with pytest.raises(PermissionError):
        ToolSigner(enc, "k", REPO_ID).sign(b"r", b"y", b"p", "/SKILL-COLLAB/packages/x.zip", "a" * 40, "1", 2)


def test_an_encrypted_key_signs_through_the_passphrase_provider(auto, tmp_path):
    import base64
    tool = ToolSigner._tool()
    raw = base64.b64decode(auto.keyfile.read_text().strip())
    enc = tmp_path / "enc.key"
    enc.write_text(tool.encrypt_private(raw, "a long passphrase for the test"), encoding="ascii")
    signer = ToolSigner(enc, "key-synthetic-1", REPO_ID, passphrase_provider=lambda _p: "a long passphrase for the test")
    info = make_request(auto.env.http)
    ready = f"---\nschema: SKILL_COLLAB_READY_V1\nstate: READY\nrequest_id: REQ-A\nrequest_revision: 1\nrequest_path: /SKILL-COLLAB/requests/REQ-A/REQUEST.md\nrequest_sha256: {hashlib.sha256(info.request).hexdigest()}\npackage_sha256: {hashlib.sha256(info.package).hexdigest()}\nbaseline_id: TEST-BASELINE-0001\n---\n".encode()
    approval = signer.sign(info.request, ready, info.package, info.package_path, info.commit_a, "1", 2)
    assert json.loads(approval)["payload"]["request_id"] == "REQ-A"
    assert b"passphrase" not in approval


def test_a_wrong_passphrase_never_signs(auto, tmp_path):
    import base64
    tool = ToolSigner._tool()
    enc = tmp_path / "enc.key"
    enc.write_text(tool.encrypt_private(base64.b64decode(auto.keyfile.read_text().strip()), "a long passphrase for the test"), encoding="ascii")
    signer = ToolSigner(enc, "k", REPO_ID, passphrase_provider=lambda _p: "the wrong passphrase!!")
    with pytest.raises(Exception):
        signer.sign(b"r", b"y", b"p", "/SKILL-COLLAB/packages/x.zip", "a" * 40, "1", 2)


# ================================ modes ================================================================================================================

def test_a_dry_run_never_invokes_automatic_approval(auto):
    make_request(auto.env.http)
    run(auto.env, policy=auto.policy, allowed=False)
    assert not approval_posted(auto.env) and type(auto.signer).calls == 0


def test_a_read_only_store_never_signs(auto):
    make_request(auto.env.http)
    ro = StateStore(auto.env.tmp / "state.sqlite3", read_only=True)
    info = auto.env.http.files()[rp("requests/REQ-A/REQUEST.md")]
    res = AutoApprover(auto.settings, auto.env.store, signer=auto.signer).process(make_transport(auto.env.http), ro, auto.policy, "/SKILL-COLLAB", "REQ-A", info.decode(), info)
    ro.close()
    assert res.status == "READ_ONLY" and type(auto.signer).calls == 0


def test_requests_that_already_have_a_ready_are_not_touched(auto):
    from bundle import publish_bundle
    publish_bundle(auto.env.http)                                               # a hand-signed request with READY (double signature backend)
    auto.cycle()
    assert type(auto.signer).calls == 0 and not puts(auto.env, "APPROVAL_SIG.json")


def test_events_never_contain_key_material_or_paths(auto):
    make_request(auto.env.http)
    auto.cycle()
    text = " ".join(f"{e} {d}" for e, d in events(auto.env))
    assert str(auto.keyfile) not in text and "PRIVATE KEY" not in text and "approver.key" not in text


# ================================ the reservation itself (store level) ===================================================================================

def _kst_day(offset_days=0):
    from skill_collab_watcher.state_store import kst_window_starts
    return kst_window_starts(int(time.time()))[0] + 3600 + offset_days * 86400


def test_the_store_reserves_a_request_once_and_says_so(github_env):
    s = github_env.store
    s.ensure_auto_tables()
    t = _kst_day()
    kw = dict(max_day_calls=2, max_day_cents=300, max_month_cents=1000)
    cj = "{}"
    assert s.auto_claim("R", "1", "a" * 64, 100, cj, t, **kw) == "CLAIMED"
    assert s.auto_claim("R", "1", "a" * 64, 100, cj, t + 1, **kw) == "EXISTS"
    assert s.auto_claim("R", "2", "a" * 64, 100, cj, t + 2, **kw) == "CLAIMED"           # another revision is another request
    assert s.auto_claim("R", "3", "a" * 64, 100, cj, t + 3, **kw) == "CLAIMED"
    assert s.auto_claim("R", "3", "a" * 64, 100, cj, _kst_day(1), **kw) == "EXISTS"
    assert s.auto_claim("R", "4", "a" * 64, 100, cj, _kst_day(1), **kw) == "CLAIMED"


def test_many_processes_racing_for_one_request_produce_exactly_one_reservation(github_env):
    github_env.store.ensure_auto_tables()
    outcomes, errors = [], []
    t = _kst_day()

    def worker():
        try:
            store = StateStore(github_env.tmp / "state.sqlite3")
            outcomes.append(store.auto_claim("R", "1", "a" * 64, 100, "{}", t, max_day_calls=9, max_day_cents=900, max_month_cents=9000))
            store.close()
        except Exception as exc:                                                                           # noqa: BLE001
            errors.append(repr(exc))

    threads = [threading.Thread(target=worker) for _ in range(8)]
    [t_.start() for t_ in threads]
    [t_.join() for t_ in threads]
    assert not errors, errors
    assert outcomes.count("CLAIMED") == 1 and outcomes.count("EXISTS") == 7


def test_first_sight_is_recorded_once_and_never_upgraded(github_env):
    s = github_env.store
    s.ensure_auto_tables()
    assert s.auto_note_seen("R", "1", False, 100) == (100, False)
    assert s.auto_note_seen("R", "1", True, 200) == (100, False)             # seen while off: stays excluded
    assert s.auto_note_seen("S", "1", True, 300) == (300, True)


def test_the_tables_exist_only_when_the_feature_is_used(github_env):
    names = {r[0] for r in github_env.store.conn.execute("select name from sqlite_master where type='table'")}
    assert "auto_claims" not in names and "auto_seen" not in names


def test_an_uncertain_automatic_signing_is_an_alert_event_with_a_plain_message():
    from skill_collab_watcher.notify_events import NOTIFY_EVENTS, build_message
    assert "AUTO_SIGNING_UNCERTAIN" in NOTIFY_EVENTS
    text = build_message("AUTO_SIGNING_UNCERTAIN", "REQ-A", "approval publication: ERROR", "github", "owner/repo")
    assert "REQ-A" in text and "모델을 호출하지 않았습니다" in text


def test_an_unexpected_error_before_any_reservation_is_a_plain_log_line_not_an_alert(auto, monkeypatch):
    make_request(auto.env.http)
    monkeypatch.setattr(auto_approval.auto_policy, "assess", lambda *a, **k: (_ for _ in ()).throw(ValueError("synthetic")))
    auto.cycle()
    assert auto.env.store.auto_get_claim("REQ-A", "1") is None and not approval_posted(auto.env)
    assert has(auto.env, "AUTO_ERROR") and not has(auto.env, "AUTO_SIGNING_UNCERTAIN") and type(auto.signer).calls == 0


def test_an_unexpected_error_after_the_reservation_is_an_alert_and_final(auto, monkeypatch):
    make_request(auto.env.http)
    monkeypatch.setattr(AutoApprover, "_sign_and_post", lambda *a, **k: (_ for _ in ()).throw(ValueError("synthetic")))
    auto.cycle()
    assert auto.env.store.auto_get_claim("REQ-A", "1")["stage"] == "UNCERTAIN" and has(auto.env, "AUTO_SIGNING_UNCERTAIN")

def test_configurable_basic_and_design_tiers_are_signed_only_when_locally_allowed(auto):
    write_delegation(auto.delegation, max_request_usd=3.0)
    auto.policy.known_run_policy_refs.append("POLICY-STATIC-V1-DESIGN")
    auto.policy.run_budgets_usd["POLICY-STATIC-V1"] = 1.5
    auto.policy.run_budgets_usd["POLICY-STATIC-V1-DESIGN"] = 3.0
    make_request(auto.env.http, "REQ-A", policy_ref="POLICY-STATIC-V1")
    make_request(auto.env.http, "REQ-B", policy_ref="POLICY-STATIC-V1-DESIGN")
    auto.cycle()
    assert approval_posted(auto.env, "REQ-A")
    assert approval_posted(auto.env, "REQ-B")
    assert type(auto.signer).calls == 2

def test_design_tier_cannot_escalate_past_protected_delegation(auto):
    write_delegation(auto.delegation, max_request_usd=1.5)
    auto.policy.known_run_policy_refs.append("POLICY-STATIC-V1-DESIGN")
    auto.policy.run_budgets_usd["POLICY-STATIC-V1-DESIGN"] = 3.0
    make_request(auto.env.http, "REQ-A", policy_ref="POLICY-STATIC-V1-DESIGN")
    auto.cycle()
    assert not approval_posted(auto.env, "REQ-A")
    assert type(auto.signer).calls == 0
