"""The real numeric-pin failure must stop before a reservation or signer call."""
import json

import pytest

from auto_helpers import auto, make_request, remote, puts, has
from bundle import REPO_ID
from fake_github import j, rp
from datetime import datetime, timezone
from skill_collab_watcher.approval import ApprovalRejected, validate_source_pin
from test_phase1_approval import _pair, _verify
from tools import approval_signer
from types import SimpleNamespace


def test_signer_rejects_invalid_repo_before_private_key_or_request_access(capsys):
    args = SimpleNamespace(source_commit="a" * 40, valid_hours=1, repo_id="repo-name-is-not-an-id")
    assert approval_signer.cmd_sign(args) == 2
    assert "PIN_REPO_ID_FORMAT" in capsys.readouterr().err


@pytest.mark.parametrize("value", [123456789, 123456789.0, True, None, [], {}])
def test_final_approval_uses_the_same_strict_pin_contract(value):
    now = datetime.now(timezone.utc)
    approval, raw = _pair(now)
    pin = json.loads(raw)
    pin["repo_id"] = value
    with pytest.raises(ApprovalRejected, match="PIN_REPO_ID_TYPE"):
        validate_source_pin(pin, expected_repo_id=REPO_ID)
    with pytest.raises(ApprovalRejected, match="PIN_REPO_ID_TYPE"):
        _verify(approval, j(pin), now)


@pytest.mark.parametrize("value", [123456789, 123456789.0, True, None, [], {}])
def test_non_string_repo_id_is_rejected_before_reservation(auto, value):
    make_request(auto.env.http)
    path = "requests/REQ-A/SOURCE_PIN.json"
    pin = json.loads(remote(auto.env, path))
    pin["repo_id"] = value
    auto.env.http.commit({rp(path): j(pin)})
    auto.cycle()
    assert auto.env.store.auto_get_claim("REQ-A", "1") is None
    assert type(auto.signer).calls == 0
    assert auto.env.runner.calls == 0
    assert not puts(auto.env, "APPROVAL_SIG.json") and not puts(auto.env, "READY.md")
    assert has(auto.env, "AUTO_NOT_ELIGIBLE", "PIN_REPO_ID_TYPE")


@pytest.mark.parametrize("value", [[], None, "bad pin", 1])
def test_non_object_pin_is_a_precise_input_rejection(auto, value):
    make_request(auto.env.http)
    auto.env.http.commit({rp("requests/REQ-A/SOURCE_PIN.json"): j(value)})
    auto.cycle()
    assert auto.env.store.auto_get_claim("REQ-A", "1") is None
    assert type(auto.signer).calls == auto.env.runner.calls == 0
    assert has(auto.env, "AUTO_NOT_ELIGIBLE", "PIN_SCHEMA_MISMATCH")
    assert not has(auto.env, "AUTO_ERROR")


def test_corrected_pin_can_proceed_when_no_reservation_was_created(auto):
    make_request(auto.env.http)
    path = "requests/REQ-A/SOURCE_PIN.json"
    valid = remote(auto.env, path)
    pin = json.loads(valid)
    pin["repo_id"] = 123456789
    auto.env.http.commit({rp(path): j(pin)})
    auto.cycle()
    assert auto.env.store.auto_get_claim("REQ-A", "1") is None
    auto.env.http.commit({rp(path): valid})
    auto.cycle()
    assert len(puts(auto.env, "READY.md")) == 1
    auto.cycle()
    auto.cycle()
    assert auto.env.runner.calls == type(auto.signer).calls == 1


def test_existing_uncertain_reservation_is_never_reset_or_retried(auto):
    make_request(auto.env.http)
    store = auto.env.store
    store.ensure_auto_tables()
    assert store.auto_claim("REQ-A", "1", "a" * 64, 100, "{}", 1,
                            max_day_calls=2, max_day_cents=300, max_month_cents=1000) == "CLAIMED"
    store.auto_update("REQ-A", "1", 2, stage="UNCERTAIN", detail="old signing attempt")
    before = dict(store.auto_get_claim("REQ-A", "1"))
    auto.cycle()
    auto.cycle()
    assert dict(store.auto_get_claim("REQ-A", "1")) == before
    assert type(auto.signer).calls == auto.env.runner.calls == 0
    assert not puts(auto.env, "READY.md")
