"""New v0.2.25 per-request budgets and aggregate-free reservations."""
from dataclasses import replace
import json
import time
import pytest
from skill_collab_watcher.auto_policy import Candidate, Delegation, Evidence, assess
from skill_collab_watcher.state_store import StateStore, kst_window_starts
from skill_collab_watcher.config import _parse_run_policy_refs, ConfigError

def scenario():
    now=int(time.time())
    d=Delegation(enabled=True,repo_id="123",branch="main",
        projects=frozenset({"project"}),skills=frozenset({"skill"}),
        expires_at=now+3600,earliest_request_at=now-120,
        max_request_cents=300)
    c=Candidate(request_id="REQ-1",revision=1,project="project",skill="skill",
        repo_id="123",branch="main",created_at=now-5,
        commit_a="a"*40,request_sha256="b"*64,zip_sha256="c"*64,
        policy="POLICY-STATIC-V1",estimated_cents=150,max_calls=1,attempt=1)
    e=Evidence(now=now,pins_verified=True,bytes_and_crc_verified=True,
        signer_and_trust_root_valid=True,prior_state="NEW",
        day_calls_used_or_reserved=999,day_cents_used_or_reserved=900000,
        month_cents_used_or_reserved=9000000,atomic_claim_available=True)
    return d,c,e

def test_configurable_tier_budgets_are_locally_registered():
    tiers={"POLICY-STATIC-V1":{"max_budget_usd":1.5},
           "POLICY-STATIC-V1-DESIGN":{"max_budget_usd":3.0}}
    names,budgets,efforts=_parse_run_policy_refs(tiers)
    assert names==list(tiers) and budgets=={"POLICY-STATIC-V1":1.5,
                                             "POLICY-STATIC-V1-DESIGN":3.0}
    assert efforts=={}
    with pytest.raises(ConfigError):
        _parse_run_policy_refs({"POLICY-STATIC-V1-DESIGN":{"max_budget_usd":float("inf")}})

def test_basic_and_design_allow_unlimited_aggregate_telemetry():
    d,c,e=scenario()
    assert assess(d,c,e)[0]
    assert assess(d,replace(c,policy="POLICY-STATIC-V1-DESIGN",
                            estimated_cents=300),e)[0]
    assert assess(d,replace(c,policy="POLICY-STATIC-V1-DESIGN",
                            estimated_cents=301),e)[1]=="PER_REQUEST_COST"

def test_scope_and_exactly_once_prevent_untrusted_escalation():
    d,c,e=scenario()
    assert assess(d,replace(c,policy="POLICY-STATIC-V1-LARGE"),e)[1]=="REVIEW_POLICY"
    assert assess(d,replace(c,max_calls=2),e)[1]=="REVIEW_POLICY"
    assert assess(d,replace(c,project="other"),e)[1]=="SCOPE"
    assert assess(d,c,replace(e,prior_state="UNCERTAIN"))[1]=="DUPLICATE_OR_UNCERTAIN"

def test_atomic_reservations_exceed_old_limits_but_duplicate_still_blocks(tmp_path):
    s=StateStore(tmp_path/"state.sqlite3")
    s.ensure_auto_tables()
    now=kst_window_starts(int(time.time()))[0]+3600
    kw=dict(max_day_calls=1,max_day_cents=0,max_month_cents=0)
    for i in range(12):
        rid=f"REQ-{i}"
        assert s.auto_claim(rid,"1","a"*64,300,"{}",now,**kw)=="CLAIMED"
    assert s.auto_claim("REQ-1","1","a"*64,300,"{}",now,**kw)=="EXISTS"
    assert s.window_usage(now)["day_cents"]>=3600
    assert s.auto_claim("BAD","1","a"*64,0,"{}",now,**kw)=="INVALID_COST"
    s.close()
