"""Precise wait reasons through the actual scan and injected, non-network sender."""
import json

from auto_helpers import auto, make_request, remote
from fake_github import j, rp
from skill_collab_watcher.notify_events import NotifyState, approval_wait_detail, build_message, run_once
from skill_collab_watcher.state_store import StateStore


def test_real_scan_records_pin_reason_instead_of_generic_ready_wait(auto):
    make_request(auto.env.http)
    path = "requests/REQ-A/SOURCE_PIN.json"
    pin = json.loads(remote(auto.env, path))
    pin["repo_id"] = 123456789
    auto.env.http.commit({rp(path): j(pin)})
    state = NotifyState()
    state.bootstrap(auto.env.store.conn, "github", 1)
    auto.cycle()
    sent = []
    assert run_once(auto.env.store.conn, state, provider="github", repo="owner/repo", send=sent.append) == 1
    assert "REQ-A r1" in sent[0] and "PIN_REPO_ID_TYPE" in sent[0]
    assert "SOURCE_PIN" in sent[0] and "이전 실행·누적 비용은 미확인" in sent[0]
    assert "비용은 아직 0" not in sent[0]
    auto.cycle()
    assert run_once(auto.env.store.conn, state, provider="github", repo="owner/repo", send=sent.append) == 0


def test_ready_published_does_not_log_a_stale_missing_ready_wait(auto):
    make_request(auto.env.http)
    state = NotifyState()
    state.bootstrap(auto.env.store.conn, "github", 1)
    auto.cycle()
    sent = []
    run_once(auto.env.store.conn, state, provider="github", repo="owner/repo", send=sent.append)
    assert sent == []
    assert auto.env.store.conn.execute("SELECT COUNT(*) FROM audit_log WHERE event='WAIT_INPUT'").fetchone()[0] == 0


def test_old_queued_wait_is_suppressed_after_corrected_pin_reaches_ready(auto):
    make_request(auto.env.http)
    path = "requests/REQ-A/SOURCE_PIN.json"
    valid = remote(auto.env, path)
    pin = json.loads(valid)
    pin["repo_id"] = 123456789
    auto.env.http.commit({rp(path): j(pin)})
    state = NotifyState()
    state.bootstrap(auto.env.store.conn, "github", 1)
    auto.cycle()
    auto.env.http.commit({rp(path): valid})
    auto.cycle()
    sent = []
    assert run_once(auto.env.store.conn, state, provider="github", repo="owner/repo", send=sent.append) == 0
    assert sent == []


def test_wait_reason_changes_are_delivered_once_and_survive_restart(tmp_path):
    store = StateStore(tmp_path / "state.sqlite3")
    state = NotifyState()
    state.bootstrap(store.conn, "github", 1)
    sent = []
    for status, detail in [("PIN_MISMATCH", "PIN_REPO_ID_TYPE"), ("PIN_MISMATCH", "PIN_REPO_ID_TYPE"),
                           ("PER_REQUEST_COST", ""), ("PER_REQUEST_COST", "")]:
        store.log_event("WAIT_INPUT", processing_key="REQ-A|1",
                        detail=approval_wait_detail("REQ-A", "1", status, detail))
    path = tmp_path / "notify.json"
    assert run_once(store.conn, state, provider="github", repo="owner/repo", send=sent.append,
                    persist=lambda: state.save(path)) == 2
    resumed = NotifyState.load(path)
    assert run_once(store.conn, resumed, provider="github", repo="owner/repo", send=sent.append) == 0
    store.close()


def test_untrusted_exception_detail_never_appears_in_user_message():
    raw = "sensitive exception text: synthetic-secret-do-not-echo"
    detail = approval_wait_detail("REQ-A", "1", "PIN_MISMATCH", raw)
    message = build_message("WAIT_INPUT", "REQ-A|1", detail, "github", "owner/repo")
    assert raw not in detail and raw not in message
    assert "NOT_VERIFIED" in message
    message = build_message("AUTO_SIGNING_UNCERTAIN", "REQ-A", raw, "github", "owner/repo")
    assert raw not in message and "이전 실행·누적 비용은 미확인" in message
    precise = build_message("AUTO_SIGNING_UNCERTAIN", "REQ-A", "signer: REPO_ID_MISMATCH", "github", "owner/repo")
    assert "오류: REPO_ID_MISMATCH" in precise and "signer:" not in precise


def test_primary_uncertainty_alert_suppresses_duplicate_wait_message(tmp_path):
    store = StateStore(tmp_path / "state.sqlite3")
    state = NotifyState()
    state.bootstrap(store.conn, "github", 1)
    store.log_event("AUTO_SIGNING_UNCERTAIN", processing_key="REQ-A", detail="signing failed")
    store.log_event("WAIT_INPUT", processing_key="REQ-A|1",
                    detail=approval_wait_detail("REQ-A", "1", "UNCERTAIN", "signing failed"))
    sent = []
    assert run_once(store.conn, state, provider="github", repo="owner/repo", send=sent.append) == 1
    store.close()
