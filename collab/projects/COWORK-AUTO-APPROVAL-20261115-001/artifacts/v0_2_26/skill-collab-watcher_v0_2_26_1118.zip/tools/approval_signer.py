"""Approver-device tool: sign a review approval, and check one offline.

    python -m tools.approval_signer keygen --out-private KEY.enc --out-public KEY.pub.txt --passphrase
    python -m tools.approval_signer sign --private-key KEY.b64 --key-id ID --repo-id REPO \
        --request REQUEST.md --ready READY.md --package PACKAGE.zip --package-path /SKILL-COLLAB/packages/x.zip \
        --source-commit <40 hex> --policy-revision 1 --out-dir OUT [--valid-hours 12]
    python -m tools.approval_signer check --trust-root ROOT.json --approval APPROVAL_SIG.json \
        --pin SOURCE_PIN.json --request REQUEST.md --ready READY.md --package PACKAGE.zip \
        --package-path /SKILL-COLLAB/packages/x.zip --policy-revision 1

This runs on the APPROVER's device. The private key never goes to the repository, to the watcher or into a log:
`keygen` writes it once to the path you give (refusing to overwrite) and prints only the PUBLIC fingerprint;
`sign` reads it from that path and writes APPROVAL_SIG.json and SOURCE_PIN.json. The signed fields are exactly
what the watcher checks. Requires the `cryptography` package.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import re
import secrets
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import yaml  # noqa: E402

from skill_collab_watcher.approval import (  # noqa: E402
    APPROVAL_SCHEMA, PAYLOAD_SCHEMA, PIN_SCHEMA, ApprovalRejected, NotConfigured, TrustRootError, canonical,
    fingerprint_of, knowledge_refs_hash, load_trust_root, validate_source_pin, verify_approval,
)

MAX_VALID_HOURS = 168


def _crypto():
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    except ImportError:
        print("REFUSED: the `cryptography` package is not installed in this environment", file=sys.stderr)
        raise SystemExit(2)
    return serialization, Ed25519PrivateKey


ENC_HEADER = "SKILL-COLLAB-ED25519-SCRYPT-AESGCM-V1"
MIN_PASSPHRASE = 12


def _ask(prompt: str) -> str:
    import getpass
    return getpass.getpass(prompt)   # hidden input; the passphrase is never an argument, file or environment variable


def _kdf_key(passphrase: str, salt: bytes) -> bytes:
    from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
    return Scrypt(salt=salt, length=32, n=2 ** 15, r=8, p=1).derive(passphrase.encode("utf-8"))


def encrypt_private(raw: bytes, passphrase: str) -> str:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    salt, nonce = secrets.token_bytes(16), secrets.token_bytes(12)
    blob = salt + nonce + AESGCM(_kdf_key(passphrase, salt)).encrypt(nonce, raw, ENC_HEADER.encode("ascii"))
    return ENC_HEADER + "\n" + base64.b64encode(blob).decode("ascii") + "\n"


def load_private_bytes(text: str, ask=None) -> bytes:
    """Accepts the encrypted format (asks for the passphrase) and the legacy plain base64 format."""
    text = text.strip()
    if not text.startswith(ENC_HEADER):
        return base64.b64decode(text, validate=True)
    from cryptography.exceptions import InvalidTag
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    try:
        blob = base64.b64decode(text[len(ENC_HEADER):].strip(), validate=True)
        salt, nonce, ciphertext = blob[:16], blob[16:28], blob[28:]
        return AESGCM(_kdf_key((ask or _ask)("Passphrase for the approver key: "), salt)).decrypt(
            nonce, ciphertext, ENC_HEADER.encode("ascii"))
    except (InvalidTag, ValueError) as exc:
        raise ValueError("WRONG_PASSPHRASE_OR_CORRUPT_KEY_FILE") from exc


def _restrict_to_owner(path: Path) -> bool:
    """Windows: remove inherited access and leave only the current account. Best effort; reports the result."""
    if sys.platform != "win32":
        return False
    import os
    import subprocess
    done = subprocess.run(["icacls", str(path), "/inheritance:r", "/grant:r", f"{os.environ.get('USERNAME', '')}:F"],
                          capture_output=True, text=True)
    return done.returncode == 0


def _front_matter(text: str) -> dict:
    if not text.startswith("---"):
        raise ValueError("REQUEST has no front matter")
    end = text.find("\n---", 3)
    data = yaml.safe_load(text[3:end])
    if not isinstance(data, dict):
        raise ValueError("REQUEST front matter is not a mapping")
    return data


def expected_fields(request: Path, ready: Path, package: Path, package_path: str, policy_revision: str) -> dict:
    """The values the watcher compares against. Everything is taken from the stored BYTES."""
    request_raw, ready_raw, package_raw = request.read_bytes(), ready.read_bytes(), package.read_bytes()
    fm = _front_matter(request_raw.decode("utf-8"))
    package_sha = hashlib.sha256(package_raw).hexdigest()
    if str(fm.get("package_sha256", "")).lower() != package_sha or int(fm.get("package_size_bytes", -1)) != len(package_raw):
        raise ValueError("the package does not match the size and SHA-256 declared in the REQUEST")
    if str(fm.get("package_path")) != package_path:
        raise ValueError("--package-path differs from package_path in the REQUEST")
    return {
        "request_id": str(fm["request_id"]), "request_revision": str(fm["request_revision"]),
        "request_sha256": hashlib.sha256(request_raw).hexdigest(),
        "ready_sha256": hashlib.sha256(ready_raw).hexdigest(),
        "package_path": package_path, "package_sha256": package_sha, "package_size_bytes": len(package_raw),
        "local_policy_revision": str(policy_revision), "run_policy_ref": str(fm["run_policy_ref"]),
        "knowledge_refs_hash": knowledge_refs_hash(fm.get("knowledge_refs") or []),
    }


def cmd_keygen(args) -> int:
    serialization, Ed25519PrivateKey = _crypto()
    private_path, public_path = Path(args.out_private), Path(args.out_public)
    if private_path.exists() or public_path.exists():
        print("REFUSED: an output file exists; a key is never overwritten", file=sys.stderr)
        return 2
    passphrase = None
    if args.passphrase:
        first = _ask("New passphrase (at least %d characters): " % MIN_PASSPHRASE)
        if len(first) < MIN_PASSPHRASE or first != _ask("Repeat the passphrase: "):
            print("REFUSED: the passphrase is too short or the two entries differ; no key was written", file=sys.stderr)
            return 2
        passphrase = first
    key = Ed25519PrivateKey.generate()
    raw_private = key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw,
                                    serialization.NoEncryption())
    raw_public = key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    with open(private_path, "x", encoding="ascii") as fh:  # "x": fails if it exists, no overwrite race
        fh.write(encrypt_private(raw_private, passphrase) if passphrase else base64.b64encode(raw_private).decode("ascii") + "\n")
    print(f"private key file: {'ENCRYPTED with a passphrase' if passphrase else 'PLAIN base64 (you chose --allow-plaintext-key)'}; "
          f"access restricted to this account: {_restrict_to_owner(private_path)}")
    public_b64 = base64.b64encode(raw_public).decode("ascii")
    public_path.write_text(public_b64 + "\n", encoding="ascii")
    print(f"public key written: {public_path.name}")
    print(f"fingerprint (sha256 of the public key): {fingerprint_of(public_b64)}")
    print("The private key file stays on THIS device. Restrict its permissions to your account; "
          "never copy it to the repository, the watcher host or a chat.")
    return 0


def cmd_sign(args) -> int:
    _, Ed25519PrivateKey = _crypto()
    if not re.fullmatch(r"[0-9a-f]{40}", args.source_commit):
        print("REFUSED: --source-commit must be a 40-character lowercase hex commit id", file=sys.stderr)
        return 2
    if not 0 < args.valid_hours <= MAX_VALID_HOURS:
        print(f"REFUSED: --valid-hours must be between 1 and {MAX_VALID_HOURS}", file=sys.stderr)
        return 2
    try:
        pin = validate_source_pin({"schema": PIN_SCHEMA, "repo_id": args.repo_id, "commit": args.source_commit})
    except ApprovalRejected as exc:
        print(f"REFUSED: {exc}", file=sys.stderr)
        return 2
    try:
        fields = expected_fields(Path(args.request), Path(args.ready), Path(args.package), args.package_path,
                                 args.policy_revision)
        key = Ed25519PrivateKey.from_private_bytes(load_private_bytes(Path(args.private_key).read_text(encoding="ascii")))
    except (ValueError, OSError, KeyError) as exc:
        print(f"REFUSED: {type(exc).__name__}", file=sys.stderr)
        return 2
    out_dir = Path(args.out_dir)
    approval_path, pin_path = out_dir / "APPROVAL_SIG.json", out_dir / "SOURCE_PIN.json"
    if approval_path.exists() or pin_path.exists():
        print("REFUSED: an approval already exists in the output folder; approvals are never overwritten",
              file=sys.stderr)
        return 2
    now = datetime.now(timezone.utc)
    payload = {
        "schema": PAYLOAD_SCHEMA, "repo_id": args.repo_id, **fields, "source_commit": args.source_commit,
        "nonce": secrets.token_hex(16),
        "issued_at": now.isoformat(), "expires_at": (now + timedelta(hours=args.valid_hours)).isoformat(),
    }
    approval = {"schema": APPROVAL_SCHEMA, "key_id": args.key_id, "payload": payload,
                "signature": base64.b64encode(key.sign(canonical(payload))).decode("ascii")}
    out_dir.mkdir(parents=True, exist_ok=True)
    approval_path.write_text(json.dumps(approval, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    pin_path.write_text(json.dumps(pin, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    print(f"signed request {fields['request_id']} revision {fields['request_revision']}; valid until {payload['expires_at']}")
    print(f"written: {approval_path.name}, {pin_path.name}; commit them together with READY.md (commit B)")
    return 0


def cmd_check(args) -> int:
    from skill_collab_watcher.signature_backend import default_backend

    try:
        trust = load_trust_root(args.trust_root)
        expected = expected_fields(Path(args.request), Path(args.ready), Path(args.package), args.package_path,
                                   args.policy_revision)
        verify_approval(Path(args.approval).read_bytes(), Path(args.pin).read_bytes(), trust=trust,
                        backend=default_backend(), expected=expected, now=datetime.now(timezone.utc))
    except (TrustRootError, ValueError, OSError) as exc:
        print(f"REFUSED: {type(exc).__name__}: {exc}")
        return 1
    except NotConfigured as exc:
        print(f"REFUSED: NOT_CONFIGURED: {exc}")
        return 1
    except ApprovalRejected as exc:
        print(f"REFUSED: {exc}")
        return 1
    print("OK: the watcher would accept this approval right now")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = parser.add_subparsers(dest="cmd", required=True)
    k = sub.add_parser("keygen")
    k.add_argument("--out-private", required=True)
    k.add_argument("--out-public", required=True)
    how = k.add_mutually_exclusive_group(required=True)
    how.add_argument("--passphrase", action="store_true", help="encrypt the private key file (recommended)")
    how.add_argument("--allow-plaintext-key", dest="plaintext", action="store_true",
                     help="store the private key as plain base64: only on an encrypted disk, only on purpose")
    k.set_defaults(f=cmd_keygen)
    s = sub.add_parser("sign")
    for name in ("private-key", "key-id", "repo-id", "request", "ready", "package", "package-path",
                 "source-commit", "policy-revision", "out-dir"):
        s.add_argument(f"--{name}", required=True)
    s.add_argument("--valid-hours", type=int, default=12)
    s.set_defaults(f=cmd_sign)
    c = sub.add_parser("check")
    for name in ("trust-root", "approval", "pin", "request", "ready", "package", "package-path", "policy-revision"):
        c.add_argument(f"--{name}", required=True)
    c.set_defaults(f=cmd_check)
    args = parser.parse_args(argv)
    return args.f(args)


if __name__ == "__main__":
    sys.exit(main())
