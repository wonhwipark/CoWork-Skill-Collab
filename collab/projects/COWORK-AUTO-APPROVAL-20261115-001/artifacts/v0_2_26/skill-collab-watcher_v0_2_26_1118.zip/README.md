# Skill Collab Watcher v0.2.26 개발 후보

**development_not_for_deployment** — REQUEST pin 타입 오류를 예약 전에 차단하고 승인 보류 원인을 기존 audit/notification 경로로 전달.

기준: SHA-256 고정 v0.2.25. 기존 운영 키·DB·정책·REQUEST/ZIP/SOURCE_PIN·서명/READY를 변경하지 않으며 과거 UNCERTAIN을 자동 재실행하지 않음.

변경·호스트 적용 경계: [REQUEST_PIN_REPAIR](docs/REQUEST_PIN_REPAIR.md).
신규 REQUEST 사전 검사: `python -m tools.review_request_gate --help`.
pin 생성·검증: `python -m tools.source_pin --help`.

위 도구는 입력 검사만 수행. 실제 보호된 Windows 승인·서명·READY·독립 리뷰·영수증을 대체하지 않음.
