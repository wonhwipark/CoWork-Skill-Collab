# Per-review budget policy (v0.2.25 development)

Current requested defaults: skill review USD 1.50; design review USD 3.00.
No daily/monthly cost or count ceilings. Do not auto-upgrade a request.

Configure the existing local reviewer.config.json review_policy block:
  "max_budget_usd": 1.5,
  "known_run_policy_refs": {
    "POLICY-STATIC-V1": {"max_budget_usd": 1.5},
    "POLICY-STATIC-V1-DESIGN": {"max_budget_usd": 3.0}
  },
  "daily_budget_usd": null,
  "max_dispatches_per_day": null

Existing protected delegation JSON must explicitly permit USD 3.00:
  "policy": "POLICY-STATIC-V1",
  "max_request_usd": 3.0

The request names only run_policy_ref, never the price. Both tiers require
the pre-existing permitted project/skill and valid SOURCE_PIN/signature/READY.
Design tier is available only when the local config explicitly lists its name,
and the protected delegation permits its price. Do not silently convert an
unapproved request from BASIC to DESIGN. The existing max_request_usd=1.0
continues to deny higher budget requests until authorized host changes.

Only change the two local values via the existing protected policy process;
ensure new settings, SHA pins, backup/rollback, and Windows host regression.
The published ZIP and this document do not install or activate LIVE settings.
Legacy max_day_usd/max_month_usd/max_day_calls keys are accepted but ignored.
Existing UNCERTAIN requests remain permanently claimed; history is preserved.
