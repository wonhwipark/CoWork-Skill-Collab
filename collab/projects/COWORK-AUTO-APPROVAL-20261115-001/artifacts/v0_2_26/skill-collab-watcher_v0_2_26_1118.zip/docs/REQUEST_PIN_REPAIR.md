# v0.2.26 — REQUEST 입력·승인 보류 재발 방지 후보

상태: **development_not_for_deployment**. v0.2.25 승인 원본/현재 운영 설치본을 이 후보로 대체하지 않음.

## 실제 수정

- `approval.validate_source_pin`: V1 schema/정확한 필드·문자열 numeric repo_id·고정 commit 검사. 자동 승인 예약 전과 최종 승인 검증이 같은 함수를 호출. 게시된 숫자형 pin은 강제 변환하지 않고 거부.
- 잘못된 pin은 `AUTO_NOT_ELIGIBLE / PIN_MISMATCH / PIN_REPO_ID_TYPE`으로 예약·signer 호출 전에 차단. 기존 UNCERTAIN/READY/완료 기록을 초기화하거나 재큐잉하지 않음.
- 기존 orchestrator가 AutoResult를 WAIT_INPUT에 연결. 성공적으로 READY가 게시된 주기에 'READY 없음' 대기 이벤트를 기록하지 않음.
- 기존 `notify_events.run_once`가 보류 단계·오류 코드·다음 한 조치를 출력. 이전 실행/누적 비용을 0으로 추정하지 않고 오류 예외 원문은 알림에 노출하지 않음. 같은 단계/원인은 1회, 원인이 바뀌면 1회; 기존 watermark·delivered 계약 유지.
- PRIVATE 정본의 `source_pin.py`, `review_request_gate.py` 원문과 각각의 시험을 패키지 `tools/`·`tests/`에 포함. 신규 REQUEST 작성자는 실제 LIVE config를 입력해 select/check를 수행해야 함. 사전 호환 검사 PASS는 서명·금액 승인이나 실행 권한이 아님.

## 남은 실제 호스트 게이트

기존 Windows Notifier는 별도 운영 프로그램. 이 패키지의 메시지 함수 구현/합성 전달 시험과 운영 Notifier의 실제 import/호출 적용은 별개. 실제 운영 어댑터·watermark와 이 라이브러리 호출을 확인·연결하기 전 Telegram 적용 PASS로 보고하지 않음. 새 발송 시험·Notifier 설치/설정 변경은 해당 승인 범위가 필요.

기존 숫자형 pin으로 이미 생성된 UNCERTAIN은 이 수정으로 자동 재시도하지 않음. 기존 MSC 요청의 로컬 예약/서명/호출/비용을 읽기 전용으로 정산하고 원래 유효 범위에서 정상 처리 가능한지를 판정. 새 REQUEST/자동 재리뷰/DB 삭제/READY 수동 조작으로 회피하지 않음.

실제 Windows 회귀·독립 리뷰·배포·보호 위임과 live 적용은 별도 미완료 게이트. 이 ZIP 게시나 Linux 합성 PASS는 기존 MSC 리뷰 완료 근거가 아님.
