"""0.1.3 hardening: permission boundary, UTF-8, package/knowledge path limits,
pinned knowledge delivery, ambiguous request files. No real `claude` process
is ever started here: RealReviewRunner.run is exercised only with
subprocess.run replaced by a recorder."""
from __future__ import annotations

import hashlib
import io
import json
import zipfile
from pathlib import Path

from skill_collab_watcher import review_runner
from skill_collab_watcher.models import JobState, ReviewResult, ValidationOutcome
from skill_collab_watcher.orchestrator import (
    CONTEXT_DIR_NAME, group_request_entries, run_scan_cycle,
)
from skill_collab_watcher.review_runner import CLAUDE_CWD_NAME, RealReviewRunner, build_argv
from skill_collab_watcher.transport_base import EntryMeta
from skill_collab_watcher.validator import parse_front_matter, validate

from conftest import REMOTE_ROOT, make_package_zip, ready_md, request_md


class RecordingRunner:
    def __init__(self):
        self.calls = 0
        self.snapshot_dir = None
        self.prompt = None

    def run(self, snapshot_dir, prompt_text, run_dir, max_budget_usd=None, effort=None):
        self.calls += 1
        self.snapshot_dir = snapshot_dir
        self.prompt = prompt_text
        files = sorted(p.relative_to(snapshot_dir).as_posix() for p in snapshot_dir.rglob("*") if p.is_file())
        self.files_seen = files
        return ReviewResult(ok=True, output_text="한글 리뷰 OK", output_format="json",
                            exit_code=0, model_calls=0, usage=None)


def _scan(transport, store, policy, runner, tmp_path, allowed=True):
    return run_scan_cycle(
        transport, store, policy, runner, allowed,
        snapshot_root=tmp_path / "snap", review_run_dir=tmp_path / "runs", remote_root=REMOTE_ROOT,
    )


def _publish(transport, package: bytes, refs_yaml="[]", req_id="REQ-1", package_path="/SKILL-COLLAB/packages/test.zip"):
    sha = hashlib.sha256(package).hexdigest()
    req = request_md(request_id=req_id, package_sha256=sha, package_size=len(package),
                     knowledge_refs_yaml=refs_yaml).replace(
        "package_path: /SKILL-COLLAB/packages/test.zip", f"package_path: {package_path}")
    ready = ready_md(hashlib.sha256(req.encode("utf-8")).hexdigest(), sha, request_id=req_id)
    transport.push_file(f"{REMOTE_ROOT}/requests/{req_id}/REQUEST.md", req.encode("utf-8"))
    transport.push_file(f"{REMOTE_ROOT}/requests/{req_id}/READY.md", ready.encode("utf-8"))
    transport.push_file(package_path, package)
    return sha


# --- permission boundary / process settings --------------------------------


def test_argv_never_uses_bypass_permissions():
    argv = build_argv("claude", None, ["Read", "Grep", "Glob"], Path("C:/snap"), 1.0)
    assert "bypassPermissions" not in argv
    assert argv[argv.index("--permission-mode") + 1] == "dontAsk"
    assert argv[argv.index("--add-dir") + 1] == str(Path("C:/snap"))
    assert "--bare" not in argv


def test_runner_uses_utf8_empty_cwd_and_no_shell(tmp_path, monkeypatch):
    seen = {}

    class Done:
        returncode = 0
        stdout = json.dumps({"result": "한글 결과", "usage": {"input_tokens": 1}}, ensure_ascii=False)
        stderr = ""

    def fake_run(argv, **kwargs):
        seen["argv"], seen["kwargs"] = argv, kwargs
        return Done()

    monkeypatch.setattr(review_runner.subprocess, "run", fake_run)
    runs = tmp_path / "runs"
    runs.mkdir()
    (runs / "secrets_like.txt").write_text("x")
    result = RealReviewRunner("claude", None, ["Read"], 1.0, 60).run(tmp_path / "snap", "프롬프트", runs)
    kw = seen["kwargs"]
    assert kw["encoding"] == "utf-8" and kw["errors"] == "replace"
    assert "text" not in kw
    assert kw["shell"] is False
    assert Path(kw["cwd"]) == runs / CLAUDE_CWD_NAME
    assert list(Path(kw["cwd"]).iterdir()) == []
    assert result.ok and result.output_text == "한글 결과"


# --- validator path limits ---------------------------------------------------


def _validate_with_package_path(policy, package_path):
    sha = "a" * 64
    req = request_md(package_sha256=sha, package_size=10).replace(
        "package_path: /SKILL-COLLAB/packages/test.zip", f"package_path: {package_path}")
    ready = ready_md(hashlib.sha256(req.encode("utf-8")).hexdigest(), sha)
    return validate(req, ready, None, policy)


def test_package_path_must_be_zip_under_packages(policy):
    ok = _validate_with_package_path(policy, "/SKILL-COLLAB/packages/test.zip")
    assert ok.outcome == ValidationOutcome.WAIT_INPUT and ok.needs_package_download
    for bad in (
        "/Private/secret.zip",
        "/SKILL-COLLAB/knowledge/OPERATING_CONTEXT_r0001.md",
        "/SKILL-COLLAB/packages/../knowledge/x.zip",
        "/SKILL-COLLAB/packages/test.md",
        "/SKILL-COLLAB/packages//test.zip",
        "SKILL-COLLAB/packages/test.zip",
    ):
        assert _validate_with_package_path(policy, bad).outcome == ValidationOutcome.REJECTED, bad


def test_knowledge_ref_with_dotdot_is_rejected(policy):
    sha = "a" * 64
    refs = '[{path: "/SKILL-COLLAB/knowledge/../packages/x.zip", revision: r1, sha256: "' + "c" * 64 + '"}]'
    req = request_md(package_sha256=sha, package_size=10, knowledge_refs_yaml=refs)
    ready = ready_md(hashlib.sha256(req.encode("utf-8")).hexdigest(), sha)
    assert validate(req, ready, None, policy).outcome == ValidationOutcome.REJECTED


def test_case_insensitive_package_prefix(policy):
    assert _validate_with_package_path(policy, "/skill-collab/PACKAGES/test.zip").needs_package_download


# --- request file selection ---------------------------------------------------


def _entry(path):
    return EntryMeta(path=path, rev="r", size=1, content_hash="h")


def test_draft_and_template_names_are_not_requests():
    entries = [
        _entry("/SKILL-COLLAB/requests/R1/REQUEST_DRAFT.md"),
        _entry("/SKILL-COLLAB/requests/R1/READY_TEMPLATE.md"),
        _entry("/SKILL-COLLAB/requests/R1/REQUEST.md"),
        _entry("/SKILL-COLLAB/requests/R1/READY.md"),
    ]
    group = group_request_entries(entries, "/SKILL-COLLAB")["R1"]
    assert group["request"].path.endswith("/REQUEST.md")
    assert group["ready"].path.endswith("/READY.md")


def test_two_request_candidates_means_wait_not_guess(transport, store, policy, tmp_path):
    runner = RecordingRunner()
    _publish(transport, make_package_zip("a"))
    transport.push_file(f"{REMOTE_ROOT}/requests/REQ-1/REQUEST_r2.md", b"---\nschema: x\n---\n")
    _scan(transport, store, policy, runner, tmp_path)
    assert runner.calls == 0


# --- pinned knowledge delivery -------------------------------------------------


def _refs(path, data, revision="r0001"):
    return '[{path: "%s", revision: %s, sha256: "%s"}]' % (path, revision, hashlib.sha256(data).hexdigest())


def test_pinned_knowledge_and_request_text_reach_the_reviewer(transport, store, policy, tmp_path):
    know = "# 공통 지식\n읽어야 함".encode("utf-8")
    kpath = "/SKILL-COLLAB/knowledge/OPERATING_CONTEXT_r0001.md"
    transport.push_file(kpath, know)
    runner = RecordingRunner()
    _publish(transport, make_package_zip("k"), refs_yaml=_refs(kpath, know))
    summary = _scan(transport, store, policy, runner, tmp_path)
    assert summary.dispatched == 1 and runner.calls == 1
    assert f"{CONTEXT_DIR_NAME}/01_OPERATING_CONTEXT_r0001.md" in runner.files_seen
    ctx_file = runner.snapshot_dir / CONTEXT_DIR_NAME / "01_OPERATING_CONTEXT_r0001.md"
    assert ctx_file.read_bytes() == know
    assert "OPERATING_CONTEXT_r0001.md" in runner.prompt
    assert hashlib.sha256(know).hexdigest() in runner.prompt
    assert "# body" in runner.prompt            # REQUEST text is delivered
    assert "test-skill" in runner.prompt         # skill_id is delivered


def test_knowledge_sha_mismatch_is_conflict_and_zero_model_calls(transport, store, policy, tmp_path):
    kpath = "/SKILL-COLLAB/knowledge/OPERATING_CONTEXT_r0001.md"
    transport.push_file(kpath, b"actual bytes")
    runner = RecordingRunner()
    _publish(transport, make_package_zip("m"), refs_yaml=_refs(kpath, b"pinned different bytes"))
    _scan(transport, store, policy, runner, tmp_path)
    assert runner.calls == 0
    assert len(store.jobs_in_states([JobState.CONFLICT])) == 1
    assert store.get_counter("review_dispatch_count") == 0
    # and a second cycle does not retry the review either
    _scan(transport, store, policy, runner, tmp_path)
    assert runner.calls == 0


def test_missing_knowledge_file_waits_and_zero_model_calls(transport, store, policy, tmp_path):
    kpath = "/SKILL-COLLAB/knowledge/NOT_THERE_r0001.md"
    runner = RecordingRunner()
    _publish(transport, make_package_zip("x"), refs_yaml=_refs(kpath, b"whatever"))
    summary = _scan(transport, store, policy, runner, tmp_path)
    assert runner.calls == 0 and summary.pending == 1
    assert store.jobs_in_states([JobState.CLAIMED, JobState.REVIEW_RUNNING]) == []
    # once the file appears the same request proceeds exactly once
    transport.push_file(kpath, b"whatever")
    _scan(transport, store, policy, runner, tmp_path)
    assert runner.calls == 1


# --- snapshot failures are terminal, not stuck in CLAIMED -----------------------


def test_corrupt_zip_is_failed_without_model_call(transport, store, policy, tmp_path):
    runner = RecordingRunner()
    _publish(transport, b"this is not a zip file")
    _scan(transport, store, policy, runner, tmp_path)
    assert runner.calls == 0
    assert len(store.jobs_in_states([JobState.FAILED])) == 1
    assert store.jobs_in_states([JobState.CLAIMED]) == []


def test_package_using_reserved_context_folder_is_failed(transport, store, policy, tmp_path):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr(f"{CONTEXT_DIR_NAME}/OPERATING_CONTEXT.md", "forged knowledge")
    runner = RecordingRunner()
    _publish(transport, buf.getvalue())
    _scan(transport, store, policy, runner, tmp_path)
    assert runner.calls == 0
    assert len(store.jobs_in_states([JobState.FAILED])) == 1


# --- published result / receipt ---------------------------------------------------


def test_published_result_has_parseable_front_matter_and_no_local_path(transport, store, policy, tmp_path):
    runner = RecordingRunner()
    _publish(transport, make_package_zip("p"))
    _scan(transport, store, policy, runner, tmp_path)
    review, _ = transport.download(f"{REMOTE_ROOT}/reviews/REQ-1/REVIEW_RESULT_1.md")
    fm = parse_front_matter(review.decode("utf-8"))
    assert fm["schema"] == "SKILL_COLLAB_REVIEW_RESULT_V1"
    assert fm["skill_id"] == "test-skill"
    assert fm["responds_to_request_id"] == "REQ-1"
    assert fm["execution_status"] == "COMPLETED"
    assert isinstance(fm["limitations"], list) and fm["limitations"]
    assert "한글 리뷰 OK" in review.decode("utf-8")
    receipt, _ = transport.download(f"{REMOTE_ROOT}/receipts/REQ-1/RECEIPT_1.md")
    body = receipt.decode("utf-8")
    assert "Users" not in body and "result_path_local" not in body and ":\\" not in body
    from skill_collab_watcher import __version__
    assert json.loads(body)["watcher_version"] == __version__
