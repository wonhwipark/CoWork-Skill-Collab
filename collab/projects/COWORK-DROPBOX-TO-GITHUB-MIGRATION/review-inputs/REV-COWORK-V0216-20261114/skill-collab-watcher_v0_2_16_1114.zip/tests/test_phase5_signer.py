"""The approver-device signing tool, end to end with real Ed25519 and throw-away keys.
Skipped (= NOT_RUN) when `cryptography` is not installed."""
from __future__ import annotations

import base64
import hashlib
import json
from datetime import datetime, timedelta, timezone

import pytest

pytest.importorskip("cryptography")

from bundle import ROOT, make_transport  # noqa: E402
from conftest import make_package_zip, ready_md, request_md  # noqa: E402
from fake_github import FakeGitHub, rp  # noqa: E402
from skill_collab_watcher.approval import load_trust_root  # noqa: E402
from skill_collab_watcher.models import JobState  # noqa: E402
from skill_collab_watcher.orchestrator import run_scan_cycle  # noqa: E402
from skill_collab_watcher.signature_backend import Ed25519Backend  # noqa: E402
from skill_collab_watcher.validator import LocalPolicy  # noqa: E402
from tools import approval_signer, trust_root_tool  # noqa: E402

REPO = "repo-id-synthetic"
KEY = "signer-key-1"


class Kit:
    def __init__(self, tmp_path, revision=1):
        self.tmp = tmp_path
        self.package = make_package_zip("signer")
        self.package_sha = hashlib.sha256(self.package).hexdigest()
        self.request = request_md(request_revision=revision, package_sha256=self.package_sha,
                                  package_size=len(self.package)).encode("utf-8")
        self.ready = ready_md(hashlib.sha256(self.request).hexdigest(), self.package_sha,
                              request_revision=revision).encode("utf-8")
        for name, data in (("REQUEST.md", self.request), ("READY.md", self.ready), ("test.zip", self.package)):
            (tmp_path / name).write_bytes(data)
        self.private, self.public = tmp_path / "approver.key", tmp_path / "approver.pub"
        assert approval_signer.main(["keygen", "--out-private", str(self.private), "--out-public", str(self.public), "--allow-plaintext-key"]) == 0
        self.root = tmp_path / "trust_root.json"
        assert trust_root_tool.main(["build", "--repo-id", REPO, "--out", str(self.root), "--version", "1",
                                     "--key", f"{KEY}:{self.public.read_text().strip()}"]) == 0
        self.out = tmp_path / "out"

    def sign(self, **override):
        args = {"private-key": str(self.private), "key-id": KEY, "repo-id": REPO, "request": str(self.tmp / "REQUEST.md"),
                "ready": str(self.tmp / "READY.md"), "package": str(self.tmp / "test.zip"),
                "package-path": "/SKILL-COLLAB/packages/test.zip", "source-commit": "a" * 40,
                "policy-revision": "1", "out-dir": str(self.out)}
        args.update(override)
        argv = ["sign"]
        for k, v in args.items():
            argv += [f"--{k}", str(v)]
        return approval_signer.main(argv)

    def check(self, **override):
        args = {"trust-root": str(self.root), "approval": str(self.out / "APPROVAL_SIG.json"),
                "pin": str(self.out / "SOURCE_PIN.json"), "request": str(self.tmp / "REQUEST.md"),
                "ready": str(self.tmp / "READY.md"), "package": str(self.tmp / "test.zip"),
                "package-path": "/SKILL-COLLAB/packages/test.zip", "policy-revision": "1"}
        args.update(override)
        argv = ["check"]
        for k, v in args.items():
            argv += [f"--{k}", str(v)]
        return approval_signer.main(argv)


@pytest.fixture
def kit(tmp_path):
    return Kit(tmp_path)


def test_keygen_prints_only_public_facts_and_never_overwrites(tmp_path, capsys):
    out_private, out_public = tmp_path / "k.key", tmp_path / "k.pub"
    assert approval_signer.main(["keygen", "--out-private", str(out_private), "--out-public", str(out_public), "--allow-plaintext-key"]) == 0
    printed = capsys.readouterr().out
    private_b64 = out_private.read_text().strip()
    assert private_b64 not in printed and private_b64 not in out_public.read_text()
    assert len(base64.b64decode(private_b64)) == 32 and len(base64.b64decode(out_public.read_text().strip())) == 32
    before = out_private.read_bytes()
    assert approval_signer.main(["keygen", "--out-private", str(out_private), "--out-public", str(tmp_path / "x.pub"), "--allow-plaintext-key"]) == 2
    assert out_private.read_bytes() == before and not (tmp_path / "x.pub").exists()


def test_a_signed_approval_is_accepted_by_the_offline_check(kit, capsys):
    assert kit.sign() == 0
    assert kit.check() == 0
    assert "OK" in capsys.readouterr().out


def test_the_private_key_never_appears_in_the_output_or_the_signed_files(kit, capsys):
    kit.sign()
    private_b64 = kit.private.read_text().strip()
    captured = capsys.readouterr()
    assert private_b64 not in captured.out + captured.err
    assert all(private_b64 not in (kit.out / n).read_text() for n in ("APPROVAL_SIG.json", "SOURCE_PIN.json"))


def test_signing_never_overwrites_an_existing_approval(kit):
    assert kit.sign() == 0
    before = (kit.out / "APPROVAL_SIG.json").read_bytes()
    assert kit.sign() == 2
    assert (kit.out / "APPROVAL_SIG.json").read_bytes() == before


@pytest.mark.parametrize("override", [
    {"source-commit": "short"}, {"source-commit": "A" * 40}, {"valid-hours": "0"}, {"valid-hours": "169"},
    {"package-path": "/SKILL-COLLAB/packages/other.zip"}, {"private-key": "missing.key"},
])
def test_sign_refuses_bad_inputs_and_writes_nothing(kit, override):
    assert kit.sign(**override) == 2
    assert not kit.out.exists() or not list(kit.out.glob("*.json"))


def test_sign_refuses_a_package_that_does_not_match_the_request(kit):
    (kit.tmp / "test.zip").write_bytes(make_package_zip("tampered"))
    assert kit.sign() == 2


def test_the_offline_check_catches_changes_made_after_signing(kit, capsys):
    kit.sign()
    (kit.tmp / "READY.md").write_bytes(kit.ready + b"\n")
    assert kit.check() == 1
    assert "BINDING_MISMATCH:ready_sha256" in capsys.readouterr().out
    (kit.tmp / "READY.md").write_bytes(kit.ready)
    assert kit.check(**{"policy-revision": "2"}) == 1
    assert "BINDING_MISMATCH:local_policy_revision" in capsys.readouterr().out


def test_the_offline_check_rejects_a_different_signers_key(kit, tmp_path, capsys):
    kit.sign()
    other = tmp_path / "other"
    other.mkdir()
    assert approval_signer.main(["keygen", "--out-private", str(other / "o.key"), "--out-public", str(other / "o.pub"), "--allow-plaintext-key"]) == 0
    root = other / "root.json"
    assert trust_root_tool.main(["build", "--repo-id", REPO, "--out", str(root), "--version", "1",
                                 "--key", f"{KEY}:{(other / 'o.pub').read_text().strip()}"]) == 0
    assert kit.check(**{"trust-root": str(root)}) == 1
    assert "BAD_SIGNATURE" in capsys.readouterr().out


def test_the_signature_is_over_the_canonical_payload_the_watcher_verifies(kit):
    kit.sign()
    approval = json.loads((kit.out / "APPROVAL_SIG.json").read_text())
    payload = approval["payload"]
    assert payload["request_sha256"] == hashlib.sha256(kit.request).hexdigest()
    assert payload["ready_sha256"] == hashlib.sha256(kit.ready).hexdigest()
    assert payload["package_sha256"] == kit.package_sha and payload["source_commit"] == "a" * 40
    assert len(payload["nonce"]) >= 16
    issued, expires = (datetime.fromisoformat(payload[k]) for k in ("issued_at", "expires_at"))
    assert timedelta(hours=11) < expires - issued <= timedelta(hours=12)


def test_two_approvals_never_share_a_nonce(kit, tmp_path):
    kit.sign()
    first = json.loads((kit.out / "APPROVAL_SIG.json").read_text())["payload"]["nonce"]
    kit.out = tmp_path / "out2"
    kit.sign()
    assert json.loads((kit.out / "APPROVAL_SIG.json").read_text())["payload"]["nonce"] != first


def test_the_signers_output_dispatches_exactly_one_review_through_the_whole_watcher(kit, tmp_path):
    """Commit A holds REQUEST and package; the tool signs against that commit; commit B holds READY, approval
    and pin. The watcher, with the trust root the tool built, runs the review once and never again."""
    http = FakeGitHub()
    commit_a = http.commit({rp("requests/REQ-1/REQUEST.md"): kit.request, rp("packages/test.zip"): kit.package})
    assert kit.sign(**{"source-commit": commit_a}) == 0
    http.commit({rp("requests/REQ-1/READY.md"): kit.ready,
                 rp("requests/REQ-1/APPROVAL_SIG.json"): (kit.out / "APPROVAL_SIG.json").read_bytes(),
                 rp("requests/REQ-1/SOURCE_PIN.json"): (kit.out / "SOURCE_PIN.json").read_bytes()})
    from skill_collab_watcher.fake_runner import FakeReviewRunner

    store_dir = tmp_path / "state"
    store_dir.mkdir()
    from skill_collab_watcher.state_store import StateStore

    store, runner = StateStore(store_dir / "s.sqlite3"), FakeReviewRunner()
    policy = LocalPolicy(active_baseline_id="TEST-BASELINE-0001", local_policy_revision="1",
                         known_run_policy_refs=["POLICY-STATIC-V1"], require_approval=True,
                         trust_root=load_trust_root(str(kit.root)), signature_backend=Ed25519Backend())
    (tmp_path / "snap").mkdir()
    (tmp_path / "runs").mkdir()
    for _ in range(2):
        run_scan_cycle(make_transport(http), store, policy, runner, allowed=True,
                       snapshot_root=tmp_path / "snap", review_run_dir=tmp_path / "runs", remote_root="/SKILL-COLLAB")
    assert runner.calls == 1
    assert store.jobs_in_states([JobState.COMPLETED])
    store.close()
