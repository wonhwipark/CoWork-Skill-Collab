# 1차 독립 설계 리뷰 — 평가 범위
동일 Work의 최신 결정 ①~④를 비판적으로 검토. 요청 범위: 문서 설계, 운영/호스트/업무 스킬 E2E 불포함.
R01: 그룹과 개인 지식 폴더의 물리 경로 1:1 재사용·초안/정본 분리가 일관적인가?
R02: Kernel export/index/root README와 knowledge/의 공존, 인덱스 오염·경로 훼손 위험은?
R03: Workflow Bootstrap + 공통 writer 실제 경로 차단이 모든 변경 경로를 커버하는가? 호출자 신뢰는?
R04: 한 clone에서 Workflow docs_sync dirty guard와 Updater commit/push의 경쟁, CAS/lock은?
R05: Work optional 정책과 Work/Evidence 원본 연결, 지식 경로 식별자·N:M 링크의 정합성은?
R06: 최초 그룹 동기화의 Base commit + content hash 보존/동기화 상태가 충분한가?
R07: 3-way 병합은 텍스트상 비중첩이어도 의미상 위험할 수 있다. 허용 병합/사용자 승인 기준은?
R08: Preview 후 다른 담당자가 재수정하면 어떻게 막는가? group writer의 compare-and-swap 필요성.
R09: 게시 성공/readback, 개인 상태 실패, Work 링크 실패, 응답 유실 시 중복 게시 없이 정산 가능한가?
R10: 이미 있는 Kernel/Git/Workflow 기능 REUSE vs 입증된 최소 EXTEND를 구분했는가?
R11: 숨은 배포·권한·정보분류 위험, 과도한 엔진/스키마 확장 위험을 지적해 줘.
각 항목: 근거/판정/심각도/최소 수정/담당 스킬/검증 사례. 인위적인 결함 개수 강제 0.
결론 ACCEPT / ACCEPT_WITH_CHANGE / REVISE / HOLD. 구현 완료·유료 리뷰 추가·코드 수정은 주장 금지.
