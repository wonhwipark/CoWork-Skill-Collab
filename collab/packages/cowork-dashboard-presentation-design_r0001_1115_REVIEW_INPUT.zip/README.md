# Presentation dashboard design review input

비민감 CoWork 설계 리뷰용. 설치 스킬/배포 후보 아님. DESIGN.md → EVIDENCE.md → REVIEW_QUESTIONS.md 순서. source/는 근거 정적 snapshot이며 실행 금지. 입력 동결 이후 다른 요청/운영을 변경하지 않음.
