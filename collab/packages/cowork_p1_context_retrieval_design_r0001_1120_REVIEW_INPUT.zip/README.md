# CoWork P1 REVIEW INPUT — immutable candidate
- Read 01_DESIGN.md and 02_REVIEW_QUESTIONS.md.
- 03_SOURCE_MANIFEST.json pins GitHub source commit and exact file hashes.
- This ZIP is a PRIVATE review-input candidate, NOT an operational skill ZIP or approved request.
- Do not execute scripts or access business host/sources.
- User requested ONE independent design review; any actual REQUEST, protected signature, READY and watcher execution require LIVE prepublication policy validation.
