# 독립 설계 리뷰 가이드 r0001
2026-11-28 KST / REQ-L1-VIEWER-SKILL-MANAGEMENT-DESIGN-R1-20261128
- 대상: Viewer 운영 관리 안의 Skill Management 읽기 전용 통합 설계
- 유효 입력: 상세 설계 r0001, Source Map Viewer v0.5.8 인계, Job-list r0004, CoWork 카탈로그
- 반드시 확인: v0.5.8 전체 ZIP 실제 함수 및 Linux 호스트 원문이 이 패키지에 포함되지 않음. 실제 API 존재 여부는 G0 미검증
- 핵심 질문: 기존 Viewer/Job-list/Updater/Kernel/MCP 기능 중복 여부; 실제 운영 상태의 근거 분리; read adapter 최소 구현; 인증/ACL; stale/충돌/서로 다른 호스트; G0 선결, SM-01~20 검증성
- 견적 및 범위: UI+read projection 우선, Collector/DB/새 execution API 금지. 추가 Linux 스킬 호출/설치/업무 소스 열람 금지
- 리뷰 출력: ACCEPT/ACCEPT_WITH_CHANGE/REVISE/HOLD, BLOCKING/MAJOR/MINOR별 절 번호·반례·최소 수정·담당·수락시험
- 결과/영수증을 동일 RID에 한 번 기록. 동일 입력 중복 실행·자동 R2·모델 재시도 금지.
