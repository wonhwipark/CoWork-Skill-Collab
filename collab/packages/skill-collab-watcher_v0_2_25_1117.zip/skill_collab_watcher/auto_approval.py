"""Bounded automatic approval (v0.2.21, development_not_for_deployment).

A REQUEST that GPT publishes to the PRIVATE repository gets an APPROVAL_SIG.json and a READY.md from THIS watcher, but only inside a delegation that
the user stored in a PROTECTED local file (AUTO_DELEGATION_V1, default enabled=false). Nothing in GitHub can enable it, widen it or extend it.

What this module never does: start a review (the unchanged READY checks, the N1 remote reservation and the single model call stay in the
orchestrator), change a key, a trust root, a ceiling or a policy, or retry blindly. Every doubt stops with an event; a stop after the local
reservation is final until a human looks (SIGNING_UNCERTAIN)."""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import math
import re
import sys
import tempfile
import threading
import time
import zipfile
from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone
from pathlib import Path

from . import auto_policy
from .approval import ApprovalRejected, NotConfigured, check_clock, verify_approval
from .transport_base import AuthRequired, RemoteNotFound, TransportError, UploadConflict
from .validator import SAFE_NAME, ValidationOutcome, parse_front_matter, validate
from .zip_safety import UnsafeZip, package_secret_findings, safe_extract

DELEGATION_SCHEMA = "AUTO_DELEGATION_V1"
KST = timezone(timedelta(hours=9))
PIN_SCHEMA = "SKILL_COLLAB_SOURCE_PIN_V1"
MAX_PACKAGE_BYTES = 5 * 1024 * 1024         # a review input, never a deployment: a bigger package is not eligible for automatic approval


# ---- settings ---------------------------------------------------------------------------------------------------------------------------


@dataclass
class AutoSettings:
    delegation_file: Path
    valid_hours: int = 2
    acl_check: str = "windows"                      # windows | skip  (skip exists for isolated tests only and is printed by config-check)
    signer: dict | None = None
    race_retries: int = 2

    @classmethod
    def from_config(cls, section) -> "AutoSettings":
        if not isinstance(section, dict) or not isinstance(section.get("delegation_file"), str) or not section["delegation_file"].strip():
            raise ValueError("auto_approval needs a delegation_file path")
        hours = section.get("valid_hours", 2)
        if isinstance(hours, bool) or not isinstance(hours, int) or not 1 <= hours <= 12:
            raise ValueError("auto_approval.valid_hours must be an integer from 1 to 12")
        acl = section.get("acl_check", "windows")
        if acl not in ("windows", "skip"):
            raise ValueError("auto_approval.acl_check must be windows or skip")
        signer = section.get("signer")
        if signer is not None and not isinstance(signer, dict):
            raise ValueError("auto_approval.signer must be an object")
        return cls(Path(section["delegation_file"]), hours, acl, signer)


def describe_for_config_check(section) -> list[str]:
    """Lines for `config-check`: never a path of a secret, never a key value."""
    try:
        s = AutoSettings.from_config(section)
    except ValueError as exc:
        return [f"auto_approval: INVALID CONFIG ({exc})"]
    lines = [f"auto_approval: configured; acl_check={s.acl_check}; valid_hours={s.valid_hours}"]
    if s.acl_check == "skip":
        lines.append("auto_approval: WARNING acl_check=skip is for isolated tests only")
    d, reason = load_delegation(s.delegation_file, time.time(), s.acl_check)
    if d is None:
        lines.append(f"auto_approval: delegation not usable ({reason}) -> AUTO_SIGNING stays OFF")
    else:
        lines.append(f"auto_approval: delegation file readable; enabled={d.enabled}; projects={len(d.projects)}; skills={len(d.skills)}; "
                     f"limit: per review {d.max_request_cents} c; no daily/monthly aggregate limits")
    lines.append(f"auto_approval: signer {'configured' if s.signer else 'NOT configured -> nothing can be signed'}")
    return lines


# ---- the protected local delegation -----------------------------------------------------------------------------------------------------


# Access-mask bits that let a principal change a file or its permissions (FILE_WRITE_DATA, FILE_APPEND_DATA, FILE_WRITE_EA, FILE_DELETE_CHILD,
# FILE_WRITE_ATTRIBUTES, DELETE, WRITE_DAC, WRITE_OWNER, GENERIC_ALL, GENERIC_WRITE).
_WRITE_MASK = 0x2 | 0x4 | 0x10 | 0x40 | 0x100 | 0x10000 | 0x40000 | 0x80000 | 0x10000000 | 0x40000000
_BROAD_SIDS = {"S-1-1-0": "Everyone", "S-1-5-32-545": "Users", "S-1-5-11": "Authenticated Users", "S-1-5-32-546": "Guests", "S-1-5-7": "Anonymous"}


def aces_allow_broad_write(aces) -> bool:
    """aces: iterable of (ace_type, sid_string, access_mask). True when a broad group is ALLOWED a write-capable right. Deny entries are ignored
    on purpose (a file is only called protected when no broad group is allowed to write at all)."""
    return any(ace_type == 0 and sid in _BROAD_SIDS and (mask & _WRITE_MASK) for ace_type, sid, mask in aces)


def read_dacl(path: Path):
    """The DACL of a file or folder as (ace_type, sid_string, access_mask) tuples, through the Win32 API (no external process, SID based so it works
    on any Windows language). Raises OSError when it cannot be read."""
    import ctypes
    from ctypes import wintypes

    adv, k32 = ctypes.WinDLL("advapi32", use_last_error=True), ctypes.WinDLL("kernel32", use_last_error=True)
    adv.GetNamedSecurityInfoW.argtypes = [wintypes.LPWSTR, ctypes.c_int, wintypes.DWORD, ctypes.c_void_p, ctypes.c_void_p,
                                          ctypes.POINTER(ctypes.c_void_p), ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
    adv.GetNamedSecurityInfoW.restype = wintypes.DWORD
    adv.GetAclInformation.argtypes = [ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.c_int]
    adv.GetAce.argtypes = [ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(ctypes.c_void_p)]
    adv.ConvertSidToStringSidW.argtypes = [ctypes.c_void_p, ctypes.POINTER(wintypes.LPWSTR)]
    k32.LocalFree.argtypes = [ctypes.c_void_p]

    class _AclSize(ctypes.Structure):
        _fields_ = [("AceCount", wintypes.DWORD), ("AclBytesInUse", wintypes.DWORD), ("AclBytesFree", wintypes.DWORD)]

    dacl, sd = ctypes.c_void_p(), ctypes.c_void_p()
    rc = adv.GetNamedSecurityInfoW(str(path), 1, 4, None, None, ctypes.byref(dacl), None, ctypes.byref(sd))   # SE_FILE_OBJECT, DACL_SECURITY_INFORMATION
    if rc != 0:
        raise OSError(f"GetNamedSecurityInfo failed ({rc})")
    try:
        if not dacl.value:
            return [(0, "S-1-1-0", 0x10000000)]                       # a NULL DACL grants everyone everything
        info = _AclSize()
        if not adv.GetAclInformation(dacl, ctypes.byref(info), ctypes.sizeof(info), 2):
            raise OSError("GetAclInformation failed")
        out = []
        for i in range(info.AceCount):
            ace = ctypes.c_void_p()
            if not adv.GetAce(dacl, i, ctypes.byref(ace)):
                raise OSError("GetAce failed")
            ace_type = ctypes.c_ubyte.from_address(ace.value).value
            mask = ctypes.c_uint32.from_address(ace.value + 4).value
            sid_text = wintypes.LPWSTR()
            if not adv.ConvertSidToStringSidW(ace.value + 8, ctypes.byref(sid_text)):
                raise OSError("ConvertSidToStringSid failed")
            try:
                out.append((ace_type, sid_text.value, mask))
            finally:
                k32.LocalFree(ctypes.cast(sid_text, ctypes.c_void_p))
        return out
    finally:
        k32.LocalFree(sd)


def windows_acl_ok(path: Path) -> tuple[bool, str]:
    """The delegation file AND its folder must not be writable by broad groups (Everyone, Users, Authenticated Users, Guests, Anonymous).
    Fail closed: when the ACL cannot be read, the file is not protected."""
    if sys.platform != "win32":
        return False, "ACL_CHECK_UNSUPPORTED_PLATFORM"
    try:
        for target in (path, path.parent):
            if aces_allow_broad_write(read_dacl(target)):
                return False, "ACL_BROAD_WRITE"
    except OSError:
        return False, "ACL_UNREADABLE"
    return True, "ok"


def project_scope(d, project: str):
    """The delegation as it applies to one project: an exact listed project, or a project that continues an owner-listed family prefix. The copy
    returned for a family match only adds THIS verified project to the set the gate checks."""
    if not project:
        return None
    if project in d.projects:
        return d
    if any(project.startswith(f) and len(project) > len(f) for f in getattr(d, "families", ())):
        return replace(d, projects=d.projects | {project})
    return None


def _iso(value, name):
    try:
        t = datetime.fromisoformat(str(value))
    except ValueError as exc:
        raise ValueError(f"{name} is not an ISO time") from exc
    if t.tzinfo is None:
        raise ValueError(f"{name} has no time zone")
    return int(t.timestamp())


def _cents(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be a finite positive number")
    return int(round(float(value) * 100))


@dataclass(frozen=True)
class Scope(auto_policy.Delegation):
    """The gate's Delegation plus the owner's explicit project families (prefixes). Only the scope helpers read `families`."""
    families: frozenset = frozenset()


_FAMILY = re.compile(r"[A-Za-z][A-Za-z0-9]*(?:-[A-Za-z0-9]+)*-")


def _families(raw) -> frozenset:
    """Owner-listed project families: words separated by '-' and ending with '-', at least 7 characters ("COWORK-" is the shortest approved
    family). No wildcard, no spaces, no leading dash, no bare word. Anything else makes the whole delegation unusable."""
    value = raw.get("project_families", [])
    if not isinstance(value, list) or not all(isinstance(x, str) for x in value):
        raise ValueError("project_families must be a list of strings")
    for x in value:
        if len(x) < 7 or _FAMILY.fullmatch(x) is None:
            raise ValueError("a project family is a word-and-dash prefix ending with '-', at least 7 characters, with no wildcard or spaces")
    return frozenset(value)


def load_delegation(path: Path, now: float, acl_check: str = "windows"):
    """(Delegation | None, reason). None means: nothing may be signed. A disabled delegation is returned as such (enabled=False)."""
    try:
        if acl_check == "windows":
            ok, why = windows_acl_ok(path)
            if not ok:
                return None, why
        raw = json.loads(Path(path).read_text(encoding="utf-8-sig"))
        if not isinstance(raw, dict) or raw.get("schema") != DELEGATION_SCHEMA:
            return None, "POLICY_SCHEMA"
        enabled = raw.get("enabled")
        if not isinstance(enabled, bool):
            return None, "POLICY_ENABLED_NOT_BOOLEAN"
        projects, skills = raw.get("projects"), raw.get("skills")
        if not (isinstance(projects, list) and isinstance(skills, list) and all(isinstance(x, str) and x for x in projects + skills)):
            return None, "POLICY_SCOPE_FORMAT"
        if raw.get("policy", "POLICY-STATIC-V1") != "POLICY-STATIC-V1":
            return None, "POLICY_NOT_STATIC_V1"
        families = _families(raw)
        d = Scope(
            enabled=enabled, repo_id=str(raw["repo_id"]), branch=str(raw["branch"]), projects=frozenset(projects), skills=frozenset(skills),
            expires_at=_iso(raw["expires_at"], "expires_at"), earliest_request_at=_iso(raw["enabled_at"], "enabled_at"),
            max_request_cents=_cents(raw.get("max_request_usd", 1.5), "max_request_usd"), max_day_calls=0,
            max_day_cents=0, max_month_cents=0,  # old day/month keys ignored
            families=families)
        return d, "ok"
    except (OSError, ValueError, KeyError, TypeError):
        return None, "POLICY_UNREADABLE"


# ---- the existing signer, called as a library -------------------------------------------------------------------------------------------


def dpapi_passphrase_provider(blob_file: Path, entropy: bytes):
    """The passphrase of the encrypted approver key exists only as a Windows DPAPI blob bound to THIS account (the existing host design)."""
    import ctypes
    from ctypes import wintypes

    class _Blob(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]

    def make(data):
        buf = ctypes.create_string_buffer(data, len(data))
        return _Blob(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte))), buf

    def ask(_prompt: str) -> str:
        crypt32, kernel32 = ctypes.WinDLL("crypt32", use_last_error=True), ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.LocalFree.argtypes = [ctypes.c_void_p]
        inb, k1 = make(Path(blob_file).read_bytes())
        ent, k2 = make(entropy)
        out = _Blob()
        if not crypt32.CryptUnprotectData(ctypes.byref(inb), None, ctypes.byref(ent), None, None, 1, ctypes.byref(out)):
            raise OSError("DPAPI could not open the passphrase blob")
        try:
            return ctypes.string_at(out.pbData, out.cbData).decode("utf-8")
        finally:
            kernel32.LocalFree(ctypes.cast(out.pbData, ctypes.c_void_p))
    return ask


class ToolSigner:
    """The existing `tools.approval_signer` (the same code the host used for every approval so far), called in-process. The private key file
    stays where it is; nothing is copied, no key or passphrase is returned, logged or put in a message."""
    _lock = threading.Lock()

    def __init__(self, private_key_file, key_id: str, repo_id: str, passphrase_provider=None, allow_plaintext_key: bool = False):
        self.private_key_file, self.key_id, self.repo_id = Path(private_key_file), key_id, str(repo_id)
        self.passphrase_provider, self.allow_plaintext_key = passphrase_provider, allow_plaintext_key

    @classmethod
    def from_config(cls, cfg: dict) -> "ToolSigner":
        provider = None
        if cfg.get("passphrase_dpapi_file"):
            provider = dpapi_passphrase_provider(Path(cfg["passphrase_dpapi_file"]), str(cfg.get("dpapi_entropy", "cowork-approver-v1")).encode())
        return cls(cfg["private_key_file"], cfg["key_id"], cfg["repo_id"], provider, bool(cfg.get("allow_plaintext_key", False)))

    @staticmethod
    def _tool():
        root = Path(__file__).resolve().parents[1]
        if str(root) not in sys.path:
            sys.path.insert(0, str(root))
        from tools import approval_signer
        return approval_signer

    def trusts_key(self, trust_root) -> bool:
        key = getattr(trust_root, "keys", {}).get(self.key_id) if trust_root is not None else None
        return key is not None and getattr(key, "status", None) == "ACTIVE"

    def sign(self, request_raw: bytes, ready_raw: bytes, package_raw: bytes, package_path: str, source_commit: str, policy_revision: str,
             valid_hours: int) -> bytes:
        """APPROVAL_SIG.json bytes bound to exactly these request/READY/package bytes (the signed payload carries ready_sha256)."""
        tool = self._tool()
        header = self.private_key_file.read_text(encoding="ascii").splitlines()[0] if self.private_key_file.exists() else ""
        encrypted = header.startswith(tool.ENC_HEADER)
        if encrypted and self.passphrase_provider is None:
            raise PermissionError("the key is encrypted and no passphrase provider is configured")
        if not encrypted and not self.allow_plaintext_key:
            raise PermissionError("a plaintext key is refused")
        with self._lock, tempfile.TemporaryDirectory(prefix="auto_sign_") as tmp:
            tmp = Path(tmp)
            (tmp / "REQUEST.md").write_bytes(request_raw)
            (tmp / "READY.md").write_bytes(ready_raw)
            (tmp / "package.zip").write_bytes(package_raw)
            old_ask = tool._ask
            if self.passphrase_provider is not None:
                tool._ask = self.passphrase_provider
            try:
                with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                    rc = tool.main(["sign", "--private-key", str(self.private_key_file), "--key-id", self.key_id, "--repo-id", self.repo_id,
                                    "--request", str(tmp / "REQUEST.md"), "--ready", str(tmp / "READY.md"), "--package", str(tmp / "package.zip"),
                                    "--package-path", package_path, "--source-commit", source_commit, "--policy-revision", str(policy_revision),
                                    "--out-dir", str(tmp / "out"), "--valid-hours", str(valid_hours)])
            finally:
                tool._ask = old_ask
            if rc != 0:
                raise RuntimeError("the signer refused")
            return (tmp / "out" / "APPROVAL_SIG.json").read_bytes()

    def verify(self, approval_raw: bytes, pin_raw: bytes, request_raw: bytes, ready_raw: bytes, package_raw: bytes, package_path: str,
               policy_revision: str, trust_root, backend) -> None:
        """The same checks the watcher makes (the signer tool's own `expected_fields` + the watcher's verify_approval). Raises on any failure."""
        tool = self._tool()
        with tempfile.TemporaryDirectory(prefix="auto_check_") as tmp:
            tmp = Path(tmp)
            (tmp / "REQUEST.md").write_bytes(request_raw)
            (tmp / "READY.md").write_bytes(ready_raw)
            (tmp / "package.zip").write_bytes(package_raw)
            expected = tool.expected_fields(tmp / "REQUEST.md", tmp / "READY.md", tmp / "package.zip", package_path, policy_revision)
            verify_approval(approval_raw, pin_raw, trust=trust_root, backend=backend, expected=expected, now=datetime.now(timezone.utc))


# ---- the approver ----------------------------------------------------------------------------------------------------------------------


@dataclass
class AutoResult:
    status: str
    detail: str = ""


def _kst_keys(now: float) -> tuple[str, str]:
    t = datetime.fromtimestamp(now, KST)
    return t.strftime("%Y-%m-%d"), t.strftime("%Y-%m")


def _ready_text(rid: str, rev: str, request_sha: str, package_sha: str, baseline: str) -> str:
    return (f"---\nschema: SKILL_COLLAB_READY_V1\nstate: READY\nrequest_id: {rid}\nrequest_revision: {rev}\n"
            f"request_path: /SKILL-COLLAB/requests/{rid}/REQUEST.md\nrequest_sha256: {request_sha}\npackage_sha256: {package_sha}\n"
            f"baseline_id: {baseline}\n---\n\n# ready\n")


class AutoApprover:
    # Requests being handled by ANY approver object of this process. A second call for the same request while the first is still between its
    # reservation and its publications must not treat the reservation as a crashed attempt and sign again. Across processes the single-instance
    # watcher lock already serialises the work, and a restart after a crash clears this set.
    _in_progress: set = set()
    _guard = threading.Lock()

    def __init__(self, settings: AutoSettings, store, signer=None, now_fn=time.time, sleep=time.sleep):
        self.s, self.store, self.now_fn, self.sleep = settings, store, now_fn, sleep
        self.signer = signer if signer is not None else (ToolSigner.from_config(settings.signer) if settings.signer else None)
        store.ensure_auto_tables()

    # -- events --
    def _once(self, event, key, detail):
        self.store.log_event_once(event, processing_key=key, detail=detail)

    def _event(self, event, key, detail):
        self.store.log_event(event, processing_key=key, detail=detail)

    # -- remote helpers --
    def _exists(self, transport, path) -> bool:
        return transport.get_metadata(path) is not None

    def _post_create_only(self, transport, path: str, data: bytes) -> str:
        """POSTED | EXISTS_SAME | EXISTS_DIFFERENT | ABSENT_AFTER_RACES | ERROR. A branch-head race (the file is not there after a conflict) is retried a
        bounded number of times; anything else is a stop."""
        for attempt in range(self.s.race_retries + 1):
            try:
                transport.upload(path, data, mode="add")
            except UploadConflict:
                try:
                    back = transport.download_latest(path)[0]
                except RemoteNotFound:
                    self.sleep(0.4 * (attempt + 1))
                    continue
                except (TransportError, AuthRequired):
                    return "ERROR"
                return "EXISTS_SAME" if back == data else "EXISTS_DIFFERENT"
            except (TransportError, AuthRequired):
                try:                                                   # maybe it was written and only the answer was lost
                    return "POSTED" if transport.download_latest(path)[0] == data else "ERROR"
                except (TransportError, AuthRequired):
                    return "ERROR"
            try:
                return "POSTED" if transport.download_latest(path)[0] == data else "EXISTS_DIFFERENT"
            except (TransportError, AuthRequired):
                return "ERROR"
        return "ABSENT_AFTER_RACES"

    # -- the entry point --
    def process(self, transport, store, policy, remote_root: str, request_id: str, request_text: str, request_raw: bytes) -> AutoResult:
        self.store = store                                             # always the store of the cycle in progress (it is replaced on a restart)
        if store.read_only:
            return AutoResult("READ_ONLY")
        with AutoApprover._guard:
            if request_id in AutoApprover._in_progress:
                return AutoResult("IN_PROGRESS")
            AutoApprover._in_progress.add(request_id)
        try:
            return self._process_once(transport, store, policy, remote_root, request_id, request_text, request_raw)
        finally:
            with AutoApprover._guard:
                AutoApprover._in_progress.discard(request_id)

    def _process_once(self, transport, store, policy, remote_root, request_id, request_text, request_raw) -> AutoResult:
        try:
            return self._process(transport, store, policy, remote_root, request_id, request_text, request_raw)
        except Exception as exc:                                       # noqa: BLE001  one bad request must not stop the others
            claim = None
            try:
                rev = str(parse_front_matter(request_text).get("request_revision"))
                claim = store.auto_get_claim(request_id, rev)
                if claim and claim["stage"] not in ("READY_POSTED", "UNCERTAIN", "POLICY_STOPPED"):
                    store.auto_update(request_id, rev, int(self.now_fn()), stage="UNCERTAIN", detail=f"unexpected {type(exc).__name__}")
            except Exception:                                          # noqa: BLE001
                claim = claim or None
            if claim is not None:
                self._event("AUTO_SIGNING_UNCERTAIN", request_id, f"unexpected {type(exc).__name__}: no further automatic action for this request")
                return AutoResult("UNCERTAIN", type(exc).__name__)
            # nothing was reserved or signed: a plain log line, not an alert
            self._once("AUTO_ERROR", request_id, f"unexpected {type(exc).__name__} before any reservation; nothing was signed")
            return AutoResult("ERROR", type(exc).__name__)

    def _process(self, transport, store, policy, remote_root, rid, request_text, request_raw) -> AutoResult:
        now = int(self.now_fn())
        front = parse_front_matter(request_text)
        rev = str(front.get("request_revision"))
        root = remote_root.rstrip("/")
        base = f"{root}/requests/{rid}"
        delegation, why = load_delegation(self.s.delegation_file, now, self.s.acl_check)
        enabled = bool(delegation and delegation.enabled)
        seen_at, seen_enabled = store.auto_note_seen(rid, rev, enabled, now)
        if delegation is None:
            self._once("AUTO_POLICY_PROBLEM", rid, f"delegation unusable: {why}")
            return AutoResult("POLICY_PROBLEM", why)
        if not enabled:
            return AutoResult("DISABLED")
        if not seen_enabled:
            self._once("AUTO_PRE_EXISTING_REQUEST", rid, "seen while automatic approval was off: never started automatically")
            return AutoResult("PRE_EXISTING_REQUEST")

        claim = store.auto_get_claim(rid, rev)
        if claim is not None:
            return self._resume(transport, store, policy, base, rid, rev, claim, delegation, front, request_raw)

        # ---- read-only checks, in this order; nothing is reserved or signed until all hold ---------------------------------------------------
        try:
            provider_time = transport.server_time()
            check_clock(provider_time, datetime.now(timezone.utc))
            server_repo = transport.repository_id()
            pin_raw = transport.download(f"{base}/SOURCE_PIN.json")[0]
        except RemoteNotFound:
            self._once("AUTO_NOT_ELIGIBLE", rid, "SOURCE_PIN.json is missing")
            return AutoResult("PIN_MISSING")
        except Exception as exc:                                       # noqa: BLE001  clock, repository id or read failure: wait, sign nothing
            self._once("AUTO_NOT_ELIGIBLE", rid, f"identity or pin unreadable: {type(exc).__name__}")
            return AutoResult("IDENTITY_UNREADABLE")
        try:
            pin = json.loads(pin_raw)
        except ValueError:
            pin = {}
        commit = str(pin.get("commit", ""))
        pins_ok = (pin.get("schema") == PIN_SCHEMA and re.fullmatch(r"[0-9a-f]{40}", commit) is not None
                   and str(pin.get("repo_id")) == server_repo == delegation.repo_id)

        pid, wid = front.get("project_id"), front.get("work_id")
        if pid and wid and str(pid) != str(wid):
            self._once("AUTO_NOT_ELIGIBLE", rid, "PROJECT_IDS_DIFFER: project_id and work_id name different projects")
            return AutoResult("PROJECT_IDS_DIFFER")
        project = str(pid or wid or "")
        if not project:
            self._once("AUTO_NOT_ELIGIBLE", rid, "PROJECT_ID_MISSING")
            return AutoResult("PROJECT_ID_MISSING")
        scoped = project_scope(delegation, project)
        if scoped is None:
            self._once("AUTO_NOT_ELIGIBLE", rid, "PROJECT_NOT_IN_SCOPE: the project is neither listed nor inside an owner-listed family")
            return AutoResult("PROJECT_NOT_IN_SCOPE")
        run_policy = str(front.get("run_policy_ref", ""))
        package_path = str(front.get("package_path", ""))
        budget = policy.run_budgets_usd.get(run_policy)
        estimated = int(round(budget * 100)) if isinstance(budget, (int, float)) else 0

        package_raw, bytes_ok, commit_ok, created_at = b"", False, False, 0
        if pins_ok and SAFE_NAME.fullmatch(rid) and package_path.startswith("/SKILL-COLLAB/packages/") and package_path.lower().endswith(".zip"):
            try:
                package_raw = transport.download(package_path)[0]
                bytes_ok = (len(package_raw) <= MAX_PACKAGE_BYTES and len(package_raw) == int(front.get("package_size_bytes", -1))
                            and hashlib.sha256(package_raw).hexdigest() == str(front.get("package_sha256")) and self._package_clean(package_raw))
                req_at_a = transport.download_at_commit(f"{base}/REQUEST.md", commit)[0]
                pkg_at_a = transport.download_at_commit(package_path, commit)[0]
                commit_ok = req_at_a == request_raw and pkg_at_a == package_raw
                created_at = int(transport.commit_time(commit))
            except (TransportError, AuthRequired, ValueError, TypeError) as exc:
                self._once("AUTO_NOT_ELIGIBLE", rid, f"commit-pinned bytes unreadable: {type(exc).__name__}")
                return AutoResult("COMMIT_UNREADABLE")

        prior = self._prior_state(transport, store, root, rid, rev)
        usage = store.window_usage(now)
        signer_ok = bool(self.signer is not None and policy.trust_root is not None and policy.signature_backend is not None
                         and (not hasattr(self.signer, "trusts_key") or self.signer.trusts_key(policy.trust_root)))
        cand = auto_policy.Candidate(
            request_id=rid, revision=int(rev) if rev.isdigit() else 0, project=project, skill=str(front.get("skill_id", "")), repo_id=str(server_repo),
            branch=str(getattr(transport, "branch", "main")), created_at=created_at, commit_a=commit,
            request_sha256=hashlib.sha256(request_raw).hexdigest(), zip_sha256=str(front.get("package_sha256", "")), policy=run_policy,
            estimated_cents=estimated, max_calls=1, attempt=1, state=str(front.get("state", "")))
        # specific, honest reasons for the three input checks (the pure gate would only say INPUT_OR_TRUST)
        if not pins_ok:
            self._once("AUTO_NOT_ELIGIBLE", rid, "PIN_MISMATCH: SOURCE_PIN schema, commit or repository id do not match the server and the delegation")
            return AutoResult("PIN_MISMATCH")
        if not bytes_ok:
            self._once("AUTO_NOT_ELIGIBLE", rid, "PACKAGE_INVALID: size, sha256, CRC, safety scan or size limit failed")
            return AutoResult("PACKAGE_INVALID")
        if not commit_ok:
            self._once("AUTO_NOT_ELIGIBLE", rid, "COMMIT_A_MISMATCH: the pinned commit does not hold the same REQUEST and package bytes")
            return AutoResult("COMMIT_A_MISMATCH")
        ev = auto_policy.Evidence(now=now, pins_verified=pins_ok and commit_ok, bytes_and_crc_verified=bytes_ok, signer_and_trust_root_valid=signer_ok,
                                  prior_state=prior, day_calls_used_or_reserved=usage["day_calls"],
                                  day_cents_used_or_reserved=usage["day_cents"], month_cents_used_or_reserved=usage["month_cents"],
                                  atomic_claim_available=True)
        ok, reason = auto_policy.assess(scoped, cand, ev)
        if not ok:
            ev_name = "AUTO_DUPLICATE_BLOCKED" if reason == "DUPLICATE_OR_UNCERTAIN" else "AUTO_NOT_ELIGIBLE"
            self._once(ev_name, rid, reason)
            return AutoResult(reason)
        # the request's own creation time (the pinned commit) must not precede the delegation: no retroactive start
        if created_at < delegation.earliest_request_at or seen_at < delegation.earliest_request_at:
            self._once("AUTO_NOT_ELIGIBLE", rid, "RETROACTIVE_OR_FUTURE_REQUEST")
            return AutoResult("RETROACTIVE_OR_FUTURE_REQUEST")

        # ---- the official validator on the READY that will be published (bytes fixed BEFORE signing) -------------------------------------------
        ready = _ready_text(rid, rev, cand.request_sha256, cand.zip_sha256, policy.active_baseline_id)
        ready_raw = ready.encode("utf-8")
        check = validate(request_text, ready, (len(package_raw), cand.zip_sha256), policy, expected_request_id=rid, request_bytes=request_raw)
        if check.outcome != ValidationOutcome.VALIDATED:
            self._once("AUTO_NOT_ELIGIBLE", rid, f"validator: {check.outcome.value}: {check.reason[:100]}")
            return AutoResult("VALIDATOR_" + check.outcome.value)

        # ---- atomic reservation -------------------------------------------------------------------------------------------------------------
        candidate = json.dumps({"request_id": rid, "revision": rev, "project": project, "skill": cand.skill, "policy": run_policy,
                                "cents": estimated, "created_at": created_at, "commit": commit, "repo_id": str(server_repo),
                                "branch": cand.branch, "state": cand.state, "request_sha256": cand.request_sha256,
                                "zip_sha256": cand.zip_sha256, "package_path": package_path}, sort_keys=True)
        verdict = store.auto_claim(rid, rev, cand.zip_sha256, estimated, candidate, now,
                                   max_day_calls=delegation.max_day_calls, max_day_cents=delegation.max_day_cents,
                                   max_month_cents=delegation.max_month_cents)
        if verdict != "CLAIMED":
            self._once("AUTO_LIMIT_BLOCKED" if verdict.endswith("LIMIT") else "AUTO_DUPLICATE_BLOCKED", rid, verdict)
            return AutoResult(verdict)
        self._event("AUTO_RESERVED", rid, f"{estimated} cents reserved; signing follows")
        return self._sign_and_post(transport, store, policy, base, rid, rev, delegation, front, request_raw, ready_raw, package_raw, pin_raw, commit)

    # -- helpers --
    @staticmethod
    def _package_clean(package_raw: bytes) -> bool:
        try:
            if zipfile.ZipFile(io.BytesIO(package_raw)).testzip() is not None:
                return False
            if package_secret_findings(package_raw):
                return False
            with tempfile.TemporaryDirectory(prefix="auto_pkg_") as tmp:
                safe_extract(package_raw, Path(tmp) / "x")
            return True
        except (zipfile.BadZipFile, UnsafeZip, ValueError, OSError):
            return False

    def _prior_state(self, transport, store, root, rid, rev) -> str:
        paths = (f"{root}/requests/{rid}/APPROVAL_SIG.json", f"{root}/requests/{rid}/READY.md", f"{root}/dispatch/{rid}/DISPATCH_{rev}.md",
                 f"{root}/receipts/{rid}/RECEIPT_{rev}.md", f"{root}/reviews/{rid}/REVIEW_RESULT_{rev}.md")
        try:
            if any(self._exists(transport, p) for p in paths):
                return "REMOTE_HISTORY"
        except (TransportError, AuthRequired):
            return "UNREADABLE"
        if store.auto_jobs_for(rid, rev) or store.auto_get_claim(rid, rev) is not None:
            return "LOCAL_HISTORY"
        return "NEW"

    def _revalidate(self, transport, store, rid, rev, claim, now) -> tuple[bool, str]:
        """The stored candidate must still be allowed by the CURRENT protected delegation: enabled, unexpired, same repository, the project in the
        (exact or family) scope, the skill in its list, the limits (per request, day, month) counted without this request's own reservation, and the
        pure gate. Anything else stops the request. Nothing is cached: this runs before every signature and every publication."""
        stored = json.loads((claim or {}).get("candidate_json") or "{}")
        if not stored:
            return False, "CANDIDATE_MISSING"
        d, why = load_delegation(self.s.delegation_file, now, self.s.acl_check)
        if d is None:
            return False, "DELEGATION_UNUSABLE:" + why
        if not d.enabled:
            return False, "DELEGATION_DISABLED"
        try:
            if transport.repository_id() != d.repo_id or d.repo_id != stored.get("repo_id"):
                return False, "REPOSITORY_CHANGED"
        except (TransportError, AuthRequired):
            return False, "REPOSITORY_UNVERIFIABLE"
        scoped = project_scope(d, str(stored.get("project", "")))
        if scoped is None:
            return False, "PROJECT_NOT_IN_SCOPE"
        usage = store.window_usage(now, exclude=(rid, rev))
        cand = auto_policy.Candidate(
            request_id=rid, revision=int(rev) if rev.isdigit() else 0, project=str(stored["project"]), skill=str(stored.get("skill", "")),
            repo_id=str(stored["repo_id"]), branch=str(stored.get("branch", "main")), created_at=int(stored["created_at"]),
            commit_a=str(stored["commit"]), request_sha256=str(stored["request_sha256"]), zip_sha256=str(stored["zip_sha256"]),
            policy=str(stored["policy"]), estimated_cents=int(stored["cents"]), max_calls=1, attempt=1, state=str(stored.get("state", "")))
        ev = auto_policy.Evidence(now=now, pins_verified=True, bytes_and_crc_verified=True, signer_and_trust_root_valid=True,
                                  prior_state="NEW", day_calls_used_or_reserved=usage["day_calls"],
                                  day_cents_used_or_reserved=usage["day_cents"], month_cents_used_or_reserved=usage["month_cents"],
                                  atomic_claim_available=True)
        ok, reason = auto_policy.assess(scoped, cand, ev)
        if not ok:
            return False, f"CURRENT_POLICY:{reason}"
        return True, "ok"

    def _policy_stop(self, store, rid, rev, why: str) -> AutoResult:
        """The delegation no longer allows this exact candidate. Terminal for the request: no signature, no publication, no model. Anything already
        published stays as it is (an approval expires on its own within its validity; without READY no review starts)."""
        store.auto_update(rid, rev, int(self.now_fn()), stage="POLICY_STOPPED", detail=why[:200])
        self._event("AUTO_POLICY_STOPPED", rid, f"{why}; no further automatic action for this request")
        return AutoResult("POLICY_STOPPED", why)

    def _uncertain(self, store, rid, rev, why: str) -> AutoResult:
        store.auto_update(rid, rev, int(self.now_fn()), stage="UNCERTAIN", detail=why[:200])
        self._event("AUTO_SIGNING_UNCERTAIN", rid, f"{why}; no further automatic action for this request")
        return AutoResult("UNCERTAIN", why)

    def _sign_and_post(self, transport, store, policy, base, rid, rev, delegation, front, request_raw, ready_raw, package_raw, pin_raw, commit) -> AutoResult:
        t = lambda: int(self.now_fn())                                 # noqa: E731
        ok, why = self._revalidate(transport, store, rid, rev, store.auto_get_claim(rid, rev), t())   # immediately before the signature
        if not ok:
            return self._policy_stop(store, rid, rev, f"before signing: {why}")
        try:
            approval_raw = self.signer.sign(request_raw, ready_raw, package_raw, str(front["package_path"]), commit, policy.local_policy_revision,
                                            self.s.valid_hours)
            self.signer.verify(approval_raw, pin_raw, request_raw, ready_raw, package_raw, str(front["package_path"]), policy.local_policy_revision,
                               policy.trust_root, policy.signature_backend)
        except (ApprovalRejected, NotConfigured) as exc:
            return self._uncertain(store, rid, rev, f"the signature did not verify: {type(exc).__name__}")
        except Exception as exc:                                       # noqa: BLE001  never include a message: it could carry a path
            return self._uncertain(store, rid, rev, f"signing failed: {type(exc).__name__}")
        store.auto_update(rid, rev, t(), stage="SIGNED_LOCAL", approval_text=approval_raw.decode("utf-8"), ready_text=ready_raw.decode("utf-8"))
        self._event("AUTO_SIGNED_LOCAL", rid, "approval signed and verified locally; publishing follows (approval first, READY last)")
        return self._publish(transport, store, base, rid, rev, delegation)

    def _publish(self, transport, store, base, rid, rev, delegation) -> AutoResult:
        claim = store.auto_get_claim(rid, rev)
        approval_raw, ready_raw = claim["approval_text"].encode("utf-8"), claim["ready_text"].encode("utf-8")
        if claim["stage"] == "SIGNED_LOCAL":
            ok, why = self._revalidate(transport, store, rid, rev, claim, int(self.now_fn()))
            if not ok:
                return self._policy_stop(store, rid, rev, f"before posting the approval: {why}")
            if self._exists(transport, f"{base}/READY.md"):
                return self._uncertain(store, rid, rev, "a READY already exists remotely")
            res = self._post_create_only(transport, f"{base}/APPROVAL_SIG.json", approval_raw)
            if res not in ("POSTED", "EXISTS_SAME"):
                return self._uncertain(store, rid, rev, f"approval publication: {res}")
            store.auto_update(rid, rev, int(self.now_fn()), stage="APPROVAL_POSTED")
            self._event("AUTO_APPROVAL_POSTED", rid, "APPROVAL_SIG.json published and read back; READY is published last")
            claim = store.auto_get_claim(rid, rev)
        if claim["stage"] == "APPROVAL_POSTED":
            ok, why = self._revalidate(transport, store, rid, rev, claim, int(self.now_fn()))
            if not ok:
                return self._policy_stop(store, rid, rev, f"before posting READY: {why}")
            try:
                remote_approval = transport.download_latest(f"{base}/APPROVAL_SIG.json")[0]
            except (TransportError, AuthRequired):
                return self._uncertain(store, rid, rev, "the published approval cannot be read back")
            if remote_approval != approval_raw:
                return self._uncertain(store, rid, rev, "the remote approval differs from the signed one")
            res = self._post_create_only(transport, f"{base}/READY.md", ready_raw)
            if res not in ("POSTED", "EXISTS_SAME"):
                return self._uncertain(store, rid, rev, f"READY publication: {res}")
            store.auto_update(rid, rev, int(self.now_fn()), stage="READY_POSTED")
            self._event("AUTO_READY_POSTED", rid, "READY.md published last and read back; the unchanged watcher validates and dispatches on a later cycle")
            return AutoResult("READY_POSTED")
        return AutoResult(claim["stage"])

    def _resume(self, transport, store, policy, base, rid, rev, claim, delegation, front, request_raw) -> AutoResult:
        stage = claim["stage"]
        if stage in ("READY_POSTED", "UNCERTAIN", "POLICY_STOPPED"):
            return AutoResult(stage)
        now = int(self.now_fn())
        if stage == "RESERVED":
            # Nothing was ever published (a publication needs a stored signature). A restart before the signature may sign ONCE more, never twice.
            try:
                remote_any = self._exists(transport, f"{base}/APPROVAL_SIG.json") or self._exists(transport, f"{base}/READY.md")
            except (TransportError, AuthRequired):
                return self._uncertain(store, rid, rev, "recovery: remote state unreadable")
            if remote_any or claim["attempts"] >= 2:
                return self._uncertain(store, rid, rev, "recovery: reservation without a signature but remote files exist or a retry was used")
            store.auto_update(rid, rev, now, attempts=claim["attempts"] + 1)
            try:
                pin_raw = transport.download(f"{base}/SOURCE_PIN.json")[0]
                pin = json.loads(pin_raw)
                package_raw = transport.download(str(front["package_path"]))[0]
            except Exception as exc:                                   # noqa: BLE001
                return self._uncertain(store, rid, rev, f"recovery: inputs unreadable ({type(exc).__name__})")
            stored = json.loads(claim.get("candidate_json") or "{}")
            if (hashlib.sha256(package_raw).hexdigest() != claim["package_sha256"] or str(pin.get("repo_id")) != delegation.repo_id
                    or stored.get("request_sha256") != hashlib.sha256(request_raw).hexdigest()):
                return self._uncertain(store, rid, rev, "recovery: bytes changed since the reservation")
            ready_raw = self._ready_for(policy, front, request_raw, claim).encode("utf-8")
            return self._sign_and_post(transport, store, policy, base, rid, rev, delegation, front, request_raw, ready_raw, package_raw, pin_raw,
                                       str(pin.get("commit")))
        if stage in ("SIGNED_LOCAL", "APPROVAL_POSTED"):
            try:
                approval = json.loads(claim["approval_text"])
                expires = datetime.fromisoformat(approval["payload"]["expires_at"])
            except (ValueError, KeyError, TypeError):
                return self._uncertain(store, rid, rev, "recovery: the stored approval is unreadable")
            if datetime.now(timezone.utc) >= expires:
                return self._uncertain(store, rid, rev, "recovery: the stored approval expired; it is never re-signed automatically")
            return self._publish(transport, store, base, rid, rev, delegation)
        return AutoResult(stage)

    @staticmethod
    def _ready_for(policy, front, request_raw, claim) -> str:
        return _ready_text(str(front["request_id"]), str(front["request_revision"]), hashlib.sha256(request_raw).hexdigest(),
                           claim["package_sha256"], policy.active_baseline_id)
