# L1 Knowledge Updater 통합 인계 r0004 · Source Map, Procedure G-2, 지식 품질

2026-11-28 KST · 업무 GPT용 · 기존 Work `L1-WORKSPACE-RAG-20261111-001` · 설계 확정 / 업무 활성본 G0 대기

**변경 범위는 세 곳입니다.** Updater는 Source Map의 생성·갱신과 분석 전 조회를 조율하고, 기존 Personal Store Writer는 `knowledge/`와 같은 계층인 `l1-workspace/source-map/`을 담당합니다. 공개 Code Analyzer에서 재현한 Procedure 추출 문제는 Analyzer 관리자가 exporter에서 처리합니다. Knowledge 문서는 기존 작성 형식 안에서 근거·조건·흐름이 부족한 부분만 보강합니다.

### 업무 GPT에 복사할 첫 요청

> 같은 Work에서 읽기 전용 G0부터 시작해 주세요. 활성 Updater·Analyzer·Writer/Reader의 실제 실행 경로와 해시, 기존 Discovery 7건, G-2 실패 bundle, UD 정책·게이트·실문서 1건을 대조해 주세요. 기존 Analyzer로 대표 시나리오의 코드 근거를 검증하고, 기존 Writer로 독립 source-map/에 저장할 때 필요한 차이만 정리해 주세요. G-2는 아래 합성 재현과 활성본을 비교해 Analyzer 관리자에게 전달해 주세요. 첫 회신에는 재사용할 기능, 변경 소유자·파일, 대표 사례의 기준선과 다음 한 행동을 담아 주세요. 구현·저장·배포는 해당 작업의 기존 승인 범위를 확인한 뒤 진행해 주세요.

본문은 11/27 Updater r0003에서 달라진 책임과 수락 기준이다. 기존 T01~T18, U19~U23, 개인·그룹 동기화 계약과 Recovery r0008은 계속 참조한다. 업무 GPT는 이 문서를 입력으로 사용하며, 이후 단계의 검토는 자체 점검과 회귀시험으로 진행한다. [Updater r0003](https://github.com/wonhwipark/L1Work/blob/b7f3a670ffd573e12be3464e16d14bb88c3be391/handoffs/L1_KNOWLEDGE_UPDATER_QWEN36_ANALYSIS_QUALITY_IMPLEMENTATION_HANDOFF_r0003_20261127_KST.md) · [공통 연동 인계](https://github.com/wonhwipark/L1Work/blob/b7f3a670ffd573e12be3464e16d14bb88c3be391/handoffs/L1_RECOVERY_SOURCE_MAP_VIEWER_INTEGRATED_IMPLEMENTATION_HANDOFF_r0001_20261127_KST.md)

## 1. 근거와 변경 소유자

공개 기준은 L1Work `b7f3a670ffd5`, CoWork `1cd998c6d507`의 main이다. 공개 패키지 6종을 원격 Git 객체에서 읽고 ZIP SHA-256·CRC를 확인했다. **업무 보고**는 첨부 r0001이 정리한 11/27 MCP 읽기 결과와 사용자 확인이다. 업무 코드, 활성 서비스 및 개인 Writer에서 이 문서 작성자가 재실행한 결과는 §7의 공개 패키지 시험과 구분한다. [L1Work 기준점](https://github.com/wonhwipark/L1Work/tree/b7f3a670ffd573e12be3464e16d14bb88c3be391) · [기존 Work 및 R2 판정](https://github.com/wonhwipark/CoWork-Skill-Collab/blob/1cd998c6d50797d948d1e2ab287c63b33e97c5db/collab/projects/L1-WORKSPACE-RAG-20261111-001/GPT_SOURCE_MAP_1500_R2_DISPOSITION_r0001_20261127_KST.md)

| 요구 | 판정 및 근거 | 변경 책임과 범위 |
|---|---|---|
| Discovery와 K단계 | **REUSE**. 업무 보고에 인벤토리·7개 산출물·근거 해시가 있다. K0~K8 및 Classification Baseline이 기존 진입점이다. | Updater가 기존 Work·결과를 대조한다. 세션 결과는 활성 Map 후보로 취급한다. |
| Map 생성·갱신 요청 및 사전 조회 | **CONNECT**. 지정 revision의 Git 인벤토리 및 Analyzer의 scope/probe/incremental 기능이 있다. 업무 조회 범위에서는 정식 Map action과 정책을 찾지 못했다. 전체 활성본은 **UNKNOWN**. | Updater의 요청 분기·기존 K2/K4 입력 연결과 회귀가 기본 변경. 실제 존재하는 action을 먼저 등록·재사용한다. |
| 개인 Map 쓰기 | **REUSE** 개인 Writer의 지식 쓰기. G5 성공 보고가 있다. **PROVEN_GAP(보고된 정책 범위)** 기존 3단계 Scenario README 경로와 독립 Map root가 맞지 않는다. 다중 파일 게시·CAS 지원은 **UNKNOWN**. | Writer 소유자가 기존 경로 해석·검증·잠금·승인·이력·readback을 재사용한다. Map 유형과 snapshot 전환에서 입증된 차이만 보완한다. |
| Map 읽기 | **CONNECT**. v0.5.8에 읽기 화면과 합성 adapter가 있다. 업무 개인 조회는 `LIBRARY_NOT_CONFIGURED` 보고. 실제 runtime Reader와 ACL은 **UNKNOWN**. | 기존 개인 Reader와 소유 adapter를 연결한다. MCP 개인 root 설정과 runtime을 각각 확인한다. |
| Procedure G-2 | **PROVEN_GAP(공개 v0.15.7)**. 두 action, 생산 파일, 처리 함수, 0건을 확인했다. 활성 업무 bundle의 동일 원인은 **UNKNOWN**. | Analyzer 담당의 exporter 호환 처리와 회귀가 1순위. Updater는 선택한 입력과 결과 수·미수용 사유만 확인한다. |
| 문서·MSC | **REUSE / CONNECT**. UD-1~10 정책은 업무 보고, Converter의 HTML 생성과 Viewer의 표시 역할은 공개 코드로 확인했다. | Updater 템플릿·설명·근거 연결을 보완한다. 업무 UD-10 실제 분모와 HTML 계보는 G0에서 확인한다. |
| Recovery / Kernel / Fix Workflow | **REUSE**. Recovery는 사실·정상 Procedure 읽기, Kernel은 Work/Evidence와 파생 뷰, Workflow는 Work 선택·조회 역할. **UNKNOWN**인 업무 측 Map 쓰기 차단을 아래 실험으로 검증한다. | Recovery·Viewer는 기존 담당 인계의 읽기 연결만 사용한다. Kernel·Workflow는 보존/권한 회귀 실패가 재현된 경로만 담당자에게 이관한다. |

`PROVEN_GAP`의 괄호는 판정 가능한 원본의 범위다. 공개 버전의 결함이 업무 활성본에서도 재현될 때 해당 버전 수정으로 승격한다.

### G0 · 업무 첫 회신

| 확인 대상 | 확보할 실제 증거와 그 결과로 결정할 일 |
|---|---|
| 실행본 식별 | 같은 시점의 서비스·Agent가 로드하는 realpath, entrypoint·정책·스크립트 SHA, 설치 영수증, 실행 action/alias를 업무 Work에 대조. Updater frontmatter 1.9.3 / MCP 라벨·회귀 1.9.1, Writer update 1.10.0 보고, Skill Updater inventory 0.5.38 / capability 0.5.43 / 공개 0.5.44를 각각 기록. 버전 문자열만 보고 설치·교체하지 않는다. |
| 생산·소비자 | Analyzer 과거 0.15.2/0.15.6 및 공개 0.15.7, Converter 0.2.26, Recovery inventory 0.3.3, 운영 Viewer 0.5.7(사용자 확인) / 공개 개발 0.5.8, Kernel 0.7.47 / Workflow 1.6.75의 활성 해시·선택 경로. 실제 OpenCode 모델 ID·Qwen tokenizer·컨텍스트·도구 권한·timeout·읽기 계측도 함께 고정. |
| 원본·범위 | 명시한 유효 소스 경로 또는 기존 등록 경로를 사용. 경로가 없거나 복수일 때 필요한 값만 질문. 고정 revision·dirty 포함 정책·RAT·build·번역 단위(TU)·허용 모듈·범위 밖 경계를 기록. 11/09 HEAD 기준 Discovery는 그 revision에 대해서만 유효. |
| 저장·조회 | 같은 actor 기준 Writer의 canonical workspace, 개인 Reader의 root/권한, MCP personal/group의 각각의 설정, 서비스 adapter를 대조. 그룹 HITS·개인 미설정·권한 거절·빈 결과를 구분. Writer의 create/update·index 범위·비교 후 교체(CAS)·reader pin·조회 영수증을 확인. |
| G-2와 UD | 활성 launcher→behavior facts→선택된 K2 bundle→exporter→K3 consumer의 경로·해시·스키마·건수, 정상 fixture와 실패 입력의 차이. UD 정책·스크립트·10개 실제 H2·기존 합격/실패 문서·적용 유형을 같은 revision에서 추출. G0 차이가 있는 단계만 보류. |

## 2. Source Map 생성·저장·조회·갱신

**생성 요청과 일반 지식 분석의 진입을 나눈다.** Map 구축/갱신 요청은 기존 Updater의 요청 해석에서 분기한다. 일반 Knowledge 요청은 K0 대상 해석 후 K2 bundle/K4 범위를 잡을 때 기존 Map을 선택 조회한다. K0.5/K1, K3, K5의 발견·적합성·coverage, K6 MSC, K7 Preview, K8 Handoff, 분류 기준을 재사용한다. 일반 지식 편집과 Recovery는 전체 Map 완성이나 Viewer 배포를 기다리지 않는다.

### 2.1 최초 생성과 원본 검증

| 업무 Discovery 원본 | 재사용 방법 |
|---|---|
| README / FINAL_REPORT | 범위·읽는 법·이전 검증·남은 일 포인터. 결과 요약은 사실의 증거 위치로 쓰지 않는다. |
| NR / LTE Source Map MD | 모듈·경계·기존 근거 후보를 선별. 공통 header는 물리 파일을 공유하고 적용 build/TU를 별도로 연결한다. |
| MESSAGE_HANDLER_DISCOVERY | ID·이름·등록·handler 후보의 출발점. 송신·등록·dispatch·수신을 각각 원문에서 확인한다. |
| SOURCE_MAP_GAPS | 미조사, 외부 경계, 제외 이유 및 다음 조회를 보존한다. |
| SOURCE_DISCOVERY_MANIFEST | 기존 revision, scope, 파일 분모, anchor, artifact hash를 대조한다. 기존 7건 각각에 hash·재사용/부분 보완/충돌·미확인 관계를 한 행씩 회신한다. |

보고된 범위는 1,306 + LTE legacy 121 = **1,427파일**이다. legacy 세부 집계 57+38+25=120의 차이 1개는 manifest 파일 목록으로 정산한다. 29개 증빙 해시·일부 심층 경로·handler 건수는 각기 다른 분모다. 경량 인벤토리, 본문을 읽은 파일, build가 확인된 TU, 원문으로 검증한 관계를 따로 집계한다. 동일 pin에서는 기존 Git 결과를 재사용하고, 갱신 대상과 대표 모듈에서 필요한 원문만 Analyzer로 연다.

| 우선 | 수집할 관계 | 확정할 수 있는 명제 |
|---|---|---|
| P0 | Module/File/RAT, contains/include, 선언·정의, calls | 소유 파일·상대경로, qualified signature/linkage·양 끝, 호출 철자·caller 범위와 실제 해소 수준. 동명·간접 호출은 후보 유지. |
| P0 | sends, receives, payload, registers, dispatches, guard/build | 송수신 API·ID·payload, 실제 테이블/switch와 대상, compile guard 및 TU. 정적 등록·빌드 적용·runtime 관측은 각각 증거가 필요하다. |
| P1 / P2 | 상태 read/write, HAL·RF/PHY IPC 경계, instance/Stack/Domain/Cell/CC, timer/callback, 기존 knowledge_ref / 제한적 alias·data flow | P1은 대표 질문에서 필요한 것부터 확장한다. P2는 P0/P1으로 풀리지 않는 실제 사례에서만 시도한다. |

논리 레코드는 양 끝 ID·관계와 방향·명제, 코드 상대경로/line·symbol·근거 해시, 추출 방법, source/build/scope·snapshot, 검증 상태·근거의 최신성·누락 범위를 담는다. `EXTRACTED/INFERRED/UNKNOWN`과 `VERIFIED/UNVERIFIED/CONFLICT`는 서로 다른 속성이다. 명제에 맞는 원문만 검증으로 승격한다. 예를 들어 “키 K가 표에서 H에 연결됨”은 테이블의 양 끝으로 검증하고, “현재 build에서 H가 실행됨”은 별도 근거를 요구한다. 기술 설명과 MSC는 기존 문서의 ID·revision만 참조한다. [관계별 예시·증분 반례](https://github.com/wonhwipark/L1Work/blob/b7f3a670ffd573e12be3464e16d14bb88c3be391/handoffs/L1_SOURCE_MAP_1500_UPDATER_INTEGRATED_HANDOFF_r0003_20261127_KST.md)

### 2.2 개인 Writer와 독자의 일관성

1. **후보 작성.** 기존 Writer의 actor/권한과 경로 제약을 적용한다. `knowledge/<module>/<feature>/<scenario_id>/README.md`의 frontmatter·VERBATIM·색인을 보존하고, 형제 `source-map/`에만 Map 유형 검증을 적용한다. 기존 Scenario 경로에 가상 모듈을 만들지 않는다. 같은 원본·build·scope·추출 버전과 해시의 후보는 재사용한다.
2. **활성화.** 기존 Writer가 묶음 단위 원자 쓰기를 제공하면 그것을 쓴다. 단일 파일 원자 쓰기만 있으면 같은 Writer로 변경 불가능한 snapshot 내용을 먼저 쓰고 참조·크기·해시를 검증한다. 기존 lock/트랜잭션이 비교와 교체 전체를 보호하는 범위에서 예상 이전 manifest 해시와 현재 활성 참조를 대조한 뒤 활성 참조 하나만 원자 교체한다. 기존 저장 방식이 Git 트리 단위이면 동등한 예상 revision 비교를 재사용한다. 단일 호스트 lock만 있으면 다중 호스트 상호 배제를 주장할 수 없다.
3. **읽기와 실패.** 독자는 시작에 활성 snapshot 하나를 고정하고 관계·근거·역색인을 같은 snapshot에서 읽는다. 충돌은 이전 활성본 및 양쪽 후보를 보존한다. 중단 전 staged 파일은 독자에게 노출하지 않는다. 응답 유실은 대상 snapshot/요청·manifest 해시 readback으로 성공 여부를 정산하고 중복 쓰기를 막는다. 검증한 전환 수단이 없으면 개인 저장만 HOLD, 분석·후보는 보존한다.
4. **권한과 기존 지식.** 최초 개인 Map 승인 대상·예상 revision을 확인한다. 기존 G5 지식 쓰기 승인 5건은 해당 문서에 한정된다. 그룹은 기존 Base/Ours/Theirs 비교→Preview→별도 승인→CAS/readback→원 Work 역링크를 사용한다. 그룹 게시 후 역링크만 실패했을 때는 역링크만 재개한다. 개인 Map을 그룹 후보로 자동 편입하지 않는다.

### 2.3 조회와 증분 갱신

- **조회.** 기존 개인 Reader에서 revision/build·scope·읽기 권한을 고정하고 정확한 qualified symbol/Message ID, 관계 종류, incoming/outgoing 1-hop으로 시작한다. 결과에는 해당 snapshot·원문 anchor·검증과 최신성·조사/미조사 범위·잘림·다음 probe 하나를 돌려준다. 관련 정상 Procedure/Feature는 원본 문서 revision과 ACL이 일치할 때 연결한다. Reader 미설정/미지원, 접근 거절, EMPTY/PARTIAL/STALE/CONFLICT/ERROR를 구분한다. 거절된 원본·존재·링크는 노출하지 않는다. 다른 권한 소스를 이용한 우회 없이, 원래 허용된 코드에만 bounded probe를 적용한다.
- **갱신.** 기존 `git-incremental`, `reuse-validate`의 변경 파일·의존성·재사용 판정을 입력으로 받는다. old/new include·등록·symbol 역참조의 **합집합**을 영향 범위로 잡는다. 공유 header·macro·build flag 변경은 의존 TU와 variant까지, rename/삭제는 전후 ID·역색인·문서 링크까지 대조한다. 사라진 관계는 새 snapshot에서 철회하거나 tombstone 처리한다. 해소 못한 영향 범위는 STALE/UNKNOWN. 같은 입력의 재실행은 같은 내용으로 정산하고, 예전 독자는 고정 snapshot을 끝까지 읽는다. 역의존이 불완전하면 해당 모듈/build부터 범위를 넓힌다.
- **분석 비용.** 전체 인벤토리 생성/갱신 비용은 질문당 비용과 별도로 기록한다. 독립 Writer·DB, 범용 파서, 전체 파일 본문 LLM 분석을 전제로 하지 않는다. 실제 필드명·파일 포맷·저장 정책은 업무 원본에 매핑한다.

## 3. Procedure G-2 · 소유자와 최소 수정안

공개 Analyzer v0.15.7의 정식 launcher로 합성 C++ 파일을 분석했다. `behavior-doc`이 `code-analyzer/behavior-facts/v1`의 `scenarios[0].entry/flow`를 생성했다. `flow`에는 양 끝이 해소된 정적 호출 2건이 있었고 `knowledge-inventory-export`는 exit 0, `procedure_count=0`이었다. 같은 exporter에서 별칭 `knowledge-bundle-export`와 유효한 2-step 입력을 사용하면 `steps`, `ordered_steps`, `messages` 각각 1건, 1-step 입력은 0건이었다. [검토한 Analyzer ZIP](https://github.com/wonhwipark/L1Work/blob/b7f3a670ffd573e12be3464e16d14bb88c3be391/code-analyzer_v0_15_7_1127.zip)

| 원본 위치 | 확인한 의미 | 적용 결정 |
|---|---|---|
| `scripts/behavior_doc.py::scenario_flow` 및 `behavior_facts.json` 생성부 | 깊이 우선 탐색한 정적 호출 후보. from/to 이름·owner·파일, 호출 line, depth, resolved를 제공. 분기 실행 순서나 메시지 송달 증명은 없다. | 기존 producer 출력 유지. `resolved=true`도 실행 순서나 실제 IPC의 근거로 승격하지 않는다. |
| `scripts/knowledge_inventory_export.py::extract_json / procedure_from_item / normalize_step` | 기존 세 입력 별칭 중 하나에서 유효 step 2개 이상을 받아 `message-procedure/v1`을 내보낸다. behavior facts의 scenarios/flow는 읽지 않는다. | Analyzer 관리자가 해당 schema와 `scenarios[]`에 한정해 호환 처리를 추가한다. 최신 공개 ZIP 안 exporter의 내부 `VERSION=0.13.20`도 별도 기록한다. |
| 동일 exporter의 `export / input_fingerprint` | 기존 resume 판정은 bundle schema와 입력 경로·크기·mtime fingerprint를 사용한다. procedure digest는 ID·participants·steps로 계산돼 fragment만 다른 두 입력이 동일 digest가 될 수 있다(합성 확인). | 변경 후 첫 비교는 새 출력 위치에서 수행한다. 이후 재사용 조건에 추출 규칙과 입력·build 근거를 검증한다. 경로·길이·mtime만 같은 이전 0건 결과가 수정 검증에 쓰이지 않도록 한다. 기존 소비자의 ID/digest 계약을 보존한다. |

**격리 재현 방법.** 합성 함수 A가 B를, B가 C를 직접 한 번씩 호출하는 파일 하나를 사용한다. 정식 launcher에서 아래 순서로 실행하고 `behavior_facts.json`의 지정 entry·두 줄 근거와 출력 bundle의 대상 Procedure ID를 대조한다. 분석 루트는 해당 실행 산출물만 든 새 디렉터리로 두고 출력 bundle과 manifest는 그 밖에 둔다.

```text
behavior-doc -- --code-root <합성소스> --path <한파일> --focus <진입함수> --max-scenarios 1 --output-root <이번분석> --json
knowledge-inventory-export -- --analysis-root <이번분석> --out <별도출력>/bundle.json --manifest-out <별도출력>/manifest.json
```

**입력 혼입도 재현했다.** `collect_files`는 `--artifact`에 지정한 파일에 analysis-root 아래 JSON·MD를 더한다. 합성 behavior facts와 다른 Procedure 1건을 같은 입력 루트에 두면, facts를 명시해도 exporter는 입력 2개를 읽고 다른 Procedure만 1건 반환했다. 업무 K2에서는 선택 artifact hash·source digest·출력 Procedure ID와 각 step의 근거를 대조한다. 전체 count가 양수라는 이유로 대상 건을 합격시키지 않는다. 공개 SHA-256 앞 12자리는 `behavior_doc.py 0603bee6ab1f`, `knowledge_inventory_export.py b0b08a815bdc`이다.

**호환 규칙.** 우선 기존 steps 계약을 그대로 처리한다. 새 분기는 schema·entry·source digest·선택 scope가 일치하는 입력만 받는다. 정적 호출 후보는 Work의 근거로 남긴다. 기존 Procedure 의미로 표현 가능한 호출/메시지와 원본 방향·근거·순서 제약이 확인된 경우에만 기존 participants/steps/fragments/source_context로 매핑한다. DFS 인덱스·기본 `required=true`로 선택 분기나 비동기 순서를 만들어 내지 않는다. export는 이미 생성된 증거를 읽으며 추가 원문 확인은 기존 Analyzer probe로 수행한다. K3 또는 그룹 consumer에 임의 변환기를 복제하지 않는다.

**0건 판정.** 실제 대상 없음, 형식 미지원, 근거 부족, 잘림/권한 문제를 구분해 기존 gap/영수증에 기록한다. entry 누락·빈/1단계 flow·동명 overload·미해소 호출·variant 충돌·callback 순서 미확인·상호배타 분기는 부분/미확인으로 남긴다. 양 형식이 함께 있으면 동일 명제·variant·분기 근거만 중복 제거한다. 불일치는 양쪽 근거를 보존하며 ID/digest만으로 합치지 않는다. 기존 출력 enum으로 표현할 수 없는 상태는 gap에 보존한다.

**수락 기준.** 기존 RACH fixture(1건), 세 별칭과 단일 step, 업무 실패 bundle 원본, 독립적으로 정답을 고정한 변환 가능 사례 1건, 위 반례를 동일 launcher→K2→K3로 확인한다. 양성은 예상 ID·participants·방향·허용 순서·근거가 일치하고 중복 0이어야 한다. 의미가 부족한 반례는 0건이어도 사유/원본이 남아야 한다. entity/interface·기존 consumer·동일 입력 재개를 함께 회귀한다. 실제 업무 bundle이 다른 exporter로 연결되면 그 경로부터 정정한다.

## 4. Qwen3.6-27B 분석 품질 평가

한 질문마다 **대상·source/build·필수 질문 고정 → Map exact/1-hop → 필요한 정상 Procedure → 기존 Analyzer 원문 probe → 주장별 지지/반대 근거 → Knowledge/MSC** 순으로 진행한다. 예를 들어 “이 메시지의 handler가 어느 조건에서 호출되는가”라면 등록표, 전달 지점, handler의 조건과 build를 각기 대조한다. 일반 함수의 인자 쌍을 등록으로, symbol 출현을 호출로, 코드 행 순서를 callback 완료 순서로 채점하지 않는다. `#elif/#else`는 이전 sibling 배제와 중첩 guard를 확인한다. 실제 build 적용성이 UNKNOWN인 정적 조건은 그대로 노출한다.

| 비교 | 고정 입력과 해석 |
|---|---|
| Updater | U-baseline 현행 → A 요청·범위 정규화 → B 기존 Analyzer 실제 연결·근거 검증 → C 입증된 Analyzer 수정이 있을 때만 비교. G-2 수리와 Map의 효과를 별도로 기록한다. |
| Map | M-D0 현행 / D1 제한 Map / D2 검증된 정상 Procedure / D3 둘 다. **D3−D2**로 기존 Procedure가 있어도 Map이 더 회수한 정답이나 절감한 비용을 측정한다. |
| Recovery | 기존 r0008의 R-D1은 검증 코드 fact, R-D2는 정상 Procedure, R-D3는 둘 다. 같은 목적·입력·예산의 유효 결과만 재사용한다. V2 Cause Rule·V3 Search Plan·V4 보호 판정과 Edge/TO-BE MSC는 Recovery 담당이다. |

- 파일럿은 NR L1 Tx → UL Tx Switching 대표 1건과 별도 평가(holdout) 사례를 쓴다. 평가 전 양성 ≥30·음성/반례 ≥10을 관계·모듈·variant별로 고정하고 정답표는 모델에 주지 않는다. 같은 모델·tokenizer·도구·소스·build·예산·질문으로 조건별 독립 문맥에서 측정한다. 개인 입력에 노출된 평가 사례는 교체하고 그 이유를 기록한다.
- Map 응답 **실제 tokenizer 4,096 tokens 및 50행**, 기본 1-hop. 원문 **20파일/step·60파일/task**, 추가 probe 최대 4단계, 질의 task 총 입출력 **32,768 tokens·20분** 또는 더 낮은 실제 한도. 잘림·미조사·메타데이터 읽기와 실제 본문 읽기를 구분한다. tokenizer 실측이 안 되면 측정 상태를 미확인으로 남긴다.
- Recall = 회수한 정답 / 사전 양성 전체(미조사 포함). Precision = 올바른 확정 / 전체 확정(0건이면 N/A). 목표는 recall ≥90%, stale/variant 불일치 탐지 100%, 근거 없는 확정과 범위 밖 읽기 각각 0. 확인된 필수 관계/분기의 문서 누락과 MSC 방향·순서 오류도 각각 0. 동일 예산에서 정확도가 오르거나 동등 품질에서 읽은 파일·토큰·시간·호출이 줄고 holdout에서 재현될 때만 확대한다. 소스 열거율·형식 통과·모델 품질을 따로 기록한다.

## 5. 기존 Knowledge 문서와 MSC 품질

기존 분류는 Module→Feature→Scenario, Procedure는 Module 안에서 관련 Feature/Scenario와 교차 참조한다. Issue는 기존 이슈 지식 유형으로 유지한다. **기존 문서의 개선 단위는 확인된 오류·근거 누락이 있는 섹션**이다. 기존 문서 1건에서 핵심 주장·조건·분기·소스 anchor·MSC 방향을 표본 대조한 뒤 승인된 변경 부분만 Preview한다. 오래된 근거는 stale로 기록하고, 정상 원문과 ID·variant·역링크는 보존한다.

| 유형 | 기술 내용과 Viewer 역할을 매핑하는 기준 |
|---|---|
| Module | 개요 → 구조·구성요소 → 인터페이스 → 관련 Feature → 제약·근거. 모듈 경계와 책임을 표시한다. |
| Feature | 개요 → 원리·조건 → 상태/전이 → 관련 Scenario → 예외·제약·근거. 진입 조건과 분기 결과를 명시한다. |
| Procedure | 개요 → API·caller/callee·인자 → 전제·반환·부작용 → 예외·근거. 정상 경로와 미확인 경계를 구분한다. |
| Scenario | 개요 → trigger/전제 → 관련 구조 → 흐름·본문 MSC → 예외·제약·근거. 동기/비동기 방향과 조건을 대조한다. |
| Issue | 증상 → 원인 → 수정 → 영향 → 검증·근거. 원인 확인, 수정 반영, 시험 완료를 별도 기록한다. |

**기존 UD 게이트와의 대응.** 실제 Scenario 템플릿의 10개 H2 문자열·번호·순서가 우선이다. 위 표는 역할을 담을 위치를 찾는 작성 가이드다. 역할별 새 제목을 삽입하거나 Scenario 제약을 다른 유형·Map에 일괄 적용하지 않는다.

| 현재 확인 범위 | 작성·검사 방법 |
|---|---|
| UD-1~4 / 실제 §1~7 | 원본 10개 H2를 읽어 해당 유형의 기술 역할을 실제 heading ID에 매핑한다. §1~7은 기술 설명 중심, UD-2의 30자 기준과 UD-3의 한국어 본문 200자·식별자 3개, UD-4의 분류·H1 일치를 현행 스크립트로 확인한다. 원문 anchor와 의미가 맞는지는 별도로 읽는다. |
| UD-5·7·8 / §8~10 | §8에 미검증·HOLD, §10에 실제 코드 anchor 8건 이상과 중복 검토·판정 근거를 둔다. §9 역할과 §1~7의 정확한 개별 제목은 첨부 보고만으로 특정할 수 없다. G0에서 템플릿·게이트·실문서를 대조해 “실제 H2 / 적용 유형 / Viewer role 또는 미매핑 / 근거”를 채운다. 숫자를 맞추려고 무관한 줄을 넣지 않는다. |
| UD-6·9·10 | MSC 계보·미동반 사유, 필수 frontmatter·40-hex revision·evidence_refs·group_publication을 확인한다. MSC 동반 시 §10 계보 2홉 이상과 본문 링크·원본 근거를 대조한다. `user_doc_quality_gate.py --doc`의 exit 0/1/2, 정책 버전, 실제 실행 게이트별 분모를 회신한다. 보고된 9/9로 UD-10 실행을 추정하지 않는다. K5.7 coverage는 별도 판정한다. |

기존 Scenario에 “등록 후 즉시 응답을 받는다”가 적혀 있고 확인된 근거가 등록표뿐이라면, 본문에는 어떤 키가 어느 handler에 매핑되는지까지 기술한다. 전달 조건·응답 순서는 §8의 미확인 항목, 등록표의 근거는 §10, 기존 MSC의 해당 화살표는 재검증 대상으로 연결한다. 이런 전후 대조 1건을 문서 품질 회귀에 포함한다.

실제 MSC는 기존 검증 IR 또는 같은 revision의 유효 산출물을 사용한다. 새 변환이 필요하면 Converter `msc-package` 또는 `msc-scenario-build`의 `PROCEDURE_FEATURE` 모드를 사용하고 검증 IR→PUML→SVG→B형 HTML/manifest/영수증·상대링크·접근 권한을 확인한다. 변환 전후 참여자·방향·순서·분기와 AS-IS/TO-BE를 대조한다. HTML 미확인 시 유효 SVG와 분석 근거를 보존하고 누락된 단계만 재개한다. Viewer는 검증된 headingId/text/role 및 문서/source revision의 동일 계층 연속 구간만 표시 재정렬한다. 미매핑은 원문 순서를 따른다. [표시 역할과 순서](https://github.com/wonhwipark/L1Work/blob/b7f3a670ffd573e12be3464e16d14bb88c3be391/handoffs/L1_WORKSPACE_VIEWER_V057_KNOWLEDGE_SECTION_ORDER_COMPLETE_HANDOFF_r0001_20261126_KST.md)

## 6. 다른 스킬에 미치는 영향과 작업 순서

| 담당 | 이번 인계의 작업 / 개별 완료 근거 |
|---|---|
| 업무 GPT · Updater, Personal Store Writer/Reader | Updater의 요청·K2/K4 연결, 기존 UD 템플릿 매핑. Writer/Reader는 기존 개인 저장 방식의 Map 유형·snapshot·exact/1-hop 접근만 최소 확장. 경로·정책·action 실제 파일명은 G0에서 지정. 개인 저장과 조회를 각각 readback한다. |
| Analyzer 관리자 | G-2 실패가 활성본과 일치하면 exporter 및 해당 회귀에 한정한다. 기존 scope/probe·git-incremental·reuse-validate 재사용. Analyzer에 Map parser/저장 의존성을 추가하지 않는다. `knowledge-analysis-preflight` 0.2.0은 선택적 근거 참조 검사에만 사용한다. |
| Viewer 담당 | 운영 v0.5.7, 개발 v0.5.8. 기존 독립 Source Map 메뉴와 읽기 UI 재사용. ZIP의 `searchSourceMap`·`resolveSourceMapKnowledge`는 합성 adapter. 업무 Reader의 snapshot·build·문서 revision·ACL 연결 후 기존 Work/Knowledge/Recovery·MSC 복귀까지 확인한다. |
| Kernel / Fix Workflow 담당 | Kernel export 후 개인 두 root의 bytes·index 보존. Workflow 공개 v1.6.75의 기존 경로 검사 함수는 `knowledge/`를 명시하며 `source-map/`에 대한 보호는 그 함수에서 확인되지 않았다. 실제 writer/OS·동기화·게시 정책의 종단 차단을 격리 검증한다. 유효 경계로 차단되면 회귀만 추가하고, 통과해버리는 경로가 입증되면 그 소유자에게 좁은 경로 보호 변경을 요청한다. |
| Recovery / Converter / MCP·Skill Updater | Recovery는 Map 선택 조회와 기존 직접 분석 경로를 보존한다. Converter는 기존 변환·계보 재사용. MCP는 개인 root·표시 라벨을 활성 runtime과 대조한다. 설치·접근 정책은 각 담당의 기존 절차를 따른다. |

**재개 순서.** G0로 해당 입력을 고정하면 ① 기존 분석 기준선과 Discovery P0 표본, ② Writer/Reader 격리 저장, ③ G-2 소유자 재현은 독립적으로 진행할 수 있다. 이후 같은 snapshot으로 Knowledge·Recovery 읽기 및 Qwen 비교, UD·MSC·Viewer 교차 회귀를 수행한다. 한 단계가 실패해도 승인된 다른 분석, 유효 문서·MSC·영수증은 재사용한다. [Recovery r0008](https://github.com/wonhwipark/L1Work/blob/b7f3a670ffd573e12be3464e16d14bb88c3be391/handoffs/L1_RECOVERY_POINT_ANALYSIS_INTEGRATED_IMPLEMENTATION_HANDOFF_r0008_20261127_KST.md)

## 7. 자체 검토·회귀 인수표

| 증거 수준 | 확인 결과 |
|---|---|
| 이번 공개 ZIP 격리 실행 | Python 3.12.14 / Node v24.22.3. Analyzer의 call/coverage·accuracy/storage·parallel 계약·compile-condition 5개 파일 **85/85 PASS**. 별도로 behavior-doc 9건, legacy inventory 1건, RACH bundle fixture와 resume 스크립트 통과. §3의 G-2 실패를 양성/호환 대조와 함께 재현했다. |
| 이번 표시·보존 회귀 | Viewer v0.5.8의 기존 6개 + Map 2개 **8/8 Node 프로그램 PASS**. Converter v0.2.26의 합성 HTML/SVG 표시 시험 **13/13 PASS**. Kernel v0.7.47의 합성 Work export 2회에서 `knowledge/`, `source-map/` 보호 표본 4파일의 SHA-256 및 목록이 동일했다. Workflow는 로컬 경로 검사 함수만 확인했다. |
| 업무 환경 과거 보고 | Updater v1.9.1 **485/485**, 별도 Confluence 실 export 1 SKIP. Phase E Writer **32/32**, knowledge_tier **59/59**는 의도된 별도 suite. G4 evidence_verified=14, G5 승인 지식 5건 실제 쓰기 보고. G6 그룹 게시·record-publication은 NOT_RUN. 이번 active 버전에 대한 재시험 결과는 별도다. |
| 업무 환경 미실행 | 실제 G-2 원본 bundle 재검증·수정 후 양성 회귀, 실제 Qwen 점수, 개인 Map Writer/Reader 다중 호스트·ACL, 운영 HTML/Viewer 및 그룹 게시 미실행. 읽기 전용 MCP 보고의 잘린 SKILL.md와 과거 캡처는 활성 코드 전체를 대신하지 않는다. |

| 인수 항목 | 업무 GPT에서 남길 판정 |
|---|---|
| T01~T18 / U19~U23 | 기존 시험 재사용. U19는 실제 템플릿 구조와 verified 표시 역할의 호환을 검사한다. U20 두 root 동일 Writer, U21 CAS·부분 실패, U22 동일 snapshot 조회와 fallback, U23 Kernel 보존·Workflow 읽기 전용·기존 메뉴와 MSC를 확인한다. |
| Map 쓰기/조회 반례 | 최초 저장·동일 입력 재시도, 승인 범위/경로 이탈 거부, 경쟁 두 Writer 중 하나만 활성화, 전환 전후 중단·응답 유실, pin된 독자, rename/삭제·양쪽 역의존·다른 build·stale 링크. 이전 유효본과 기존 지식 파일·색인의 bytes/hash를 대조한다. |
| 추출·서술 반례 | §3의 양성/미확인/호환·재개와 §4의 holdout, UD 통과 문서의 잘못된 anchor·뒤집힌 MSC 검출. 기존 485 기준선은 유지하고 32·59 및 실 UD·신규 결손 시험을 별도 실행·집계한다. Confluence 자료 부재는 동일 사유로 SKIP. |
| 회신 한 행의 형식 | `단계 / 소유자 / 실제 변경 파일·활성 해시 / source·build·모델 또는 N/A / 테스트명·분모 / PASS·FAIL·SKIP·NOT_RUN·BLOCKED / evidence·receipt / 승인 범위 / 재개점·다음 행동`. 분석, Knowledge 문서, MSC, Work 보존, 개인 Knowledge, Map 저장, Map 조회, Viewer, 그룹 게시를 별도 행으로 기록한다. |

최초 회신은 **활성 exporter 지문과 실패 bundle의 선택 경로, 개인 Writer/Reader의 같은 root 여부, 대표 사례와 측정 분모**다. 제품 코드·업무 절대 경로·상세 MSC·원본 로그는 업무 Work에 보존하고 공유 시에는 검증 상태와 허용된 참조만 전달한다.
