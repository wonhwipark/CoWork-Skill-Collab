# ACE·PEC-HOP·ACON 독립 설계 리뷰 — 범위·질문

독립 Windows Claude Code 리뷰어는 01~03 문서를 읽고 다음을 비판적으로 검토:
1. ACE: CoWork `CONTEXT_BRIEF→CURRENT→Work/Evidence` 및 L1 Kernel을 재사용하면 새 메모리/원장이 실제로 불필요한가? 정본 충돌과 최신 결정의 우선순위가 타당한가?
2. PEC-HOP: CODE FACT/CL·PR/원본 위치·source revision·모듈/시나리오 조건·부정조건을 무손실 보존할 수 있는가? Issue/Fact/HLD/MSC 원본과 출력 owner가 섞이지 않는가?
3. ACON: full-context 성공/압축본 실패의 재현·반례/통제와 기존 피드백/회귀 경로 연결이 충분한가? 압축률보다 정확성을 먼저 판정하는가?
4. 현재 개발 후보 `l1-fix-workflow`, `l1-github`, `work-ledger-kernel`의 `development_not_for_deployment`, raw Git 우회/G0, 실제 Updater 미확인, 그룹 Knowledge 승인/충돌·writer 경계가 설계에서 보존되는가?
5. 공개 전달/업무 보안·기존 리뷰 승인/서명·READY·중복/비용 fail-closed를 위반하지 않는가?
6. 각 기능에 REUSE/CONNECT/증명된 최소 EXTEND/DEFER를 판정하고 실제 누락/과도한 신규 시스템 제안의 반례를 제시해라.

요청 판정: ACCEPT / ACCEPT_WITH_CHANGE / REVISE / HOLD. 확정 결함과 구조 개선 기회 분리. 결함 0건도 허용; 근거·심각도·최소 수정·미확인·수용 시험을 명시하고 **1회 독립 리뷰** 후 결과/영수증을 게시. 임의 다중 유료 재리뷰·모델 전환·추가 서브에이전트 금지.
