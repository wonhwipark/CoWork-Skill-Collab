"""v0.2.18 gates (synthetic data; no model, no real GitHub):
N1  a result already published for this exact request and package is never reviewed again, even after the local state was lost;
N2  an approval is only honoured when the provider's own repository id equals the id the trust root was issued for (fail closed);
Q8  usage-limit wait -> restart -> other policy revision -> rollback -> cursor loss -> a second process -> state loss: one review."""
from __future__ import annotations

import pytest


from bundle import ROOT, github_policy, make_transport, publish_bundle  # noqa: E402
from skill_collab_watcher import orchestrator  # noqa: E402
from skill_collab_watcher.models import JobState  # noqa: E402
from skill_collab_watcher.state_store import StateStore  # noqa: E402
from skill_collab_watcher.transport_base import AuthRequired, TransportError  # noqa: E402
from test_phase1_github import has_event, run  # noqa: E402
from test_usage_limit_resume import Sequence, clear_hold, limited  # noqa: E402


def lose_state(env):
    env.store.close()
    for suffix in ("", "-wal", "-shm"):
        p = env.tmp / f"state.sqlite3{suffix}"
        if p.exists():
            p.unlink()
    env.store = StateStore(env.tmp / "state.sqlite3")


def published(env):
    files = env.http.files()
    return [p for p in files if p.endswith("RECEIPT_1.md") or p.endswith("REVIEW_RESULT_1.md")]


# --- N1 -------------------------------------------------------------------------------------------------------------------

def test_n1_after_total_state_loss_a_published_result_is_not_reviewed_again(github_env):
    publish_bundle(github_env.http)
    run(github_env, policy=github_policy())
    assert github_env.runner.calls == 1 and len(published(github_env)) == 2
    lose_state(github_env)                                          # new machine / wiped database / restored old backup
    run(github_env, policy=github_policy())
    assert github_env.runner.calls == 1
    assert has_event(github_env.store, "REMOTE_RESULT_EXISTS")


def test_n1_a_result_without_its_receipt_(github_env):
    """The watcher uploads the result first and the receipt second: a crash in between, then state loss, must not start a review."""
    publish_bundle(github_env.http)
    run(github_env, policy=github_policy())
    for path in [p for p in published(github_env) if p.endswith("RECEIPT_1.md")]:
        github_env.http.files().pop(path)
    lose_state(github_env)
    run(github_env, policy=github_policy())
    assert github_env.runner.calls == 1
    assert has_event(github_env.store, "REMOTE_RESULT_EXISTS")


def test_n1_a_failure_reading_the_remote_leaves_the_request_waiting_without_a_review(github_env, monkeypatch):
    publish_bundle(github_env.http)

    def boom(*a, **k):
        raise TransportError("synthetic outage")

    monkeypatch.setattr(orchestrator, "_remote_result_published", boom)
    run(github_env, policy=github_policy())
    assert github_env.runner.calls == 0


# --- N2 -------------------------------------------------------------------------------------------------------------------

def test_n2_a_matching_server_repository_id_lets_the_review_run(github_env):
    publish_bundle(github_env.http)
    run(github_env, policy=github_policy())
    assert github_env.runner.calls == 1


def test_n2_another_repository_id_blocks_the_review(github_env):
    publish_bundle(github_env.http)
    github_env.http.repo_id = "some-other-repository"
    run(github_env, policy=github_policy())
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_REPO_ID_REMOTE_MISMATCH")


def test_n2_a_server_that_reports_no_id_blocks_the_review(github_env):
    publish_bundle(github_env.http)
    github_env.http.repo_id = None
    run(github_env, policy=github_policy())
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_REPO_ID_UNVERIFIABLE")


@pytest.mark.parametrize("error", [AuthRequired("403 for this credential"), TransportError("timeout")])
def test_n2_an_unreadable_identity_blocks_the_review(github_env, monkeypatch, error):
    from skill_collab_watcher.github_transport import GitHubTransport

    publish_bundle(github_env.http)

    def fail(self):
        raise error

    monkeypatch.setattr(GitHubTransport, "repository_id", fail)
    run(github_env, policy=github_policy())
    assert github_env.runner.calls == 0
    assert has_event(github_env.store, "APPROVAL_REPO_ID_UNVERIFIABLE")


# --- Q8 -------------------------------------------------------------------------------------------------------------------

def test_q8_usage_limit_restart_policy_change_rollback_cursor_loss_second_process_and_state_loss_give_one_review(github_env):
    github_env.runner = Sequence([limited("BEFORE_START", 120)])
    publish_bundle(github_env.http)                                             # approval for policy revision 1
    run(github_env, policy=github_policy(local_policy_revision="1"))
    assert github_env.runner.calls == 1                                         # refused before any model work
    assert github_env.store.get_counter(orchestrator.USAGE_HOLD_COUNTER) > 0

    github_env.store.close()                                                    # restart while the window is exhausted
    github_env.store = StateStore(github_env.tmp / "state.sqlite3")
    run(github_env, policy=github_policy(local_policy_revision="1"))
    assert github_env.runner.calls == 1

    publish_bundle(github_env.http, payload_changes={"local_policy_revision": "2", "nonce": "synthetic-nonce-q8-rev2-0001"})
    run(github_env, policy=github_policy(local_policy_revision="2"))            # operator moved to another policy revision
    assert github_env.runner.calls == 1

    publish_bundle(github_env.http, payload_changes={"nonce": "synthetic-nonce-q8-back-0002"})   # and back
    github_env.store.conn.execute("DELETE FROM cursors")                        # with a lost cursor
    other = StateStore(github_env.tmp / "state.sqlite3")                       # a second process on the same database
    try:
        orchestrator.run_scan_cycle(make_transport(github_env.http), other, github_policy(local_policy_revision="1"), github_env.runner,
                                    allowed=True, snapshot_root=github_env.snapshot_root, review_run_dir=github_env.review_run_dir,
                                    remote_root=ROOT, exclusive=False)
    finally:
        other.close()
    run(github_env, policy=github_policy(local_policy_revision="1"))
    assert github_env.runner.calls == 1                                         # still waiting: nothing started in the meantime

    clear_hold(github_env)                                                      # the window is back
    run(github_env, policy=github_policy(local_policy_revision="1"))
    assert github_env.runner.calls == 2                                         # exactly one real review
    assert [j for (j,) in github_env.store.conn.execute("select state from jobs where state=?", (JobState.COMPLETED.value,))] == [JobState.COMPLETED.value]

    lose_state(github_env)                                                      # finally: everything local is gone
    publish_bundle(github_env.http, payload_changes={"nonce": "synthetic-nonce-q8-last-0003"})
    run(github_env, policy=github_policy(local_policy_revision="1"))
    assert github_env.runner.calls == 2
