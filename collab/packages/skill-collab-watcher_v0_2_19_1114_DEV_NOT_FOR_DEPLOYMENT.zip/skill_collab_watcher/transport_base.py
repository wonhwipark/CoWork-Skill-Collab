from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class EntryMeta:
    path: str
    rev: str
    size: int
    content_hash: str
    is_deleted: bool = False
    is_folder: bool = False
    file_id: str = ""


@dataclass
class ListResult:
    entries: list[EntryMeta]
    cursor: str
    has_more: bool


class AuthRequired(Exception):
    """Raised when credentials are missing or rejected. Never raised from
    inside a model call - the watcher must be able to reach this state
    without ever starting a claude process."""


class TransportError(Exception):
    pass


class TransientTransportError(TransportError):
    """Rate limit, 5xx, connection reset or timeout: worth retrying later.

    retry_after is the server-suggested wait in seconds when it gave one.
    Subclasses TransportError so existing `except TransportError` paths keep
    working; only code that wants to distinguish "try again" from "give up"
    needs to look at this type."""

    def __init__(self, message: str, retry_after: float | None = None):
        super().__init__(message)
        self.retry_after = retry_after


class RemoteNotFound(TransportError):
    """The listed remote folder does not exist (e.g. a requests/<id>/ folder
    that was deleted). Permanent for that path, not a transient failure."""


class UploadConflict(Exception):
    def __init__(self, path: str):
        super().__init__(f"path already exists and mode=add: {path}")
        self.path = path


class Transport(ABC):
    @abstractmethod
    def ensure_auth(self) -> None:
        ...

    @abstractmethod
    def list_folder(self, path: str) -> ListResult:
        ...

    @abstractmethod
    def list_folder_continue(self, cursor: str) -> ListResult:
        ...

    @abstractmethod
    def longpoll(self, cursor: str, timeout_sec: int) -> bool:
        """Return True if changes are waiting, without raising on timeout."""

    @abstractmethod
    def download(self, path: str) -> tuple[bytes, EntryMeta]:
        ...

    @abstractmethod
    def get_metadata(self, path: str) -> EntryMeta | None:
        ...

    @abstractmethod
    def upload(self, path: str, data: bytes, mode: str = "add") -> EntryMeta:
        ...

    def server_time(self):
        """The provider's own clock (datetime) from its latest response, or None."""
        return None

    @property
    def provider_name(self) -> str:
        """Scope of pending requests and notifications. Dropbox is the legacy
        scope, so its stored ids stay unprefixed."""
        return "dropbox"

    @property
    def cursor_name(self) -> str:
        """Key of the stored listing cursor. Each provider keeps its own, so a
        cutover or rollback never feeds one provider's cursor to the other."""
        return "skill_collab_root"

    def download_latest(self, path: str) -> tuple[bytes, EntryMeta]:
        """Read the newest revision, ignoring any pin. Used only to verify
        what this watcher just wrote."""
        return self.download(path)

    def repository_id(self) -> str | None:
        """The provider's own identifier of the repository (GitHub: the numeric id), or None for a provider that has no
        such concept. Approvals are only honoured when this equals the id the trust root was issued for."""
        return None

    def pin_current(self) -> str | None:
        """Freeze reads to one revision until unpin(). Providers without
        revisions (Dropbox) keep this no-op."""
        return None

    def unpin(self) -> None:
        return None

    def current_pin(self) -> str | None:
        """The revision reads are currently frozen to, or None."""
        return None
