# Work → Knowledge 독립 설계 리뷰 입력

비민감 설계 문서 전용 입력. 설치/배포용 스킬이 아니며 실행 코드가 없음.
고정 설계 commit: 4f83ca9a83e6bb24f5828b83601f3b2df7e3e9fc
범위: 기존 Work 재사용, 개인 후보/보완, 그룹 승인 게시, 결과·역링크 복구.
실제 API/설치/코드 분석/RAG 본문 소비는 NOT_VERIFIED/NOT_RUN으로 유지.
REVIEW_QUESTIONS.md의 R01~R10만 독립 검토. 자체시험/기능 검증으로 확대 금지.
