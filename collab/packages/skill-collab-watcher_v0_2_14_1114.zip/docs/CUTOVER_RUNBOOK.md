# Cutover runbook: Dropbox to GitHub (v0.2.14, development_not_for_deployment)

Status: a design with isolated test evidence. Nothing here installs, starts or switches anything on the
operating host. Each step marked APPROVAL needs an explicit decision by the user.

## 1. Roles and separation of duties (B-7)

| Role | Holds | Never holds |
|---|---|---|
| Approver (the user, via a signing tool on a separate device or session) | the PRIVATE signing key | the Windows host admin rights used to edit the trust root |
| Windows host admin (the user, on the review PC) | the trust root file, its SHA-256 pin, the GitHub read/write token file | the signing key |
| Watcher process | the PUBLIC key (inside the trust root), the token file path | any private key; it cannot edit the trust root |
| GPT / repository writers | the ability to commit files | any ability to start a review: a commit alone is never an approval |

The signing key and the trust root are never stored in the repository, in prompts or in logs.

## 2. Trust root lifecycle

File: SKILL_COLLAB_TRUST_ROOT_V1 (JSON), kept in a folder only the host admin can write, outside the
repository, outside any synced folder. `tools/trust_root_tool.py build` writes it from PUBLIC keys and prints the
SHA-256 to put in the local config as `github.trust_root_sha256`. The watcher refuses to use a trust root that is
unpinned, whose bytes differ from the pin, whose folder grants write to Everyone/Users/Authenticated Users/
Domain Users, or whose `version` is lower than one it has already accepted.

| Event | Action | Result in the watcher |
|---|---|---|
| Bootstrap APPROVAL | user generates the key pair on the approver device; only the public key is carried to the host | root version 1, one ACTIVE key, pinned |
| Scheduled rotation | publish version N+1 with the old key RETIRED and the new key ACTIVE; update the pin | old key rejected (KEY_RETIRED), new accepted |
| Suspected key exposure | publish version N+1 with that key REVOKED and a new key; update the pin | KEY_REVOKED, all approvals by that key rejected |
| Incident, key state unknown | publish version N+1 with `frozen: true` | every approval rejected (TRUST_ROOT_FROZEN); no key surgery needed |
| Lost signing key | same as exposure: new key, old REVOKED | pending approvals must be signed again |
| Restoring an older file | refused: version is a ratchet | TRUST_ROOT_REFUSED ROLLBACK; recover with a HIGHER version, never a lower one |
| Trust root file damaged or edited | pin mismatch | TRUST_ROOT_REFUSED; approvals cannot be verified, no model call |
| Clock problem | the provider's `Date` header must be within 5 minutes of the local clock | APPROVAL_CLOCK_UNTRUSTED, request waits |

### Independent custody (S-2)

A pin is only as strong as whoever can change it. If the account the watcher runs as can rewrite both the trust root
and the pin, a compromise of that account replaces both and the check proves nothing. In LIVE the watcher therefore
refuses (`TRUST_ROOT_NOT_INDEPENDENT`, default `enforce`) unless its own account, user and groups, has NO write-like
right on: the trust root file, its folder, the configuration file that holds the pin, and that file's folder. The
check uses the Windows effective-rights API; a missing item or an unreadable permission is a finding, not a pass.
`github.trust_root_independence: "warn"` loads the root anyway and records the weakness (development only).

Consequence on a host where the watcher runs as the interactive administrator user: files in that user's own
profile are always changeable by it, so LIVE approvals stay blocked there. The arrangement that passes: the trust
root and the configuration live in a folder writable only by Administrators and readable by the watcher account,
and the watcher runs as a NON-administrator account. The approver's private key is on a different device.

The approver's tool, `tools/approval_signer.py` (`keygen`, `sign`, `check`), runs on the approver's device. `sign`
computes every signed field from the stored bytes of REQUEST, READY and the package, refuses a mismatch, a bad
commit id or a validity over 168 hours, never overwrites an approval, and never prints or copies the private key.
`check` runs the watcher's own verification offline before anything is committed.

The provider's clock also has a high-water mark: if it ever runs backwards by more than 5 minutes the approval is
refused (`provider clock moved backwards`), so a controlled clock source cannot revive an expired approval.

Approvals also carry: nonce (16+ chars), issued_at/expires_at, the repo id, the exact request, READY and package
hashes, the source commit, the policy revision, the run policy and the pinned knowledge hash. They are rejected if
they live longer than `max_approval_lifetime_sec` (default 24 h) or were issued outside the key's own window.
Replay is harmless because a finished logical job (request id, revision, package) is never run again.

Every failure above is fail-closed: it never starts a model call and never falls back to an unsigned path.

## 3. Failure recovery and rollback

1. Stop path (fastest): set `review_policy.enabled=false` in the local config, or publish a frozen trust root.
2. Trust root rollback: not possible by design; publish a higher version that restores the wanted keys.
3. Provider rollback (GitHub back to Dropbox): `switch_provider("github", "dropbox")` is refused while a job is in
   flight; the Dropbox cursor and pending list are kept under their own keys, so nothing is lost or repeated.
4. Database rollback: restore the backup taken before the first v0.2.x open (byte-identical copy). Verified:
   v0.1.5 opens both the migrated copy and the restored backup.
5. Interrupted model call: the next lock-holding watcher seals the job as REVIEW_UNCERTAIN. There is no requeue;
   a new request revision is the only way to review again.

## 4. Settlement of the unsettled Dropbox request (C-1)

Read-only findings on the operating Dropbox (anonymised): 65 request folders; 63 clean REQUEST+READY pairs; 2
folders without a pair.

| Case | What it is | Model calls so far | Decision |
|---|---|---|---|
| F1 (this is also the single pending request) | REQUEST plus one other file, no READY; waiting since 2026-11-09; no job in the database | 0 | HOLD. It is simply waiting for its READY. Do not migrate it. After cutover it needs a fresh GitHub REQUEST/READY with an approval, or it stays on Dropbox |
| F2 | REQUEST only; its READY was removed after the review COMPLETED (1 completed job) | 1 (finished) | SETTLED. Nothing to do; the logical-duplicate rule prevents a repeat |
| G1-G3 (clean pairs, no job) | READY invalid (missing fields, or placeholder knowledge hash); REJECTED once, logged once | 0 | SETTLED as rejected. v0.2.4 rejects the same three |

Zero lost, zero unaccounted, zero repeated model calls. Cutover rule: `switch_provider(..., hold_pending=True)`
records the held ids in the audit log (PENDING_HELD) and keeps them under the Dropbox scope.
`python -m skill_collab_watcher.cli --config ... reconcile` prints the same accounting read-only at any time.

Differential check on all 65 real folders, v0.1.5 against the candidate: identical outcome and processing key for
64; one intended difference: a request that v0.1.5 only caught later as a knowledge-hash mismatch (job already
CONFLICT, no model call) is now rejected at validation for the same reason (63-character hash).

## 5. SHADOW on the host: preparation and gates (S-1: the operating database is never opened)

SHADOW means: no model call, no write to GitHub, no Dropbox access, no Telegram message, and **no access to the
operating database at all**. SQLite's read-only mode still touches the `-shm` index of a WAL database, so
"read-only" is not "untouched" and SHADOW does not use it on the live database.

Configuration: `provider_mode: "SHADOW"`, `transport: "github"`, `shadow.state_dir` (required) and a read-only token.
`local_state_dir` stays the LIVE folder and is used only to prove that the two are separate.
SHADOW keeps its own database, cursors, single-instance lock, runs and snapshots in `shadow.state_dir`.

What the code enforces (fail closed: any doubt means SHADOW does not start and nothing is created):
- the folders must differ, not contain each other, not be empty, relative, a drive root or a network (UNC) path;
- no reparse point (junction, symlink, mount point) anywhere in the shadow path;
- no shared file identity (volume + file index) with the live folder or its ancestors, so aliases that a string
  comparison cannot see are caught; the check runs again after the folder is created;
- the GitHub transport object itself is read-only (a write raises), the runner can never start a review, approvals
  and dispatch are off, the provider lease is not touched, and the live `Config.state_dir` property is never read.

Evidence (isolated): a Windows tripwire holds the live database files open with sharing denied during complete
SHADOW cycles and during the real `watch` command; any open of them would abort the run. It did not. Against the
real PRIVATE repository: GET only. This is proof at the file-handle level for the exercised paths; it is not a
trace of a real host process.

Operator commands (`reconcile`, `status`, `recover`) read the database of the MODE they are configured for. In a
LIVE configuration they do open the live database (read-only for `reconcile`); that is an operator decision, not
something SHADOW does.

APPROVAL gates before SHADOW runs on the host: install the candidate in a separate folder (not over the live
watcher), create a contents-read-only token, and trace the real SHADOW process's file I/O (for example with
Process Monitor) to confirm it never opens the three live database files. Until then the host SHADOW is NOT_RUN.

## 5b. Unattended review execution (scope: automatic reviews only)

Meaning: once an approved READY is published, the watcher runs the Claude Code review with nobody present, and
the user is told the outcome. Development work (code changes) stays user-started.

Already built into the review call: headless `claude -p`, `--permission-mode dontAsk` (never prompts, reads only
the empty working folder and the package snapshot), read-only tools, no MCP servers, no session saved, one run
budget cap per request tier, a time limit, one dispatch per processing key, REVIEW_UNCERTAIN instead of a retry
after an interrupted call.

Added for unattended use (all off or neutral until configured):

| Safeguard | Behaviour | Where it shows |
|---|---|---|
| Login preflight | `claude auth status` (no model call) runs right before a job is claimed. Not logged in, unreadable answer, timeout or missing CLI: the request stays pending, nothing is claimed, no model call, one CLAUDE_AUTH_REQUIRED alert. Re-login resumes by itself | event + Telegram |
| Daily count ceiling | `review_policy.max_dispatches_per_day` over any rolling 24 h; reached: request stays pending | DAILY_LIMIT_BLOCKED |
| Daily spending ceiling | `review_policy.daily_budget_usd` over any rolling 24 h. A dispatch with no recorded cost counts at its cap, so a failing loop cannot spend unseen money. Blocked when spent + this run's cap would exceed it | DAILY_BUDGET_BLOCKED |
| Remote pause | any writer may create `PAUSE_REVIEWS` at the root of the shared folder (`collab/PAUSE_REVIEWS` on GitHub); while it exists no new review starts and requests stay pending. Deleting it resumes. Pausing is the safe direction, so it needs no approval | REVIEWS_PAUSED (not alerted: the user asked for it) |
| Dead-man alert | the notifier compares the newest SCAN_START with the clock: no scan for 15 minutes gives one STALLED alert per outage and one RECOVERED message | Telegram |
| Fail-closed approval | unsigned, expired, wrongly bound, revoked or frozen approvals never reach the preflight, let alone a model call | see section 2 |

Recommended starting values (to be decided by the user): `daily_budget_usd` 3.0, `max_dispatches_per_day` 3.

Host facts read from the existing scheduled tasks (read-only):
- Watcher and notifier start at user logon, restart up to 3 times at 5-minute intervals, have no run-time limit,
  never start a second copy, and run as the interactive user. Consequence: after a reboot nothing runs until that
  user is logged on. For true unattended use after a reboot the host needs automatic sign-in for that user, or a
  task set to run whether or not the user is logged on (Windows then stores the account password). Either is a
  security decision that needs explicit approval; it is NOT done here.
- The Claude Code login belongs to that user profile. The preflight above is what turns an expired login into a
  pause plus an alert instead of a lost request.
- After 3 failed restarts the task stays down; the dead-man alert is what tells the user.
- Sleep: the active power plan is High performance. The host must not sleep or hibernate while unattended.

## 6. Order of the remaining gates

1. APPROVAL: bootstrap the approver key (on the approver's device with `approval_signer keygen`) and the trust root
   (`trust_root_tool build`) in a folder the watcher account cannot write (section 2, independent custody).
2. APPROVAL: host SHADOW for a defined period, with real file-I/O tracing of the SHADOW process (section 5).
3. APPROVAL: one formal independent review through a real signed REQUEST/READY, receipt read back.
4. APPROVAL: database backup, watcher stop, first v0.2.x open (adds three tables), lease set to the active provider.
5. APPROVAL: cutover with `hold_pending=True`; Dropbox stays available for rollback.
6. Notifier: bootstrap from the running notifier's `last_id` per provider and epoch; no history is re-sent.
