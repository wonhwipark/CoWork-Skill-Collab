from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Protocol

from .models import ReviewResult


CLAUDE_CWD_NAME = "_review_cwd"
TRANSCRIPT_DIR_NAME = "transcripts"
MAX_TRANSCRIPT_BYTES = 30 * 1024 * 1024
CACHE_5M_ENV = "FORCE_PROMPT_CACHING_5M"
PREFLIGHT_TIMEOUT_SEC = 30


class ReviewRunner(Protocol):
    def run(
        self, snapshot_dir: Path, prompt_text: str, run_dir: Path,
        max_budget_usd: float | None = None, effort: str | None = None,
    ) -> ReviewResult:
        ...


def _parse_cli_output(stdout: str) -> dict:
    """The CLI's final answer as a dict. `--output-format json` prints one
    object; `--output-format stream-json` prints one event per line and the
    last `type == "result"` event carries the same fields."""
    try:
        parsed = json.loads(stdout)
        return parsed if isinstance(parsed, dict) else {}
    except (json.JSONDecodeError, TypeError):
        pass
    result: dict = {}
    for line in (stdout or "").splitlines():
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(event, dict) and event.get("type") == "result":
            result = event
    return result


def _cli_usage(parsed: dict) -> dict | None:
    """Token usage plus the cost facts needed to size budgets later."""
    usage = dict(parsed.get("usage") or {})
    for key in ("total_cost_usd", "num_turns", "subtype"):
        if parsed.get(key) is not None:
            usage[key] = parsed[key]
    return usage or None


def build_argv(
    claude_exe: str,
    model: str | None,
    allowed_tools: list[str],
    snapshot_dir: Path,
    max_budget_usd: float | None,
    effort: str | None = None,
    stream: bool = False,
) -> list[str]:
    """Flags chosen from `claude --help` on the installed 2.1.218 build
    (checked 2026-11-01, no model call):

    - `-p --output-format json`: non-interactive, parseable result+usage.
      `stream: True` switches to `stream-json --verbose` (one event per turn,
      same final result event) so a per-turn transcript can be kept locally.
    - `--tools <csv>`: restricts the *available* tool set itself (unlike
      --allowedTools, which only skips the approval prompt for tools that
      are still available). Static review only needs read tools.
    - `--permission-mode dontAsk`: never prompts (no TTY) and denies anything
      outside the working directories. `bypassPermissions` (used up to 0.1.2)
      let the Read tool open ANY file the user can read, e.g. secrets.json in
      the parent of the run dir - measured with canary files on 2026-11-03.
      With dontAsk only cwd (an empty dir) and --add-dir (the snapshot) are
      readable.
    - `--setting-sources user`: excludes "project"/"local" settings, so a
      reviewed package's own .claude/settings.json never auto-loads. The user
      settings still apply (this PC: model sonnet, effortLevel xhigh), which is
      why `--effort` is passed explicitly when a run policy names one.
    - `--strict-mcp-config` with no `--mcp-config`: zero MCP servers load,
      so a package's own .mcp.json cannot expand the sandbox.
    - `--no-session-persistence`: no resumable session is written to disk.
    - `--add-dir <snapshot_dir>`: grants read access to the downloaded
      package without using it as cwd (cwd stays the trusted run_dir, so
      CLAUDE.md auto-discovery never walks into the package).
    - deliberately NOT `--bare`: this account authenticates via claude.ai
      OAuth/subscription (confirmed via `claude auth status`), and --bare
      only reads ANTHROPIC_API_KEY/apiKeyHelper, never OAuth/keychain.
    """
    argv = [
        claude_exe,
        "-p",
        "--output-format", "stream-json" if stream else "json",
    ]
    if stream:
        argv.append("--verbose")
    argv += [
        "--tools", ",".join(allowed_tools),
        "--permission-mode", "dontAsk",
        "--setting-sources", "user",
        "--strict-mcp-config",
        "--no-session-persistence",
        "--add-dir", str(snapshot_dir),
    ]
    if model:
        argv += ["--model", model]
    if effort:
        argv += ["--effort", effort]
    if max_budget_usd is not None:
        argv += ["--max-budget-usd", str(max_budget_usd)]
    return argv


class RealReviewRunner:
    """The only class in this project allowed to start a `claude` process.

    Every other module (orchestrator, validator, transports, cli scan/
    status/recover) must reach every decision - WAIT_INPUT, CONFLICT,
    REJECTED, DUPLICATE, AUTH_REQUIRED - without touching this class.
    tests/test_no_model_calls.py never imports or instantiates this class;
    it only uses FakeReviewRunner, and a separate static check greps the
    rest of the package for subprocess/Popen calls outside this file.
    """

    def __init__(
        self,
        claude_exe: str,
        model: str | None,
        allowed_tools: list[str],
        max_budget_usd: float | None,
        timeout_sec: int,
        prompt_cache_ttl: str = "1h",
        save_transcript: bool = False,
    ):
        self.claude_exe = claude_exe
        self.model = model
        self.allowed_tools = allowed_tools
        self.max_budget_usd = max_budget_usd
        self.timeout_sec = timeout_sec
        self.prompt_cache_ttl = prompt_cache_ttl
        self.save_transcript = save_transcript

    def _child_env(self) -> dict[str, str] | None:
        """Only the review process gets the cache-TTL switch; the user's own
        interactive Claude sessions and global settings are not touched."""
        if self.prompt_cache_ttl != "5m":
            return None
        env = dict(os.environ)
        env[CACHE_5M_ENV] = "1"
        return env

    def _keep_transcript(self, run_dir: Path, snapshot_dir: Path, stdout: str) -> None:
        """Best effort, local only (never uploaded). Failure to write must not
        change the review outcome."""
        try:
            data = stdout.encode("utf-8")
            if not data or len(data) > MAX_TRANSCRIPT_BYTES:
                return
            out = run_dir / TRANSCRIPT_DIR_NAME
            out.mkdir(parents=True, exist_ok=True)
            (out / f"{snapshot_dir.name}.jsonl").write_bytes(data)
        except OSError:
            pass

    def preflight(self) -> tuple[bool, str]:
        """Is the CLI logged in? `claude auth status` makes no model call. An
        unattended watcher checks this before claiming a job, so an expired login
        pauses the queue instead of turning the next request into a terminal
        FAILED. Only a reason code is returned: the account details in the CLI's
        answer are never kept."""
        try:
            proc = subprocess.run(
                [self.claude_exe, "auth", "status", "--json"],
                capture_output=True, encoding="utf-8", errors="replace",
                shell=False, timeout=PREFLIGHT_TIMEOUT_SEC,
            )
        except subprocess.TimeoutExpired:
            return False, "CLAUDE_CLI_TIMEOUT"
        except OSError:
            return False, "CLAUDE_CLI_NOT_FOUND"
        try:
            parsed = json.loads(proc.stdout)
        except (json.JSONDecodeError, TypeError):
            return False, "CLAUDE_STATUS_UNREADABLE"
        if proc.returncode == 0 and isinstance(parsed, dict) and parsed.get("loggedIn") is True:
            return True, "ok"
        return False, "CLAUDE_NOT_LOGGED_IN"

    def run(
        self, snapshot_dir: Path, prompt_text: str, run_dir: Path,
        max_budget_usd: float | None = None, effort: str | None = None,
    ) -> ReviewResult:
        budget = self.max_budget_usd if max_budget_usd is None else max_budget_usd
        argv = build_argv(self.claude_exe, self.model, self.allowed_tools, snapshot_dir, budget,
                          effort=effort, stream=self.save_transcript)
        # Empty working directory: it is the only place besides the snapshot
        # the reviewer may read, so it must not hold results or state.
        cwd = run_dir / CLAUDE_CWD_NAME
        cwd.mkdir(parents=True, exist_ok=True)
        try:
            # encoding is explicit: text=True alone decodes with the Windows
            # ANSI code page (cp949 here), but the CLI speaks UTF-8.
            proc = subprocess.run(
                argv,
                input=prompt_text,
                capture_output=True,
                encoding="utf-8",
                errors="replace",
                cwd=str(cwd),
                env=self._child_env(),
                shell=False,
                timeout=self.timeout_sec,
            )
        except subprocess.TimeoutExpired:
            # Unknown whether the model was actually invoked before the
            # timeout - count it as a call and let the caller mark the job
            # REVIEW_UNCERTAIN rather than silently retrying.
            return ReviewResult(
                ok=False, output_text="", output_format="json", exit_code=-1,
                model_calls=1, usage=None, error=f"timeout after {self.timeout_sec}s",
            )

        if self.save_transcript:
            self._keep_transcript(run_dir, snapshot_dir, proc.stdout)
        parsed = _parse_cli_output(proc.stdout)
        usage = _cli_usage(parsed)
        cli_failed = parsed.get("is_error") is True or str(parsed.get("subtype", "")).startswith("error")
        if proc.returncode == 0 and not cli_failed:
            output_text = parsed.get("result") if parsed else proc.stdout
            return ReviewResult(
                ok=True, output_text=output_text if isinstance(output_text, str) else proc.stdout,
                output_format="json", exit_code=0, model_calls=1, usage=usage,
            )
        # Exit code 1 + subtype error_max_budget_usd was measured for a run that
        # exceeded --max-budget-usd (result null, cost recorded). Say why, so an
        # operator can tell a budget stop from any other failure.
        reason = f"claude_cli_failed exit={proc.returncode}"
        if parsed.get("subtype"):
            reason += f" subtype={parsed['subtype']}"
        if parsed.get("total_cost_usd") is not None:
            reason += f" total_cost_usd={parsed['total_cost_usd']}"
        if budget is not None:
            reason += f" max_budget_usd={budget}"
        stderr_tail = proc.stderr[-1500:] if proc.stderr else ""
        return ReviewResult(
            ok=False,
            output_text=json.dumps(parsed, ensure_ascii=False) if parsed else (proc.stdout or "")[:20000],
            output_format="json",
            exit_code=proc.returncode, model_calls=1, usage=usage,
            error=(reason + (f" | stderr: {stderr_tail}" if stderr_tail else ""))[:4000],
        )
