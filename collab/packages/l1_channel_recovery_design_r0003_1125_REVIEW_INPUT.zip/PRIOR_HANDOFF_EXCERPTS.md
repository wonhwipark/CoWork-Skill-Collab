# r0003과 대조할 기존 공개 인계 원문 발췌

각 범위는 기재한 L1Work 커밋에서 읽은 원문 행이에요. 현재 심사 대상은 함께 제공하는 r0003 전문이에요.

## L1_RECOVERY_POINT_ANALYSIS_DETAILED_DESIGN_AND_IMPLEMENTATION_HANDOFF_r0002_20261119_KST.md · 59–68행

https://github.com/wonhwipark/L1Work/blob/891b05ccb794d67ea7ea168d2f96e2d8444a0ec8/handoffs/L1_RECOVERY_POINT_ANALYSIS_DETAILED_DESIGN_AND_IMPLEMENTATION_HANDOFF_r0002_20261119_KST.md#L59-L68

### 2.3 세 가지 판단을 구분

| 판단 | 질문 | 필요한 근거 |
|---|---|---|
| 정적·설계상 유사 결함 탐색 | 현재 코드에 같은 위험 원인 구조가 남아 있는가? | 실제 대상 코드·전제·실행 경로·기존 보호 조사 |
| 런타임 검출 가능성 | 실행 중 정상과 오류를 구분할 수 있는 신호가 있는가? | 해당 순간의 반환값·상태·이벤트·신뢰 가능한 관측 |
| recovery 적합성 | 검출 시점에 소유자가 안전한 상태로 되돌릴 수 있는가? | 정리 권한·부분 부작용·복귀 조건·공유 영향·실제 검증 |

첫 번째가 성립해도 두 번째나 세 번째가 자동 성립하지 않아요. 오류를 실행 중 구분할 수 없다면 원인 수정·사전 검증·관측 보강이 적합할 수 있어요. 모든 후보를 recovery로 해결하지 않아요.


## L1_RECOVERY_POINT_ANALYSIS_DETAILED_DESIGN_AND_IMPLEMENTATION_HANDOFF_r0002_20261119_KST.md · 237–255행

https://github.com/wonhwipark/L1Work/blob/891b05ccb794d67ea7ea168d2f96e2d8444a0ec8/handoffs/L1_RECOVERY_POINT_ANALYSIS_DETAILED_DESIGN_AND_IMPLEMENTATION_HANDOFF_r0002_20261119_KST.md#L237-L255

### 9.1 후보 처리 결과

- 직접 수정 누락: 동일 위치/기능에 원래 Fix 또는 동등한 해결이 빠짐
- 미커버 유사 원인 구조: 다른 경로에 전제·위험·보호 공백이 코드 근거로 확인됨
- 이미 보호됨: 동등한 보호 위치와 적용 범위가 확인됨
- 전제 불성립: 해당 자원을 사용하지 않거나 실패 계약·빌드·설계가 다름
- 보류: 실행·보호·소유 계약의 필수 근거 부족

분류는 기존 artifact의 내용으로 기록해요. 새로운 Kernel enum·상태 전이·Evidence kind를 추가하라는 뜻이 아니에요.

### 9.2 세 가지 커버를 혼동하지 않기

| 커버 의미 | 기록할 것 | 보장하지 않는 것 |
|---|---|---|
| 분석 범위 커버 | 실제 조사한 파일·호출 경계·옵션·revision·남은 범위 | 조사 밖 코드의 안전성 |
| 보호 커버 | 해당 실패 경로에 적용되는 실제 검사·정리·대체 설계 | 다른 입력·수명·공유 상황까지 전부 안전 |
| 시험 커버 | 실제 수행한 조건·주입 지점·실행 환경·결과 | 미시험 HW·경쟁·제품 효과 |

특정 범위에서 새 후보를 찾지 못했다면 '해당 기준·조사 범위에서 미커버 근거를 찾지 못함'으로 보고해요. 전체 결함 부재를 선언하지 않아요.

## L1_RECOVERY_POINT_ANALYSIS_DETAILED_DESIGN_AND_IMPLEMENTATION_HANDOFF_r0002_20261119_KST.md · 272–301행

https://github.com/wonhwipark/L1Work/blob/891b05ccb794d67ea7ea168d2f96e2d8444a0ec8/handoffs/L1_RECOVERY_POINT_ANALYSIS_DETAILED_DESIGN_AND_IMPLEMENTATION_HANDOFF_r0002_20261119_KST.md#L272-L301

### 10.2 런타임 검출 조건

- 해당 순간에 실제 읽을 수 있는 반환값·상태·이벤트인지 확인해요.
- Jira Cause·사후 로그·미래 결과를 알아야만 성립하는 조건을 검출부에 넣지 않아요.
- 정상 지연·정상 중간 상태·허용된 다른 절차와 구분해야 해요.
- 기존 보호나 HW 오류 처리에 이미 포함된 조건인지 확인해요.
- 오류 확산 또는 신뢰 가능한 복구 기회를 잃기 전에 검출할 수 있는지 확인해요.

정적 분석으로 잘못된 계산을 발견했어도 runtime 값이 모두 정상 범위이고 독립 판별 근거가 없으면 recovery 후보로 확정하지 않아요.

### 10.3 실제 복구 수행 경계

복구 책임자는 해당 시점의 상태·자원을 변경·반납하고 종료 결과를 책임질 런타임 소유자예요. CL 작성자·공식 담당자·최초 감지자·최초 할당 함수와 구분해요. 소유권 이전·공유 조정자·task/IRQ·lock·객체 수명을 확인해요.

검출부와 소유 경계가 같고 호출 계약이 맞으면 직접 기존 실패 처리를 사용할 수 있어요. 다르면 기존 반환값·이벤트·작업 전달을 사용해 소유자에게 넘겨요. 새 메시지·task·전역 manager를 기본 요구로 만들지 않아요.

같은 작업·객체·세대의 정리·최종 통지가 중복 성립하지 않도록 기존 직렬화·식별·수명 관리를 검증해요. 단순 전역 boolean이나 분산 exactly-once 보장을 답으로 삼지 않아요.

### 10.4 국소 recovery 후보의 필수 조건

| 조건 | 입증할 근거 |
|---|---|
| 신뢰할 오류 신호 | 정상 경로와 구분 가능한 현재 관측값·분기 |
| 정리 권한 | 실제 자원 소유·오류 전파·종료 책임 |
| 부분 부작용 처리 | 실제 획득·HW 적용·참조 상태와 정리/재설정 지원 |
| 복귀 상태 | SW/HW·자원 일치와 확인 수단 |
| 경쟁·공유 통제 | 중복·release·새 작업·다른 Stack/CC 영향 |
| 제한과 실패 종료 | 시간·고정 자원·재시도·복구 중 오류·상위 이관 |

정상 release 함수도 부분 실패 상태·현재 문맥·공유 자원 범위에 맞는지 확인한 뒤 재사용해요. flag 초기화만으로 HW 상태가 정상이라고 보고하지 않아요. 신뢰할 수 있는 복귀 상태를 입증 못 하면 국소 recovery는 보류해요.

## L1_RECOVERY_WORKSPACE_IMPLEMENTED_CONTRACT_HANDOFF_r0002_20261120_KST.md · 50–65행

https://github.com/wonhwipark/L1Work/blob/891b05ccb794d67ea7ea168d2f96e2d8444a0ec8/handoffs/L1_RECOVERY_WORKSPACE_IMPLEMENTED_CONTRACT_HANDOFF_r0002_20261120_KST.md#L50-L65

## 4. 분석 절차에 반영할 최소 보완

| 단계 | 방법·필수 근거 | 남길 결과·종료 조건 |
|---|---|---|
| A. 입력 고정 | CL/PR 설명·수정 전후 실제 diff/revision, 현재 source·제품/빌드/활성 조건·범위·관련 로그/테스트 확인. merged 사실과 현재 제품/branch 반영 구분 | Seed와 현재 대상의 대응·차이·미접근. 핵심 revision 불명은 해당 판단 보류 |
| B. 결함 복원 | 증상·원인·발생 전제·객체/수명·호출/IPC 순서·깨진 불변 조건·Fix 보장/제외 범위. 설명 주장과 코드 사실 구분 | 원인 하나의 규칙과 anchor. 기능 추가 등 비결함 CL은 알려진 결함 Seed로 강제하지 않음 |
| C. 추적 범위 | 원인과 관련된 caller/callee·상태 reader/writer·초기화/해제/재사용·callback/timer/IPC·실패/취소/복구·공통/상위 보호·조건부 빌드 확인 | 조사 경계·분석 확대 이유·남은 경계. 관련 RAT/Stack/domain/CC/절차만 선택 |
| D. 규칙·보정 | 아래 규칙 표를 작성하고 역사적 결함·수정 후·안전한 유사 사례와 대조 | 검색 매치와 위험 판정 구분. 같은 전제에서 Fix 효과를 설명하지 못하면 규칙 보류/수정 |
| E. 단계적 탐색 | 좁은 기준에서 시작해 검색 의미 또는 공간 범위를 한 번에 한 요소씩 확대. 전체 허용 루트의 좁은 검색과 후보별 정밀 읽기를 구분 | 검색식·유지/일반화 조건·전체 매치·고유 후보·미분석 보존. 잡음 급증 시 조건 재조정 |
| F. 후보 검증 | 입력 유입·전제·같은 객체/세대·실행/빌드 경로·위반·caller/callee/HAL/PHY 보호·후속 fix·반례 확인 | 아래 판정과 결정 근거. 결정적인 보호/도달성 경계가 미확인이면 확정하지 않음 |
| G. 조치 판단 | 근본 수정 가능성, 기존 recovery 포괄, 수정 후 잔여 위험, 실제 검출 신호·권한·안전 복귀 대조 | 원인 수정/예방/관측/국소 recovery/상위 이관 또는 보류. 결함 확인만으로 recovery를 정답으로 정하지 않음 |

관련 비교 축은 LTE/NR, Stack/domain, SCell config/activation/deactivation/release, Tx switching·Dual SIM, DRX/CDRX, L1C/HAL/RF/PHY IPC 중 원인과 관계가 있는 것만 선택해요. 모든 축을 매번 분석하지 않아요.

필요한 코드는 후보 하나의 의미 단위로 제공해요. 관련 분기·return·cleanup·객체/필드 정의·상위 보호를 무작정 잘라내지 않아요. 근거가 부족하면 필요한 정의/호출 경계만 추가 조회하고, 새 근거가 없거나 예산이 소진되면 잔여 후보와 이유를 보존하고 부분 조사로 종료해요.


## L1_RECOVERY_WORKSPACE_IMPLEMENTED_CONTRACT_HANDOFF_r0002_20261120_KST.md · 79–104행

https://github.com/wonhwipark/L1Work/blob/891b05ccb794d67ea7ea168d2f96e2d8444a0ec8/handoffs/L1_RECOVERY_WORKSPACE_IMPLEMENTED_CONTRACT_HANDOFF_r0002_20261120_KST.md#L79-L104

### 후보 판정과 확정 근거

| 판정 | 필요한 설명 |
|---|---|
| 이미 해결됨 | 현재 수정 또는 동등 보호가 위반 경로를 막는 코드 근거 |
| 발생 불가능 | 현재 대상의 빌드·입력·객체/수명·실행 전제가 성립하지 않는 근거 |
| 미해결 결함 확인 | 같은 객체/작업에서 입력→전제→실행→위반이 이어지고, 관련 보호 경계를 대조한 근거. 코드로 입증한 범위와 실제 실행 검증을 별도 명시 |
| 추가 검증 필요 / 근거 부족 | 결정적인 옵션·caller/callee·동일성·순서·보호 등 남은 항목과 다음 조회 하나 |

기존 r0002의 직접 Fix 누락·미커버 변형·보호됨·전제 불성립·보류는 세부 사유로 유지해요. 분류 이름을 맞추느라 과거 결과를 삭제하거나 중복 후보를 만들지 않아요. 코드가 비슷하다거나 보호를 찾지 못했다는 사실만으로 미해결 결함을 확정하지 않아요.

Recovery가 필요한 후보는 검출/진입·금지 조건, 실제 상태/자원 소유자, 영향 범위·순서·동시성, 타 Stack/정상 경로 영향, 중복/반복 방지, 완료·실패 처리와 관측/검증을 추가 검토해요.

## 5. 효과 평가 계획

보정에 사용한 Seed와 평가용 사례를 구분해요. 평가 사례로 규칙을 수정하면 그 사례는 보정용으로 옮기고 별도 평가 사례를 남겨요.

- 수정된 Seed, 알려진 누락/미해결 유사 결함.
- 닮았지만 정상인 경로, 다른 계층에서 보호된 경로, 실행 조건 불성립 경로.
- 자료 부족 사례, 검색 결과 잘림·중단·재개·의존 코드 변경 사례.

같은 모델/설정·source·사례·도구·예산·기존 결과 재사용 조건에서 기존/확장 절차를 비교해요. 확인된 신규 결함·오탐/이미 해결됨 재보고·알려진 결함 누락·적절한 보류·trace·동일 입력의 변동과 시간/호출/입출력량을 함께 기록해요.

정답 집합이 있는 사례 세트에서만 그 집합에 대한 누락/재현율을 계산해요. 실제 코드의 알려지지 않은 결함 전체에 대한 재현율을 주장하지 않아요. 한두 건은 절차 확인이며 효과 판정에는 여러 대표 사례가 필요해요.

이 절은 **계획**이에요. 아래 저장 스킬의 시험 통과 수를 이 분석 방법의 정확도나 L1 제품 효과로 보고하지 않아요.

## L1_CHANNEL_RECOVERY_WORKSPACE_VIEWER_NEW_CHAT_HANDOFF_r0002_20261124_KST.md · 51–61행

https://github.com/wonhwipark/L1Work/blob/891b05ccb794d67ea7ea168d2f96e2d8444a0ec8/handoffs/L1_CHANNEL_RECOVERY_WORKSPACE_VIEWER_NEW_CHAT_HANDOFF_r0002_20261124_KST.md#L51-L61

## 3. 업무 GPT가 수행하는 Recovery 분석 흐름

1. 기존 merged GitHub PR 또는 P4 submitted CL(시드)을 입력으로, 수정 전/후 코드의 실제 결함 원인을 분석한다.
2. 결함 원인을 대상 객체·상태·순서·조건·누락된 방어 등의 검증 가능한 **원인 규칙**으로 구조화한다.
3. 현행 코드에서 유사 패턴 후보를 찾는다. **Caller·Callee·공통 계층의 기존 방어** 및 실행 가능성을 확인하고, 이미 해결/불가능한 후보를 배제한다.
4. 필요 시 `원인 수정 / 사전 검사 / 런타임 Recovery / 상위 절차 이관 / 추가 근거 필요` 등을 비교하고 실제 Recovery 필요성을 판정한다.
5. 저사양 LLM에 맞춰 탐색을 순차로 수행하고, 확대/종료 기준·반례·검증되지 않은 가정을 명확하게 기록한다.
6. MSC가 유의미한 경우 기존 `doc-converter`를 써서 **Seed 수정 전·후**, **후보 AS-IS**, **조치 TO-BE** MSC를 산출한다. Converter 결과 HTML/SVG/PlantUML은 원본 입력·revision과 함께 연결한다.

**Edge 관련 미확정 사항**: 과거 11/19 인계에 위 MSC 구분은 명시됐다는 이전 검토 결과가 있다. 반면 `Edge`가 무엇을 의미하는지(예: 인과 관계의 호출/상태 전이, 그래프 Edge, 특정 검증 결과 등) 및 별도 산출물의 스키마·판정 계약은 **기존 공개 인계에서 확정적으로 확인되지 않았다**. 이를 임의 정의하지 않는다. 업무 GPT에 Edge의 의미·생성 조건·출력 형식·Evidence 링크·AS-IS/TO-BE에서의 표현을 확인한 후 Kernel/Viewer 표시만 매핑한다.


## L1_CHANNEL_RECOVERY_VIEWER_KERNEL_CONVERTER_COMPLETE_HANDOFF_r0001_20261124_KST.md · 19–25행

https://github.com/wonhwipark/L1Work/blob/891b05ccb794d67ea7ea168d2f96e2d8444a0ec8/handoffs/L1_CHANNEL_RECOVERY_VIEWER_KERNEL_CONVERTER_COMPLETE_HANDOFF_r0001_20261124_KST.md#L19-L25

## 2. 책임과 분석·MSC 구분

1. l1-channel-recovery 스킬 자체와 분석 의미는 업무 GPT 책임. 기존 merged PR/P4 submitted CL의 Seed 수정 전·후 원인 구조를 배우고, 현재 코드의 다른 경로에서 실제 미커버 여부, 호출자/callee/wrapper/상위 보호, 반례·빌드·자원 소유·복귀 가능성을 검증. 해결된 Seed에 recovery를 억지 추가하지 않음. REQ→CNF 미수신 timeout과 이미 커버된 해당 메커니즘 제외.
2. 업무 GPT는 실제 지원되는 기존 code-analyzer와 doc-converter의 입력·출력 계약 확인 후, 의미 있는 시나리오별 **Seed 수정 전, Seed 수정 후, 후보 AS-IS, 조치 TO-BE** MSC를 생성. 실제 Converter 실행 근거, 입력 source revision/IR, 원본 PlantUML, SVG, B형 HTML 및 manifest/SHA를 동일 Work에 남김. 파일이 없으면 링크를 만들어서는 안 됨.
3. Edge의 의미·판정·출력은 업무 GPT가 원본 분석 계약으로 정의하고 source/Evidence로 뒷받침해야 함. Viewer/Kernel이 그래프 Edge나 결과를 임의 정의하지 않음. 미확정이면 화면에 미확정으로 표시.
4. Kernel은 이미 존재하는 Work/Evidence와 승인된 writer의 source hash·Evidence revision·중복/CAS/readback을 재사용. 분석기 실행, 새 DB·profile·writer·Knowledge 게시 역할 없음.
5. Viewer는 읽기 전용 회복 사례 목록·상세·Work/Evidence와 확인된 HTML/SVG/PUML artifact 연결만 담당. HTML 원문 직접 삽입, 임의 파일 경로, 확인되지 않은 URL 프록시·unsafe iframe 금지.
