# Per-review budget policy (v0.2.28 development)

Unified default for every new independent review: USD 3.00, single `run_policy_ref=POLICY-STATIC-V1`.
No daily/monthly cost or count ceilings. Do not auto-upgrade a request. The DESIGN/LARGE names below
exist only for manual approval (`approve_request.py`) of individual requests; the automatic signer
never admits them, at any registered budget or delegation headroom.

Configure the existing local reviewer.config.json review_policy block:
  "max_budget_usd": 3.0,
  "known_run_policy_refs": {
    "POLICY-STATIC-V1": {"max_budget_usd": 3.0},
    "POLICY-STATIC-V1-LARGE": {"max_budget_usd": 3.0},
    "POLICY-STATIC-V1-DESIGN": {"max_budget_usd": 3.0}
  },
  "daily_budget_usd": null,
  "max_dispatches_per_day": null

Existing protected delegation JSON must explicitly permit USD 3.00:
  "policy": "POLICY-STATIC-V1",
  "max_request_usd": 3.0

The request names only run_policy_ref, never the price. `POLICY-STATIC-V1` requires the
pre-existing permitted project/skill and valid SOURCE_PIN/signature/READY, same as before.
`POLICY-STATIC-V1-LARGE` and `POLICY-STATIC-V1-DESIGN` are REVIEW_POLICY-refused by the
automatic engine unconditionally (v0.2.27, `auto_policy.py::assess`) -- registering either name
at any budget, or raising the delegation's `max_request_usd`, does not make them auto-eligible.
Those two names remain usable only through the existing manual approval tool. Do not silently
convert an unapproved request from one tier to another.

Only change the local values via the existing protected policy process; ensure new settings,
SHA pins, backup/rollback, and Windows host regression. The published ZIP and this document do
not install or activate LIVE settings. Legacy max_day_usd/max_month_usd/max_day_calls keys are
accepted but ignored. Existing UNCERTAIN requests remain permanently claimed; history is preserved.
