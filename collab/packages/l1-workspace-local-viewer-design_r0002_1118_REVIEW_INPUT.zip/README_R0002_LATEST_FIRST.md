# REVIEW INPUT R0002 — 최신 요구 우선

- Work: L1-WORKSPACE-RAG-20261111-001; R1 리뷰 요청 ID 예약: REQ-L1-WORKSPACE-LOCAL-VIEWER-DESIGN-R1-20261118 (정식 REQUEST 아직 미등록)
- 최신 요구사항은 06_FULL_WORKSPACE_TREE_VIEWER_DESIGN_DELTA_r0002.md. 업무망 내 전체 Workspace 폴더 URL 탐색, Work별 승인 allowlist 기본 제거, Markdown 즉석 렌더/HTML·SVG·JSON·PDF 원본 직접 표시. 상세 기준: Delta 내 R23~R27/T27~T34.
- 기존 7파일은 r0001 고정 입력 원본, FILE_INDEX.json은 r0001 역사적 index. 상충하면 최신 06 Delta 우선. 기존 7파일 bytes/CRC/offset 그대로 보존.
- Windows LIVE PREFLIGHT_BLOCKED: POLICY_COST_MISMATCH (최저 정책 USD 1.50 > 현재 유효 자동 위임 USD 1.00). 사용자 새로운 비용 승인 없이 REQUEST/SOURCE_PIN/APPROVAL_SIG/READY/모델 호출 금지.
- 새 r0002 패키징은 **리뷰 실행 아님**. 업무 Linux 설치/웹 서버 노출/Work source/Group Knowledge 변경은 별도 단계.
