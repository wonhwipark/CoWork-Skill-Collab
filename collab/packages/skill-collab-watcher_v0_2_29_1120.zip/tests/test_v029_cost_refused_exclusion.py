"""v0.2.29: a request refused only by the per-request cap is excluded for good. Raising the cap later must not admit it retroactively,
even when enabled_at is not refreshed. Synthetic data, throw-away key, fake GitHub, no model."""
from __future__ import annotations

import time

from auto_helpers import CountingSigner, auto, has, make_request, remote, write_delegation  # noqa: F401
from bundle import make_transport  # noqa: E402


def direct(auto_ns, rid, info):
    transport = make_transport(auto_ns.env.http)
    transport.ensure_auth()
    return auto_ns.approver.process(transport, auto_ns.env.store, auto_ns.policy, "/SKILL-COLLAB", rid, info.request.decode(), info.request).status


def test_a_cost_refused_request_stays_excluded_after_the_cap_is_raised_without_touching_enabled_at(auto):
    first = write_delegation(auto.delegation, max_request_usd=0.5)
    a = make_request(auto.env.http, "REQ-A")
    assert direct(auto, "REQ-A", a) == "PER_REQUEST_COST"
    write_delegation(auto.delegation, max_request_usd=3.0, enabled_at=first["enabled_at"])
    assert direct(auto, "REQ-A", a) == "POLICY_STOPPED"
    assert remote(auto.env, "requests/REQ-A/READY.md") is None
    assert auto.signer.calls == 0
    assert auto.env.store.auto_get_claim("REQ-A", "1")["stage"] == "POLICY_STOPPED"


def test_b_a_request_first_seen_after_the_raise_is_still_admitted(auto):
    first = write_delegation(auto.delegation, max_request_usd=0.5)
    a = make_request(auto.env.http, "REQ-A")
    direct(auto, "REQ-A", a)
    write_delegation(auto.delegation, max_request_usd=3.0, enabled_at=first["enabled_at"])
    b = make_request(auto.env.http, "REQ-B")
    assert direct(auto, "REQ-B", b) == "READY_POSTED"
    assert remote(auto.env, "requests/REQ-B/READY.md") is not None


def test_c_a_cost_refused_request_is_not_counted_as_a_call_in_the_usage_telemetry(auto):
    write_delegation(auto.delegation, max_request_usd=0.5)
    a = make_request(auto.env.http, "REQ-A")
    direct(auto, "REQ-A", a)
    usage = auto.env.store.window_usage(int(time.time()))
    assert usage["day_calls"] == 0 and usage["day_cents"] == 0 and usage["month_cents"] == 0
