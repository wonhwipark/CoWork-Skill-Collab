"""One fixed tool for the step that was missing: turn a request that GPT already posted into a watcher-runnable one.

  check   <request_id>                         read-only (GitHub GET + a byte copy of the watcher DB). Nothing is signed or written.
  approve <request_id> --max-usd N --execute   sign with the approver key (2 h) and post APPROVAL_SIG.json, then READY.md LAST, create-only.

`approve` refuses unless: check passes, --execute is given, and --max-usd equals the policy cap of the request (the user's explicit
cost decision must be typed, not assumed). It never runs a model and never overwrites a remote file. No token or key is printed."""
import argparse
import base64
import hashlib
import json
import os
import pathlib
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import zipfile

sys.dont_write_bytecode = True
DEPLOY = pathlib.Path(os.environ.get("SKILL_COLLAB_DEPLOY") or r"D:\User\whpark\skill-collab-watcher-github")
APPROVER = pathlib.Path(r"D:\User\whpark\cowork-phase1\a_review")
sys.path.insert(0, str(DEPLOY))
sys.path.insert(0, str(APPROVER))
from skill_collab_watcher import approval, validator  # noqa: E402
from skill_collab_watcher.config import Config  # noqa: E402
from skill_collab_watcher.models import ValidationOutcome  # noqa: E402

R = "wonhwipark/CoWork-Skill-Collab"
h = lambda b: hashlib.sha256(b).hexdigest()
LOCAL = pathlib.Path(os.environ["LOCALAPPDATA"])
results = []


def ok(name, cond, detail=""):
    results.append(bool(cond))
    print(("PASS " if cond else "FAIL ") + name + (f"  [{detail}]" if detail else ""))
    return bool(cond)


def gh(*a, inp=None):
    p = subprocess.run(["gh", *a], capture_output=True, input=inp)
    return p.returncode, p.stdout.decode("utf-8", "replace").strip(), p.stderr.decode("utf-8", "replace").strip()


def raw(path, ref="main"):
    p = subprocess.run(["gh", "api", "-H", "Accept: application/vnd.github.raw", f"repos/{R}/contents/{path}?ref={ref}"], capture_output=True)
    return p.stdout if p.returncode == 0 else None


def exists(path):
    return gh("api", f"repos/{R}/contents/{path}?ref=main", "--jq", ".sha")[0] == 0


def put(path, data, message):
    if exists(path):
        sys.exit(f"already exists, stop (never overwrite): {path}")
    body = {"message": message, "branch": "main", "content": base64.b64encode(data).decode()}
    rc, out, err = gh("api", "-X", "PUT", f"repos/{R}/contents/{path}", "--input", "-", "--jq", ".commit.sha", inp=json.dumps(body).encode())
    if rc:
        sys.exit("PUT failed: " + err[:200])
    return out


def load_policy():
    cfg = Config.load(str(DEPLOY / "config" / "reviewer.config.json"))
    rp = cfg.review_policy
    pol = validator.LocalPolicy(active_baseline_id=cfg.baseline_id, local_policy_revision=str(cfg.schema_version),
                                known_run_policy_refs=list(rp.known_run_policy_refs), run_budgets_usd={k: rp.budget_for(k) for k in rp.known_run_policy_refs})
    return cfg, pol


def check(rid):
    ctx = {}
    base = f"collab/requests/{rid}"
    req_b, pin_b = raw(f"{base}/REQUEST.md"), raw(f"{base}/SOURCE_PIN.json")
    if not ok("REQUEST.md is readable on main", req_b):
        return None
    req_t = req_b.decode("utf-8")
    cfg, pol = load_policy()
    front = validator.parse_front_matter(req_t)
    ref = str(front.get("run_policy_ref"))
    cap = pol.run_budgets_usd.get(ref)
    ok("run policy is registered on this host", ref in pol.known_run_policy_refs, f"{ref}, cap USD {cap}")
    ok("no APPROVAL_SIG.json and no READY.md yet (nothing to repeat)", not exists(f"{base}/APPROVAL_SIG.json") and not exists(f"{base}/READY.md"))
    for d in ("dispatch", "receipts", "reviews"):
        ok(f"no remote {d} folder for this id", not exists(f"collab/{d}/{rid}"))

    pkg_path = str(front["package_path"])
    pkg_remote = "collab/" + pkg_path.split("/SKILL-COLLAB/", 1)[-1].lstrip("/")
    pin = None
    if ok("SOURCE_PIN.json is present and parses with the verifier's own parser", pin_b):
        pin = approval._parse(pin_b, approval.PIN_SCHEMA, "PIN")
    if pin:
        import approver_ops as ops
        st = ops.status()
        ok("pin repo_id equals the approver key's repo_id", str(pin.get("repo_id")) == str(st.get("repo_id")), str(pin.get("repo_id")))
        ok("approver key decrypts (DPAPI, nothing printed)", st.get("private_key_decrypts") is True, st.get("key_id", "?"))
        commit = str(pin["commit"])
        rc, status, _ = gh("api", f"repos/{R}/compare/{commit}...main", "--jq", ".status")
        ok("pinned commit is on main", rc == 0 and status in ("ahead", "identical"), status)
        ok("REQUEST bytes at the pinned commit equal main", raw(f"{base}/REQUEST.md", commit) == req_b)
        zip_b = raw(pkg_remote, commit)
    else:
        commit, zip_b = None, raw(pkg_remote)
    if not ok("package is readable at the pinned commit", zip_b):
        return None
    ok("package size and sha256 equal the REQUEST", len(zip_b) == int(front["package_size_bytes"]) and h(zip_b) == str(front["package_sha256"]))
    with tempfile.TemporaryDirectory(prefix="apchk_") as t:
        zp = pathlib.Path(t) / "p.zip"
        zp.write_bytes(zip_b)
        with zipfile.ZipFile(zp) as z:
            names = z.namelist()
            ok("ZIP CRC is clean and no path escapes", z.testzip() is None and not [n for n in names if n.startswith(("/", "\\")) or ".." in pathlib.PurePosixPath(n).parts])
    for k in front.get("knowledge_refs") or []:
        kp = "collab/" + str(k["path"]).split("/SKILL-COLLAB/", 1)[-1].lstrip("/")
        kb = raw(kp, commit or "main")
        ok(f"knowledge ref {pathlib.PurePosixPath(kp).name} matches its sha256", kb is not None and h(kb) == str(k["sha256"]))

    ready_t = (f"---\nschema: SKILL_COLLAB_READY_V1\nstate: READY\nrequest_id: {rid}\nrequest_revision: {front['request_revision']}\n"
               f"request_path: /SKILL-COLLAB/requests/{rid}/REQUEST.md\nrequest_sha256: {h(req_b)}\npackage_sha256: {front['package_sha256']}\n"
               f"baseline_id: {cfg.baseline_id}\n---\n\n# ready\n")
    r = validator.validate(req_t, ready_t, (len(zip_b), h(zip_b)), pol, expected_request_id=rid, request_bytes=req_b)
    ok("the deployed validator accepts REQUEST + candidate READY + package", r.outcome == ValidationOutcome.VALIDATED, f"{r.outcome.name}: {r.reason}")

    with tempfile.TemporaryDirectory(prefix="apdb_") as t:
        dst = pathlib.Path(t) / "state.sqlite3"
        src = LOCAL / "skill-collab-watcher-github"
        for n in ("state.sqlite3", "state.sqlite3-wal"):
            if (src / n).exists():
                with open(src / n, "rb") as a, open(pathlib.Path(t) / n, "wb") as b:
                    shutil.copyfileobj(a, b)
        c = sqlite3.connect(dst)
        jobs = c.execute("select count(*) from jobs where request_id = ?", (rid,)).fetchone()[0]
        c.close()
        ok("the watcher database has no job for this id (no duplicate)", jobs == 0, str(jobs))
    ctx.update(front=front, req_b=req_b, zip_b=zip_b, ready_t=ready_t, pin_b=pin_b, commit=commit, cap=cap, pol=pol, cfg=cfg, pkg_path=pkg_path)
    return ctx


def approve(rid, max_usd):
    ctx = check(rid)
    if ctx is None or not all(results):
        sys.exit("NOT APPROVED: a check failed, nothing was signed or posted")
    import approver_ops as ops
    base = f"collab/requests/{rid}"
    work = pathlib.Path(tempfile.mkdtemp(prefix="apsign_"))
    try:
        (work / "REQUEST.md").write_bytes(ctx["req_b"])
        (work / "READY.md").write_bytes(ctx["ready_t"].encode("utf-8"))
        (work / "pkg.zip").write_bytes(ctx["zip_b"])
        out = work / "out"
        out.mkdir()
        rc = ops.sign_approval(request=work / "REQUEST.md", ready=work / "READY.md", package=work / "pkg.zip", package_path=ctx["pkg_path"],
                               source_commit=ctx["commit"], policy_revision=ctx["pol"].local_policy_revision, out_dir=out, valid_hours=2)
        assert rc == 0, "signing failed: nothing was published"
        (work / "PIN.json").write_bytes(ctx["pin_b"])
        signer, _ = ops._signer()
        rc = signer.main(["check", "--trust-root", str(ops.ROOT), "--approval", str(out / "APPROVAL_SIG.json"), "--pin", str(work / "PIN.json"),
                          "--request", str(work / "REQUEST.md"), "--ready", str(work / "READY.md"), "--package", str(work / "pkg.zip"),
                          "--package-path", ctx["pkg_path"], "--policy-revision", ctx["pol"].local_policy_revision])
        assert rc == 0, "offline check against the REMOTE pin failed: nothing was published"
        print("approval expires_at:", json.loads((out / "APPROVAL_SIG.json").read_text())["payload"]["expires_at"])
        for name, data in (("APPROVAL_SIG.json", (out / "APPROVAL_SIG.json").read_bytes()), ("READY.md", (work / "READY.md").read_bytes())):
            c = put(f"{base}/{name}", data, f"Host approval: {name} for {rid}")
            assert raw(f"{base}/{name}", c) == data
            print(f"{name}: commit {c[:12]} | {len(data)} B | remote bytes identical")
        print("DONE: READY was posted last; the running watcher dispatches it on the next scan")
    finally:
        shutil.rmtree(work, ignore_errors=True)


ap = argparse.ArgumentParser()
ap.add_argument("cmd", choices=["check", "approve"])
ap.add_argument("request_id")
ap.add_argument("--max-usd", type=float)
ap.add_argument("--execute", action="store_true")
a = ap.parse_args()
if a.cmd == "check":
    ctx = check(a.request_id)
    print(("APPROVABLE (cap USD %s, 1 call): approve with --max-usd %s --execute" % (ctx["cap"], ctx["cap"])) if ctx and all(results) else "NOT APPROVABLE")
else:
    if not a.execute:
        sys.exit("approve needs --execute")
    approve(a.request_id, a.max_usd)
