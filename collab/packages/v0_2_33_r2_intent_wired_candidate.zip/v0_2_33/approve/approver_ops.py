"""Single-PC approver operations for the A-approved review. Nothing secret is ever printed or logged.

The private key is encrypted by the reviewed signer tool (scrypt + AES-GCM) under a random 256-bit passphrase. That
passphrase lives only as a Windows DPAPI blob bound to this Windows account, so any process of THIS account can use the key
(accepted by the user for the single-user setup, trust_root_independence=warn) and nobody else, nor another PC, can.

  python approver_ops.py init      create folder, key, DPAPI blob and trust root (refuses to overwrite)
  python approver_ops.py status    show roles, key id, fingerprint and pin; proves the key decrypts (prints no secret)
Used as a module by the review scripts: sign_approval(...)
"""
import ctypes
import hashlib
import json
import os
import secrets
import subprocess
import sys
from ctypes import wintypes
from pathlib import Path

ENGINE = Path(__file__).parent / "eng14"            # the approved review target; its signer tools are used as shipped
sys.path.insert(0, str(ENGINE))
HOME = Path(os.environ.get("COWORK_APPROVER_HOME") or (Path(os.environ["LOCALAPPDATA"]) / "cowork-approver"))
KEY_ID = "cowork-approver-1"
REPO_ID = "1451933830"                               # numeric id of the PRIVATE repository
ENTROPY = b"cowork-approver-v1"

KEY, PUB, PASS, ROOT, PIN = (HOME / n for n in ("approver.key.enc", "approver.pub", "approver.pass.dpapi", "trust_root.json",
                                                 "trust_root.sha256"))


class _Blob(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]


def _blob(data: bytes):
    buf = ctypes.create_string_buffer(data, len(data))
    return _Blob(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte))), buf


def _dpapi(data: bytes, protect: bool) -> bytes:
    crypt32, kernel32 = ctypes.WinDLL("crypt32", use_last_error=True), ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    inb, keep1 = _blob(data)
    ent, keep2 = _blob(ENTROPY)
    out = _Blob()
    fn = crypt32.CryptProtectData if protect else crypt32.CryptUnprotectData
    args = (ctypes.byref(inb), None, ctypes.byref(ent), None, None, 1, ctypes.byref(out)) if protect else \
           (ctypes.byref(inb), None, ctypes.byref(ent), None, None, 1, ctypes.byref(out))
    if not fn(*args):
        raise OSError("DPAPI call failed (%d)" % ctypes.get_last_error())
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        kernel32.LocalFree(ctypes.cast(out.pbData, ctypes.c_void_p))


def protect(data: bytes) -> bytes:
    return _dpapi(data, True)


def unprotect(blob: bytes) -> bytes:
    return _dpapi(blob, False)


def _icacls_owner_only(path: Path, folder: bool) -> None:
    user = os.environ["USERNAME"]
    grant = f"{user}:(OI)(CI)F" if folder else f"{user}:F"
    done = subprocess.run(["icacls", str(path), "/inheritance:r", "/grant:r", grant, "/grant:r",
                           "*S-1-5-18:(OI)(CI)F" if folder else "*S-1-5-18:F"], capture_output=True, text=True)
    if done.returncode:
        raise OSError("could not restrict access to the approver folder")


def _signer():
    from tools import approval_signer, trust_root_tool
    return approval_signer, trust_root_tool


def init() -> dict:
    if HOME.exists() and any(HOME.iterdir()):
        raise SystemExit("REFUSED: the approver folder already has content; a key is never overwritten")
    signer, root_tool = _signer()
    HOME.mkdir(parents=True, exist_ok=True)
    _icacls_owner_only(HOME, folder=True)
    passphrase = secrets.token_urlsafe(32)
    signer._ask = lambda _prompt: passphrase                      # the signer's hidden prompt, answered in memory only
    rc = signer.main(["keygen", "--out-private", str(KEY), "--out-public", str(PUB), "--passphrase"])
    if rc != 0:
        raise SystemExit("keygen failed")
    PASS.write_bytes(protect(passphrase.encode()))
    # prove the round trip before anything depends on it
    raw = signer.load_private_bytes(KEY.read_text(encoding="ascii"), ask=lambda _p: unprotect(PASS.read_bytes()).decode())
    assert len(raw) == 32
    del passphrase, raw
    rc = root_tool.main(["build", "--repo-id", REPO_ID, "--out", str(ROOT), "--version", "1", "--key",
                         f"{KEY_ID}:{PUB.read_text().strip()}"])
    if rc != 0:
        raise SystemExit("trust root build failed")
    PIN.write_text(hashlib.sha256(ROOT.read_bytes()).hexdigest() + "\n", encoding="ascii")
    return status()


def status() -> dict:
    signer, _ = _signer()
    info = {"folder_exists": HOME.exists(), "files": {p.name: p.exists() for p in (KEY, PUB, PASS, ROOT, PIN)}}
    if all(info["files"].values()):
        pub = PUB.read_text().strip()
        raw = signer.load_private_bytes(KEY.read_text(encoding="ascii"), ask=lambda _p: unprotect(PASS.read_bytes()).decode())
        info.update({"key_id": KEY_ID, "fingerprint": signer.fingerprint_of(pub), "private_key_decrypts": len(raw) == 32,
                     "trust_root_pin": PIN.read_text().strip(), "repo_id": REPO_ID})
        info["key_file_has_plain_base64_key"] = False
        del raw
    return info


def sign_approval(**args) -> int:
    """args use the signer's names with underscores: request, ready, package, package_path, source_commit, policy_revision,
    out_dir, valid_hours."""
    signer, _ = _signer()
    signer._ask = lambda _prompt: unprotect(PASS.read_bytes()).decode()
    argv = ["sign", "--private-key", str(KEY), "--key-id", KEY_ID, "--repo-id", REPO_ID]
    for name, value in args.items():
        argv += ["--" + name.replace("_", "-"), str(value)]
    return signer.main(argv)


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"
    print(json.dumps(init() if cmd == "init" else status(), indent=2))
