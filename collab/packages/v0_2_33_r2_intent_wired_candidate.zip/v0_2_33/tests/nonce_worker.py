"""Subprocess helper for the cross-process nonce test: consumes one nonce against a shared database file and prints the result."""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from skill_collab_watcher.state_store import StateStore  # noqa: E402


if __name__ == "__main__":
    db, nonce, rid = sys.argv[1], sys.argv[2], sys.argv[3]
    store = StateStore(Path(db))
    try:
        print(f"PID={os.getpid()} CONSUMED={store.consume_review_intent_nonce(nonce, rid, 1)}", flush=True)
    finally:
        store.close()
