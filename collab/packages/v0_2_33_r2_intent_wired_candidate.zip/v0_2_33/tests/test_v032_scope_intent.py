"""v0.2.32: signed review-intent verification, isolated. Throw-away Ed25519 keys generated in the test; no trust root
on disk, no model, no network."""
import base64
import json
from datetime import datetime, timedelta, timezone

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from skill_collab_watcher.approval import TrustRoot, TrustedKey, canonical
from skill_collab_watcher.review_intent import IntentRejected, INTENT_KEY_PURPOSE, verify_review_intent
from skill_collab_watcher.signature_backend import Ed25519Backend

REPO = "1451933830"
NOW = datetime(2026, 11, 22, 12, 0, tzinfo=timezone.utc)
EXPECTED = {
    "request_id": "REQ-SCOPE-1", "request_revision": 1, "skill_id": "cowork-context-design",
    "source_commit": "a" * 40, "request_sha256": "b" * 64, "zip_sha256": "c" * 64, "package_size": 1234,
}


def _key():
    priv = Ed25519PrivateKey.generate()
    pub = priv.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return priv, base64.b64encode(pub).decode()


def _trust(pub, status="ACTIVE", purpose=INTENT_KEY_PURPOSE, frozen=False):
    key = TrustedKey(key_id="intent-1", public_key=pub, fingerprint="x", status=status, purpose=purpose)
    return TrustRoot(repo_id=REPO, keys={"intent-1": key}, frozen=frozen)


def _payload(**over):
    base = {"schema": "REVIEW_INTENT_V1", "repo_id": REPO, "nonce": "n" * 24,
            "issued_at": (NOW - timedelta(minutes=5)).isoformat(), "expires_at": (NOW + timedelta(hours=1)).isoformat(),
            **EXPECTED}
    base.update(over)
    return {k: v for k, v in base.items() if v is not None}


def _envelope(priv, payload, key_id="intent-1", signer=None):
    sig = base64.b64encode((signer or priv).sign(canonical(payload))).decode()
    return json.dumps({"key_id": key_id, "payload": payload, "signature": sig}).encode("utf-8")


def _consumer(seen):
    def consume(nonce):
        if nonce in seen:
            return False
        seen.add(nonce)
        return True
    return consume


def _check(raw, trust, used=None, expected=EXPECTED):
    seen = set() if used is None else used
    return verify_review_intent(raw, trust=trust, backend=Ed25519Backend(), expected=expected, now=NOW,
                                consume_nonce=_consumer(seen))


def test_valid_intent_for_the_exact_skill_and_request_passes():
    priv, pub = _key()
    payload = _check(_envelope(priv, _payload()), _trust(pub))
    assert payload["skill_id"] == "cowork-context-design"


@pytest.mark.parametrize("change,code", [
    ({"skill_id": "cowork-*"}, "BINDING_SKILL_ID"),
    ({"skill_id": "*"}, "BINDING_SKILL_ID"),
    ({"skill_id": "other-skill"}, "BINDING_SKILL_ID"),
    ({"request_id": "REQ-OTHER"}, "BINDING_REQUEST_ID"),
    ({"request_revision": 2}, "BINDING_REQUEST_REVISION"),
    ({"zip_sha256": "d" * 64}, "BINDING_ZIP_SHA256"),
    ({"request_sha256": "e" * 64}, "BINDING_REQUEST_SHA256"),
    ({"source_commit": "f" * 40}, "BINDING_SOURCE_COMMIT"),
    ({"package_size": 999}, "BINDING_PACKAGE_SIZE"),
    ({"repo_id": "999999"}, "WRONG_REPO"),
    ({"issued_at": (NOW + timedelta(minutes=1)).isoformat()}, "NOT_YET_VALID"),
    ({"expires_at": (NOW - timedelta(seconds=1)).isoformat()}, "EXPIRED"),
    ({"issued_at": (NOW - timedelta(days=30)).isoformat()}, "LIFETIME"),
    ({"nonce": "short"}, "NONCE_FORMAT"),
    ({"issued_at": "not-a-time"}, "TIME_FORMAT"),
    ({"schema": "SOMETHING_ELSE"}, "SCHEMA"),
])
def test_bound_and_time_violations_are_rejected(change, code):
    priv, pub = _key()
    with pytest.raises(IntentRejected) as err:
        _check(_envelope(priv, _payload(**change)), _trust(pub))
    assert err.value.code == code


def test_wildcard_skill_cannot_match_even_when_the_request_names_it():
    priv, pub = _key()
    star = dict(EXPECTED, skill_id="*")
    with pytest.raises(IntentRejected) as err:
        _check(_envelope(priv, _payload(skill_id="*")), _trust(pub), expected=star)
    assert err.value.code == "SKILL_NOT_EXACT"


def test_forged_signature_by_another_key_is_rejected():
    priv, pub = _key()
    forger, _ = _key()
    with pytest.raises(IntentRejected) as err:
        _check(_envelope(priv, _payload(), signer=forger), _trust(pub))
    assert err.value.code == "SIGNATURE_INVALID"


def test_tampered_payload_after_signing_is_rejected():
    priv, pub = _key()
    raw = json.loads(_envelope(priv, _payload()))
    raw["payload"]["skill_id"] = "cowork-context-design-x"
    with pytest.raises(IntentRejected) as err:
        _check(json.dumps(raw).encode("utf-8"), _trust(pub))
    assert err.value.code in {"SIGNATURE_INVALID", "BINDING_SKILL_ID", "SKILL_NOT_EXACT"}


def test_revoked_key_is_rejected_even_with_a_valid_signature():
    priv, pub = _key()
    with pytest.raises(IntentRejected) as err:
        _check(_envelope(priv, _payload()), _trust(pub, status="REVOKED"))
    assert err.value.code == "KEY_NOT_ACTIVE"


def test_approval_purpose_key_cannot_sign_an_intent():
    priv, pub = _key()
    with pytest.raises(IntentRejected) as err:
        _check(_envelope(priv, _payload()), _trust(pub, purpose="APPROVAL"))
    assert err.value.code == "KEY_PURPOSE"


def test_replayed_nonce_is_rejected_once_used():
    priv, pub = _key()
    used = set()
    raw = _envelope(priv, _payload())
    _check(raw, _trust(pub), used=used)
    with pytest.raises(IntentRejected) as err:
        _check(raw, _trust(pub), used=used)
    assert err.value.code == "REPLAY"


def test_unsigned_github_text_claiming_approval_is_rejected():
    _, pub = _key()
    text = b'{"payload": {"schema": "REVIEW_INTENT_V1", "approved_by_user": true}}'
    with pytest.raises(IntentRejected) as err:
        _check(text, _trust(pub))
    assert err.value.code in {"MISSING_SIGNATURE", "SCHEMA"}


def test_frozen_or_missing_trust_root_fails_closed():
    priv, pub = _key()
    with pytest.raises(IntentRejected) as err:
        _check(_envelope(priv, _payload()), _trust(pub, frozen=True))
    assert err.value.code == "TRUST_ROOT_FROZEN"
    with pytest.raises(IntentRejected) as err:
        _check(_envelope(priv, _payload()), None)
    assert err.value.code == "TRUST_ROOT_MISSING"
