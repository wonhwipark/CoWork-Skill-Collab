"""v0.2.33: separate OS processes, separate databases, one shared atomic dispatch record. A model is never started twice for one request,
and a process that dies inside the model call is sealed on restart, not re-run. Fake runner only; no network, no real model."""
import json
import subprocess
import sys
from pathlib import Path

WORKER = Path(__file__).with_name("dispatch_worker.py")


def _launch(mode, tmp_path, name, parties):
    db = tmp_path / f"{name}.sqlite3"
    out = tmp_path / f"{name}.json"
    proc = subprocess.Popen([sys.executable, str(WORKER), mode, str(db), str(tmp_path / "claims"), str(tmp_path / "barrier"),
                             str(parties), str(out)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    return proc, out, db


def _dirs(tmp_path):
    (tmp_path / "claims").mkdir(exist_ok=True)
    (tmp_path / "barrier").mkdir(exist_ok=True)


def test_two_os_processes_on_separate_databases_start_at_most_one_model_call(tmp_path):
    _dirs(tmp_path)
    procs = [_launch("race", tmp_path, f"w{i}", 2) for i in range(2)]
    results = []
    for proc, out, _ in procs:
        _, err = proc.communicate(timeout=180)
        assert proc.returncode == 0, err
        results.append(json.loads(out.read_text(encoding="utf-8")))
    assert len({r["pid"] for r in results}) == 2, "the two watchers must be distinct OS processes"
    assert sum(r["calls"] for r in results) == 1
    assert sum(r["dispatched"] for r in results) == 1
    loser = next(r for r in results if r["calls"] == 0)
    assert loser["uncertain"] >= 1, "the losing watcher must seal its attempt, not dispatch"
    assert len(list((tmp_path / "claims").iterdir())) == 1, "exactly one dispatch record must exist remotely"


def test_a_process_killed_inside_the_model_call_is_sealed_on_restart_and_never_rerun(tmp_path):
    _dirs(tmp_path)
    crash, _, db = _launch("crash", tmp_path, "crash", 1)
    _, err = crash.communicate(timeout=180)
    assert crash.returncode == 3, err
    restart, out, _ = _launch("restart", tmp_path, "crash", 1)
    _, err = restart.communicate(timeout=180)
    assert restart.returncode == 0, err
    result = json.loads(out.read_text(encoding="utf-8"))
    assert result["calls"] == 0, "no model call may follow a process that died inside one"
    assert result["uncertain_jobs"] == 1
