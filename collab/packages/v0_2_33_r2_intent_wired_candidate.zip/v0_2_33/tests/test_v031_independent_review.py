"""v0.2.31: one independent review per request id. Replay, restart, a second watcher with a fresh database, a conflicting
package and an uncertain run must never start a second model call. No budget value reaches the CLI and a missing amount never
blocks a dispatch. Fake runner and in-memory transport only; no model is called."""
import hashlib
import json
from dataclasses import replace

import pytest

from skill_collab_watcher.auto_policy import assess
from skill_collab_watcher.fake_runner import FakeReviewRunner
from skill_collab_watcher.models import JobState, ReviewResult
from skill_collab_watcher.orchestrator import run_scan_cycle
from skill_collab_watcher.state_store import StateStore
from skill_collab_watcher.transport_base import TransportError
from skill_collab_watcher.validator import LocalPolicy

from conftest import BASELINE, REMOTE_ROOT, make_package_zip, ready_md, request_md
from test_review_budget_policy_v025 import scenario

RID = "REQ-1"
SMALL = "POLICY-STATIC-V1"
PKG_PATH = f"{REMOTE_ROOT}/packages/test.zip"


def _policy(budgets=None):
    return LocalPolicy(
        active_baseline_id=BASELINE, local_policy_revision="1",
        known_run_policy_refs=[SMALL], run_budgets_usd={SMALL: 1.0} if budgets is None else budgets,
    )


def _publish(transport, marker="ok"):
    package = make_package_zip(marker)
    sha = hashlib.sha256(package).hexdigest()
    req = request_md(request_id=RID, package_sha256=sha, package_size=len(package), run_policy_ref=SMALL)
    ready = ready_md(hashlib.sha256(req.encode("utf-8")).hexdigest(), sha, request_id=RID)
    transport.push_file(f"{REMOTE_ROOT}/requests/{RID}/REQUEST.md", req.encode("utf-8"))
    transport.push_file(f"{REMOTE_ROOT}/requests/{RID}/READY.md", ready.encode("utf-8"))
    transport.push_file(PKG_PATH, package)


def _scan(transport, store, runner, tmp_path, policy=None):
    return run_scan_cycle(transport, store, policy or _policy(), runner, True,
                          snapshot_root=tmp_path / "snap", review_run_dir=tmp_path / "runs",
                          remote_root=REMOTE_ROOT)


def _events(store, name):
    return [e for e in store.recent_events(200) if e[1] == name]


def test_same_request_is_dispatched_once_across_rescans(transport, store, runner, tmp_path):
    _publish(transport)
    _scan(transport, store, runner, tmp_path)
    _scan(transport, store, runner, tmp_path)
    _scan(transport, store, runner, tmp_path)
    assert runner.calls == 1
    assert len(_events(store, "REVIEW_DISPATCHED")) == 1


def test_restart_on_the_same_database_does_not_redispatch(transport, store, runner, tmp_path):
    _publish(transport)
    _scan(transport, store, runner, tmp_path)
    store.close()
    reopened = StateStore(tmp_path / "state.sqlite3")
    try:
        _scan(transport, reopened, runner, tmp_path)
        assert runner.calls == 1
    finally:
        reopened.close()


def test_second_watcher_with_a_fresh_database_does_not_redispatch(transport, tmp_path):
    first, second = StateStore(tmp_path / "first.sqlite3"), StateStore(tmp_path / "second.sqlite3")
    runner = FakeReviewRunner()
    try:
        _publish(transport)
        _scan(transport, first, runner, tmp_path)
        _scan(transport, second, runner, tmp_path)
        assert runner.calls == 1
        assert _events(second, "REVIEW_DISPATCHED") == []
    finally:
        first.close()
        second.close()


def test_same_revision_with_another_package_is_conflict_and_never_reviewed(transport, store, runner, tmp_path):
    _publish(transport, "first")
    _scan(transport, store, runner, tmp_path)
    _publish(transport, "second")
    _scan(transport, store, runner, tmp_path)
    assert runner.calls == 1
    assert _events(store, "CONFLICT"), "a changed package under the same request revision must be a CONFLICT"


def test_runner_timeout_after_model_start_is_uncertain_and_not_retried(transport, store, runner, tmp_path):
    runner.canned_result = ReviewResult(ok=False, output_text="", output_format="json", exit_code=124,
                                        model_calls=1, usage=None, error="timeout after 60 s")
    _publish(transport)
    _scan(transport, store, runner, tmp_path)
    _scan(transport, store, runner, tmp_path)
    assert runner.calls == 1
    assert len(store.jobs_in_states([JobState.REVIEW_UNCERTAIN])) == 1


def test_result_upload_failure_publishes_later_without_a_second_model_call(transport, store, runner, tmp_path, monkeypatch):
    real_upload = transport.upload

    def failing_upload(path, data, mode="add"):
        if "REVIEW_RESULT" in path:
            raise TransportError("simulated upload failure")
        return real_upload(path, data, mode=mode)

    monkeypatch.setattr(transport, "upload", failing_upload)
    _publish(transport)
    _scan(transport, store, runner, tmp_path)
    assert runner.calls == 1
    monkeypatch.setattr(transport, "upload", real_upload)
    _scan(transport, store, runner, tmp_path)
    _scan(transport, store, runner, tmp_path)
    assert runner.calls == 1
    assert len(store.jobs_in_states([JobState.COMPLETED])) == 1


def test_missing_amount_does_not_block_the_dispatch(transport, store, runner, tmp_path):
    _publish(transport)
    _scan(transport, store, runner, tmp_path, policy=_policy(budgets={}))
    assert runner.calls == 1
    detail = json.loads(_events(store, "REVIEW_DISPATCHED")[0][3])
    assert detail["accounting_reference_usd"] is None
    assert "max_budget_usd" not in detail


def test_scope_refuses_unlisted_skill_and_treats_star_as_a_literal():
    d, c, e = scenario()
    assert assess(d, c, e)[0]
    assert assess(d, replace(c, skill="cowork-context-design"), e) == (False, "SCOPE")
    star = replace(d, skills=frozenset({"*"}))
    assert assess(star, replace(c, skill="cowork-context-design"), e) == (False, "SCOPE")
