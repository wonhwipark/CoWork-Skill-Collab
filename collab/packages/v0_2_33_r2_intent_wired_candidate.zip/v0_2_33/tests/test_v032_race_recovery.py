"""v0.2.32 pre-LIVE: two watchers that race for the same request, lost responses, crashes and restarts.
Every test uses a fake runner and a shared in-memory transport whose create-only upload is made atomic with a lock,
the way the server's create-only rule behaves. No model is called."""
import hashlib
import json
import threading

import pytest

from skill_collab_watcher.fake_runner import FakeReviewRunner
from skill_collab_watcher.models import JobState, ReviewResult
from skill_collab_watcher.mock_transport import MockTransport
from skill_collab_watcher.orchestrator import run_scan_cycle
from skill_collab_watcher.state_store import StateStore
from skill_collab_watcher.transport_base import TransportError

from auto_helpers import Crash
from conftest import BASELINE, REMOTE_ROOT, make_package_zip, ready_md, request_md
from test_v031_independent_review import _events, _policy, _publish, _scan

RID = "REQ-RACE-1"
SMALL = "POLICY-STATIC-V1"


class AtomicTransport(MockTransport):
    """MockTransport whose create-only upload is atomic, as the server's create-only rule is."""

    def __init__(self):
        super().__init__()
        self._guard = threading.Lock()

    def upload(self, path, data, mode="add"):
        with self._guard:
            return super().upload(path, data, mode=mode)


def _publish_for(transport, rid):
    package = make_package_zip(rid)
    sha = hashlib.sha256(package).hexdigest()
    req = request_md(request_id=rid, package_sha256=sha, package_size=len(package), run_policy_ref=SMALL)
    ready = ready_md(hashlib.sha256(req.encode("utf-8")).hexdigest(), sha, request_id=rid)
    transport.push_file(f"{REMOTE_ROOT}/requests/{rid}/REQUEST.md", req.encode("utf-8"))
    transport.push_file(f"{REMOTE_ROOT}/requests/{rid}/READY.md", ready.encode("utf-8"))
    transport.push_file("/SKILL-COLLAB/packages/test.zip", package)


def test_two_watchers_racing_on_the_same_dispatch_start_at_most_one_model_call(tmp_path):
    transport = AtomicTransport()
    _publish(transport)
    barrier = threading.Barrier(2, timeout=15)
    original_get = transport.get_metadata

    def racing_get(path):
        if "/DISPATCH_" in path:
            barrier.wait()
        return original_get(path)

    transport.get_metadata = racing_get
    runners = [FakeReviewRunner(), FakeReviewRunner()]
    results = [{}, {}]
    errors = []

    def watcher(index):
        store = StateStore(tmp_path / f"w{index}.sqlite3")
        try:
            _scan(transport, store, runners[index], tmp_path / f"w{index}")
            results[index]["dispatched"] = len(_events(store, "REVIEW_DISPATCHED"))
            results[index]["uncertain"] = len(_events(store, "REVIEW_UNCERTAIN"))
        except Exception as exc:
            errors.append(exc)
        finally:
            store.close()

    threads = [threading.Thread(target=watcher, args=(i,)) for i in range(2)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=60)
    assert not errors, errors
    assert sum(r.calls for r in runners) == 1
    assert sum(r["dispatched"] for r in results) == 1
    assert sum(r["uncertain"] for r in results) == 1, "the losing watcher must seal its attempt, not dispatch"


def test_lost_reservation_response_retries_once_and_only_after_no_model_start(tmp_path):
    transport = AtomicTransport()
    _publish_for(transport, RID)
    store, runner = StateStore(tmp_path / "s.sqlite3"), FakeReviewRunner()
    real_upload = transport.upload

    def write_then_lose_response(path, data, mode="add"):
        result = real_upload(path, data, mode=mode)
        if "/DISPATCH_" in path:
            raise TransportError("response lost after the server stored the reservation")
        return result

    transport.upload = write_then_lose_response
    try:
        _scan(transport, store, runner, tmp_path / "r1")
        assert runner.calls == 0, "no model may start while the reservation outcome is unknown"
        transport.upload = real_upload
        _scan(transport, store, runner, tmp_path / "r2")
        _scan(transport, store, runner, tmp_path / "r3")
        assert runner.calls == 1, "the lifecycle yields exactly one model call"
    finally:
        store.close()


def test_lost_reservation_seen_by_a_fresh_watcher_is_sealed_not_dispatched(tmp_path):
    transport = AtomicTransport()
    _publish_for(transport, RID)
    writer = StateStore(tmp_path / "writer.sqlite3")
    real_upload = transport.upload

    def write_then_lose_response(path, data, mode="add"):
        result = real_upload(path, data, mode=mode)
        if "/DISPATCH_" in path:
            raise TransportError("response lost after the server stored the reservation")
        return result

    transport.upload = write_then_lose_response
    try:
        _scan(transport, writer, FakeReviewRunner(), tmp_path / "w1")
    finally:
        writer.close()
        transport.upload = real_upload
    fresh = StateStore(tmp_path / "fresh.sqlite3")
    runner = FakeReviewRunner()
    try:
        _scan(transport, fresh, runner, tmp_path / "f1")
        assert runner.calls == 0
        assert _events(fresh, "REVIEW_UNCERTAIN"), "a reservation this watcher cannot account for must be sealed"
    finally:
        fresh.close()


def test_reservation_that_could_not_be_written_starts_no_model(tmp_path):
    transport = AtomicTransport()
    _publish_for(transport, RID)
    store, runner = StateStore(tmp_path / "s.sqlite3"), FakeReviewRunner()
    real_get = transport.get_metadata

    def broken_claim(path):
        if "/DISPATCH_" in path:
            raise TransportError("claim check unavailable")
        return real_get(path)

    transport.get_metadata = broken_claim
    try:
        _scan(transport, store, runner, tmp_path / "r1")
        assert runner.calls == 0
    finally:
        store.close()


def test_crash_after_the_claim_is_sealed_on_restart_and_never_rerun(tmp_path):
    transport = AtomicTransport()
    _publish_for(transport, RID)
    first = StateStore(tmp_path / "s.sqlite3")
    crashing = FakeReviewRunner()

    def die(*args, **kwargs):
        raise Crash("power loss inside the model call")

    crashing.run = die
    with pytest.raises(Crash):
        _scan(transport, first, crashing, tmp_path / "c1")
    first.close()

    reopened = StateStore(tmp_path / "s.sqlite3")
    runner = FakeReviewRunner()
    try:
        reopened.seal_interrupted(exclusive=True)
        _scan(transport, reopened, runner, tmp_path / "c2")
        assert runner.calls == 0
        assert len(reopened.jobs_in_states([JobState.REVIEW_UNCERTAIN])) == 1
    finally:
        reopened.close()


@pytest.mark.parametrize("error", ["timeout after 60 s", "claude_cli_failed exit=-9 signal=SIGKILL", "claude_cli_failed exit=1"])
def test_non_clean_end_after_model_start_is_terminal_and_never_retried(tmp_path, error):
    transport = AtomicTransport()
    _publish_for(transport, RID)
    store, runner = StateStore(tmp_path / "s.sqlite3"), FakeReviewRunner()
    runner.canned_result = ReviewResult(ok=False, output_text="", output_format="json", exit_code=1,
                                        model_calls=1, usage=None, error=error)
    try:
        _scan(transport, store, runner, tmp_path / "f1")
        _scan(transport, store, runner, tmp_path / "f2")
        _scan(transport, store, runner, tmp_path / "f3")
        assert runner.calls == 1
        assert store.jobs_in_states([JobState.REVIEW_UNCERTAIN]) or store.jobs_in_states([JobState.FAILED])
    finally:
        store.close()


def test_result_already_published_by_another_watcher_is_not_reviewed_again(tmp_path):
    transport = AtomicTransport()
    _publish_for(transport, RID)
    first_store, first_runner = StateStore(tmp_path / "a.sqlite3"), FakeReviewRunner()
    second_store, second_runner = StateStore(tmp_path / "b.sqlite3"), FakeReviewRunner()
    try:
        _scan(transport, first_store, first_runner, tmp_path / "a")
        _scan(transport, second_store, second_runner, tmp_path / "b")
        assert first_runner.calls == 1 and second_runner.calls == 0
    finally:
        first_store.close()
        second_store.close()
