"""OS-process worker for the dispatch race and crash tests.

The remote create-only dispatch record is a file in a shared directory created with O_CREAT|O_EXCL, so two processes race on
the same atomic primitive. Everything else (request, READY, package) is identical bytes in each process. No model is called.
Usage: dispatch_worker.py <mode race|crash|restart> <db> <claim_dir> <barrier_dir> <parties> <out_json>
"""
import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

from skill_collab_watcher.fake_runner import FakeReviewRunner  # noqa: E402
from skill_collab_watcher.mock_transport import MockTransport  # noqa: E402
from skill_collab_watcher.models import JobState  # noqa: E402
from skill_collab_watcher.orchestrator import run_scan_cycle  # noqa: E402
from skill_collab_watcher.state_store import StateStore  # noqa: E402
from skill_collab_watcher.transport_base import UploadConflict  # noqa: E402
from skill_collab_watcher.validator import LocalPolicy  # noqa: E402

from conftest import BASELINE, REMOTE_ROOT, make_package_zip, ready_md, request_md  # noqa: E402

RID = "REQ-PROC-1"
SMALL = "POLICY-STATIC-V1"
PKG = "/SKILL-COLLAB/packages/test.zip"


class SharedDispatchTransport(MockTransport):
    def __init__(self, claim_dir: Path, barrier_dir: Path, parties: int):
        super().__init__()
        self.claim_dir, self.barrier_dir, self.parties = claim_dir, barrier_dir, parties

    def _claim_file(self, path: str) -> Path:
        return self.claim_dir / path.rsplit("/", 1)[-1]

    def _arrive_and_wait(self) -> None:
        (self.barrier_dir / f"arrive_{os.getpid()}").write_text("1")
        deadline = time.time() + 60
        while len(list(self.barrier_dir.glob("arrive_*"))) < self.parties:
            if time.time() > deadline:
                raise TimeoutError("barrier")
            time.sleep(0.01)

    def get_metadata(self, path):
        if "/DISPATCH_" in path:
            self._arrive_and_wait()
            claim = self._claim_file(path)
            if claim.exists():
                self.push_file(path, claim.read_bytes())
        return super().get_metadata(path)

    def upload(self, path, data, mode="add"):
        if "/DISPATCH_" not in path:
            return super().upload(path, data, mode=mode)
        claim = self._claim_file(path)
        try:
            fd = os.open(claim, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            self.push_file(path, claim.read_bytes())
            raise UploadConflict(path)
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
        self.push_file(path, data)
        return self._meta(path)


def publish(transport: MockTransport) -> None:
    package = make_package_zip(RID)
    import hashlib
    sha = hashlib.sha256(package).hexdigest()
    req = request_md(request_id=RID, package_sha256=sha, package_size=len(package), run_policy_ref=SMALL)
    ready = ready_md(hashlib.sha256(req.encode("utf-8")).hexdigest(), sha, request_id=RID)
    transport.push_file(f"{REMOTE_ROOT}/requests/{RID}/REQUEST.md", req.encode("utf-8"))
    transport.push_file(f"{REMOTE_ROOT}/requests/{RID}/READY.md", ready.encode("utf-8"))
    transport.push_file(PKG, package)


class CrashingRunner(FakeReviewRunner):
    def run(self, *args, **kwargs):
        self.calls += 1
        os._exit(3)


def main() -> int:
    mode, db, claim_dir, barrier_dir, parties, out = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], int(sys.argv[5]), sys.argv[6]
    claim_dir, barrier_dir = Path(claim_dir), Path(barrier_dir)
    transport = SharedDispatchTransport(claim_dir, barrier_dir, parties)
    publish(transport)
    policy = LocalPolicy(active_baseline_id=BASELINE, local_policy_revision="1", known_run_policy_refs=[SMALL],
                         run_budgets_usd={SMALL: 1.0})
    store = StateStore(Path(db))
    runner = CrashingRunner() if mode == "crash" else FakeReviewRunner()
    if mode == "restart":
        store.seal_interrupted(exclusive=True)
    base = Path(db).parent / f"snap_{os.getpid()}"
    try:
        run_scan_cycle(transport, store, policy, runner, True, snapshot_root=base / "snap", review_run_dir=base / "runs",
                       remote_root=REMOTE_ROOT)
        names = [e[1] for e in store.recent_events(500)]
        result = {"pid": os.getpid(), "mode": mode, "calls": runner.calls,
                  "dispatched": names.count("REVIEW_DISPATCHED"), "uncertain": names.count("REVIEW_UNCERTAIN"),
                  "uncertain_jobs": len(store.jobs_in_states([JobState.REVIEW_UNCERTAIN]))}
    finally:
        store.close()
    Path(out).write_text(json.dumps(result), encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
