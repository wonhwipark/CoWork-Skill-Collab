"""Acceptance cases T05, T06, T07, T19 and T25. Synthetic data only, zero model calls
except where a test explicitly expects the single allowed dispatch."""
from __future__ import annotations

import hashlib
import io
import os
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

from bundle import ROOT, github_policy, key_for, make_transport, publish_bundle, sha256
from conftest import BASELINE, REMOTE_ROOT, RUN_POLICY_REF, make_package_zip, push_valid_request, ready_md, request_md
from skill_collab_watcher.fake_runner import FakeReviewRunner
from skill_collab_watcher.lock import SingleInstanceLock
from skill_collab_watcher.orchestrator import run_scan_cycle
from skill_collab_watcher.validator import LocalPolicy

SRC = str(Path(__file__).resolve().parents[1])


def _policy():
    return LocalPolicy(active_baseline_id=BASELINE, local_policy_revision="1",
                       known_run_policy_refs=[RUN_POLICY_REF])


def _scan(transport, store, runner, snapshot_root, review_run_dir, policy=None):
    return run_scan_cycle(transport, store, policy or _policy(), runner, allowed=True,
                          snapshot_root=snapshot_root, review_run_dir=review_run_dir, remote_root=REMOTE_ROOT)


def _events(store):
    return [(e, d or "") for _ts, e, _k, d in store.recent_events(500)]


def _push_bundle(transport, package: bytes, *, declared_sha: str | None = None,
                 declared_size: int | None = None, knowledge_yaml: str = "[]", request_id="REQ-1"):
    sha = declared_sha or hashlib.sha256(package).hexdigest()
    size = declared_size if declared_size is not None else len(package)
    req = request_md(request_id=request_id, package_sha256=sha, package_size=size,
                     knowledge_refs_yaml=knowledge_yaml).encode("utf-8")
    transport.push_file(f"{REMOTE_ROOT}/requests/{request_id}/REQUEST.md", req)
    transport.push_file(f"{REMOTE_ROOT}/requests/{request_id}/READY.md",
                        ready_md(hashlib.sha256(req).hexdigest(), sha, request_id=request_id).encode("utf-8"))
    transport.push_file("/SKILL-COLLAB/packages/test.zip", package)


# --- T05: ZIP SHA, size and CRC must match before anything runs -----------------

def test_T05_declared_package_size_mismatch_costs_no_model_call(transport, store, runner, snapshot_root, review_run_dir):
    package = make_package_zip("t05")
    _push_bundle(transport, package, declared_size=len(package) + 1)
    _scan(transport, store, runner, snapshot_root, review_run_dir)
    assert runner.calls == 0


def test_T05_declared_package_sha_mismatch_costs_no_model_call(transport, store, runner, snapshot_root, review_run_dir):
    package = make_package_zip("t05b")
    _push_bundle(transport, package, declared_sha="e" * 64)
    _scan(transport, store, runner, snapshot_root, review_run_dir)
    assert runner.calls == 0


def test_T05_crc_corrupt_zip_with_matching_sha_is_refused_before_extraction(
        transport, store, runner, snapshot_root, review_run_dir):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_STORED) as zf:
        zf.writestr("SKILL-COLLAB/CLAUDE.md", b"CONTENT-ABC-END")
    damaged = buf.getvalue().replace(b"CONTENT-ABC-END", b"CONTENT-ABD-END")
    _push_bundle(transport, damaged)
    _scan(transport, store, runner, snapshot_root, review_run_dir)
    assert runner.calls == 0
    assert any(e == "FAILED" and "CRC" in d for e, d in _events(store))


# --- T06: pinned knowledge must carry a valid hash and the pinned bytes ----------

def test_T06_knowledge_ref_without_a_hash_is_rejected(transport, store, runner, snapshot_root, review_run_dir):
    package = make_package_zip("t06a")
    _push_bundle(transport, package, knowledge_yaml="[{path: /SKILL-COLLAB/knowledge/k.md}]")
    transport.push_file("/SKILL-COLLAB/knowledge/k.md", b"knowledge")
    _scan(transport, store, runner, snapshot_root, review_run_dir)
    assert runner.calls == 0


def test_T06_knowledge_ref_with_a_non_hex_hash_is_rejected(transport, store, runner, snapshot_root, review_run_dir):
    package = make_package_zip("t06b")
    _push_bundle(transport, package, knowledge_yaml="[{path: /SKILL-COLLAB/knowledge/k.md, sha256: not-a-hash}]")
    transport.push_file("/SKILL-COLLAB/knowledge/k.md", b"knowledge")
    _scan(transport, store, runner, snapshot_root, review_run_dir)
    assert runner.calls == 0


def test_T06_knowledge_bytes_that_differ_from_the_pin_are_a_conflict(
        transport, store, runner, snapshot_root, review_run_dir):
    package = make_package_zip("t06c")
    pinned = hashlib.sha256(b"the pinned version").hexdigest()
    _push_bundle(transport, package, knowledge_yaml=f"[{{path: /SKILL-COLLAB/knowledge/k.md, sha256: {pinned}}}]")
    transport.push_file("/SKILL-COLLAB/knowledge/k.md", b"a different version")
    _scan(transport, store, runner, snapshot_root, review_run_dir)
    assert runner.calls == 0
    assert any(e == "CONFLICT" and "sha256" in d for e, d in _events(store))


# --- T07: the same ZIP under a new request id needs its own approval -------------

def test_T07_same_zip_under_a_new_request_id_without_approval_is_not_reviewed(github_env):
    package = make_package_zip("REQ-1")
    publish_bundle(github_env.http, "REQ-1", package=package)
    publish_bundle(github_env.http, "REQ-2", package=package, omit=("approval", "pin"))
    _run(github_env)
    assert github_env.runner.calls == 1
    assert github_env.store.get_job(key_for(sha256(package), request_id="REQ-2")) is None


def test_T07_same_zip_under_a_new_request_id_with_its_own_approval_is_reviewed_once_more(github_env):
    package = make_package_zip("REQ-1")
    publish_bundle(github_env.http, "REQ-1", package=package)
    publish_bundle(github_env.http, "REQ-2", package=package)
    _run(github_env)
    assert github_env.runner.calls == 2


def _run(env):
    run_scan_cycle(make_transport(env.http), env.store, github_policy(), env.runner, allowed=True,
                   snapshot_root=env.snapshot_root, review_run_dir=env.review_run_dir, remote_root=ROOT)


# --- T19: a second watcher process cannot hold the lock; one dispatch per job ----

@pytest.mark.skipif(sys.platform != "win32", reason="msvcrt byte-range lock is Windows-only")
def test_T19_second_watcher_process_cannot_take_the_lock(tmp_path):
    lock_path = tmp_path / "watch.lock"
    child = subprocess.Popen(
        [sys.executable, "-c",
         f"import sys,time; sys.path.insert(0, {SRC!r}); from pathlib import Path; "
         "from skill_collab_watcher.lock import SingleInstanceLock as L; "
         f"l = L(Path({str(lock_path)!r})); assert l.acquire(); print('HELD', flush=True); time.sleep(60)"],
        stdout=subprocess.PIPE, text=True, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
    )
    try:
        assert child.stdout.readline().strip() == "HELD"
        assert SingleInstanceLock(lock_path).acquire() is False
    finally:
        # a venv python.exe is a launcher whose child holds the lock: end the whole tree, not just the launcher
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(child.pid)], capture_output=True)
        child.wait()
    taker = SingleInstanceLock(lock_path)
    assert taker.acquire() is True
    taker.release()


class _ReentrantRunner(FakeReviewRunner):
    """Starts a second scan while the first model call is still running."""

    def run(self, snapshot_dir, prompt_text, run_dir, effort=None):
        nested = getattr(self, "nested", None)
        if nested is not None:
            self.nested = None
            nested()
        return super().run(snapshot_dir, prompt_text, run_dir, effort=effort)


def test_T19_a_second_scan_during_a_model_call_never_dispatches(transport, store, snapshot_root, review_run_dir):
    push_valid_request(transport)
    runner = _ReentrantRunner()
    runner.nested = lambda: _scan(transport, store, runner, snapshot_root, review_run_dir)
    _scan(transport, store, runner, snapshot_root, review_run_dir)
    assert runner.calls == 1
    assert any(e == "IN_PROGRESS_SKIPPED" for e, _d in _events(store))


# --- T25: hostile packages are refused before they can run anything --------------

def _zip_with(entries):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for name, data, attr in entries:
            info = zipfile.ZipInfo(name)
            info.external_attr = attr
            zf.writestr(info, data)
    return buf.getvalue()


def test_T25_path_escape_in_package_is_refused(transport, store, runner, snapshot_root, review_run_dir):
    _push_bundle(transport, _zip_with([("../escape.txt", b"x", 0o100644 << 16)]))
    _scan(transport, store, runner, snapshot_root, review_run_dir)
    assert runner.calls == 0
    assert any(e == "FAILED" and "escape" in d for e, d in _events(store))


def test_T25_symlink_in_package_is_refused(transport, store, runner, snapshot_root, review_run_dir):
    _push_bundle(transport, _zip_with([("SKILL-COLLAB/link", b"/etc/passwd", 0o120777 << 16)]))
    _scan(transport, store, runner, snapshot_root, review_run_dir)
    assert runner.calls == 0
    assert any(e == "FAILED" and "symlink" in d for e, d in _events(store))


def test_T25_credential_shaped_text_in_package_is_rejected_before_claim(
        transport, store, runner, snapshot_root, review_run_dir):
    fake_secret = b'{"refresh_' + b'token": "abcdefghijklmnopqrstu"}'
    package = _zip_with([("SKILL-COLLAB/config.json", fake_secret, 0o100644 << 16)])
    _push_bundle(transport, package)
    _scan(transport, store, runner, snapshot_root, review_run_dir)
    assert runner.calls == 0
    assert any(e == "REJECTED" and "credential-shaped" in d for e, d in _events(store))
    assert store.get_job(key_for(hashlib.sha256(package).hexdigest())) is None
