"""Only tests argv construction. Never calls RealReviewRunner.run() -
doing so would start a real `claude` process and bill tokens, which is
exactly what WATCHER_IMPLEMENT_PROMPT_r0001.md section 10 says not to do
during this kind of mock-cycle test."""
from __future__ import annotations

from pathlib import Path

from skill_collab_watcher.review_runner import build_argv


def test_argv_excludes_bare_and_restricts_tools():
    argv = build_argv("claude", "sonnet", ["Read", "Grep", "Glob"], Path("C:/snap"))
    assert "--bare" not in argv
    assert "--tools" in argv
    i = argv.index("--tools")
    assert argv[i + 1] == "Read,Grep,Glob"
    assert "--strict-mcp-config" in argv
    assert "--no-session-persistence" in argv
    assert "--setting-sources" in argv
    j = argv.index("--setting-sources")
    assert argv[j + 1] == "user"
    assert "--model" in argv
    assert argv[argv.index("--model") + 1] == "sonnet"
    assert "--max-budget-usd" not in argv


def test_argv_omits_model_and_budget_when_not_configured():
    argv = build_argv("claude", None, ["Read"], Path("C:/snap"))
    assert "--model" not in argv
    assert "--max-budget-usd" not in argv
