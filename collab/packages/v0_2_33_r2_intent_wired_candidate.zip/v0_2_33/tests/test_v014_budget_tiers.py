"""0.1.4: per-request spending tier chosen from locally registered run
policies, plus a readable reason and the cost on failure. No real `claude`
process: subprocess.run is replaced by a recorder where the runner is used."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest

from skill_collab_watcher import review_runner
from skill_collab_watcher.config import Config, ConfigError
from skill_collab_watcher.fake_runner import FakeReviewRunner
from skill_collab_watcher.models import JobState, ReviewResult
from skill_collab_watcher.orchestrator import run_scan_cycle
from skill_collab_watcher.review_runner import RealReviewRunner
from skill_collab_watcher.validator import LocalPolicy

from conftest import BASELINE, REMOTE_ROOT, make_package_zip, ready_md, request_md

SMALL, LARGE = "POLICY-STATIC-V1", "POLICY-STATIC-V1-LARGE"


def _cfg(tmp_path, known) -> Config:
    p = tmp_path / "c.json"
    p.write_text(json.dumps({"baseline_id": BASELINE, "local_state_dir": str(tmp_path / "st"),
                             "review_policy": {"max_budget_usd": 1.0, "known_run_policy_refs": known}}),
                 encoding="utf-8")
    return Config.load(p)


# --- config ---------------------------------------------------------------


def test_legacy_list_form_uses_default_budget(tmp_path):
    rp = _cfg(tmp_path, [SMALL]).review_policy
    assert rp.known_run_policy_refs == [SMALL] and rp.run_budgets == {}
    assert rp.budget_for(SMALL) == 1.0


def test_tier_form_gives_each_ref_its_own_budget(tmp_path):
    rp = _cfg(tmp_path, {SMALL: {"max_budget_usd": 1.0}, LARGE: {"max_budget_usd": 3}}).review_policy
    assert rp.known_run_policy_refs == [SMALL, LARGE]
    assert rp.budget_for(SMALL) == 1.0 and rp.budget_for(LARGE) == 3.0
    assert rp.budget_for("NOT-REGISTERED") == 1.0   # falls back; the validator rejects such a ref anyway


@pytest.mark.parametrize("bad", [
    {LARGE: {"max_budget_usd": 0}},
    {LARGE: {"max_budget_usd": -2}},
    {LARGE: {"max_budget_usd": True}},
    {LARGE: {"max_budget_usd": "3.0"}},
    {LARGE: {"max_budget": 3.0}},          # typo'd key must not silently fall back
    {LARGE: 3.0},
    "POLICY-STATIC-V1",
    [SMALL, ""],
])
def test_bad_run_policy_config_is_a_config_error(tmp_path, bad):
    with pytest.raises(ConfigError):
        _cfg(tmp_path, bad)


# --- orchestrator picks the tier named by the REQUEST ---------------------------


def _policy():
    return LocalPolicy(
        active_baseline_id=BASELINE, local_policy_revision="1",
        known_run_policy_refs=[SMALL, LARGE], run_budgets_usd={SMALL: 1.0, LARGE: 3.0},
    )


def _publish(transport, ref, req_id="REQ-1"):
    package = make_package_zip(req_id)
    sha = hashlib.sha256(package).hexdigest()
    req = request_md(request_id=req_id, package_sha256=sha, package_size=len(package), run_policy_ref=ref)
    ready = ready_md(hashlib.sha256(req.encode("utf-8")).hexdigest(), sha, request_id=req_id)
    transport.push_file(f"{REMOTE_ROOT}/requests/{req_id}/REQUEST.md", req.encode("utf-8"))
    transport.push_file(f"{REMOTE_ROOT}/requests/{req_id}/READY.md", ready.encode("utf-8"))
    transport.push_file("/SKILL-COLLAB/packages/test.zip", package)


def _scan(transport, store, runner, tmp_path):
    return run_scan_cycle(transport, store, _policy(), runner, True,
                          snapshot_root=tmp_path / "snap", review_run_dir=tmp_path / "runs",
                          remote_root=REMOTE_ROOT)


@pytest.mark.parametrize("ref,expected", [(SMALL, 1.0), (LARGE, 3.0)])
def test_request_tier_is_recorded_as_accounting_reference_not_a_cli_cap(transport, store, tmp_path, ref, expected):
    runner = FakeReviewRunner()
    _publish(transport, ref)
    _scan(transport, store, runner, tmp_path)
    assert runner.calls == 1
    dispatched = [e for e in store.recent_events(50) if e[1] == "REVIEW_DISPATCHED"]
    detail = json.loads(dispatched[0][3])
    assert detail["run_policy_ref"] == ref and detail["accounting_reference_usd"] == expected
    assert "max_budget_usd" not in detail
    assert detail["effort"] is None and detail["prompt_cache_ttl"] == "1h"


def test_request_cannot_name_an_amount_or_an_unregistered_tier(transport, store, tmp_path):
    runner = FakeReviewRunner()
    _publish(transport, "POLICY-STATIC-V1-HUGE")
    _scan(transport, store, runner, tmp_path)
    assert runner.calls == 0
    assert "REJECTED" in [e[1] for e in store.recent_events(50)]


class FailingRunner:
    def __init__(self):
        self.calls = 0

    def run(self, snapshot_dir, prompt_text, run_dir, effort=None):
        self.calls += 1
        return ReviewResult(
            ok=False, output_text="{}", output_format="json", exit_code=1, model_calls=1,
            usage={"total_cost_usd": 3.02, "num_turns": 9, "subtype": "error_max_budget_usd"},
            error="claude_cli_failed exit=1 subtype=error_max_budget_usd total_cost_usd=3.02 max_budget_usd=3.0",
        )


def test_budget_stop_is_failed_readable_costed_and_not_published(transport, store, tmp_path):
    runner = FailingRunner()
    _publish(transport, LARGE)
    _scan(transport, store, runner, tmp_path)
    assert runner.calls == 1
    jobs = store.jobs_in_states([JobState.FAILED])
    assert len(jobs) == 1 and "error_max_budget_usd" in jobs[0].last_error
    events = {e[1]: e[3] for e in store.recent_events(50)}
    assert json.loads(events["REVIEW_COST"])["total_cost_usd"] == 3.02
    assert "error_max_budget_usd" in events["FAILED"]
    assert not any(p.startswith(f"{REMOTE_ROOT}/reviews/") for p in transport.files)
    _scan(transport, store, runner, tmp_path)           # not retried by itself
    assert runner.calls == 1


# --- RealReviewRunner against a recorded CLI answer ---------------------------------


def _run_with(monkeypatch, tmp_path, returncode, payload):
    seen = {}

    class Done:
        pass

    done = Done()
    done.returncode, done.stdout, done.stderr = returncode, json.dumps(payload), ""

    def fake_run(argv, **kwargs):
        seen["argv"] = argv
        return done

    monkeypatch.setattr(review_runner, "_run", fake_run)
    runs = tmp_path / "runs"
    runs.mkdir(exist_ok=True)
    result = RealReviewRunner("claude", None, ["Read"], 60).run(tmp_path / "s", "p", runs)
    return result, seen["argv"]


def test_runner_argv_never_carries_a_budget_cap(monkeypatch, tmp_path):
    _, argv = _run_with(monkeypatch, tmp_path, 0, {"result": "ok", "subtype": "success"})
    assert "--max-budget-usd" not in argv


def test_runner_budget_stop_as_measured_exit1_is_a_readable_failure(monkeypatch, tmp_path):
    # shape recorded from the real CLI on 2026-11-03 with --max-budget-usd 0.0001
    payload = {"type": "result", "subtype": "error_max_budget_usd", "is_error": True, "num_turns": 1,
               "total_cost_usd": 0.000588, "result": None, "usage": {"input_tokens": 3}}
    result, _ = _run_with(monkeypatch, tmp_path, 1, payload)
    assert not result.ok and result.model_calls == 1
    assert "subtype=error_max_budget_usd" in result.error
    assert result.usage["total_cost_usd"] == 0.000588 and result.usage["input_tokens"] == 3


def test_runner_treats_cli_reported_error_with_exit0_as_failure(monkeypatch, tmp_path):
    result, _ = _run_with(monkeypatch, tmp_path, 0, {"is_error": True, "subtype": "error_during_execution", "result": None})
    assert not result.ok and "error_during_execution" in result.error


def test_runner_success_records_cost_and_turns(monkeypatch, tmp_path):
    result, _ = _run_with(monkeypatch, tmp_path, 0, {"result": "리뷰", "subtype": "success", "num_turns": 4,
                                                      "total_cost_usd": 0.42, "usage": {"output_tokens": 9}})
    assert result.ok and result.output_text == "리뷰"
    assert result.usage == {"output_tokens": 9, "total_cost_usd": 0.42, "num_turns": 4, "subtype": "success"}
