"""v0.2.33: the review-intent nonce is consumed at most once across restarts and separate OS processes (real StateStore on a
temp database; no model, no network)."""
import subprocess
import sys
from pathlib import Path

from skill_collab_watcher.state_store import StateStore

WORKER = Path(__file__).with_name("nonce_worker.py")


def test_consumed_once_then_refused_and_still_refused_after_a_restart(tmp_path):
    db = tmp_path / "state.sqlite3"
    store = StateStore(db)
    store.ensure_auto_tables()
    assert store.consume_review_intent_nonce("a" * 24, "REQ-1", 1) is True
    assert store.consume_review_intent_nonce("a" * 24, "REQ-1", 2) is False
    store.close()
    restarted = StateStore(db)
    restarted.ensure_auto_tables()
    try:
        assert restarted.consume_review_intent_nonce("a" * 24, "REQ-1", 3) is False
        assert restarted.consume_review_intent_nonce("b" * 24, "REQ-1", 3) is True
    finally:
        restarted.close()


def test_read_only_store_never_consumes(tmp_path):
    db = tmp_path / "state.sqlite3"
    rw = StateStore(db)
    rw.ensure_auto_tables()
    rw.close()
    ro = StateStore(db, read_only=True)
    try:
        assert ro.consume_review_intent_nonce("c" * 24, "REQ-1", 1) is False
    finally:
        ro.close()


def test_two_os_processes_racing_for_one_nonce_yield_exactly_one_consumer(tmp_path):
    db = tmp_path / "state.sqlite3"
    seed = StateStore(db)
    seed.ensure_auto_tables()
    seed.close()
    nonce = "d" * 24
    procs = [subprocess.Popen([sys.executable, str(WORKER), str(db), nonce, "REQ-RACE"],
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) for _ in range(2)]
    outputs = []
    for p in procs:
        out, err = p.communicate(timeout=120)
        assert p.returncode == 0, err
        outputs.append(out.strip())
    pids = {line.split()[0] for line in outputs}
    consumed = [line.split()[1] for line in outputs]
    assert len(pids) == 2, "the two consumers must be distinct OS processes"
    assert consumed.count("CONSUMED=True") == 1, outputs
