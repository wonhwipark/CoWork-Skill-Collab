"""User-signed independent-review intent, verified fail-closed. Isolated: nothing in the admission path calls it yet.

The intent is signed with a trust-root key whose purpose is REVIEW_INTENT, bound to one exact request id, revision,
skill, repository and package bytes, valid for a bounded window and usable once (nonce). Wildcards, GitHub text and
keys of another purpose are never accepted."""
from __future__ import annotations

import json
from datetime import datetime
from typing import Callable

from skill_collab_watcher.approval import TrustRoot, canonical

INTENT_SCHEMA = "REVIEW_INTENT_V1"
INTENT_KEY_PURPOSE = "REVIEW_INTENT"
MAX_INTENT_BYTES = 16384
MAX_INTENT_LIFETIME_SEC = 7 * 86400
BOUND_FIELDS = ("request_id", "request_revision", "skill_id", "source_commit", "request_sha256", "zip_sha256", "package_size")


class IntentRejected(Exception):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


def _ts(value) -> datetime:
    if not isinstance(value, str):
        raise IntentRejected("TIME_FORMAT")
    try:
        return datetime.fromisoformat(value)
    except ValueError as exc:
        raise IntentRejected("TIME_FORMAT") from exc


def verify_review_intent(raw: bytes, *, trust: TrustRoot | None, backend, expected: dict, now: datetime,
                         consume_nonce: Callable[[str], bool]) -> dict:
    return verify_review_intent_with_key(raw, trust=trust, backend=backend, expected=expected, now=now, consume_nonce=consume_nonce)[0]


def verify_review_intent_with_key(raw: bytes, *, trust: TrustRoot | None, backend, expected: dict, now: datetime,
                                  consume_nonce: Callable[[str], bool]) -> tuple[dict, str]:
    if trust is None:
        raise IntentRejected("TRUST_ROOT_MISSING")
    if backend is None:
        raise IntentRejected("BACKEND_MISSING")
    if trust.frozen:
        raise IntentRejected("TRUST_ROOT_FROZEN")
    if len(raw) > MAX_INTENT_BYTES:
        raise IntentRejected("TOO_LARGE")
    try:
        envelope = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise IntentRejected("MALFORMED") from exc
    if not isinstance(envelope, dict):
        raise IntentRejected("MALFORMED")
    payload, signature = envelope.get("payload"), envelope.get("signature")
    if not isinstance(payload, dict) or payload.get("schema") != INTENT_SCHEMA:
        raise IntentRejected("SCHEMA")
    if not isinstance(signature, str) or not signature:
        raise IntentRejected("MISSING_SIGNATURE")
    key = trust.keys.get(str(envelope.get("key_id")))
    if key is None:
        raise IntentRejected("UNKNOWN_KEY")
    if key.status != "ACTIVE":
        raise IntentRejected("KEY_NOT_ACTIVE")
    if key.purpose != INTENT_KEY_PURPOSE:
        raise IntentRejected("KEY_PURPOSE")
    if not backend.verify(key.public_key, canonical(payload), signature):
        raise IntentRejected("SIGNATURE_INVALID")
    if payload.get("repo_id") != trust.repo_id:
        raise IntentRejected("WRONG_REPO")
    for name in BOUND_FIELDS:
        if str(payload.get(name)) != str(expected.get(name)):
            raise IntentRejected(f"BINDING_{name.upper()}")
    skill = payload.get("skill_id")
    if not isinstance(skill, str) or not skill or "*" in skill:
        raise IntentRejected("SKILL_NOT_EXACT")
    issued, expires = _ts(payload.get("issued_at")), _ts(payload.get("expires_at"))
    if issued.replace(microsecond=0) > now.replace(microsecond=0):
        raise IntentRejected("NOT_YET_VALID")
    if expires <= now:
        raise IntentRejected("EXPIRED")
    if (expires - issued).total_seconds() > MAX_INTENT_LIFETIME_SEC or expires <= issued:
        raise IntentRejected("LIFETIME")
    nonce = payload.get("nonce")
    if not isinstance(nonce, str) or len(nonce) < 16:
        raise IntentRejected("NONCE_FORMAT")
    if not consume_nonce(nonce):
        raise IntentRejected("REPLAY")
    return payload, str(envelope.get("key_id"))
