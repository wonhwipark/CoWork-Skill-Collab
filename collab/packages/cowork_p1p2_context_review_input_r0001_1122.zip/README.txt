P1/P2 independent reviewer input (candidate only). Includes full existing code, tests, design, Windows E2E plan and current published UI. No signed request or host execution is implied.
