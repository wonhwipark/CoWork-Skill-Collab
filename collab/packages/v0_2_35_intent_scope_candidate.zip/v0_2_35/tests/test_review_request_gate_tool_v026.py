"""Pure local regression: no network, watcher, signing, READY or paid calls."""
import contextlib
import io
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tools import review_request_gate as gate

REQ = "REQ-COWORK-REVIEW-GATE-R2-20261117"
SHA_COMMIT = "f" * 40
REPO_ID = "1451933830"


class GateTests(unittest.TestCase):
    def setUp(self):
        self.ctx = tempfile.TemporaryDirectory()
        self.addCleanup(self.ctx.cleanup)
        self.root = Path(self.ctx.name)
        self.package = self.root / "candidate.zip"
        with zipfile.ZipFile(self.package, "w") as z:
            z.writestr("skill_collab_watcher/__init__.py", "# test package\n")
        self.config = self.root / "reviewer.config.json"
        self.policy_map = {
            "POLICY-STATIC-V1": {"max_budget_usd": 1.0},
            "POLICY-STATIC-V1-LARGE": {"max_budget_usd": 3.0},
        }
        self.save_config()
        self.request = self.root / "REQUEST.md"
        self.fields = {
            "schema": "SKILL_COLLAB_REVIEW_REQUEST_V1", "state": "SUBMITTED",
            "request_id": REQ, "request_revision": "1",
            "project_id": "COWORK-AUTO-APPROVAL-20261115-001",
            "work_id": "COWORK-AUTO-APPROVAL-20261115-001",
            "skill_id": "cowork-review-watcher",
            "package_path": "/SKILL-COLLAB/packages/candidate.zip",
            "package_sha256": hashlib.sha256(self.package.read_bytes()).hexdigest(),
            "package_size_bytes": str(self.package.stat().st_size),
            "reviewer_os": "WINDOWS", "test_policy": "STATIC_ONLY",
            "run_policy_ref": "POLICY-STATIC-V1-LARGE",
        }
        self.save_request()

    def save_config(self):
        self.config.write_text(json.dumps({"review_policy": {"known_run_policy_refs": self.policy_map}}), encoding="utf-8")

    def save_request(self):
        self.request.write_bytes(("---\n" + "".join(f"{key}: {val}\n" for key, val in self.fields.items()) +
                                  "knowledge_refs: []\n---\n\n# Review\n").encode("utf-8"))

    def pass_check(self, intent="design", max_usd="3.00"):
        return gate.check_request(self.request, self.package, self.config,
                                  intent=intent, required_budget=gate._target_money(max_usd))

    def run_cli(self, *args):
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            code = gate.main(list(args))
        return code, out.getvalue(), err.getvalue()

    def test_independent_publication_does_not_consult_cost(self):
        self.fields["run_policy_ref"] = "POLICY-STATIC-V1"
        self.save_request()
        self.config.write_text("{not valid json}")
        result = gate.check_request_for_publication(self.request, self.package)
        self.assertEqual(result["run_policy_ref"], "POLICY-STATIC-V1")
        self.assertNotIn("expected_max_budget_usd", result)
        self.assertEqual(result["authorization"], "NOT_CHECKED")

    def test_independent_selector_uses_registered_identity_without_price(self):
        self.assertEqual(gate.select_policy(gate._json(self.config), "independent", None),
                         "POLICY-STATIC-V1")

    def test_independent_publication_ignores_legacy_budget_parameter(self):
        self.fields["run_policy_ref"] = "POLICY-STATIC-V1"
        self.save_request()
        for legacy in (None, "invalid", -1, True, float("inf"), "3.00"):
            result = gate.check_request_for_publication(self.request, self.package, required_budget=legacy)
            self.assertEqual(result["authorization"], "NOT_CHECKED")
            self.assertNotIn("expected_max_budget_usd", result)

    def test_independent_publication_rejects_bad_policy_reference(self):
        self.fields["run_policy_ref"] = "POLICY-NOT-KNOWN"
        self.save_request()
        with self.assertRaisesRegex(gate.GateReject, "RUN_POLICY_NOT_PUBLISHABLE_FOR_INTENT"):
            gate.check_request_for_publication(self.request, self.package)

    def test_request_fixture_has_lf_newlines_on_all_platforms(self):
        request_bytes = self.request.read_bytes()
        self.assertTrue(request_bytes.startswith(b"---\n"))
        self.assertNotIn(b"\r\n", request_bytes)

    def test_publication_gate_without_live_config_checks_schema_zip_and_ref(self):
        self.config.unlink()
        self.fields["run_policy_ref"] = "POLICY-STATIC-V1"
        self.save_request()
        out = gate.check_request_for_publication(
            self.request, self.package, intent="unified", required_budget=gate._target_money("3.00"))
        self.assertEqual(out["status"], "PASS_REQUEST_INPUT_ONLY")
        self.assertEqual(out["authorization"], "NOT_CHECKED")
        self.assertEqual(out["package_sha256"], self.fields["package_sha256"])
        self.assertEqual(out["model_calls"], 0)

    def test_publication_gate_rejects_legacy_ref_even_without_host(self):
        self.config.unlink()
        with self.assertRaisesRegex(gate.GateReject, "RUN_POLICY_NOT_PUBLISHABLE_FOR_INTENT"):
            gate.check_request_for_publication(
                self.request, self.package, intent="unified", required_budget=gate._target_money("3.00"))

    def test_legacy_unified_uses_policy_identity_without_price(self):
        """The old unified spelling has no price gate or implied authorization."""
        self.policy_map["POLICY-STATIC-V1"] = {"max_budget_usd": 3.0}
        self.save_config()
        self.fields["run_policy_ref"] = "POLICY-STATIC-V1"
        self.save_request()
        result = self.pass_check("unified", "3.00")
        self.assertEqual(result["run_policy_ref"], "POLICY-STATIC-V1")
        self.assertNotIn("expected_max_budget_usd", result)
        self.assertEqual(result["authorization"], "NOT_CHECKED")
        self.assertEqual(gate.select_policy(gate._json(self.config), "unified",
                                            gate._target_money("3.00")), "POLICY-STATIC-V1")

    def test_unified_ignores_old_one_and_one_fifty_config(self):
        self.fields["run_policy_ref"] = "POLICY-STATIC-V1"
        self.save_request()
        for configured in (1.0, 1.5):
            self.policy_map["POLICY-STATIC-V1"] = {"max_budget_usd": configured}
            self.save_config()
            self.assertEqual(self.pass_check("unified", "3.00")["run_policy_ref"], "POLICY-STATIC-V1")

    def test_unified_rejects_legacy_design_ref_despite_three_dollar_registration(self):
        self.policy_map["POLICY-STATIC-V1"] = {"max_budget_usd": 3.0}
        self.save_config()
        # Existing DESIGN and LARGE refs can stay installed for legacy requests.
        for legacy in ("POLICY-STATIC-V1-DESIGN", "POLICY-STATIC-V1-LARGE"):
            self.fields["run_policy_ref"] = legacy
            self.save_request()
            with self.assertRaisesRegex(gate.GateReject, "RUN_POLICY_NOT_LIVE_MATCH"):
                self.pass_check("unified", "3.00")

    def test_unified_cli_prepublication_is_not_approval(self):
        self.policy_map["POLICY-STATIC-V1"] = {"max_budget_usd": 3.0}
        self.save_config()
        self.fields["run_policy_ref"] = "POLICY-STATIC-V1"
        self.save_request()
        code, out, err = self.run_cli("select", "--live-config", str(self.config),
                                      "--intent", "unified")
        self.assertEqual((code, err), (0, ""))
        self.assertEqual(json.loads(out)["selected_run_policy_ref"], "POLICY-STATIC-V1")
        self.assertEqual(json.loads(out)["cost_gate"], "OFF")
        self.assertEqual(json.loads(out)["approval"], "NOT_CHECKED")
        code, out, err = self.run_cli("check", "--live-config", str(self.config),
                                      "--intent", "unified", "--request", str(self.request),
                                      "--package", str(self.package))
        self.assertEqual((code, err), (0, ""))
        self.assertEqual(json.loads(out)["status"], "PASS_PREPUBLICATION_ONLY")

    def test_unified_ignores_legacy_requested_amount(self):
        self.policy_map["POLICY-STATIC-V1"] = {"max_budget_usd": 1.5}
        self.save_config()
        self.fields["run_policy_ref"] = "POLICY-STATIC-V1"
        self.save_request()
        self.assertEqual(self.pass_check("unified", "1.50")["authorization"], "NOT_CHECKED")
        self.policy_map["POLICY-STATIC-V1"] = {"max_budget_usd": 3.0}
        self.save_config()
        self.assertEqual(self.pass_check("unified", "6.00")["authorization"], "NOT_CHECKED")

    def test_unified_stale_or_missing_policy_fail_closed(self):
        self.policy_map.pop("POLICY-STATIC-V1")
        self.save_config()
        with self.assertRaisesRegex(gate.GateReject, "POLICY_NOT_INSTALLED"):
            gate.select_policy(gate._json(self.config), "unified", gate._target_money("3"))
        self.config.unlink()
        with self.assertRaises(gate.GateReject):
            self.pass_check("unified", "3.00")

    def test_old_live_legacy_large_design_passes(self):
        r = self.pass_check()
        self.assertEqual(r["run_policy_ref"], "POLICY-STATIC-V1-LARGE")
        self.assertEqual(r["authorization"], "NOT_CHECKED")
        self.assertEqual(r["request_sha256"], hashlib.sha256(self.request.read_bytes()).hexdigest())
        self.assertEqual(r["model_calls"], 0)

    def test_new_design_preference_when_installed(self):
        self.policy_map["POLICY-STATIC-V1-DESIGN"] = {"max_budget_usd": 3.0}
        self.save_config()
        self.assertEqual(gate.select_policy(gate._json(self.config), "design", gate._target_money("3")),
                         "POLICY-STATIC-V1-DESIGN")

    def test_self_bootstrap_mismatch_is_blocked(self):
        self.fields["run_policy_ref"] = "POLICY-STATIC-V1-DESIGN"
        self.save_request()
        with self.assertRaisesRegex(gate.GateReject, "RUN_POLICY_NOT_LIVE_MATCH"):
            self.pass_check()

    def test_no_host_evidence_fails_closed(self):
        self.config.unlink()
        with self.assertRaises(gate.GateReject):
            self.pass_check()

    def test_unknown_tier_fails_closed(self):
        self.policy_map = {"POLICY-STATIC-V1": {"max_budget_usd": 1.0}}
        self.save_config()
        with self.assertRaisesRegex(gate.GateReject, "POLICY_NOT_INSTALLED"):
            self.pass_check()

    def test_configured_cost_disagreement_is_not_a_gate(self):
        self.policy_map["POLICY-STATIC-V1-LARGE"] = {"max_budget_usd": 6.0}
        self.save_config()
        self.assertEqual(self.pass_check()["authorization"], "NOT_CHECKED")

    def test_legacy_skill_amount_is_not_a_gate(self):
        self.fields["run_policy_ref"] = "POLICY-STATIC-V1"
        self.save_request()
        self.assertEqual(self.pass_check("skill", "1.50")["run_policy_ref"], "POLICY-STATIC-V1")

    def test_basic_after_live_config_change(self):
        self.policy_map["POLICY-STATIC-V1"] = {"max_budget_usd": 1.5}
        self.save_config()
        self.fields["run_policy_ref"] = "POLICY-STATIC-V1"
        self.save_request()
        self.assertEqual(self.pass_check("skill", "1.50")["run_policy_ref"], "POLICY-STATIC-V1")

    def test_missing_or_unparseable_registry(self):
        for bad in ({}, {"review_policy": {}}, {"review_policy": {"known_run_policy_refs": ["POLICY-STATIC-V1-LARGE"]}}):
            self.config.write_text(json.dumps(bad), encoding="utf-8")
            with self.assertRaises(gate.GateReject):
                self.pass_check()

    def test_legacy_price_values_cannot_reject_registered_input(self):
        for v in ("3.0", True, 0, -3, float("inf"), float("nan"), 3.001):
            self.policy_map["POLICY-STATIC-V1-LARGE"] = {"max_budget_usd": v}
            self.save_config()
            self.assertEqual(self.pass_check()["authorization"], "NOT_CHECKED")

    def test_cli_ignores_malformed_legacy_price_flag(self):
        code, out, err = self.run_cli("select", "--live-config", str(self.config),
                                      "--intent", "independent", "--required-budget-usd", "not-a-price")
        self.assertEqual((code, err), (0, ""))
        self.assertEqual(json.loads(out)["cost_gate"], "OFF")
        self.assertEqual(json.loads(out)["approval"], "NOT_CHECKED")

    def test_modified_package_rejected(self):
        self.package.write_bytes(self.package.read_bytes() + b"modified")
        with self.assertRaisesRegex(gate.GateReject, "PACKAGE_SIZE_MISMATCH"):
            self.pass_check()

    def test_bad_sha_rejected(self):
        self.fields["package_sha256"] = "f" * 64
        self.save_request()
        with self.assertRaisesRegex(gate.GateReject, "PACKAGE_SHA256_MISMATCH"):
            self.pass_check()

    def test_malformed_zip_rejected(self):
        self.package.write_bytes(b"not a zip")
        self.fields["package_sha256"] = hashlib.sha256(self.package.read_bytes()).hexdigest()
        self.fields["package_size_bytes"] = str(self.package.stat().st_size)
        self.save_request()
        with self.assertRaisesRegex(gate.GateReject, "INVALID_PACKAGE_ZIP"):
            self.pass_check()

    def test_zip_traversal_rejected(self):
        with zipfile.ZipFile(self.package, "w") as z:
            z.writestr("../escape.txt", "bad")
        self.fields["package_sha256"] = hashlib.sha256(self.package.read_bytes()).hexdigest()
        self.fields["package_size_bytes"] = str(self.package.stat().st_size)
        self.save_request()
        with self.assertRaisesRegex(gate.GateReject, "UNSAFE_PACKAGE_MEMBER"):
            self.pass_check()

    def test_duplicate_policy_field_rejected(self):
        self.request.write_bytes(self.request.read_bytes().replace(
            b"run_policy_ref: POLICY-STATIC-V1-LARGE\n", b"run_policy_ref: POLICY-STATIC-V1-LARGE\nrun_policy_ref: POLICY-STATIC-V1-DESIGN\n"))
        with self.assertRaisesRegex(gate.GateReject, "REQUEST_DUPLICATE_FIELD"):
            self.pass_check()

    def test_wrong_scope_rejected(self):
        self.fields["work_id"] = "COWORK-OTHER"
        self.save_request()
        with self.assertRaisesRegex(gate.GateReject, "PROJECT_WORK_SCOPE_MISMATCH"):
            self.pass_check()

    def test_nested_request_package_path_rejected(self):
        self.fields["package_path"] = "/SKILL-COLLAB/packages/nested/candidate.zip"
        self.save_request()
        with self.assertRaisesRegex(gate.GateReject, "INVALID_PACKAGE_PATH"):
            self.pass_check()

    def test_invalid_request_path_rejected(self):
        self.fields["package_path"] = "/SKILL-COLLAB/packages/../candidate.zip"
        self.save_request()
        with self.assertRaisesRegex(gate.GateReject, "INVALID_PACKAGE_PATH"):
            self.pass_check()

    def test_source_pin_string_passes(self):
        pin = self.root / "SOURCE_PIN.json"
        pin.write_text(json.dumps({"schema": "SKILL_COLLAB_SOURCE_PIN_V1", "commit": SHA_COMMIT, "repo_id": REPO_ID}))
        gate.check_source_pin(pin, REPO_ID, SHA_COMMIT)

    def test_source_pin_numeric_and_wrong_commit_rejected(self):
        pin = self.root / "SOURCE_PIN.json"
        for bad in ({"schema": "SKILL_COLLAB_SOURCE_PIN_V1", "commit": SHA_COMMIT, "repo_id": 1451933830},
                    {"schema": "SKILL_COLLAB_SOURCE_PIN_V1", "commit": "e" * 40, "repo_id": REPO_ID}):
            pin.write_text(json.dumps(bad))
            with self.assertRaises(gate.GateReject):
                gate.check_source_pin(pin, REPO_ID, SHA_COMMIT)

    def test_select_cli_is_not_approval(self):
        code, out, _ = self.run_cli("select", "--live-config", str(self.config), "--intent", "design")
        self.assertEqual(code, 0)
        self.assertEqual(json.loads(out)["status"], "POLICY_COMPATIBLE_NOT_APPROVED")

    def test_check_cli_blocked_is_nonzero(self):
        self.fields["run_policy_ref"] = "POLICY-STATIC-V1-DESIGN"
        self.save_request()
        code, out, err = self.run_cli("check", "--live-config", str(self.config), "--intent", "design",
                                      "--request", str(self.request), "--package", str(self.package))
        self.assertEqual(code, 2)
        self.assertFalse(out)
        self.assertIn("REQUEST_PREFLIGHT_BLOCKED", err)

    def test_check_cli_pass_is_prepublication_only(self):
        code, out, err = self.run_cli("check", "--live-config", str(self.config), "--intent", "design",
                                      "--request", str(self.request), "--package", str(self.package))
        self.assertEqual((code, err), (0, ""))
        self.assertEqual(json.loads(out)["status"], "PASS_PREPUBLICATION_ONLY")
        self.assertEqual(json.loads(out)["request_sha256"], hashlib.sha256(self.request.read_bytes()).hexdigest())

    def test_incomplete_source_pin_cli_is_blocked(self):
        code, out, err = self.run_cli("check", "--live-config", str(self.config), "--intent", "design",
                                      "--request", str(self.request), "--package", str(self.package),
                                      "--expected-repo-id", REPO_ID)
        self.assertEqual(code, 2)
        self.assertIn("INCOMPLETE_SOURCE_PIN_CHECK", err)


if __name__ == "__main__":
    unittest.main()

