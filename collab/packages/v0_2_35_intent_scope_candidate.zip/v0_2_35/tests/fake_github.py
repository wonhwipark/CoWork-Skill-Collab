from __future__ import annotations

import base64
import hashlib
import time
from datetime import datetime, timezone
import json
import urllib.parse

from skill_collab_watcher.github_transport import blob_sha

REPO = "example-owner/synthetic-private"
TOKEN = "test-token-not-real"


def j(obj) -> bytes:
    return json.dumps(obj).encode("utf-8")


def rp(rel: str) -> str:
    """Repository path for a file under the watcher's virtual root."""
    return "collab/" + rel


class FakeGitHub:
    """Synthetic stand-in for the REST endpoints GitHubTransport calls.

    Every commit is a full snapshot. Only commit() moves the branch head;
    commit_side() creates a snapshot that no branch points to (a PR head or a
    fork), which the watcher must never read.
    """

    def __init__(self) -> None:
        self._objects: dict[str, dict[str, bytes]] = {}
        self._head: str | None = None
        self._count = 0
        self.calls: list[tuple[str, str]] = []
        self._order: list[str] = []
        self.repo_id = "123456789"
        self._inject: list[dict] = []
        self._times: dict[str, float] = {}
        self._corrupt: set[str] = set()
        self.commit({})

    def _new_sha(self) -> str:
        self._count += 1
        sha = hashlib.sha1(f"synthetic-commit-{self._count}".encode()).hexdigest()
        self._times[sha] = time.time()
        return sha

    def set_commit_time(self, sha: str, epoch: float) -> None:
        self._times[sha] = epoch

    def commit(self, files: dict[str, bytes]) -> str:
        base = dict(self._objects[self._head]) if self._head else {}
        base.update(files)
        sha = self._new_sha()
        self._objects[sha] = base
        self._head = sha
        self._order.append(sha)
        return sha

    def commit_side(self, files: dict[str, bytes]) -> str:
        base = dict(self._objects[self._head])
        base.update(files)
        sha = self._new_sha()
        self._objects[sha] = base
        return sha

    def head(self) -> str:
        return self._head

    def files(self) -> dict[str, bytes]:
        return self._objects[self._head]

    def inject(self, method: str, needle: str, status: int = 0, headers=None, times: int = 1,
               exc: Exception | None = None) -> None:
        self._inject.append({"method": method, "needle": needle, "status": status,
                             "headers": headers or {}, "times": times, "exc": exc})

    def corrupt(self, repo_path: str) -> None:
        self._corrupt.add(repo_path)

    clock_offset_sec = 0
    send_date = True

    def request(self, method, url, headers, body=None):
        status, hdrs, data = self._request(method, url, headers, body)
        if self.send_date:
            import time
            from email.utils import formatdate

            hdrs = {**hdrs, "date": formatdate(time.time() + self.clock_offset_sec, usegmt=True)}
        return status, hdrs, data

    def _request(self, method, url, headers, body=None):
        self.calls.append((method, url))
        for rule in self._inject:
            if rule["times"] > 0 and rule["method"] == method and rule["needle"] in url:
                rule["times"] -= 1
                if rule["exc"] is not None:
                    raise rule["exc"]
                return rule["status"], rule["headers"], j({"message": "injected"})
        return self._route(method, url, headers, body)

    def _route(self, method, url, headers, body):
        parts = urllib.parse.urlsplit(url)
        path = urllib.parse.unquote(parts.path)
        query = urllib.parse.parse_qs(parts.query)
        base = f"/repos/{REPO}"
        if not path.startswith(base):
            return 404, {}, j({})
        rest = path[len(base):]
        if method == "GET" and rest == "":
            return 200, {}, j({"full_name": REPO, "id": self.repo_id} if self.repo_id is not None else {"full_name": REPO})
        if method == "GET" and rest.startswith("/commits/") and rest[len("/commits/"):] in self._objects:
            sha = rest[len("/commits/"):]
            date = datetime.fromtimestamp(self._times.get(sha, time.time()), timezone.utc).isoformat()
            return 200, {}, j({"sha": sha, "commit": {"committer": {"date": date}}})
        if method == "GET" and rest.startswith("/commits/"):
            etag = f'"{self._head}"'
            if headers.get("If-None-Match") == etag:
                return 304, {"etag": etag}, b""
            return 200, {"etag": etag}, j({"sha": self._head})
        if method == "GET" and rest.startswith("/git/trees/"):
            files = self._objects.get(rest.split("/git/trees/", 1)[1])
            if files is None:
                return 404, {}, j({})
            tree = [{"path": p, "type": "blob", "sha": blob_sha(d), "size": len(d)}
                    for p, d in sorted(files.items())]
            return 200, {}, j({"truncated": False, "tree": tree})
        if method == "GET" and rest == "/commits":
            want = query.get("path", [""])[0]
            limit = int(query.get("per_page", ["3"])[0])
            hits = []
            for index in range(len(self._order) - 1, -1, -1):
                sha = self._order[index]
                before = self._objects[self._order[index - 1]] if index > 0 else {}
                if self._objects[sha].get(want) != before.get(want):
                    hits.append({"sha": sha})
            return 200, {}, j(hits[:limit])
        if method == "GET" and rest.startswith("/compare/"):
            old_sha, new_sha = rest.split("/compare/", 1)[1].split("...", 1)
            old, new = self._objects.get(old_sha), self._objects.get(new_sha)
            if old is None or new is None:
                return 404, {}, j({})
            changed = []
            for p in sorted(set(old) | set(new)):
                if p not in new:
                    changed.append({"filename": p, "status": "removed"})
                elif old.get(p) != new[p]:
                    status = "modified" if p in old else "added"
                    changed.append({"filename": p, "status": status, "sha": blob_sha(new[p])})
            if old_sha == new_sha:
                relation = "identical"
            elif old_sha in self._order and new_sha in self._order:
                relation = "ahead" if self._order.index(old_sha) < self._order.index(new_sha) else "behind"
            else:
                relation = "diverged"
            return 200, {}, j({"files": changed, "status": relation})
        if method == "GET" and rest.startswith("/contents/"):
            repo_path = rest[len("/contents/"):]
            files = self._objects.get(query.get("ref", [self._head])[0])
            if files is None or repo_path not in files:
                return 404, {}, j({})
            data = files[repo_path]
            served = data
            if repo_path in self._corrupt:
                served = data[:-1] + bytes([data[-1] ^ 0x01])
            return 200, {}, j({"type": "file", "sha": blob_sha(data), "size": len(data),
                               "encoding": "base64", "content": base64.b64encode(served).decode("ascii")})
        if method == "PUT" and rest.startswith("/contents/"):
            repo_path = rest[len("/contents/"):]
            data = base64.b64decode(json.loads(body)["content"])
            if repo_path in self.files():
                return 422, {}, j({"message": "sha wasn't supplied"})
            self.commit({repo_path: data})
            return 201, {}, j({"content": {"sha": blob_sha(data)}})
        return 404, {}, j({})


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
