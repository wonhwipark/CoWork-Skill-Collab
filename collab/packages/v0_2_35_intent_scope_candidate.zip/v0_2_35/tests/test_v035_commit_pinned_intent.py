"""v0.2.35 (F3): the user-signed review intent is read from a snapshot commit C that is a descendant of the request's commit A, and the
exact C and the intent bytes hash are pinned at the first verification. Later replacements do not change an approval. Fake GitHub with a
linear branch and side commits, throw-away Ed25519 key, no model, no network."""
import json
from datetime import datetime, timedelta, timezone

from skill_collab_watcher.approval import TrustedKey

from auto_helpers import auto, make_request, write_delegation  # noqa: F401
from bundle import make_transport
from fake_github import rp
from test_v033_intent_wiring import (INTENT_KEY_ID, _claim_after_approval, _envelope, _install_key, _intent, _intent_key, _revalidate,
                                     _run, _setup)


def _intent_path(rid):
    return rp(f"requests/{rid}/REVIEW_INTENT.json")


def test_a_later_commit_is_pinned_and_the_approval_is_bound_to_it(auto):
    info, priv = _setup(auto)
    raw = _envelope(priv, _intent(priv, info), auto.trust.repo_id)
    assert _run(auto, info.rid, info, raw) == "READY_POSTED"
    claim = auto.env.store.auto_get_claim(info.rid, str(info.rev))
    stored = json.loads(claim["candidate_json"])
    assert stored["intent_commit"] != info.commit_a
    transport = make_transport(auto.env.http)
    transport.ensure_auth()
    assert transport.download_at_commit(stored["intent_path"], stored["intent_commit"])[0] == raw
    assert stored["intent_path"].endswith("/REVIEW_INTENT.json")
    assert len(stored["intent_raw_sha"]) == 64


def test_replacing_the_intent_later_does_not_change_the_pinned_approval(auto):
    info, priv = _setup(auto)
    claim = _claim_after_approval(auto, info, priv)
    other = _intent_key()[0]
    replacement = _envelope(other, _intent(other, info, nonce="z" * 24), auto.trust.repo_id)
    auto.env.http.commit({_intent_path(info.rid): replacement})
    assert _revalidate(auto, info, claim, auto.trust) == (True, "ok")


def test_an_intent_committed_before_the_request_is_refused(auto):
    write_delegation(auto.delegation)
    priv, pub = _intent_key()
    _install_key(auto, pub)
    rid = "REQ-SCOPE-EARLY"
    auto.env.http.commit({_intent_path(rid): _envelope(priv, _intent(priv, _FakeInfo(rid, auto)), auto.trust.repo_id)})
    info = make_request(auto.env.http, rid, skill="other-skill")
    assert _run(auto, info.rid, info, None) == "SCOPE"
    assert auto.signer.calls == 0


def test_two_intent_commits_are_ambiguous_and_refused(auto):
    info, priv = _setup(auto)
    raw = _envelope(priv, _intent(priv, info), auto.trust.repo_id)
    auto.env.http.commit({_intent_path(info.rid): raw})
    auto.env.http.commit({_intent_path(info.rid): raw + b" "})
    assert _run(auto, info.rid, info, None) == "SCOPE"
    assert auto.signer.calls == 0


def test_a_snapshot_with_changed_request_bytes_is_refused(auto):
    info, priv = _setup(auto)
    raw = _envelope(priv, _intent(priv, info), auto.trust.repo_id)
    changed = info.request + b"\n# edited after approval request\n"
    auto.env.http.commit({rp(f"requests/{info.rid}/REQUEST.md"): changed, _intent_path(info.rid): raw})
    assert _run(auto, info.rid, info, None) == "SCOPE"
    assert auto.signer.calls == 0


def test_an_intent_only_on_a_side_commit_is_invisible_and_refused(auto):
    info, priv = _setup(auto)
    raw = _envelope(priv, _intent(priv, info), auto.trust.repo_id)
    auto.env.http.commit_side({_intent_path(info.rid): raw})
    assert _run(auto, info.rid, info, None) == "SCOPE"
    assert auto.signer.calls == 0


class _FakeInfo:
    def __init__(self, rid, auto):
        self.rid = rid
        self.rev = 1
        self.commit_a = ""
        self.package = b""
        self.request = b""
