"""Cost metadata cannot block approval; use test keys/fake transport only."""
import json
import pytest

from auto_helpers import auto, make_request, write_delegation
from test_auto_approval import direct
from skill_collab_watcher.auto_approval import load_delegation
from skill_collab_watcher.config import Config
from skill_collab_watcher.state_store import StateStore

BAD_AMOUNTS = [None, 0, -1, True, '3', 'broken', {}, float('inf'), float('nan'), 10**400]


@pytest.mark.parametrize('amount', BAD_AMOUNTS)
def test_config_price_metadata_cannot_prevent_loading(tmp_path, amount):
    path = tmp_path / 'config.json'
    path.write_text(json.dumps({'review_policy': {
        'max_budget_usd': amount, 'daily_budget_usd': amount,
        'known_run_policy_refs': {'POLICY-STATIC-V1': {'max_budget_usd': amount}},
    }}))
    p = Config.load(path).review_policy
    assert p.max_budget_usd is None and p.run_budgets == {} and p.daily_budget_usd is None
    assert p.dispatch_allowed is False  # price removal cannot enable execution


@pytest.mark.parametrize('amount', BAD_AMOUNTS)
def test_bad_legacy_amount_still_uses_real_test_signer_once(auto, amount):
    write_delegation(auto.delegation, max_request_usd=amount)
    d, why = load_delegation(auto.delegation, __import__('time').time(), 'skip')
    assert d is not None and why == 'ok' and d.max_request_cents == 0
    auto.policy.run_budgets_usd = {'POLICY-STATIC-V1': amount}
    info = make_request(auto.env.http)
    assert direct(auto, info.rid, info) == 'READY_POSTED'
    assert type(auto.signer).calls == 1
    direct(auto, info.rid, info)  # cached READY_POSTED may be returned; no second signature is allowed
    assert type(auto.signer).calls == 1 and auto.env.runner.calls == 0


@pytest.mark.parametrize('amount', BAD_AMOUNTS)
def test_bad_price_does_not_enable_disabled_authority(auto, amount):
    write_delegation(auto.delegation, max_request_usd=amount, enabled=False)
    info = make_request(auto.env.http)
    direct(auto, info.rid, info)
    assert type(auto.signer).calls == 0 and auto.env.runner.calls == 0


@pytest.mark.parametrize('amount', BAD_AMOUNTS)
def test_price_telemetry_does_not_replace_atomic_duplicate_check(tmp_path, amount):
    s = StateStore(tmp_path / 'temp.sqlite3')
    try:
        s.ensure_auto_tables()
        args = ('COST-ONLY', '1', 'a'*64, amount, '{}', 2_000_000_000)
        kw = dict(max_day_calls=0, max_day_cents=0, max_month_cents=0)
        assert s.auto_claim(*args, **kw) == 'CLAIMED'
        assert s.auto_get_claim('COST-ONLY', '1')['reserved_cents'] == 0
        assert s.auto_claim(*args, **kw) == 'EXISTS'
    finally:
        s.close()


def test_accounting_query_cannot_become_an_approval_dependency(auto, monkeypatch):
    def must_not_query(*args, **kwargs):
        raise AssertionError('accounting must not gate authority or revalidation')
    monkeypatch.setattr(auto.env.store, 'window_usage', must_not_query)
    info = make_request(auto.env.http)
    assert direct(auto, info.rid, info) == 'READY_POSTED'
    assert type(auto.signer).calls == 1 and auto.env.runner.calls == 0


def test_legacy_claim_price_metadata_cannot_block_revalidation(auto):
    info = make_request(auto.env.http)
    assert direct(auto, info.rid, info) == 'READY_POSTED'
    claim = dict(auto.env.store.auto_get_claim(info.rid, str(info.rev)))
    candidate = json.loads(claim['candidate_json'])
    candidate['cents'] = 'unparseable historical price'
    claim['candidate_json'] = json.dumps(candidate)
    from bundle import make_transport
    transport = make_transport(auto.env.http)
    transport.ensure_auth()
    allowed, why = auto.approver._revalidate(transport, auto.env.store, info.rid, str(info.rev),
                                            claim, __import__('time').time(), auto.trust)
    assert allowed and why == 'ok'
