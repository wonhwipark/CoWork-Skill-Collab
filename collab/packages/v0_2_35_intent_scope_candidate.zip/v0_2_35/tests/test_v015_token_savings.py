"""0.1.5: cache-TTL switch, per-tier effort, local transcript, stream-json parsing,
file index + prompt, request_id validation, path redaction, null-budget guard.
No real `claude` process: subprocess.run is replaced by a recorder."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest

from skill_collab_watcher import review_runner
from skill_collab_watcher.config import Config, ConfigError
from skill_collab_watcher.fake_runner import FakeReviewRunner
from skill_collab_watcher.models import JobState, ReviewResult, ValidationOutcome
from skill_collab_watcher.orchestrator import (
    CONTEXT_DIR_NAME, FILE_INDEX_NAME, _file_index, _redact_local_paths, run_scan_cycle,
)
from skill_collab_watcher.review_runner import (
    CACHE_5M_ENV, CLAUDE_CWD_NAME, RealReviewRunner, _parse_cli_output, build_argv,
)
from skill_collab_watcher.validator import LocalPolicy, validate

from conftest import BASELINE, REMOTE_ROOT, make_package_zip, ready_md, request_md

SMALL, LARGE = "POLICY-STATIC-V1", "POLICY-STATIC-V1-LARGE"


def _cfg(tmp_path, review_policy: dict) -> Config:
    p = tmp_path / "c.json"
    base = {"max_budget_usd": 1.0}
    base.update(review_policy)
    p.write_text(json.dumps({"baseline_id": BASELINE, "local_state_dir": str(tmp_path / "st"),
                             "review_policy": base}), encoding="utf-8")
    return Config.load(p)


# --- config --------------------------------------------------------------------------


def test_new_options_default_to_old_behaviour(tmp_path):
    rp = _cfg(tmp_path, {"known_run_policy_refs": [SMALL]}).review_policy
    assert rp.prompt_cache_ttl == "1h" and rp.save_transcript is False and rp.effort is None
    assert rp.effort_for(SMALL) is None


def test_tier_effort_and_default_effort(tmp_path):
    rp = _cfg(tmp_path, {
        "effort": "high",
        "known_run_policy_refs": {SMALL: {"max_budget_usd": 1.0, "effort": "medium"}, LARGE: {"max_budget_usd": 3.0}},
    }).review_policy
    assert rp.effort_for(SMALL) == "medium"
    assert rp.effort_for(LARGE) == "high"          # falls back to review_policy.effort
    assert rp.effort_for("unknown") == "high"


@pytest.mark.parametrize("bad", [
    {"prompt_cache_ttl": "30m"},
    {"prompt_cache_ttl": 5},
    {"save_transcript": "true"},
    {"effort": "ultra"},
    {"known_run_policy_refs": {SMALL: {"effort": "turbo"}}},
])
def test_bad_values_are_config_errors(tmp_path, bad):
    with pytest.raises(ConfigError):
        _cfg(tmp_path, bad)


# --- argv / env / transcript -------------------------------------------------------------


def test_argv_effort_and_stream_flags():
    plain = build_argv("claude", None, ["Read"], Path("C:/s"))
    assert "--effort" not in plain and plain[plain.index("--output-format") + 1] == "json" and "--verbose" not in plain
    argv = build_argv("claude", None, ["Read"], Path("C:/s"), effort="medium", stream=True)
    assert argv[argv.index("--effort") + 1] == "medium"
    assert argv[argv.index("--output-format") + 1] == "stream-json" and "--verbose" in argv
    assert "bypassPermissions" not in argv and argv[argv.index("--permission-mode") + 1] == "dontAsk"


def _stream(result: dict) -> str:
    events = [
        {"type": "system", "subtype": "init"},
        {"type": "assistant", "message": {"usage": {"output_tokens": 5}}},
        {"type": "user", "message": "tool result"},
        result,
    ]
    return "\n".join(json.dumps(e) for e in events) + "\n"


def test_parse_handles_single_object_and_stream():
    one = {"type": "result", "subtype": "success", "result": "x", "total_cost_usd": 0.1}
    assert _parse_cli_output(json.dumps(one)) == one
    assert _parse_cli_output(_stream(one)) == one
    assert _parse_cli_output("not json at all") == {}
    assert _parse_cli_output("") == {}


def _runner_run(monkeypatch, tmp_path, stdout, returncode=0, **runner_kwargs):
    seen = {}

    class Done:
        pass

    done = Done()
    done.returncode, done.stdout, done.stderr = returncode, stdout, ""

    def fake_run(argv, **kwargs):
        seen["argv"], seen["kwargs"] = argv, kwargs
        return done

    monkeypatch.setattr(review_runner, "_run", fake_run)
    runs = tmp_path / "runs"
    runs.mkdir(parents=True, exist_ok=True)
    snap = tmp_path / "snap_k"
    snap.mkdir(parents=True, exist_ok=True)
    effort = runner_kwargs.pop("effort", None)
    result = RealReviewRunner("claude", None, ["Read"], 60, **runner_kwargs).run(snap, "p", runs, effort=effort)
    return result, seen, runs


def test_cache_ttl_env_only_when_5m(monkeypatch, tmp_path):
    monkeypatch.delenv(CACHE_5M_ENV, raising=False)
    ok = json.dumps({"result": "r", "subtype": "success"})
    _, seen, _ = _runner_run(monkeypatch, tmp_path, ok)
    assert seen["kwargs"]["env"] is None                       # 1h (default): environment untouched
    _, seen, _ = _runner_run(monkeypatch, tmp_path, ok, prompt_cache_ttl="5m")
    env = seen["kwargs"]["env"]
    assert env[CACHE_5M_ENV] == "1"
    # nothing else is added or removed: this is os.environ plus the one switch
    import os
    assert {k: v for k, v in env.items() if k != CACHE_5M_ENV} == {k: v for k, v in os.environ.items() if k != CACHE_5M_ENV}
    assert CACHE_5M_ENV not in os.environ                      # the parent process is not changed


def test_effort_reaches_argv(monkeypatch, tmp_path):
    ok = json.dumps({"result": "r", "subtype": "success"})
    _, seen, _ = _runner_run(monkeypatch, tmp_path, ok, effort="medium")
    assert seen["argv"][seen["argv"].index("--effort") + 1] == "medium"


def test_transcript_saved_locally_and_result_parsed_from_stream(monkeypatch, tmp_path):
    final = {"type": "result", "subtype": "success", "is_error": False, "result": "리뷰 본문", "num_turns": 7,
             "total_cost_usd": 0.5, "usage": {"output_tokens": 9, "cache_read_input_tokens": 11}}
    result, seen, runs = _runner_run(monkeypatch, tmp_path, _stream(final), save_transcript=True)
    assert seen["argv"][seen["argv"].index("--output-format") + 1] == "stream-json"
    assert result.ok and result.output_text == "리뷰 본문"
    assert result.usage["total_cost_usd"] == 0.5 and result.usage["num_turns"] == 7 and result.usage["cache_read_input_tokens"] == 11
    files = list((runs / "transcripts").glob("*.jsonl"))
    assert len(files) == 1 and files[0].name == "snap_k.jsonl"
    assert files[0].read_text(encoding="utf-8").count("\n") == 4
    # no transcript, no stream, when the option is off
    result2, seen2, runs2 = _runner_run(monkeypatch, tmp_path / "other", json.dumps({"result": "x", "subtype": "success"}))
    assert not (runs2 / "transcripts").exists()


def test_stream_budget_stop_is_a_readable_failure(monkeypatch, tmp_path):
    final = {"type": "result", "subtype": "error_max_budget_usd", "is_error": True, "result": None,
             "total_cost_usd": 3.01, "usage": {}}
    result, _, _ = _runner_run(monkeypatch, tmp_path, _stream(final), returncode=1, save_transcript=True)
    assert not result.ok and "subtype=error_max_budget_usd" in result.error and "total_cost_usd=3.01" in result.error
    assert len(result.output_text) < 2000                      # not the whole stream


# --- request_id validation -------------------------------------------------------------------


def _policy():
    return LocalPolicy(active_baseline_id=BASELINE, local_policy_revision="1", known_run_policy_refs=[SMALL],
                       run_budgets_usd={SMALL: 1.0}, run_efforts={SMALL: "medium"})


def _validate_id(request_id, revision="1", folder=None):
    sha = "a" * 64
    req = request_md(request_id=request_id, request_revision=revision, package_sha256=sha, package_size=10)
    ready = ready_md(hashlib.sha256(req.encode("utf-8")).hexdigest(), sha, request_id=request_id, request_revision=revision)
    return validate(req, ready, None, _policy(), expected_request_id=folder)


def test_plain_request_ids_pass():
    for rid in ("REQ-1", "WLK-WORKLIST-20261103-001", "a", "A_b.c-9"):
        assert _validate_id(rid, folder=rid).needs_package_download, rid


@pytest.mark.parametrize("rid", ["..", "..\\..\\evil", "a/b", "a b", ".hidden", "-lead", "x" * 129, "ａｂｃ", "a|b", "a:b", "con?"])
def test_unsafe_request_ids_rejected(rid):
    # single-quoted YAML has no escapes, so the value reaches the validator unchanged
    quoted = "'" + rid.replace("'", "''") + "'"
    out = _validate_id(quoted, folder=None)
    assert out.outcome == ValidationOutcome.REJECTED and "plain name" in out.reason, (rid, out.outcome, out.reason)


def test_unsafe_revision_rejected():
    out = _validate_id("REQ-1", revision='"1/../x"')
    assert out.outcome == ValidationOutcome.REJECTED


def test_request_id_must_match_its_folder():
    out = _validate_id("REQ-1", folder="REQ-2")
    assert out.outcome == ValidationOutcome.REJECTED and "folder" in out.reason


# --- orchestrator: prompt, index, redaction, effort ------------------------------------------------


class RecordingRunner:
    def __init__(self, text="ok"):
        self.calls = 0
        self.text = text

    def run(self, snapshot_dir, prompt_text, run_dir, effort=None):
        self.calls += 1
        self.snapshot_dir, self.prompt, self.effort = snapshot_dir, prompt_text, effort
        self.index = (snapshot_dir / CONTEXT_DIR_NAME / FILE_INDEX_NAME).read_text(encoding="utf-8")
        return ReviewResult(ok=True, output_text=self.text.replace("@SNAP@", str(snapshot_dir)), output_format="json",
                            exit_code=0, model_calls=0, usage=None)


def _publish(transport, req_id="REQ-1", package=None):
    package = package or make_package_zip(req_id)
    sha = hashlib.sha256(package).hexdigest()
    req = request_md(request_id=req_id, package_sha256=sha, package_size=len(package))
    ready = ready_md(hashlib.sha256(req.encode("utf-8")).hexdigest(), sha, request_id=req_id)
    transport.push_file(f"{REMOTE_ROOT}/requests/{req_id}/REQUEST.md", req.encode("utf-8"))
    transport.push_file(f"{REMOTE_ROOT}/requests/{req_id}/READY.md", ready.encode("utf-8"))
    transport.push_file("/SKILL-COLLAB/packages/test.zip", package)


def _scan(transport, store, runner, tmp_path, policy=None):
    return run_scan_cycle(transport, store, policy or _policy(), runner, True,
                          snapshot_root=tmp_path / "snap", review_run_dir=tmp_path / "runs", remote_root=REMOTE_ROOT)


def test_prompt_names_the_snapshot_context_index_and_efficiency_rules(transport, store, tmp_path):
    runner = RecordingRunner()
    _publish(transport)
    _scan(transport, store, runner, tmp_path)
    assert runner.calls == 1
    p = runner.prompt
    assert str(runner.snapshot_dir) in p                              # absolute location is stated
    assert f"{CONTEXT_DIR_NAME}/{FILE_INDEX_NAME}" in p and "verified" in p
    assert "parallel" in p and "at most once" in p and "never by an absolute path" in p
    assert "CLAUDE.md" in runner.index                                # the package's own file is indexed
    assert CONTEXT_DIR_NAME not in runner.index                       # trusted context is not listed as package


def test_effort_from_the_tier_reaches_the_runner_and_the_audit_log(transport, store, tmp_path):
    runner = RecordingRunner()
    _publish(transport)
    _scan(transport, store, runner, tmp_path)
    assert runner.effort == "medium"
    detail = json.loads([e for e in store.recent_events(50) if e[1] == "REVIEW_DISPATCHED"][0][3])
    assert detail["effort"] == "medium"


def test_local_paths_are_removed_from_the_published_answer(transport, store, tmp_path):
    runner = RecordingRunner(text="Found it in @SNAP@\\src\\a.py and also @SNAP@/src/b.py")
    _publish(transport)
    _scan(transport, store, runner, tmp_path)
    review, _ = transport.download(f"{REMOTE_ROOT}/reviews/REQ-1/REVIEW_RESULT_1.md")
    body = review.decode("utf-8")
    assert "<snapshot>" in body and str(runner.snapshot_dir) not in body and str(tmp_path) not in body


def test_redact_helper_handles_both_separators(tmp_path):
    p = tmp_path / "snap" / "k"
    text = f"{p}\\x and {str(p).replace(chr(92), '/')}/y"
    assert _redact_local_paths(text, p) == "<snapshot>\\x and <snapshot>/y"


def test_file_index_lists_sizes_sorted_and_skips_context(tmp_path):
    (tmp_path / "b.txt").write_text("12345")
    (tmp_path / "a").mkdir()
    (tmp_path / "a" / "c.py").write_text("x")
    (tmp_path / CONTEXT_DIR_NAME).mkdir()
    (tmp_path / CONTEXT_DIR_NAME / "k.md").write_text("zzz")
    lines = _file_index(tmp_path).splitlines()
    assert lines[0].startswith("# 2 package files, 6 bytes")
    assert [l.split()[-1] for l in lines[1:]] == ["a/c.py", "b.txt"]


def test_template_problem_ends_job_failed_without_a_model_call(transport, store, tmp_path, monkeypatch):
    from skill_collab_watcher import orchestrator
    monkeypatch.setattr(orchestrator, "_PROMPT_TEMPLATE_PATH", tmp_path / "missing.md")
    runner = RecordingRunner()
    _publish(transport)
    _scan(transport, store, runner, tmp_path)
    assert runner.calls == 0
    assert len(store.jobs_in_states([JobState.FAILED])) == 1 and store.jobs_in_states([JobState.CLAIMED]) == []
