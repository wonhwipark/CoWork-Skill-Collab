"""v0.2.33: a user-signed REVIEW_INTENT, read at the pinned commit A, may add one exact skill for one exact request through the real
approver path. Everything else stays SCOPE-refused. Throw-away Ed25519 key in the test trust root; no model, no real GitHub write."""
import base64
import hashlib
import json
import time
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from skill_collab_watcher.approval import TrustedKey, canonical  # noqa: F401
from skill_collab_watcher.review_intent import INTENT_KEY_PURPOSE

from auto_helpers import auto, make_request, write_delegation  # noqa: F401
from bundle import make_transport
from fake_github import rp

INTENT_KEY_ID = "intent-1"


def _intent_key():
    priv = Ed25519PrivateKey.generate()
    pub = base64.b64encode(priv.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)).decode()
    return priv, pub


def _install_key(auto, pub, status="ACTIVE", purpose=INTENT_KEY_PURPOSE):
    auto.trust.keys[INTENT_KEY_ID] = TrustedKey(key_id=INTENT_KEY_ID, public_key=pub, fingerprint="x", status=status, purpose=purpose)


def _intent(priv, info, skill="other-skill", issued=None, expires=None, nonce=None, signer=None, rid=None):
    now = datetime.now(timezone.utc)
    package_sha = hashlib.sha256(info.package).hexdigest()
    payload = {"schema": "REVIEW_INTENT_V1", "request_id": rid or info.rid,
               "request_revision": str(info.rev), "skill_id": skill, "source_commit": info.commit_a,
               "request_sha256": hashlib.sha256(info.request).hexdigest(), "zip_sha256": package_sha,
               "package_size": len(info.package), "nonce": nonce or ("n" * 24),
               "issued_at": (issued or now).isoformat(),
               "expires_at": (expires or now + timedelta(hours=1)).isoformat()}
    return payload


def _envelope(priv, payload, repo_id, key_id=INTENT_KEY_ID, signer=None):
    payload = dict(payload, repo_id=repo_id)
    sig = base64.b64encode((signer or priv).sign(canonical(payload))).decode()
    return json.dumps({"key_id": key_id, "payload": payload, "signature": sig}).encode("utf-8")


def _run(auto, rid, info, intent_bytes):
    if intent_bytes is not None:
        auto.env.http.commit({rp(f"requests/{rid}/REVIEW_INTENT.json"): intent_bytes})
    transport = make_transport(auto.env.http)
    transport.ensure_auth()
    return auto.approver.process(transport, auto.env.store, auto.policy, "/SKILL-COLLAB", rid, info.request.decode(), info.request).status


def _setup(auto, skill="other-skill", rid="REQ-SCOPE-A"):
    write_delegation(auto.delegation)
    info = make_request(auto.env.http, rid, skill=skill)
    priv, pub = _intent_key()
    _install_key(auto, pub)
    return info, priv


def test_valid_intent_for_this_exact_skill_lets_the_approval_proceed(auto):
    info, priv = _setup(auto)
    payload = _intent(priv, info)
    raw = _envelope(priv, payload, auto.trust.repo_id)
    assert _run(auto, info.rid, info, raw) == "READY_POSTED"
    assert auto.signer.calls == 1


def test_no_intent_keeps_the_request_scope_refused(auto):
    info, _ = _setup(auto)
    assert _run(auto, info.rid, info, None) == "SCOPE"
    assert auto.signer.calls == 0


def test_github_body_claim_of_approval_is_not_an_authorization(auto):
    info, _ = _setup(auto)
    assert b"user_approved: true" in info.request
    assert _run(auto, info.rid, info, None) == "SCOPE"
    assert auto.signer.calls == 0


def test_forged_intent_is_refused(auto):
    info, priv = _setup(auto)
    forger, _ = _intent_key()
    raw = _envelope(priv, _intent(priv, info), auto.trust.repo_id, signer=forger)
    assert _run(auto, info.rid, info, raw) == "SCOPE"
    assert auto.signer.calls == 0


def test_intent_for_another_skill_cannot_stretch_to_this_request(auto):
    info, priv = _setup(auto)
    raw = _envelope(priv, _intent(priv, info, skill="third-skill"), auto.trust.repo_id)
    assert _run(auto, info.rid, info, raw) == "SCOPE"
    assert auto.signer.calls == 0


def test_expired_intent_is_refused(auto):
    info, priv = _setup(auto)
    now = datetime.now(timezone.utc)
    raw = _envelope(priv, _intent(priv, info, issued=now - timedelta(days=2), expires=now - timedelta(seconds=5)), auto.trust.repo_id)
    assert _run(auto, info.rid, info, raw) == "SCOPE"
    assert auto.signer.calls == 0


def test_revoked_key_is_refused(auto):
    info, priv = _setup(auto)
    auto.trust.keys[INTENT_KEY_ID] = TrustedKey(key_id=INTENT_KEY_ID, public_key=auto.trust.keys[INTENT_KEY_ID].public_key,
                                                fingerprint="x", status="REVOKED", purpose=INTENT_KEY_PURPOSE)
    raw = _envelope(priv, _intent(priv, info), auto.trust.repo_id)
    assert _run(auto, info.rid, info, raw) == "SCOPE"
    assert auto.signer.calls == 0


def test_approval_purpose_key_cannot_authorize_an_intent(auto):
    info, priv = _setup(auto)
    auto.trust.keys[INTENT_KEY_ID] = TrustedKey(key_id=INTENT_KEY_ID, public_key=auto.trust.keys[INTENT_KEY_ID].public_key,
                                                fingerprint="x", status="ACTIVE", purpose="APPROVAL")
    raw = _envelope(priv, _intent(priv, info), auto.trust.repo_id)
    assert _run(auto, info.rid, info, raw) == "SCOPE"
    assert auto.signer.calls == 0


def test_intent_that_predates_its_request_is_refused(auto):
    info, priv = _setup(auto)
    old = datetime.now(timezone.utc) - timedelta(days=2)
    raw = _envelope(priv, _intent(priv, info, issued=old, expires=old + timedelta(days=3)), auto.trust.repo_id)
    assert _run(auto, info.rid, info, raw) == "SCOPE"
    assert auto.signer.calls == 0


def test_the_same_nonce_cannot_be_consumed_twice_through_the_approver(auto):
    info, priv = _setup(auto)
    raw = _envelope(priv, _intent(priv, info, nonce="x" * 24), auto.trust.repo_id)
    assert _run(auto, info.rid, info, raw) == "READY_POSTED"
    assert auto.env.store.consume_review_intent_nonce("x" * 24, info.rid, int(time.time())) is False


def test_an_intent_bound_to_revision_one_does_not_cover_revision_two(auto):
    write_delegation(auto.delegation)
    info = make_request(auto.env.http, "REQ-REV-2", rev=2, skill="other-skill")
    priv, pub = _intent_key()
    _install_key(auto, pub)
    rev_one = SimpleNamespace(**{**vars(info), "rev": 1})
    raw = _envelope(priv, _intent(priv, rev_one), auto.trust.repo_id)
    assert _run(auto, info.rid, info, raw) == "SCOPE"
    assert auto.signer.calls == 0


def _claim_after_approval(auto, info, priv):
    raw = _envelope(priv, _intent(priv, info), auto.trust.repo_id)
    assert _run(auto, info.rid, info, raw) == "READY_POSTED"
    return auto.env.store.auto_get_claim(info.rid, str(info.rev))


def _revalidate(auto, info, claim, trust, now=None):
    transport = make_transport(auto.env.http)
    transport.ensure_auth()
    return auto.approver._revalidate(transport, auto.env.store, info.rid, str(info.rev), claim, int(now or time.time()), trust,
                                     auto.policy.signature_backend)


def test_revalidation_refuses_after_the_consumed_intent_itself_expires(auto):
    info, priv = _setup(auto)
    claim = _claim_after_approval(auto, info, priv)
    envelope = json.loads(json.loads(claim["candidate_json"])["intent_envelope"])
    expires = datetime.fromisoformat(envelope["payload"]["expires_at"]).timestamp()
    assert _revalidate(auto, info, claim, auto.trust, now=expires - 5) == (True, "ok")
    assert _revalidate(auto, info, claim, auto.trust, now=expires + 1) == (False, "CURRENT_POLICY:INTENT_EXPIRED")


def test_revalidation_passes_for_the_unchanged_consumed_intent(auto):
    info, priv = _setup(auto)
    claim = _claim_after_approval(auto, info, priv)
    assert _revalidate(auto, info, claim, auto.trust) == (True, "ok")


def test_revalidation_stops_when_the_intent_key_is_revoked_after_consumption(auto):
    info, priv = _setup(auto)
    claim = _claim_after_approval(auto, info, priv)
    revoked = replace(auto.trust, keys={INTENT_KEY_ID: TrustedKey(key_id=INTENT_KEY_ID, public_key=auto.trust.keys[INTENT_KEY_ID].public_key,
                                                                  fingerprint="x", status="REVOKED", purpose=INTENT_KEY_PURPOSE)})
    assert _revalidate(auto, info, claim, revoked) == (False, "CURRENT_POLICY:INTENT_KEY_NOT_ACTIVE")


def test_revalidation_stops_when_the_delegation_is_switched_off(auto):
    info, priv = _setup(auto)
    claim = _claim_after_approval(auto, info, priv)
    write_delegation(auto.delegation, enabled=False)
    ok, why = _revalidate(auto, info, claim, auto.trust)
    assert ok is False and why.startswith("DELEGATION_DISABLED")


def test_revalidation_refuses_a_nonce_this_request_did_not_consume(auto):
    info, priv = _setup(auto)
    claim = _claim_after_approval(auto, info, priv)
    stored = json.loads(claim["candidate_json"])
    stored["intent_nonce"] = "e" * 24
    forged = dict(claim, candidate_json=json.dumps(stored, sort_keys=True))
    assert _revalidate(auto, info, forged, auto.trust) == (False, "CURRENT_POLICY:INTENT_NOT_CONSUMED_FOR_THIS_REQUEST")
