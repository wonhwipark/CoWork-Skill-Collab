"""v0.2.34: the release manifest lists exactly the files shipped in this candidate, with their real sizes and SHA-256 values.
The manifest itself is the only self-excluded file. No model, no network."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SELF = "docs/RELEASE_MANIFEST.json"


def _shipped():
    out = {}
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT).as_posix()
        if rel == SELF or ".venv" in path.parts or "__pycache__" in path.parts or ".pytest_cache" in path.parts or path.suffix == ".pyc":
            continue
        out[rel] = path.read_bytes()
    return out


def test_manifest_version_matches_the_package():
    manifest = json.loads((ROOT / SELF).read_text(encoding="utf-8"))
    assert manifest["version"] == "0.2.35"
    assert manifest["self_excluded_path"] == SELF


def test_every_listed_file_has_the_recorded_size_and_hash():
    manifest = json.loads((ROOT / SELF).read_text(encoding="utf-8"))
    for entry in manifest["files"]:
        data = (ROOT / entry["path"]).read_bytes()
        assert len(data) == entry["bytes"], entry["path"]
        assert hashlib.sha256(data).hexdigest() == entry["sha256"], entry["path"]


def test_no_shipped_file_is_missing_from_the_manifest_and_no_listed_file_is_missing():
    manifest = json.loads((ROOT / SELF).read_text(encoding="utf-8"))
    listed = {entry["path"] for entry in manifest["files"]}
    shipped = set(_shipped())
    assert listed == shipped, (sorted(shipped - listed), sorted(listed - shipped))
    assert manifest["file_count"] == len(listed)
