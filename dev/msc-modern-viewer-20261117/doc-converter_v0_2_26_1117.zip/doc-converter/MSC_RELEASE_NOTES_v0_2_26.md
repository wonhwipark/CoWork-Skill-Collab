# doc-converter 0.2.26

- MSC HTML을 네이비 상단바·출처 카드·반응형 화면·배율 표시·폭 맞춤·100% 초기화·단계 선택/카드로 개선.
- 기존 spec의 source revision·MSC 종류·참여자·표시 메시지·설명만 표시. 미확인/중복 단계는 이동 비활성화.
- `msc-package`·MSC HTML 요청의 기존 action 라우팅 보완. `PROCEDURE_FEATURE` opt-in 및 SVG 성공 조건 유지.
- 원본 SVG 내장·외부 네트워크 의존 없음·CSP 스크립트 해시·기존 3인자 함수 호출 호환 유지.
- Knowledge 게시·호스트 설치·HTML 호스팅 설정을 자동 수행하지 않음.
