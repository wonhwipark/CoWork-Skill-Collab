import argparse
import json
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import msc_tool
from msc_b_viewer import phase_button_report


def _spec():
    return {"schema":"doc-converter/msc-spec/v1","kind":"AS_IS","title":"Synthetic",
            "participants":[{"id":"L1","label":"L1"},{"id":"RF","label":"RF"}],
            "steps":[{"type":"divider","label":"INIT"},
                     {"type":"message","id":"S1","from":"L1","to":"RF",
                      "label":"INIT_REQ","evidence_status":"CODE_CONFIRMED"}]}


def _fake_render(puml, svg, timeout=60):
    Path(svg).write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 300">'
                         '<text x="60" y="140">INIT</text></svg>', encoding="utf-8")
    return {"ok": True, "status": "READY"}


def _run(names, mode="PROCEDURE_FEATURE"):
    with tempfile.TemporaryDirectory() as t:
        root = Path(t)
        pkg = root / "pkg.json"
        pkg.write_text(json.dumps({"schema":"doc-converter/msc-package/v1","issue_id":"SYNTHETIC",
                                   "view_mode":mode,"diagrams":[{"name":n,"spec":_spec()} for n in names]}),encoding="utf-8")
        ns=argparse.Namespace(input=str(pkg),output_dir=str(root/"out"),overwrite=False,
                              allow_unrendered=False,timeout=5,json=True,view_mode=mode)
        with patch.object(msc_tool, "_render_puml",side_effect=_fake_render):
            status=msc_tool.cmd_package(ns)
        mf=root/"out"/"MSC_MANIFEST.json"
        return status,json.loads(mf.read_text(encoding="utf-8")),root/"out"


def test_case_only_names_hard_fail(capsys):
    code,man,_=_run(["Init","init"])
    assert code != 0
    assert any(e["code"]=="DIAGRAM_NAME_DUPLICATE" for e in man["package_errors"])


def test_nfc_nfd_stability(capsys):
    import unicodedata
    a="한글초기화"
    b=unicodedata.normalize("NFD",a)
    code1,man1,_=_run([a])
    code2,man2,_=_run([b])
    assert code1 == code2 == 0
    assert man1["diagrams"][0]["name"] == man2["diagrams"][0]["name"]
    code3,man3,_=_run([a,b])
    assert code3 != 0
    assert any(e["code"]=="DIAGRAM_NAME_DUPLICATE" for e in man3["package_errors"])


def test_policy_has_both_actions():
    policy=json.loads((Path(__file__).resolve().parents[1]/"skillsilent"/"policy.json").read_text(encoding="utf-8"))
    for name in ("msc-package","msc-scenario-build"):
        flags=policy["actions"][name]
        assert "--view-mode" in flags["allowed_flags"]
        assert "--view-mode" in flags["value_flags"]


def test_phase_missing_and_ambiguous_are_visible(tmp_path):
    svg=tmp_path/"sample.svg"
    svg.write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">'
                   '<text y="20">INIT</text><text y="50">INIT</text></svg>',encoding="utf-8")
    report=phase_button_report(svg,["INIT","UNKNOWN"])
    assert report["requested"]==2 and report["enabled"]==0
    assert {r["reason"] for r in report["disabled"]}=={"AMBIGUOUS","NOT_FOUND"}
