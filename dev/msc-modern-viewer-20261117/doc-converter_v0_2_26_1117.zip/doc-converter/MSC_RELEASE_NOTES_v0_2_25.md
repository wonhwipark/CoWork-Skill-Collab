# doc-converter 0.2.25

MSC Procedure/Feature HTML+SVG B viewer and name collision fixes. Synthetic regression and direct CLI validation; no automatic Knowledge publication.
