"""Standalone MSC viewer. Presentation only: no publication or fact inference."""
from __future__ import annotations

import base64
import hashlib
from html import escape
import math
from pathlib import Path
import re
import xml.etree.ElementTree as ET


def _read_svg(svg_path: Path) -> tuple[bytes, ET.Element, list[float]]:
    data = Path(svg_path).read_bytes()
    if len(data) > 2 * 1024 * 1024:
        raise ValueError("B_VIEW_SVG_TOO_LARGE")
    root = ET.fromstring(data)
    if root.tag.rsplit("}", 1)[-1].lower() != "svg":
        raise ValueError("B_VIEW_NOT_SVG")
    try:
        box = [float(x) for x in re.split(r"[ ,]+", root.attrib["viewBox"].strip()) if x]
    except (KeyError, ValueError) as exc:
        raise ValueError("B_VIEW_VIEWBOX_MISSING") from exc
    if len(box) != 4 or not all(math.isfinite(x) for x in box) or box[2] <= 0 or box[3] <= 0:
        raise ValueError("B_VIEW_VIEWBOX_INVALID")
    return data, root, box


def _phase_rows(root: ET.Element, phases: list[str]) -> list[dict]:
    rows = []
    for phase in dict.fromkeys(phases):
        matches = []
        for element in root.iter():
            if element.tag.rsplit("}", 1)[-1].lower() != "text":
                continue
            label = "".join(element.itertext()).strip()
            if label == phase or label.strip("= ").strip() == phase:
                try:
                    y = float(element.attrib["y"])
                except (ValueError, KeyError):
                    continue
                if math.isfinite(y):
                    matches.append(y)
        row = {"phase": phase}
        if len(matches) == 1:
            row["y"] = matches[0]
        else:
            row["reason"] = "AMBIGUOUS" if len(matches) > 1 else "NOT_FOUND"
        rows.append(row)
    return rows


_CSS = """
:root{color-scheme:light;--bg:#f4f7fb;--paper:#fff;--ink:#172d48;--muted:#60738b;--line:#dbe4ef;--blue:#285cb6}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.65 system-ui,-apple-system,"Malgun Gothic",sans-serif}
button,select,a{font:inherit}button,select,a.button{min-height:42px}button{cursor:pointer}button:disabled{cursor:default;opacity:.65}
button:focus-visible,a:focus-visible,select:focus-visible,.viewport:focus-visible{outline:3px solid #3a72c3;outline-offset:3px}
.top{background:#142d4a;color:white}.topin{max-width:1260px;margin:auto;padding:14px 24px;display:flex;justify-content:space-between;align-items:center;gap:16px}
.brand{font-weight:850;letter-spacing:.05em}.topnote{color:#bfd1e8;font-size:12px}.wrap{max-width:1260px;margin:auto;padding:25px 24px 45px;min-width:0}
h1,h2,p{margin:0}h1{font-size:clamp(25px,3.3vw,37px);line-height:1.3;letter-spacing:-.04em;overflow-wrap:anywhere}h2{font-size:18px;letter-spacing:-.02em}
.eyebrow{font-size:11px;color:#4770aa;font-weight:850;letter-spacing:.12em;margin-bottom:8px}.sub{color:var(--muted);margin-top:9px;overflow-wrap:anywhere}
.hero{display:flex;justify-content:space-between;align-items:flex-start;gap:20px}.actions{display:flex;gap:8px;flex-wrap:wrap}.button,button,select{border:1px solid #cddbeb;border-radius:9px;padding:8px 12px;background:white;color:var(--ink)}
a.button{text-decoration:none;white-space:nowrap;font-size:13px;font-weight:650}.tag{display:inline-block;font-size:11px;padding:3px 8px;border-radius:6px;background:#e8f1ff;color:#325d97;font-weight:750}
.meta{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin:20px 0 0}.meta div,.surface{border:1px solid var(--line);border-radius:12px;background:var(--paper);padding:14px 16px;min-width:0}
.meta dt{color:var(--muted);font-size:11px}.meta dd{margin:3px 0 0;font-size:14px;font-weight:750;overflow-wrap:anywhere}.surface{margin-top:16px}.surface p{margin-top:8px;white-space:pre-wrap;overflow-wrap:anywhere}
.viewer-shell{border:1px solid var(--line);border-radius:13px;background:var(--paper);overflow:hidden;margin-top:18px;min-width:0}.toolbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:13px;border-bottom:1px solid var(--line)}
.toolbar button,.toolbar select{min-height:38px;padding:6px 11px;font-size:13px}.toolbar select{max-width:100%;min-width:0}.pct{font-variant-numeric:tabular-nums;min-width:52px;text-align:center;font-size:12px;font-weight:800;color:#3f628c}
.viewport{height:70vh;min-height:300px;overflow:auto;overscroll-behavior:contain;background:white;position:relative}.viewport img{display:block;max-width:none;height:auto}
.viewer-foot{border-top:1px solid var(--line);padding:9px 14px;display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;color:var(--muted);font-size:11px}
.controls{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px}.controls button{font-size:12px;text-align:left;overflow-wrap:anywhere;max-width:100%}.phase[aria-current="step"]{border-color:#6290ce;background:#edf4ff;color:#285cb6}
.stage-notes{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px;margin-top:16px}.stage-note{border:1px solid var(--line);border-radius:11px;background:white;padding:15px;min-width:0;overflow-wrap:anywhere}
.stage-note strong{display:block;font-size:13px}.stage-note p{font-size:12px;color:var(--muted);margin-top:6px}.stage-note[aria-current="step"]{border-color:#6290ce;box-shadow:inset 0 3px 0 #285cb6;background:#f4f8ff}
.footer{margin-top:23px;color:var(--muted);font-size:11px;border-top:1px solid var(--line);padding-top:15px}.sr-only{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0)}
@media(max-width:760px){.topin{padding:12px 15px}.topnote{font-size:11px}.wrap{padding:19px 14px 32px}.hero{display:block}.actions{margin-top:14px}.meta{grid-template-columns:repeat(2,minmax(0,1fr))}.toolbar{gap:6px;padding:10px}.toolbar select{flex:1 1 180px}.viewport{height:65vh}.stage-notes{grid-template-columns:1fr}.viewer-foot{display:block}}
@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto!important}}
""".strip()


_JS = """(() => {
'use strict';
const pane=document.getElementById('pane'),img=document.getElementById('msc'),pct=document.getElementById('pct'),stage=document.getElementById('stage'),state=document.getElementById('viewstate');
const width=Number(img.dataset.vbw);let zoom=1;
const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
function markPhase(key){
document.querySelectorAll('[data-phase-index]').forEach(el=>el.setAttribute('aria-current',el.dataset.phaseIndex===key?'step':'false'));
if(stage)stage.value=key;
}
function applyZoom(next){
const top=pane.scrollTop/zoom,left=pane.scrollLeft/zoom;zoom=Math.max(.2,Math.min(3,next));
img.style.width=(width*zoom)+'px';pct.textContent=Math.round(zoom*100)+'%';pane.scrollTop=top*zoom;pane.scrollLeft=left*zoom;
const selected=stage&&stage.selectedOptions[0];
state.textContent=(selected&&selected.dataset.y?selected.textContent+' · ':'')+'배율 '+pct.textContent;
}
function goPhase(option){
if(!option||!option.dataset.y)return;
markPhase(option.value);const ratio=img.getBoundingClientRect().width/width;
pane.scrollTo({top:Math.max(0,Number(option.dataset.y)*ratio-24),behavior:reduced?'auto':'smooth'});
state.textContent=option.textContent+' · '+pct.textContent;
}
document.querySelectorAll('[data-zoom]').forEach(b=>b.addEventListener('click',()=>{
const action=b.dataset.zoom;applyZoom(action==='in'?zoom+.2:action==='out'?zoom-.2:action==='fit'?pane.clientWidth/width:1);
}));
document.querySelectorAll('button.phase').forEach(b=>b.addEventListener('click',()=>{
if(stage)goPhase([...stage.options].find(o=>o.value===b.dataset.phaseIndex));
}));
if(stage)stage.addEventListener('change',()=>goPhase(stage.selectedOptions[0]));
applyZoom(1);
})();"""


def build_html(svg_path: Path, title: str, phases: list[str], *, context: dict | None = None) -> str:
    """Build modern B HTML from SVG and existing spec metadata; keep old callers valid."""
    data, root, box = _read_svg(svg_path)
    rows = _phase_rows(root, phases)
    context = context if isinstance(context, dict) else {}
    safe_title = escape(str(title))
    source = context.get("source_provenance")
    revision = source.get("revision") if isinstance(source, dict) else None
    kind = str(context.get("kind") or "미확인").upper()
    kind = {"AS_IS": "AS-IS", "TO_BE": "TO-BE", "PROBLEM": "문제 구간"}.get(kind, kind)
    participants = context.get("participants")
    steps = context.get("steps")
    participant_count = str(len(participants)) + "개" if isinstance(participants, list) else "미제공"
    message_count = (str(sum(isinstance(x, dict) and str(x.get("type", "message")).lower() == "message"
                            and x.get("visible", True) is not False for x in steps)) + "개"
                     if isinstance(steps, list) else "미제공")
    metadata = "".join('<div><dt>' + label + '</dt><dd>' + escape(str(value)) + '</dd></div>'
                       for label, value in [("소스 기준", revision or "미확인"), ("MSC 종류", kind),
                                            ("참여자", participant_count), ("메시지", message_count)])
    description = context.get("explanation") or context.get("caption")
    summary = ('<section class="surface"><h2>흐름 설명</h2><p>' + escape(description) + '</p></section>'
               if isinstance(description, str) and description.strip() else "")
    controls, options, cards = [], [], []
    for index, row in enumerate(rows):
        phase = escape(str(row["phase"]))
        if "y" in row:
            y = str(row["y"] - box[1])
            controls.append('<button class="phase" data-y="' + y + '" data-phase-index="' + str(index) + '" aria-current="false">' + phase + '</button>')
            options.append('<option value="' + str(index) + '" data-y="' + y + '">' + str(index + 1) + ' · ' + phase + '</option>')
            note = "위 단계 버튼을 누르면 그림의 해당 위치로 이동해요."
        else:
            note = "같은 단계명이 여러 곳에 있어 위치 확인이 필요해요." if row["reason"] == "AMBIGUOUS" else "그림에서 단계 위치를 확인하지 못했어요."
            controls.append('<button class="phase-unavailable" disabled title="' + note + '">' + phase + ' · 위치 미확인</button>')
        cards.append('<section class="stage-note" data-phase-index="' + str(index) + '" aria-current="false"><strong>' + f'{index + 1:02d}' + ' · ' + phase + '</strong><p>' + note + '</p></section>')
    phase_select = ('<label class="sr-only" for="stage">MSC 단계 이동</label><select id="stage" aria-label="MSC 단계 이동"><option value="">단계 선택</option>' + "".join(options) + '</select>'
                    if options else "")
    phase_controls = '<div class="controls" aria-label="단계별 이동">' + "".join(controls) + '</div>' if rows else ""
    stage_cards = '<div class="stage-notes">' + "".join(cards) + '</div>' if rows else ""
    encoded = base64.b64encode(data).decode("ascii")
    data_url = "data:image/svg+xml;base64," + encoded
    digest = base64.b64encode(hashlib.sha256(_JS.encode("utf-8")).digest()).decode("ascii")
    return ('<!doctype html><html lang="ko"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; img-src data:; style-src \'unsafe-inline\'; script-src \'sha256-' + digest + '\'; connect-src \'none\'; font-src \'none\'; base-uri \'none\'; form-action \'none\'">'
            '<title>' + safe_title + ' | MSC 뷰어</title><style>' + _CSS + '</style></head><body>'
            '<header class="top"><div class="topin"><div class="brand">MSC VIEWER</div><span class="topnote">그림과 보기 기능을 한 파일에</span></div></header>'
            '<main class="wrap"><div class="hero"><div><div class="eyebrow">PROCEDURE / FEATURE · MSC</div><h1>' + safe_title + '</h1>'
            '<p class="sub">단계별 흐름을 살펴보고, 확대해서 메시지를 확인해요.</p></div><div class="actions"><a class="button" download="msc.svg" href="' + data_url + '">SVG 원본 다운로드</a></div></div>'
            '<dl class="meta">' + metadata + '</dl>' + summary +
            '<section class="viewer-shell" aria-label="MSC 확대·스크롤 뷰어"><div class="toolbar">'
            '<button id="minus" data-zoom="out" aria-label="MSC 축소">− 축소</button><span class="pct" id="pct" aria-live="polite">100%</span>'
            '<button id="plus" data-zoom="in" aria-label="MSC 확대">+ 확대</button><button data-zoom="reset">100%</button><button data-zoom="fit">폭에 맞춤</button>' + phase_select +
            '</div><div class="viewport" id="pane" tabindex="0" role="region" aria-label="MSC 그림 · 가로·세로 스크롤"><img id="msc" alt="' + escape(str(title), quote=True) +
            '" data-vbw="' + str(box[2]) + '" src="' + data_url + '"></div><div class="viewer-foot"><span id="viewstate" aria-live="polite">배율 100%</span>'
            '<span>가로·세로 스크롤 · 배율 20–300%</span></div></section>' + phase_controls + stage_cards +
            '<footer class="footer">원본 SVG를 담은 열람본이에요. 코드 동작·원격 게시·검증 상태는 연결된 분석 문서의 근거를 확인해 주세요.</footer>'
            '</main><script>' + _JS + '</script></body></html>')


def phase_button_report(svg_path: Path, phases: list[str]) -> dict:
    """Retain the manifest contract for matched, missing, and ambiguous phases."""
    _, root, _ = _read_svg(svg_path)
    rows = _phase_rows(root, phases)
    return {"requested": len(rows), "enabled": sum("y" in row for row in rows),
            "disabled": [{"phase": row["phase"], "reason": row["reason"]} for row in rows if "reason" in row]}


